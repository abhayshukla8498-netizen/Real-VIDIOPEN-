package com.example

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.decode.VideoFrameDecoder
import com.example.di.AppContainer
import com.example.di.AppContainerImpl
import com.startapp.sdk.adsbase.StartAppSDK
import timber.log.Timber

class NovaPlayApplication : Application(), ImageLoaderFactory {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainerImpl(this)
        
        // Initialize Start.io SDK
        try {
            StartAppSDK.init(this, "206371143", false)
            try {
                StartAppSDK.enableReturnAds(false)
            } catch (ex: Exception) {
                Timber.w(ex, "StartAppSDK.enableReturnAds failed")
            }
            try {
                com.startapp.sdk.adsbase.StartAppAd.disableSplash()
            } catch (ex: Exception) {
                Timber.w(ex, "StartAppAd.disableSplash failed")
            }
            Timber.d("StartAppSDK: Initialized successfully with App ID 206371143")
            // Preload Interstitial Ads for in-app user interactions
            com.example.utils.StartAppInterstitialHelper.initAndLoad(this)
        } catch (e: Exception) {
            Timber.e(e, "StartAppSDK: Failed to initialize")
        }
        
        // Initialize Timber logging
        Timber.plant(Timber.DebugTree())
        Timber.d("NovaPlayApplication: Initialized successfully with manual DI and Timber")
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .components {
                add(com.example.utils.VideoThumbnailFetcher.Factory(this@NovaPlayApplication))
                add(VideoFrameDecoder.Factory())
            }
            .memoryCache {
                coil.memory.MemoryCache.Builder(this)
                    .maxSizePercent(0.20)
                    .build()
            }
            .diskCache {
                coil.disk.DiskCache.Builder()
                    .directory(cacheDir.resolve("image_cache"))
                    .maxSizeBytes(150L * 1024L * 1024L)
                    .build()
            }
            .allowRgb565(true)
            .crossfade(true)
            .build()
    }
}
