package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.GlassWhite
import com.example.ui.theme.GlassWhiteBorder
import com.example.ui.theme.RoyalPurple

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderWidth: Dp = 1.dp,
    glowing: Boolean = false,
    content: @Composable BoxScope.() -> Unit
) {
    val scaleSource = remember { MutableInteractionSource() }
    val isPressed by scaleSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 400f),
        label = "PressScale"
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = if (glowing) 16.dp else 4.dp,
                shape = RoundedCornerShape(cornerRadius),
                clip = false,
                ambientColor = if (glowing) ElectricBlue else Color.Black,
                spotColor = if (glowing) RoyalPurple else Color.Black
            )
            .border(
                width = borderWidth,
                brush = Brush.linearGradient(
                    colors = listOf(
                        GlassWhiteBorder,
                        Color.White.copy(alpha = 0.05f),
                        RoyalPurple.copy(alpha = 0.15f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.08f),
                        Color.White.copy(alpha = 0.02f)
                    )
                )
            )
            .background(GlassWhite)
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 20.dp,
    text: String,
    icon: @Composable (() -> Unit)? = null,
    glowColor: Color = ElectricBlue
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "ButtonPress"
    )

    Box(
        modifier = modifier
            .shadow(
                elevation = if (isPressed) 8.dp else 12.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = glowColor,
                spotColor = RoyalPurple
            )
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.25f),
                        glowColor.copy(alpha = 0.4f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.12f),
                        glowColor.copy(alpha = 0.18f)
                    )
                )
            )
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = glowColor),
                onClick = onClick
            )
            .padding(horizontal = 24.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (icon != null) {
                icon()
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                style = TextStyle(
                    shadow = Shadow(
                        color = glowColor.copy(alpha = 0.6f),
                        offset = Offset(0f, 0f),
                        blurRadius = 8f
                    )
                )
            )
        }
    }
}

@Composable
fun GlowText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    glowColor: Color = ElectricBlue,
    fontSize: androidx.compose.ui.unit.TextUnit = 16.sp,
    fontWeight: FontWeight = FontWeight.Normal,
    style: TextStyle = TextStyle.Default
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontSize = fontSize,
        fontWeight = fontWeight,
        style = style.copy(
            shadow = Shadow(
                color = glowColor.copy(alpha = 0.8f),
                offset = Offset(0f, 0f),
                blurRadius = 12f
            )
        )
    )
}

fun Modifier.springPress(
    onPress: () -> Unit = {},
    onRelease: () -> Unit = {}
) = pointerInput(Unit) {
    detectTapGestures(
        onPress = {
            onPress()
            try {
                awaitRelease()
            } finally {
                onRelease()
            }
        }
    )
}
