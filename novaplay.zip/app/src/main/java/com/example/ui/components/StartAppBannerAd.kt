package com.example.ui.components

import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.startapp.sdk.ads.banner.Banner
import timber.log.Timber

@Composable
fun StartAppBannerAd(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(60.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color.White.copy(alpha = 0.05f)),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxWidth(),
            factory = { context ->
                FrameLayout(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    try {
                        val banner = Banner(context).apply {
                            layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                                FrameLayout.LayoutParams.WRAP_CONTENT,
                                Gravity.CENTER
                            )
                        }
                        addView(banner)
                        
                        // Try to load ad if method exists, else rely on auto-load on attach
                        try {
                            val loadAdMethod = banner.javaClass.getMethod("loadAd")
                            loadAdMethod.invoke(banner)
                            Timber.d("StartAppBannerAd: loadAd() called via reflection")
                        } catch (e: Exception) {
                            Timber.d("StartAppBannerAd: loadAd() method not found or failed, relying on auto-load")
                        }
                        
                        Timber.d("StartAppBannerAd: Banner instantiated successfully")
                    } catch (e: Exception) {
                        Timber.e(e, "StartAppBannerAd: Failed to instantiate Banner")
                    }
                }
            },
            update = { _ ->
                // No dynamic update needed
            }
        )
    }
}
