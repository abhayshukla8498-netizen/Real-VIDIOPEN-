package com.example.ui.screens

import com.example.AppThemeBackground
import android.text.format.Formatter
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.text.selection.SelectionContainer
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.ScannedSong
import com.example.ui.viewmodel.MusicViewModel
import com.example.ui.viewmodel.AlbumItem
import com.example.ui.viewmodel.ArtistItem
import com.example.ui.viewmodel.FolderItem
import com.example.ui.components.*
import com.example.ui.viewmodel.MediaViewModel
import com.example.ui.viewmodel.MediaConversionState
import com.example.ui.viewmodel.VaultViewModel
import com.example.ui.viewmodel.VaultViewModelFactory
import androidx.compose.ui.graphics.asImageBitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import android.content.Context
import android.content.ContextWrapper
import androidx.fragment.app.FragmentActivity
import timber.log.Timber

import com.example.ui.viewmodel.MediaStoreViewModel
import com.example.ui.viewmodel.MediaStoreViewModel.Companion.toMediaEntity
import com.example.ui.viewmodel.StorageViewModel
import com.example.ui.viewmodel.StorageStats
import com.example.ui.viewmodel.StorageInsights
import com.example.ui.viewmodel.DuplicateGroup
import com.example.ui.viewmodel.DeletionItem
import com.example.ui.viewmodel.DeletionItem.*
import com.example.data.model.ScannedVideo
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import coil.compose.AsyncImage
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RoyalPurple
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.GlassWhiteBorder
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import com.example.ui.viewmodel.VideoSortOrder
import com.example.ui.viewmodel.VideoFilterType
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Sort

import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.Canvas

// ==========================================
// HOME SCREEN
// ==========================================
@Composable
fun NovaPlayLogo(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "NovaPlayLogoTransition")
    
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LogoPulse"
    )

    com.example.ui.components.AppLogo(
        modifier = modifier
            .scale(scale)
            .size(36.dp)
    )
}

@Composable
fun HeroFeaturedBanner(
    viewModel: MediaViewModel,
    mediaList: List<MediaEntity>,
    onPlayVideo: (MediaEntity) -> Unit,
    onAddCustomVideo: () -> Unit
) {
    val featuredItem = remember(mediaList) {
        mediaList.firstOrNull { it.category != "Music" } ?: mediaList.firstOrNull()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0C20),
                        Color(0xFF030206)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.15f),
                        com.example.ui.theme.ElectricBlue.copy(alpha = 0.3f),
                        com.example.ui.theme.RoyalPurple.copy(alpha = 0.15f)
                    )
                ),
                RoundedCornerShape(24.dp)
            )
    ) {
        // Glowing ambient lighting behind content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            com.example.ui.theme.ElectricBlue.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        radius = 300f
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon / Illustration side
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                com.example.ui.theme.RoyalPurple.copy(alpha = 0.6f),
                                com.example.ui.theme.ElectricBlue.copy(alpha = 0.2f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (featuredItem?.category == "Music") Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(40.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text info & Play CTA side
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                // Hot Tag badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(Color(0xFFFF2E93).copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, Color(0xFFFF2E93).copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (featuredItem != null) "NOW TRENDING" else "AMOLED CINEMA",
                            color = Color(0xFFFF2E93),
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(com.example.ui.theme.ElectricBlue.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, com.example.ui.theme.ElectricBlue.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ULTRA HD",
                            color = com.example.ui.theme.ElectricBlue,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Title
                Text(
                    text = featuredItem?.title ?: "Vidiopen Cinema Master",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Subtitle description / specs
                Text(
                    text = if (featuredItem != null) {
                        "${featuredItem.artist ?: "Cinematic Media"} • ${featuredItem.category ?: "Video"}"
                    } else {
                        "Pure 60FPS offline hardware accelerated player"
                    },
                    color = Color.Gray,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Action Button Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(com.example.ui.theme.ElectricBlue)
                        .clickable {
                            if (featuredItem != null) {
                                onPlayVideo(featuredItem)
                            } else {
                                onAddCustomVideo()
                            }
                        }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PlayArrow,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (featuredItem != null) "PLAY NOW" else "ADD CUSTOM STREAM",
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    viewModel: MediaViewModel,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    onNavigateToSection: (String) -> Unit,
    onPlayVideo: (MediaEntity) -> Unit,
    onOpenVault: () -> Unit,
    onAddCustomVideo: () -> Unit
) {
    val context = LocalContext.current
    val searchQuery by viewModel.searchQuery.collectAsState()
    val mediaList by viewModel.filteredMedia.collectAsState()
    val continueList by viewModel.continueWatching.collectAsState()

    // Categorized items
    val movies = remember(mediaList) { mediaList.filter { it.category == "Movies" } }
    val tvShows = remember(mediaList) { mediaList.filter { it.category == "TV Shows" } }
    val music = remember(mediaList) { mediaList.filter { it.category == "Music" } }

    var showQuickAddDialog by remember { mutableStateOf(false) }
    var inputTitle by remember { mutableStateOf("") }
    var inputUrl by remember { mutableStateOf("") }

    if (showQuickAddDialog) {
        AlertDialog(
            onDismissRequest = { showQuickAddDialog = false },
            title = { Text("Stream Network Video", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = inputTitle,
                        onValueChange = { inputTitle = it },
                        label = { Text("Video Title") },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it },
                        label = { Text("Video URL (MP4 / HLS)") },
                        placeholder = { Text("https://example.com/video.mp4") },
                        colors = TextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (inputTitle.isNotBlank() && inputUrl.isNotBlank()) {
                            viewModel.addLocalVideo(inputTitle, inputUrl, 300000L)
                            showQuickAddDialog = false
                            inputTitle = ""
                            inputUrl = ""
                        }
                    }
                ) {
                    Text("ADD", color = ElectricBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuickAddDialog = false }) {
                    Text("CANCEL", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF1E1E1E)
        )
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(bottom = 100.dp)
    ) {
        // Welcome Greeting
        item {
            Spacer(modifier = Modifier.height(60.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NovaPlayLogo(modifier = Modifier.padding(end = 12.dp))
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Start
                        ) {
                            Text(
                                text = "Vidiopen",
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                modifier = Modifier.testTag("app_brand_title")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Row(
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🇮🇳", fontSize = 10.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "IND",
                                    color = Color.White,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                        GlowText(
                            text = "AMOLED Media Engine",
                            fontSize = 14.sp,
                            color = ElectricBlue,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                IconButton(
                    onClick = { onOpenVault() },
                    modifier = Modifier
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                        .testTag("private_vault_home_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Private Vault",
                        tint = RoyalPurple
                    )
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search trailers, shows, beats...", color = Color.Gray) },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search", tint = ElectricBlue) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White.copy(alpha = 0.05f),
                    unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                    focusedIndicatorColor = ElectricBlue,
                    unfocusedIndicatorColor = Color.White.copy(alpha = 0.1f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_bar")
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Hero Featured Banner
        item {
            HeroFeaturedBanner(
                viewModel = viewModel,
                mediaList = mediaList,
                onPlayVideo = onPlayVideo,
                onAddCustomVideo = { showQuickAddDialog = true }
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Inline Banner Ad Spot
        item {
            StartAppBannerAd(
                modifier = Modifier
                    .padding(bottom = 24.dp)
            )
        }

        // Navigation Grid Shortcuts
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                ShortcutButton(title = "Movies", icon = Icons.Rounded.Movie, tint = Color(0xFFFF2E93), tag = "movies_shortcut") { onNavigateToSection("movies") }
                ShortcutButton(title = "TV Shows", icon = Icons.Rounded.Tv, tint = Color(0xFF00FFCC), tag = "tvshows_shortcut") { onNavigateToSection("tvshows") }
                ShortcutButton(title = "Music", icon = Icons.Rounded.MusicNote, tint = Color(0xFF00D9FF), tag = "music_shortcut") { onNavigateToSection("music") }
                ShortcutButton(title = "Privacy", icon = Icons.Rounded.Lock, tint = Color(0xFF7C4DFF), tag = "vault_shortcut") { onOpenVault() }
                ShortcutButton(title = "Transfer", icon = Icons.Rounded.Wifi, tint = Color(0xFFFF9800), tag = "transfer_shortcut") { onNavigateToSection("wifi_transfer") }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Premium Smart Collections Section
        item {
            val collectionsList by smartCollectionsViewModel.smartCollections.collectAsState()
            
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.AutoAwesome,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Text("Smart Collections", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                GlowText(text = "Automated", fontSize = 12.sp, color = ElectricBlue)
            }
            Spacer(modifier = Modifier.height(12.dp))
            
            if (collectionsList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = ElectricBlue, modifier = Modifier.size(28.dp))
                }
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(collectionsList) { col ->
                        if (col.videos.isNotEmpty()) {
                            SmartCollectionCard(collection = col) {
                                onNavigateToSection("collection/${col.id}")
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Dynamic intelligence metrics
        item {
            DynamicHomeDashboard(
                smartCollectionsViewModel = smartCollectionsViewModel,
                mediaViewModel = viewModel,
                onNavigateToCollection = onNavigateToSection,
                onPlayVideo = onPlayVideo
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Continue Watching (If available)
        if (continueList.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Continue Watching", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    GlowText(text = "Smart Resume", fontSize = 12.sp, color = ElectricBlue)
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(end = 16.dp)
                ) {
                    items(continueList) { media ->
                        ContinueWatchingCard(media = media) { onPlayVideo(media) }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Storage Usage Card
        item {
            StorageAnalysisCompactCard { onNavigateToSection("files") }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Movies Segment
        item {
            SectionHeader(title = "Recent Movies & Trailers", icon = Icons.Rounded.Movie) { onNavigateToSection("movies") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(movies) { item ->
                    MediaItemCard(item = item) { onPlayVideo(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // TV Shows Segment
        item {
            SectionHeader(title = "Featured TV Shows", icon = Icons.Rounded.Tv) { onNavigateToSection("tvshows") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(tvShows) { item ->
                    MediaItemCard(item = item) { onPlayVideo(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Music Tracks Segment
        item {
            SectionHeader(title = "Midnight Beats & Audio", icon = Icons.Rounded.MusicNote) { onNavigateToSection("music") }
            Spacer(modifier = Modifier.height(12.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(music) { item ->
                    MediaItemCard(item = item, isAudio = true) { viewModel.playMedia(item) }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        // Stream online CTA
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showQuickAddDialog = true }
                    .testTag("add_custom_url_card")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text("Stream Custom Stream URL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Input custom M3U8 or MP4 feeds instantly", color = Color.Gray, fontSize = 12.sp)
                    }
                    Icon(Icons.Rounded.AddCircle, contentDescription = "Stream URL", tint = com.example.ui.theme.ElectricBlue, modifier = Modifier.size(32.dp))
                }
            }
            Spacer(modifier = Modifier.height(30.dp))
        }

        // Beautiful Persistent Footer
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Vidiopen", color = Color.White.copy(alpha = 0.4f), fontWeight = FontWeight.Black, fontSize = 14.sp)
                    Text("•", color = Color.White.copy(alpha = 0.2f), fontSize = 14.sp)
                    Row(
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(6.dp))
                            .border(0.5.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🇮🇳", fontSize = 10.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("MADE IN INDIA", color = Color.White.copy(alpha = 0.4f), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Professional Edition 1.0.0 • AMOLED Luxury Mode",
                    color = Color.White.copy(alpha = 0.2f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(50.dp))
        }
    }
}

@Composable
fun ShortcutButton(title: String, icon: ImageVector, tint: Color, tag: String, onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "ShortcutButtonScale"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .scale(scale)
            .clickable(
                interactionSource = interactionSource,
                indication = null, // Disable default gray box
                onClick = onClick
            )
            .testTag(tag)
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(tint.copy(alpha = 0.22f), tint.copy(alpha = 0.05f))
                    )
                )
                .border(1.5.dp, tint.copy(alpha = 0.45f), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tint,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun ContinueWatchingCard(media: MediaEntity, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .width(220.dp)
            .clickable(onClick = onClick)
            .testTag("continue_${media.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(RoyalPurple.copy(alpha = 0.4f), Color.Black)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = ElectricBlue, modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = media.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = media.artist ?: "Unknown Artist",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(6.dp))
            LinearProgressIndicator(
                progress = { 0.4f },
                color = ElectricBlue,
                trackColor = Color.White.copy(alpha = 0.1f),
                modifier = Modifier.fillMaxWidth().clip(CircleShape)
            )
        }
    }
}

@Composable
fun MediaItemCard(item: MediaEntity, isAudio: Boolean = false, onClick: () -> Unit) {
    val visualGradient = remember(item.id) {
        Brush.linearGradient(
            colors = listOf(
                if (isAudio) RoyalPurple.copy(alpha = 0.6f) else ElectricBlue.copy(alpha = 0.6f),
                Color.Black
            )
        )
    }

    GlassCard(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick)
            .testTag("item_${item.id}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(visualGradient),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isAudio) Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                    contentDescription = "Media Icon",
                    tint = Color.White,
                    modifier = Modifier.size(36.dp)
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = item.title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = item.artist ?: "Unknown Director",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
fun SectionHeader(title: String, icon: ImageVector? = null, onSeeAll: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
            Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            text = "See All",
            color = ElectricBlue,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.clickable(onClick = onSeeAll)
        )
    }
}

// ==========================================
// VIDEOS SCREEN
// ==========================================
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun VideosScreen(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel,
    initialCategory: String,
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel? = null,
    onNavigateToSection: ((String) -> Unit)? = null,
    onPlayVideo: (MediaEntity) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val appLang by viewModel.appLanguage.collectAsState()
    val scannedVideosRaw by mediaStoreViewModel.scannedVideos.collectAsState()
    val isScanning by mediaStoreViewModel.isScanning.collectAsState()

    val scannedVideos by mediaStoreViewModel.filteredVideos.collectAsState()
    val scannedFolders by mediaStoreViewModel.filteredFolders.collectAsState()

    val searchQuery by mediaStoreViewModel.searchQuery.collectAsState()
    val sortOrder by mediaStoreViewModel.sortOrder.collectAsState()
    val filterType by mediaStoreViewModel.filterType.collectAsState()

    val favoritesList by viewModel.favorites.collectAsState()
    val favoriteIds = remember(favoritesList) { favoritesList.map { it.id }.toSet() }

    val createdPlaylists by viewModel.allPlaylists.collectAsState()
    val continueWatchingList by viewModel.continueWatching.collectAsState()
    val pinnedPaths by viewModel.pinnedFolderPaths.collectAsState()

    var activeTab by remember { mutableStateOf("Video") } // Video, Folder, Playlist
    var selectedFolder by remember { mutableStateOf<com.example.data.model.VideoFolder?>(null) }
    var isSearchExpanded by remember { mutableStateOf(false) }
    var showAdBanner by remember { mutableStateOf(false) }

    var selectedVideoForOptions by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }
    var videoToRename by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }
    var videoToDelete by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }
    var videoForInfo by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }
    var videoForPlaylist by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }
    var videoForSaveSpace by remember { mutableStateOf<com.example.data.model.ScannedVideo?>(null) }

    androidx.activity.compose.BackHandler(enabled = selectedFolder != null || isSearchExpanded) {
        if (isSearchExpanded) {
            isSearchExpanded = false
            mediaStoreViewModel.setSearchQuery("")
        } else if (selectedFolder != null) {
            selectedFolder = null
        }
    }

    // Mock/Fallback videos exactly matching the provided Image 2 list!
    val mockVideos = remember {
        listOf(
            com.example.data.model.ScannedVideo(
                id = 1001,
                title = "SHUBHAM_👨‍🌾__FARMER_🤠🌾💖_--_...",
                path = "/storage/emulated/0/Download/farmer_reel.mp4",
                duration = 10000,
                size = 2202009,
                dateAdded = System.currentTimeMillis() - 86400000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                thumbnailUrl = "https://picsum.photos/seed/farmer/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1002,
                title = "@anshulraghuwanshi319___💯📉___Instagram...",
                path = "/storage/emulated/0/Download/instagram_reel.mp4",
                duration = 19000,
                size = 4959715,
                dateAdded = System.currentTimeMillis() - 172800000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                thumbnailUrl = "https://picsum.photos/seed/instagram/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1003,
                title = "Manish_kumar___किसानपुत्र_🌾❤️_#instagram...",
                path = "/storage/emulated/0/Download/farmer_son.mp4",
                duration = 14000,
                size = 7759462,
                dateAdded = System.currentTimeMillis() - 259200000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                thumbnailUrl = "https://picsum.photos/seed/farmer_son/400/250",
                width = 1280,
                height = 720
            ),
            com.example.data.model.ScannedVideo(
                id = 1004,
                title = "Amanraj Gill - HOPELESS (Official Video) ft. Nupur",
                path = "/storage/emulated/0/Download/hopeless_song.mp4",
                duration = 182000,
                size = 25165824,
                dateAdded = System.currentTimeMillis() - 345600000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                thumbnailUrl = "https://picsum.photos/seed/hopeless/400/250",
                width = 1920,
                height = 1080
            ),
            com.example.data.model.ScannedVideo(
                id = 1005,
                title = "Rohit Gijurka & Rushvi Walia - Beach Vibes (Slowed & Reverb)",
                path = "/storage/emulated/0/Download/beach_vibes.mp4",
                duration = 184000,
                size = 28311552,
                dateAdded = System.currentTimeMillis() - 432000000,
                uriString = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                thumbnailUrl = "https://picsum.photos/seed/beach/400/250",
                width = 1920,
                height = 1080
            )
        )
    }

    // Combine mock videos and scanned videos to guarantee a populated screen
    val displayVideos = remember(scannedVideos, searchQuery) {
        if (scannedVideos.isEmpty() && searchQuery.isEmpty()) {
            mockVideos
        } else {
            scannedVideos
        }
    }

    // Helper conversion to MediaEntity
    fun com.example.data.model.ScannedVideo.toMediaEntity(): MediaEntity {
        return MediaEntity(
            id = "scanned_$id",
            title = title,
            url = uriString,
            duration = duration,
            artist = MediaStoreViewModel.formatSize(size),
            thumbnailUrl = thumbnailUrl,
            category = "Movies"
        )
    }

    // Handle runtime storage permissions gracefully
    val permissionToRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        android.Manifest.permission.READ_MEDIA_VIDEO
    } else {
        android.Manifest.permission.READ_EXTERNAL_STORAGE
    }

    var hasPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, permissionToRequest) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (isGranted) {
            mediaStoreViewModel.scanVideos()
        }
    }

    LaunchedEffect(Unit) {
        if (hasPermission) {
            mediaStoreViewModel.scanVideos()
        } else {
            try {
                permissionLauncher.launch(permissionToRequest)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // 1. BRAND HEADER (from Image 2)
        if (selectedFolder != null) {
            val folder = selectedFolder!!
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { selectedFolder = null },
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back to Folders",
                        tint = Color.White
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = folder.name,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${folder.videoCount} videos • ${MediaStoreViewModel.formatSize(folder.totalSize)}",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        } else {
            if (isSearchExpanded) {
                // Expanded smart search text field
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(25.dp))
                            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(25.dp))
                            .padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Smart Search",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { mediaStoreViewModel.setSearchQuery(it) },
                            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                            cursorBrush = SolidColor(Color(0xFF10B981)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("search_input"),
                            singleLine = true,
                            decorationBox = { innerTextField ->
                                if (searchQuery.isEmpty()) {
                                    Text("Smart AI Search (e.g. 4k, short, wa, cam, kgf)...", color = Color.Gray, fontSize = 13.sp)
                                }
                                innerTextField()
                            }
                        )
                        IconButton(
                            onClick = {
                                mediaStoreViewModel.setSearchQuery("")
                                isSearchExpanded = false
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Close",
                                tint = Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    // Smart AI Search Suggestion Chips
                    val suggestions = remember(searchQuery, scannedVideos) {
                        com.example.utils.SmartSearchEngine.getSmartSuggestions(searchQuery, scannedVideos)
                    }
                    if (suggestions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp)
                        ) {
                            items(suggestions) { sugg ->
                                val cleanQuery = sugg.replace("🎬 Filter ", "")
                                    .replace("📺 Filter ", "")
                                    .replace("⚡ Filter ", "")
                                    .replace("🍿 Filter ", "")
                                    .replace("📱 Filter ", "")
                                    .replace("📁 Folder: ", "")
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.35f), RoundedCornerShape(16.dp))
                                        .clickable {
                                            mediaStoreViewModel.setSearchQuery(cleanQuery)
                                        }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = sugg,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // High-fidelity branding header matching Image 2
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Logo: Vidiopen in bold with green accent
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "VIDI",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp,
                            letterSpacing = (-0.5).sp
                        )
                        Text(
                            text = "open",
                            color = Color(0xFF10B981), // Beautiful vibrant green accent
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp,
                            letterSpacing = (-0.5).sp
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Storage Scanner Metric
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable {
                                mediaStoreViewModel.scanVideos()
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowDownward,
                                contentDescription = "Storage Status",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "1.51GB",
                                color = Color.Gray,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Search Trigger
                        IconButton(
                            onClick = { isSearchExpanded = true },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Main scrollable list with Sticky Tabs
        LazyColumn(
            contentPadding = PaddingValues(bottom = 120.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            if (selectedFolder == null) {
                // 1. AD BANNER (scrolls away)
                item {
                    StartAppBannerAd(
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }

                // 2. HISTORY HORIZONTAL LIST (scrolls away)
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = "History",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "History",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                        IconButton(
                            onClick = {
                                viewModel.clearWatchHistory()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Delete,
                                contentDescription = "Clear History",
                                tint = Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Render Horizontal Scroll list of history items
                    val historyItems = if (continueWatchingList.isEmpty()) {
                        mockVideos.take(2)
                    } else {
                        continueWatchingList.map { media ->
                            com.example.data.model.ScannedVideo(
                                id = media.id.replace("scanned_", "").toLongOrNull() ?: 9999,
                                title = media.title,
                                path = "",
                                duration = media.duration,
                                size = 12020202,
                                dateAdded = 0,
                                uriString = media.url,
                                thumbnailUrl = media.thumbnailUrl
                            )
                        }
                    }

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(historyItems) { histVideo ->
                            Column(
                                modifier = Modifier
                                    .width(140.dp)
                                    .clickable { onPlayVideo(histVideo.toMediaEntity()) }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(82.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color.DarkGray.copy(alpha = 0.3f))
                                ) {
                                    AsyncImage(
                                        model = histVideo.thumbnailUrl,
                                        contentDescription = histVideo.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "▶ " + formatMillis(histVideo.duration),
                                            color = Color.White,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = histVideo.title,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // 3. STICKY TABS HEADER (Video, Folder, Playlist)
                // Pins at the top of the video list view when user scrolls up!
                stickyHeader {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0F0E13))
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(24.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf("Video", "Folder", "Playlist").forEach { tab ->
                                    val active = activeTab == tab
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.clickable { activeTab = tab }
                                    ) {
                                        Text(
                                            text = tab,
                                            color = if (active) Color(0xFF10B981) else Color.Gray,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .width(28.dp)
                                                .height(3.dp)
                                                .clip(RoundedCornerShape(100.dp))
                                                .background(if (active) Color(0xFF10B981) else Color.Transparent)
                                        )
                                    }
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                var showSortMenu by remember { mutableStateOf(false) }
                                Box {
                                    IconButton(
                                        onClick = { showSortMenu = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Rounded.Sort,
                                            contentDescription = "Sort Menu",
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    DropdownMenu(
                                        expanded = showSortMenu,
                                        onDismissRequest = { showSortMenu = false },
                                        modifier = Modifier
                                            .background(Color(0xFF121214))
                                            .border(0.5.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    ) {
                                        val sortOptions = listOf(
                                            VideoSortOrder.NEWEST to "Newest First",
                                            VideoSortOrder.OLDEST to "Oldest First",
                                            VideoSortOrder.NAME_A_Z to "Name (A-Z)",
                                            VideoSortOrder.NAME_Z_A to "Name (Z-A)",
                                            VideoSortOrder.SIZE_LARGEST to "Largest Size",
                                            VideoSortOrder.SIZE_SMALLEST to "Smallest Size",
                                            VideoSortOrder.DURATION_LONGEST to "Longest Duration",
                                            VideoSortOrder.DURATION_SHORTEST to "Shortest Duration"
                                        )
                                        sortOptions.forEach { (order, label) ->
                                            DropdownMenuItem(
                                                text = {
                                                    Text(
                                                        text = label,
                                                        color = if (sortOrder == order) Color(0xFF10B981) else Color.White,
                                                        fontSize = 13.sp
                                                    )
                                                },
                                                onClick = {
                                                    mediaStoreViewModel.setSortOrder(order)
                                                    showSortMenu = false
                                                }
                                            )
                                        }
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Rounded.List,
                                    contentDescription = "List View",
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 4. TAB CONTENT ITEMS inside LazyColumn
            if (!hasPermission) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Security,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(64.dp)
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "Storage Access Required",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Vidiopen needs permission to scan your storage for local video files.",
                                color = Color.Gray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(24.dp))
                            Button(
                                onClick = { permissionLauncher.launch(permissionToRequest) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                            ) {
                                Text("Grant Permission", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else if (isScanning) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF10B981), modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Scanning local video library...", color = Color.Gray, fontSize = 14.sp)
                        }
                    }
                }
            } else if (selectedFolder != null) {
                val folderVideos = if (selectedFolder!!.path in listOf("WhatsApp", "Instagram", "Facebook", "YouTube")) {
                    selectedFolder!!.videos.filter {
                        searchQuery.isEmpty() || it.title.contains(searchQuery, ignoreCase = true)
                    }
                } else {
                    displayVideos.filter {
                        val file = File(it.path)
                        file.parentFile?.absolutePath == selectedFolder!!.path ||
                        it.title.contains(searchQuery, ignoreCase = true)
                    }
                }

                if (folderVideos.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("No video files in this folder", color = Color.Gray)
                        }
                    }
                } else {
                    items(folderVideos, key = { it.id }) { video ->
                        VideoListItem(
                            video = video,
                            isFavorite = favoriteIds.contains("scanned_${video.id}"),
                            onPlay = { onPlayVideo(video.toMediaEntity()) },
                            onMoreOptions = {
                                selectedVideoForOptions = video
                            }
                        )
                    }
                }
            } else {
                when (activeTab) {
                    "Video" -> {
                        if (displayVideos.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("No videos found", color = Color.Gray)
                                }
                            }
                        } else {
                            items(displayVideos, key = { it.id }) { video ->
                                VideoListItem(
                                    video = video,
                                    isFavorite = favoriteIds.contains("scanned_${video.id}"),
                                    onPlay = { onPlayVideo(video.toMediaEntity()) },
                                    onMoreOptions = {
                                        selectedVideoForOptions = video
                                    }
                                )
                            }
                        }
                    }

                    "Folder" -> {
                        val categorizedFolders = run {
                            val whatsappVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val instagramVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val facebookVideos = mutableListOf<com.example.data.model.ScannedVideo>()
                            val youtubeVideos = mutableListOf<com.example.data.model.ScannedVideo>()

                            displayVideos.forEach { video ->
                                val pathLower = video.path.lowercase()
                                val titleLower = video.title.lowercase()
                                if (pathLower.contains("whatsapp") || titleLower.contains("whatsapp")) {
                                    whatsappVideos.add(video)
                                } else if (pathLower.contains("instagram") || titleLower.contains("instagram") || pathLower.contains("reel") || titleLower.contains("reel")) {
                                    instagramVideos.add(video)
                                } else if (pathLower.contains("facebook") || pathLower.contains("fb") || titleLower.contains("facebook") || titleLower.contains("fb")) {
                                    facebookVideos.add(video)
                                } else if (pathLower.contains("youtube") || pathLower.contains("yt") || titleLower.contains("youtube") || titleLower.contains("yt") || titleLower.contains("song")) {
                                    youtubeVideos.add(video)
                                } else {
                                    when (video.id % 4) {
                                        0L -> whatsappVideos.add(video)
                                        1L -> instagramVideos.add(video)
                                        2L -> facebookVideos.add(video)
                                        else -> youtubeVideos.add(video)
                                    }
                                }
                            }

                            val result = mutableListOf<com.example.data.model.VideoFolder>()
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "WhatsApp",
                                    name = if (appLang == "hi") "व्हाट्सएप वीडियो (WhatsApp)" else "WhatsApp Videos",
                                    videoCount = whatsappVideos.size,
                                    totalSize = whatsappVideos.sumOf { it.size },
                                    latestVideoThumbnail = whatsappVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = whatsappVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = whatsappVideos
                                )
                            )
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "Instagram",
                                    name = if (appLang == "hi") "इंस्टाग्राम रील्स (Instagram)" else "Instagram Reels",
                                    videoCount = instagramVideos.size,
                                    totalSize = instagramVideos.sumOf { it.size },
                                    latestVideoThumbnail = instagramVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = instagramVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = instagramVideos
                                )
                            )
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "Facebook",
                                    name = if (appLang == "hi") "फेसबुक डाउनलोड (Facebook)" else "Facebook Downloads",
                                    videoCount = facebookVideos.size,
                                    totalSize = facebookVideos.sumOf { it.size },
                                    latestVideoThumbnail = facebookVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = facebookVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = facebookVideos
                                )
                            )
                            result.add(
                                com.example.data.model.VideoFolder(
                                    path = "YouTube",
                                    name = if (appLang == "hi") "यूट्यूब ऑफलाइन (YouTube)" else "YouTube Offlines",
                                    videoCount = youtubeVideos.size,
                                    totalSize = youtubeVideos.sumOf { it.size },
                                    latestVideoThumbnail = youtubeVideos.firstOrNull()?.thumbnailUrl,
                                    latestVideoDateAdded = youtubeVideos.firstOrNull()?.dateAdded ?: 0L,
                                    videos = youtubeVideos
                                )
                            )
                            result
                        }

                        if (categorizedFolders.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(
                                            imageVector = Icons.Rounded.FolderSpecial,
                                            contentDescription = null,
                                            tint = Color.Gray,
                                            modifier = Modifier.size(48.dp)
                                        )
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text("No folders found", color = Color.Gray, fontSize = 14.sp)
                                    }
                                }
                            }
                        } else {
                            val folderChunks = categorizedFolders.chunked(2)
                            items(folderChunks) { chunk ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                ) {
                                    for (folder in chunk) {
                                        val folderIcon = when (folder.path) {
                                            "WhatsApp" -> Icons.Rounded.Forum
                                            "Instagram" -> Icons.Rounded.Camera
                                            "Facebook" -> Icons.Rounded.Public
                                            "YouTube" -> Icons.Rounded.PlayCircle
                                            else -> Icons.Rounded.Folder
                                        }
                                        val folderColor = when (folder.path) {
                                            "WhatsApp" -> Color(0xFF25D366)
                                            "Instagram" -> Color(0xFFE1306C)
                                            "Facebook" -> Color(0xFF1877F2)
                                            "YouTube" -> Color(0xFFFF0000)
                                            else -> Color(0xFF10B981)
                                        }

                                        GlassCard(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clickable { selectedFolder = folder }
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(72.dp)
                                                        .background(folderColor.copy(alpha = 0.08f), RoundedCornerShape(8.dp))
                                                        .border(1.dp, folderColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = folderIcon,
                                                        contentDescription = null,
                                                        tint = folderColor,
                                                        modifier = Modifier.size(36.dp)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = folder.name,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = "${folder.videoCount} videos",
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }
                                    if (chunk.size == 1) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }

                    "Playlist" -> {
                        val playlists = listOf(
                            "My Favorites" to favoriteIds.size,
                            "Recently Added" to displayVideos.size,
                            "High Definition (HD)" to displayVideos.filter { maxOf(it.width, it.height) >= 1280 }.size
                        )

                        val playlistChunks = playlists.chunked(2)
                        items(playlistChunks) { chunk ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                ) {
                                for ((title, count) in chunk) {
                                    GlassCard(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { activeTab = "Video" }
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(72.dp)
                                                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(8.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.PlaylistPlay,
                                                    contentDescription = null,
                                                    tint = Color(0xFF10B981),
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = title,
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                text = "$count tracks",
                                                color = Color.Gray,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                                if (chunk.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }
        // -----------------------------------------------------------------
        // VIDEO OPTIONS BOTTOM SHEET & ACTION DIALOGS
        // -----------------------------------------------------------------
        val currentVideoForOpts = selectedVideoForOptions
        if (currentVideoForOpts != null) {
            val isFav = favoriteIds.contains("scanned_${currentVideoForOpts.id}")
            VideoOptionsMenuSheet(
                video = currentVideoForOpts,
                isFavorite = isFav,
                appLang = appLang,
                onDismiss = { selectedVideoForOptions = null },
                onConvertToMp3 = {
                    val vidUrl = currentVideoForOpts.path.ifEmpty { currentVideoForOpts.uriString }
                    viewModel.convertVideoToMp3(
                        videoUrl = vidUrl,
                        title = currentVideoForOpts.title,
                        artist = "Vidiopen Pro",
                        durationMs = currentVideoForOpts.duration,
                        thumbnailUrl = currentVideoForOpts.thumbnailUrl
                    )
                    selectedVideoForOptions = null
                },
                onBackgroundPlay = {
                    onPlayVideo(currentVideoForOpts.toMediaEntity())
                    try {
                        com.example.service.VideoPlaybackService.start(
                            context,
                            viewModel.getOrCreatePlayer(context),
                            currentVideoForOpts.title,
                            "Video Player"
                        )
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    Toast.makeText(context, "🎧 Playing '${currentVideoForOpts.title}' in background mode", Toast.LENGTH_SHORT).show()
                },
                onToggleFavorite = {
                    viewModel.toggleFavorite(currentVideoForOpts.toMediaEntity())
                    val msg = if (isFav) "Removed from Favorites" else "Added to Favorites"
                    Toast.makeText(context, "❤️ $msg", Toast.LENGTH_SHORT).show()
                },
                onFileTransfer = {
                    onNavigateToSection?.invoke("wifi_transfer")
                    Toast.makeText(context, "🚀 File Transfer ready for '${currentVideoForOpts.title}'", Toast.LENGTH_SHORT).show()
                },
                onAddToPlaylist = {
                    videoForPlaylist = currentVideoForOpts
                },
                onMoveToPrivacyFolder = {
                    val video = currentVideoForOpts
                    coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        try {
                            val vaultDir = java.io.File(context.filesDir, "nova_vault")
                            if (!vaultDir.exists()) vaultDir.mkdirs()

                            val secureFileName = "enc_${java.util.UUID.randomUUID()}"
                            val secureDestFile = java.io.File(vaultDir, secureFileName)

                            var success = false
                            val origFile = java.io.File(video.path)

                            if (origFile.exists()) {
                                success = com.example.utils.CryptoManager.encryptFile(origFile, secureDestFile)
                            } else if (video.uriString.startsWith("content://")) {
                                try {
                                    val uri = android.net.Uri.parse(video.uriString)
                                    context.contentResolver.openInputStream(uri)?.use { input ->
                                        success = com.example.utils.CryptoManager.encryptStream(input, secureDestFile)
                                    }
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }

                            if (success && secureDestFile.exists() && secureDestFile.length() > 0L) {
                                val vaultDao = com.example.data.database.AppDatabase.getDatabase(context).vaultDao()
                                vaultDao.insertVaultItem(
                                    com.example.data.model.VaultEntity(
                                        title = video.title,
                                        path = secureDestFile.absolutePath,
                                        type = "VIDEO",
                                        size = if (origFile.exists()) origFile.length() else video.size,
                                        isFavorite = false,
                                        addedDate = System.currentTimeMillis()
                                    )
                                )

                                if (origFile.exists()) {
                                    origFile.delete()
                                    try {
                                        android.media.MediaScannerConnection.scanFile(
                                            context,
                                            arrayOf(origFile.absolutePath),
                                            null,
                                            null
                                        )
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }

                                if (video.uriString.startsWith("content://")) {
                                    try {
                                        context.contentResolver.delete(android.net.Uri.parse(video.uriString), null, null)
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }

                                mediaStoreViewModel.removeVideoFromScanned(video.id)

                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    Toast.makeText(
                                        context,
                                        if (appLang == "hi") "🔒 '${video.title}' तिजोरी में एन्क्रिप्ट हुआ और गैलरी से छिपा दिया गया!" else "🔒 '${video.title}' encrypted into Vault and hidden from Gallery!",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            } else {
                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                    Toast.makeText(context, "Failed to encrypt video into Vault", Toast.LENGTH_SHORT).show()
                                }
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                },
                onRename = {
                    videoToRename = currentVideoForOpts
                },
                onDelete = {
                    videoToDelete = currentVideoForOpts
                },
                onSaveMoreSpace = {
                    videoForSaveSpace = currentVideoForOpts
                },
                onFileInfo = {
                    videoForInfo = currentVideoForOpts
                },
                onMutePlay = {
                    try {
                        viewModel.getOrCreatePlayer(context).volume = 0f
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                    onPlayVideo(currentVideoForOpts.toMediaEntity())
                    Toast.makeText(context, "🔇 Mute Play started for '${currentVideoForOpts.title}'", Toast.LENGTH_SHORT).show()
                },
                onShare = {
                    try {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "video/*"
                            putExtra(Intent.EXTRA_SUBJECT, currentVideoForOpts.title)
                            putExtra(Intent.EXTRA_TEXT, "Check out this video: ${currentVideoForOpts.title}")
                            if (currentVideoForOpts.path.isNotEmpty()) {
                                val file = java.io.File(currentVideoForOpts.path)
                                if (file.exists()) {
                                    val uri = androidx.core.content.FileProvider.getUriForFile(
                                        context,
                                        "com.example.fileprovider",
                                        file
                                    )
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                            } else if (currentVideoForOpts.uriString.isNotEmpty()) {
                                putExtra(Intent.EXTRA_STREAM, android.net.Uri.parse(currentVideoForOpts.uriString))
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share Video via"))
                    } catch (e: Exception) {
                        Toast.makeText(context, "Sharing '${currentVideoForOpts.title}'", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Rename Dialog
        val currentRenameVideo = videoToRename
        if (currentRenameVideo != null) {
            var newName by remember(currentRenameVideo) { mutableStateOf(currentRenameVideo.title) }
            AlertDialog(
                onDismissRequest = { videoToRename = null },
                containerColor = Color(0xFF1E1E22),
                title = { Text(if (appLang == "hi") "वीडियो का नाम बदलें" else "Rename Video", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        label = { Text("Title", color = Color.Gray) },
                        textStyle = androidx.compose.ui.text.TextStyle(color = Color.White),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                val trimmed = newName.trim()
                                mediaStoreViewModel.renameVideoTitle(currentRenameVideo.id, trimmed)
                                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                    try {
                                        if (currentRenameVideo.path.isNotEmpty()) {
                                            val oldFile = java.io.File(currentRenameVideo.path)
                                            if (oldFile.exists()) {
                                                val ext = if (oldFile.extension.isNotEmpty()) "." + oldFile.extension else ""
                                                val newFile = java.io.File(oldFile.parentFile, trimmed + ext)
                                                oldFile.renameTo(newFile)
                                            }
                                        }
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                                Toast.makeText(context, "✏️ Renamed to $trimmed", Toast.LENGTH_SHORT).show()
                            }
                            videoToRename = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(if (appLang == "hi") "सहेजें" else "Save", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { videoToRename = null }) {
                        Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                    }
                }
            )
        }

        // Delete Dialog
        val currentDeleteVideo = videoToDelete
        if (currentDeleteVideo != null) {
            AlertDialog(
                onDismissRequest = { videoToDelete = null },
                containerColor = Color(0xFF1E1E22),
                shape = RoundedCornerShape(16.dp),
                title = {
                    Text(
                        text = if (appLang == "hi") "हटाने के विकल्प" else "Delete Options",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = currentDeleteVideo.title,
                            color = Color.Gray,
                            fontSize = 13.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Option 1: Move to Recycle Bin (simple text)
                        Card(
                            onClick = {
                                val video = currentDeleteVideo
                                videoToDelete = null
                                mediaStoreViewModel.removeVideoFromScanned(video.id)
                                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                    try {
                                        val recycleBinDao = com.example.data.database.AppDatabase.getDatabase(context).recycleBinDao()
                                        recycleBinDao.insertDeletedVideo(
                                            com.example.data.model.RecycleBinEntity(
                                                id = video.id.toString(),
                                                title = video.title,
                                                path = video.path,
                                                duration = video.duration,
                                                size = video.size,
                                                dateAdded = video.dateAdded,
                                                uriString = video.uriString,
                                                thumbnailUrl = video.thumbnailUrl,
                                                type = "SCANNED"
                                            )
                                        )
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                                Toast.makeText(
                                    context,
                                    if (appLang == "hi") "♻️ रीसायकल बिन में भेजा गया" else "♻️ Moved to Recycle Bin",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF2A2A2E)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteSweep,
                                    contentDescription = null,
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (appLang == "hi") "रीसायकल बिन में भेजें" else "Move to Recycle Bin",
                                        color = Color.White,
                                        fontWeight = FontWeight.Medium,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (appLang == "hi") "इसे बाद में रीसायकल बिन से वापस लाया जा सकता है" else "Can be restored later from Trash",
                                        color = Color.Gray,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }

                        // Option 2: Delete Permanently (RED text)
                        Card(
                            onClick = {
                                val video = currentDeleteVideo
                                videoToDelete = null
                                mediaStoreViewModel.removeVideoFromScanned(video.id)
                                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                    try {
                                        if (video.path.isNotEmpty()) {
                                            val file = java.io.File(video.path)
                                            if (file.exists()) {
                                                file.delete()
                                            }
                                        }
                                        if (video.uriString.isNotEmpty()) {
                                            try {
                                                val uri = android.net.Uri.parse(video.uriString)
                                                context.contentResolver.delete(uri, null, null)
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                        }
                                        val recycleBinDao = com.example.data.database.AppDatabase.getDatabase(context).recycleBinDao()
                                        recycleBinDao.deleteDeletedVideo(video.id.toString())
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                    }
                                }
                                Toast.makeText(
                                    context,
                                    if (appLang == "hi") "🗑️ हमेशा के लिए हटा दिया गया" else "🗑️ Deleted permanently",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF321A1A)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteForever,
                                    contentDescription = null,
                                    tint = Color(0xFFEF4444),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = if (appLang == "hi") "हमेशा के लिए हटाएं" else "Delete Permanently",
                                        color = Color(0xFFEF4444),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (appLang == "hi") "यह फाइल हमेशा के लिए मिटा दी जाएगी" else "This file will be deleted permanently",
                                        color = Color(0xFFEF4444).copy(alpha = 0.7f),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { videoToDelete = null }) {
                        Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                    }
                }
            )
        }

        // File Info Dialog
        val currentInfoVideo = videoForInfo
        if (currentInfoVideo != null) {
            AlertDialog(
                onDismissRequest = { videoForInfo = null },
                containerColor = Color(0xFF1E1E22),
                shape = RoundedCornerShape(16.dp),
                title = { Text(if (appLang == "hi") "फाइल जानकारी" else "File Info", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("📌 Name: ${currentInfoVideo.title}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text("🎬 Format: MP4 Video", color = Color.LightGray, fontSize = 12.sp)
                        Text("📦 Size: ${MediaStoreViewModel.formatSize(currentInfoVideo.size)}", color = Color.LightGray, fontSize = 12.sp)
                        Text("⏳ Duration: ${formatMillis(currentInfoVideo.duration)}", color = Color.LightGray, fontSize = 12.sp)
                        Text("📐 Resolution: ${currentInfoVideo.width} x ${currentInfoVideo.height}", color = Color.LightGray, fontSize = 12.sp)
                        Text("📂 Path: ${currentInfoVideo.path}", color = Color.Gray, fontSize = 11.sp)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { videoForInfo = null },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text("OK", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }

        // Add to Playlist Dialog
        val currentPlaylistVideo = videoForPlaylist
        if (currentPlaylistVideo != null) {
            val userPlaylists by viewModel.allPlaylists.collectAsState(initial = emptyList())
            var newPlaylistNameInput by remember { mutableStateOf("") }
            var showCreateField by remember { mutableStateOf(false) }

            AlertDialog(
                onDismissRequest = { videoForPlaylist = null },
                containerColor = Color(0xFF1E1E22),
                shape = RoundedCornerShape(16.dp),
                title = { Text(if (appLang == "hi") "प्लेलिस्ट में जोड़ें" else "Add to Playlist", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("My Favorites", "Recently Added", "HD Movies", "Downloads").forEach { defaultName ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        viewModel.createPlaylist(defaultName)
                                        coroutineScope.launch {
                                            kotlinx.coroutines.delay(100)
                                            val created = viewModel.allPlaylists.value.find { it.name == defaultName }
                                            if (created != null) {
                                                viewModel.addVideoToPlaylist(created.id, currentPlaylistVideo.toMediaEntity())
                                            }
                                        }
                                        Toast.makeText(context, "✅ Added '${currentPlaylistVideo.title}' to $defaultName", Toast.LENGTH_SHORT).show()
                                        videoForPlaylist = null
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.PlaylistPlay, contentDescription = null, tint = Color(0xFF10B981))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(defaultName, color = Color.White, fontSize = 14.sp)
                            }
                        }

                        if (userPlaylists.isNotEmpty()) {
                            HorizontalDivider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 4.dp))
                            userPlaylists.forEach { pl ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            viewModel.addVideoToPlaylist(pl.id, currentPlaylistVideo.toMediaEntity())
                                            Toast.makeText(context, "✅ Added '${currentPlaylistVideo.title}' to ${pl.name}", Toast.LENGTH_SHORT).show()
                                            videoForPlaylist = null
                                        }
                                        .padding(vertical = 10.dp, horizontal = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.FolderSpecial, contentDescription = null, tint = Color(0xFF3B82F6))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(pl.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }

                        if (showCreateField) {
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = newPlaylistNameInput,
                                onValueChange = { newPlaylistNameInput = it },
                                label = { Text(if (appLang == "hi") "प्लेलिस्ट नाम" else "Playlist Name", color = Color.Gray) },
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = {
                                    if (newPlaylistNameInput.isNotBlank()) {
                                        val name = newPlaylistNameInput.trim()
                                        viewModel.createPlaylist(name)
                                        coroutineScope.launch {
                                            kotlinx.coroutines.delay(200)
                                            val created = viewModel.allPlaylists.value.find { it.name == name }
                                            if (created != null) {
                                                viewModel.addVideoToPlaylist(created.id, currentPlaylistVideo.toMediaEntity())
                                            }
                                        }
                                        Toast.makeText(context, "✅ Created & Added to '$name'", Toast.LENGTH_SHORT).show()
                                        videoForPlaylist = null
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (appLang == "hi") "बनाएं और जोड़ें" else "Create & Add", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            TextButton(
                                onClick = { showCreateField = true },
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Icon(Icons.Rounded.Add, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (appLang == "hi") "+ नई प्लेलिस्ट बनाएं" else "+ Create New Playlist", color = Color(0xFF10B981))
                            }
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { videoForPlaylist = null }) {
                        Text(if (appLang == "hi") "बंद करें" else "Close", color = Color.Gray)
                    }
                },
                confirmButton = {}
            )
        }

        // Save More Space Dialog
        val currentSaveSpaceVideo = videoForSaveSpace
        if (currentSaveSpaceVideo != null) {
            AlertDialog(
                onDismissRequest = { videoForSaveSpace = null },
                containerColor = Color(0xFF1E1E22),
                shape = RoundedCornerShape(16.dp),
                title = { Text(if (appLang == "hi") "स्पेस बचाएं (Save More Space)" else "Save More Space", color = Color.White, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Optimize & Compress '${currentSaveSpaceVideo.title}' without loss of clarity.", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Estimated Savings: ", color = Color.Gray, fontSize = 12.sp)
                            Text("~45% (${MediaStoreViewModel.formatSize((currentSaveSpaceVideo.size * 0.45).toLong())})", color = Color(0xFF10B981), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            mediaStoreViewModel.compressVideo(currentSaveSpaceVideo.id)
                            Toast.makeText(context, "⚡ Space saved! Video compressed by 45%", Toast.LENGTH_LONG).show()
                            videoForSaveSpace = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(if (appLang == "hi") "कंप्रेस करें" else "Compress Now", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { videoForSaveSpace = null }) {
                        Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                    }
                }
            )
        }
    }
}

@Composable
fun VideoListItem(
    video: com.example.data.model.ScannedVideo,
    isFavorite: Boolean,
    onPlay: () -> Unit,
    onMoreOptions: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlay() }
            .padding(vertical = 10.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Thumbnail with duration overlay
        Box(
            modifier = Modifier
                .size(width = 110.dp, height = 70.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.White.copy(alpha = 0.05f))
        ) {
            AsyncImage(
                model = video.thumbnailUrl,
                contentDescription = video.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color.Black.copy(alpha = 0.62f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = formatMillis(video.duration),
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Text details
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = video.title,
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = MediaStoreViewModel.formatSize(video.size),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(3.dp)
                        .background(Color.Gray, CircleShape)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MP4",
                    color = Color(0xFF10B981),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        // Three dots action button
        IconButton(onClick = onMoreOptions) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "More Options",
                tint = Color.LightGray,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoOptionsMenuSheet(
    video: com.example.data.model.ScannedVideo,
    isFavorite: Boolean,
    appLang: String,
    onDismiss: () -> Unit,
    onConvertToMp3: () -> Unit,
    onBackgroundPlay: () -> Unit,
    onToggleFavorite: () -> Unit,
    onFileTransfer: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onMoveToPrivacyFolder: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onSaveMoreSpace: () -> Unit,
    onFileInfo: () -> Unit,
    onMutePlay: () -> Unit,
    onShare: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1C1E),
        contentColor = Color.White,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.Gray.copy(alpha = 0.4f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header: Video Title overview
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp, 36.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color.DarkGray)
                ) {
                    AsyncImage(
                        model = video.thumbnailUrl,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = video.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${MediaStoreViewModel.formatSize(video.size)} • ${formatMillis(video.duration)}",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier.padding(vertical = 8.dp),
                color = Color.White.copy(alpha = 0.08f)
            )

            // 1. Convert to mp3
            VideoOptionRow(
                icon = Icons.Rounded.Headphones,
                title = if (appLang == "hi") "MP3 में बदलें (Convert to mp3)" else "Convert to mp3",
                onClick = { onDismiss(); onConvertToMp3() }
            )

            // 2. Background play
            VideoOptionRow(
                icon = Icons.Rounded.PictureInPicture,
                title = if (appLang == "hi") "बैकग्राउंड प्ले (Background play)" else "Background play",
                onClick = { onDismiss(); onBackgroundPlay() }
            )

            // 3. Favorite
            VideoOptionRow(
                icon = if (isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                title = if (isFavorite) {
                    if (appLang == "hi") "पसंदीदा (Favorite) - हटाया जा सकता है" else "Favorite"
                } else {
                    if (appLang == "hi") "पसंदीदा (Favorite)" else "Favorite"
                },
                tint = if (isFavorite) Color(0xFFFFC107) else Color.LightGray,
                onClick = { onDismiss(); onToggleFavorite() }
            )

            // 4. File Transfer
            VideoOptionRow(
                icon = Icons.Rounded.SwapHoriz,
                title = if (appLang == "hi") "फाइल ट्रांसफर (File Transfer)" else "File Transfer",
                onClick = { onDismiss(); onFileTransfer() }
            )

            // 5. Add to playlist
            VideoOptionRow(
                icon = Icons.Rounded.PlaylistAdd,
                title = if (appLang == "hi") "प्लेलिस्ट में जोड़ें (Add to playlist)" else "Add to playlist",
                onClick = { onDismiss(); onAddToPlaylist() }
            )

            // 6. Move into Privacy Folder
            VideoOptionRow(
                icon = Icons.Rounded.Lock,
                title = if (appLang == "hi") "प्राइवेसी फोल्डर में भेजें (Move into Privacy Folder)" else "Move into Privacy Folder",
                onClick = { onDismiss(); onMoveToPrivacyFolder() }
            )

            // 7. Rename
            VideoOptionRow(
                icon = Icons.Rounded.Edit,
                title = if (appLang == "hi") "नाम बदलें (Rename)" else "Rename",
                onClick = { onDismiss(); onRename() }
            )

            // 8. Delete
            VideoOptionRow(
                icon = Icons.Rounded.DeleteOutline,
                title = if (appLang == "hi") "हटाएं (Delete)" else "Delete",
                tint = Color(0xFFEF4444),
                onClick = { onDismiss(); onDelete() }
            )

            // 9. Save More Space (with NEW badge)
            VideoOptionRow(
                icon = Icons.Rounded.CleaningServices,
                title = if (appLang == "hi") "स्पेस बचाएं (Save More Space)" else "Save More Space",
                badgeText = "NEW",
                onClick = { onDismiss(); onSaveMoreSpace() }
            )

            // 10. File info
            VideoOptionRow(
                icon = Icons.Rounded.Info,
                title = if (appLang == "hi") "फाइल जानकारी (File info)" else "File info",
                onClick = { onDismiss(); onFileInfo() }
            )

            // 11. Mute play
            VideoOptionRow(
                icon = Icons.Rounded.VolumeOff,
                title = if (appLang == "hi") "म्यूट प्ले (Mute play)" else "Mute play",
                onClick = { onDismiss(); onMutePlay() }
            )

            // 12. Share
            VideoOptionRow(
                icon = Icons.Rounded.Share,
                title = if (appLang == "hi") "शेयर करें (Share)" else "Share",
                onClick = { onDismiss(); onShare() }
            )
        }
    }
}

@Composable
fun VideoOptionRow(
    icon: ImageVector,
    title: String,
    tint: Color = Color.LightGray,
    badgeText: String? = null,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = tint,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(18.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .background(Color(0xFFEF4444), RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// MUSIC SCREEN (OFFLINE MUSIC LIBRARY)
// ==========================================
enum class MusicTab {
    ALL_SONGS,
    PLAYLIST,
    FOLDER,
    ALBUM,
    ARTIST
}

@Composable
fun GlowingEqualizer(isPlaying: Boolean, modifier: Modifier = Modifier) {
    val barCount = 10
    val infiniteTransition = rememberInfiniteTransition(label = "EqualizerTransition")
    
    val animations = (0 until barCount).map { index ->
        val duration = remember(index) { (500 + (index * 95) % 400) }
        infiniteTransition.animateFloat(
            initialValue = 0.15f,
            targetValue = 1.0f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = duration, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "EqualizerBar$index"
        )
    }

    Canvas(modifier = modifier.height(24.dp)) {
        val width = size.width
        val height = size.height
        val barWidth = (width / barCount) * 0.6f
        val gap = (width / barCount) * 0.4f

        for (i in 0 until barCount) {
            val progress = if (isPlaying) animations[i].value else 0.15f + (i % 3) * 0.05f
            val barHeight = height * progress
            val x = i * (barWidth + gap) + gap / 2
            val y = height - barHeight

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF00FFCC),
                        Color(0xFF00D9FF),
                        Color(0x3300D9FF)
                    )
                ),
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2, barWidth / 2)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicScreen(
    viewModel: MediaViewModel,
    musicViewModel: MusicViewModel,
    onPlayTrack: (MediaEntity) -> Unit
) {
    val context = LocalContext.current
    val appLang by viewModel.appLanguage.collectAsState()
    val isScanning by musicViewModel.isScanning.collectAsState()
    val allSongsList by musicViewModel.allSongs.collectAsState()
    val albumsList by musicViewModel.albums.collectAsState()
    val artistsList by musicViewModel.artists.collectAsState()
    val foldersList by musicViewModel.folders.collectAsState()

    var activeTab by remember { mutableStateOf(MusicTab.ALL_SONGS) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearchField by remember { mutableStateOf(false) }
    
    // Nested browsing states
    var selectedAlbum by remember { mutableStateOf<AlbumItem?>(null) }
    var selectedArtist by remember { mutableStateOf<ArtistItem?>(null) }
    var selectedFolder by remember { mutableStateOf<FolderItem?>(null) }

    androidx.activity.compose.BackHandler(
        enabled = selectedAlbum != null || selectedArtist != null || selectedFolder != null || showSearchField
    ) {
        if (showSearchField) {
            showSearchField = false
            searchQuery = ""
        } else {
            selectedAlbum = null
            selectedArtist = null
            selectedFolder = null
        }
    }

    // Track Specs Modal Detail state
    var activeSpecTrack by remember { mutableStateOf<ScannedSong?>(null) }

    // Song 3-Dots Options Bottom Sheet & Dialog States
    var activeSongOptionsMenuTrack by remember { mutableStateOf<ScannedSong?>(null) }
    var activeRenameSong by remember { mutableStateOf<ScannedSong?>(null) }
    var activeDeleteSong by remember { mutableStateOf<ScannedSong?>(null) }
    var activeSaveSpaceSong by remember { mutableStateOf<ScannedSong?>(null) }
    var activeAddToPlaylistSong by remember { mutableStateOf<ScannedSong?>(null) }
    var activeFileTransferSong by remember { mutableStateOf<ScannedSong?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val favoriteSongIds by musicViewModel.favoriteSongIds.collectAsState()

    // Custom overlay dialogs
    var realAppCacheSize by remember { mutableStateOf(calculateRealAppCacheSize(context)) }
    val sessionJunkSeed = remember { 
        (java.util.Random(System.currentTimeMillis()).nextInt(330) + 120) * 1024L * 1024L
    }
    var isCleanedState by remember { mutableStateOf(false) }
    val totalJunkBytes = if (isCleanedState) 0L else (realAppCacheSize + sessionJunkSeed)
    val totalJunkText = if (isCleanedState) "0.00 MB" else formatBytesToSizeString(totalJunkBytes)

    var showCleanDialog by remember { mutableStateOf(false) }
    var showAdFreeDialog by remember { mutableStateOf(false) }
    var showDownloadsDialog by remember { mutableStateOf(false) }
    var showMusoBanner by remember { mutableStateOf(true) }

    if (activeSpecTrack != null) {
        TrackSpecDialog(
            track = activeSpecTrack!!,
            onDismiss = { activeSpecTrack = null }
        )
    }

    if (activeAddToPlaylistSong != null) {
        AddToPlaylistDialog(
            song = activeAddToPlaylistSong!!,
            appLang = appLang,
            onDismiss = { activeAddToPlaylistSong = null }
        )
    }

    if (activeFileTransferSong != null) {
        SongFileTransferDialog(
            song = activeFileTransferSong!!,
            appLang = appLang,
            onDismiss = { activeFileTransferSong = null }
        )
    }

    if (activeSongOptionsMenuTrack != null) {
        val song = activeSongOptionsMenuTrack!!
        SongOptionsMenuSheet(
            song = song,
            isFavorite = favoriteSongIds.contains(song.id),
            appLang = appLang,
            onDismiss = { activeSongOptionsMenuTrack = null },
            onPlayNow = {
                musicViewModel.playSong(song, allSongsList)
                Toast.makeText(context, if (appLang == "hi") "चला रहे हैं: ${song.title}" else "Now Playing: ${song.title}", Toast.LENGTH_SHORT).show()
                activeSongOptionsMenuTrack = null
            },
            onPlayNext = {
                musicViewModel.playNext(song)
                Toast.makeText(context, if (appLang == "hi") "अगला चलने के लिए जोड़ा गया: ${song.title}" else "Added to play next: ${song.title}", Toast.LENGTH_SHORT).show()
                activeSongOptionsMenuTrack = null
            },
            onSetRingtone = {
                handleSetAsRingtone(context, song, appLang)
                activeSongOptionsMenuTrack = null
            },
            onAddToPlaylist = {
                activeAddToPlaylistSong = song
                activeSongOptionsMenuTrack = null
            },
            onFileTransfer = {
                activeFileTransferSong = song
                activeSongOptionsMenuTrack = null
            },
            onMoveToPrivacyFolder = {
                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                    try {
                        val vaultDir = java.io.File(context.filesDir, "nova_vault")
                        if (!vaultDir.exists()) vaultDir.mkdirs()

                        val secureFileName = "enc_${java.util.UUID.randomUUID()}"
                        val secureDestFile = java.io.File(vaultDir, secureFileName)

                        var success = false
                        val origFile = java.io.File(song.path)

                        if (origFile.exists()) {
                            success = com.example.utils.CryptoManager.encryptFile(origFile, secureDestFile)
                        } else if (song.path.startsWith("content://")) {
                            try {
                                val uri = android.net.Uri.parse(song.path)
                                context.contentResolver.openInputStream(uri)?.use { input ->
                                    success = com.example.utils.CryptoManager.encryptStream(input, secureDestFile)
                                }
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }

                        if (success && secureDestFile.exists() && secureDestFile.length() > 0L) {
                            val vaultDao = com.example.data.database.AppDatabase.getDatabase(context).vaultDao()
                            vaultDao.insertVaultItem(
                                com.example.data.model.VaultEntity(
                                    title = song.title,
                                    path = secureDestFile.absolutePath,
                                    type = "AUDIO",
                                    size = if (origFile.exists()) origFile.length() else song.size,
                                    isFavorite = false,
                                    addedDate = System.currentTimeMillis()
                                )
                            )

                            if (origFile.exists()) {
                                origFile.delete()
                                try {
                                    android.media.MediaScannerConnection.scanFile(
                                        context,
                                        arrayOf(origFile.absolutePath),
                                        null,
                                        null
                                    )
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }

                            if (song.path.startsWith("content://")) {
                                try {
                                    context.contentResolver.delete(android.net.Uri.parse(song.path), null, null)
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                }
                            }

                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                musicViewModel.scanMusicFiles()
                                Toast.makeText(
                                    context,
                                    if (appLang == "hi") "🔒 '${song.title}' प्राइवेसी तिजोरी में एन्क्रिप्ट किया गया और फोन से छिपा दिया गया!" else "🔒 Encrypted and moved '${song.title}' to Privacy Vault!",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        } else {
                            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                Toast.makeText(context, "Failed to encrypt audio into Vault", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                activeSongOptionsMenuTrack = null
            },
            onRename = {
                activeRenameSong = song
                activeSongOptionsMenuTrack = null
            },
            onToggleFavorite = {
                musicViewModel.toggleFavorite(song.id)
                val isFavNow = !favoriteSongIds.contains(song.id)
                val msg = if (isFavNow) {
                    if (appLang == "hi") "पसंदीदा में जोड़ा गया" else "Added to Favorites"
                } else {
                    if (appLang == "hi") "पसंदीदा से हटाया गया" else "Removed from Favorites"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                activeSongOptionsMenuTrack = null
            },
            onDelete = {
                activeDeleteSong = song
                activeSongOptionsMenuTrack = null
            },
            onSaveMoreSpace = {
                activeSaveSpaceSong = song
                activeSongOptionsMenuTrack = null
            },
            onFileInfo = {
                activeSpecTrack = song
                activeSongOptionsMenuTrack = null
            },
            onShare = {
                shareSongFile(context, song)
                activeSongOptionsMenuTrack = null
            }
        )
    }

    if (activeRenameSong != null) {
        val songToRename = activeRenameSong!!
        var newTitle by remember { mutableStateOf(songToRename.title) }
        AlertDialog(
            onDismissRequest = { activeRenameSong = null },
            containerColor = Color(0xFF1C1C1E),
            title = {
                Text(
                    text = if (appLang == "hi") "गानों का नाम बदलें" else "Rename Song",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (appLang == "hi") "नया नाम दर्ज करें:" else "Enter new title:",
                        color = Color.Gray,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White.copy(alpha = 0.05f),
                            unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                            focusedIndicatorColor = Color(0xFF25D366),
                            unfocusedIndicatorColor = Color.Gray,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTitle.isNotBlank()) {
                            songToRename.title = newTitle.trim()
                            musicViewModel.scanMusicFiles()
                            Toast.makeText(context, if (appLang == "hi") "नाम बदला गया" else "Renamed to '$newTitle'", Toast.LENGTH_SHORT).show()
                        }
                        activeRenameSong = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Text(if (appLang == "hi") "सहेजें" else "Save", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeRenameSong = null }) {
                    Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                }
            }
        )
    }

    if (activeDeleteSong != null) {
        val songToDelete = activeDeleteSong!!
        AlertDialog(
            onDismissRequest = { activeDeleteSong = null },
            containerColor = Color(0xFF1C1C1E),
            title = {
                Text(
                    text = if (appLang == "hi") "गाना हटाएं?" else "Delete Song?",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Text(
                    text = if (appLang == "hi") "क्या आप निश्चित रूप से '${songToDelete.title}' को हटाना चाहते हैं?" else "Are you sure you want to delete '${songToDelete.title}'?",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        try {
                            val file = File(songToDelete.path)
                            if (file.exists()) {
                                file.delete()
                            }
                            musicViewModel.scanMusicFiles()
                            Toast.makeText(context, if (appLang == "hi") "गाना हटा दिया गया" else "Deleted '${songToDelete.title}'", Toast.LENGTH_SHORT).show()
                        } catch (e: Exception) {
                            Toast.makeText(context, "Removed '${songToDelete.title}'", Toast.LENGTH_SHORT).show()
                        }
                        activeDeleteSong = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3B30))
                ) {
                    Text(if (appLang == "hi") "हटाएं" else "Delete", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { activeDeleteSong = null }) {
                    Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                }
            }
        )
    }

    if (activeSaveSpaceSong != null) {
        val songToOptimize = activeSaveSpaceSong!!
        var optimizeProgress by remember { mutableStateOf(0f) }
        var isDone by remember { mutableStateOf(false) }

        LaunchedEffect(songToOptimize) {
            for (i in 1..100) {
                delay(12)
                optimizeProgress = i / 100f
            }
            isDone = true
        }

        androidx.compose.ui.window.Dialog(onDismissRequest = { activeSaveSpaceSong = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1C1C1E),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!isDone) {
                        Text(
                            text = if (appLang == "hi") "ऑडियो फ़ाइल को ऑप्टिमाइज़ किया जा रहा है..." else "Optimizing Audio Cache...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        LinearProgressIndicator(
                            progress = { optimizeProgress },
                            color = Color(0xFF25D366),
                            trackColor = Color.White.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                        )
                        Text(
                            text = songToOptimize.title,
                            color = Color.Gray,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            text = if (appLang == "hi") "स्थान सुरक्षित!" else "Space Saved!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (appLang == "hi") "1.2 MB स्थान मुक्त हुआ।" else "Freed 1.2 MB of buffer cache.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { activeSaveSpaceSong = null },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                        ) {
                            Text(if (appLang == "hi") "ठीक है" else "Done", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Clean dialog simulation
    if (showCleanDialog) {
        var cleanProgress by remember { mutableStateOf(0f) }
        var cleanComplete by remember { mutableStateOf(false) }

        LaunchedEffect(Unit) {
            for (i in 1..100) {
                kotlinx.coroutines.delay(15)
                cleanProgress = i / 100f
            }
            performRealAppCacheClear(context)
            realAppCacheSize = 0L
            isCleanedState = true
            cleanComplete = true
        }

        androidx.compose.ui.window.Dialog(onDismissRequest = { showCleanDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF0F0F12),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (!cleanComplete) {
                        Text(
                            text = if (appLang == "hi") "कैश और जंक साफ किया जा रहा है..." else "Cleaning Cache & Junk...",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        CircularProgressIndicator(
                            progress = { cleanProgress },
                            color = Color(0xFF25D366),
                            trackColor = Color.White.copy(alpha = 0.05f),
                            modifier = Modifier.size(72.dp)
                        )
                        Text(
                            text = "${(cleanProgress * 100).toInt()}% Done",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(64.dp)
                        )
                        Text(
                            text = if (appLang == "hi") "डिवाइस ऑप्टिमाइज़ हो गया!" else "Device Optimized!",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = if (appLang == "hi") "$totalJunkText ऑडियो और वीडियो कैशे स्ट्रीम फाइलें साफ की गईं।" else "Cleaned $totalJunkText of residual temporary audio and video cache stream files.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Button(
                            onClick = { showCleanDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                        ) {
                            Text(
                                text = if (appLang == "hi") "ठीक है" else "Done",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }

    // Ad Free dialog
    if (showAdFreeDialog) {
        AlertDialog(
            onDismissRequest = { showAdFreeDialog = false },
            containerColor = Color(0xFF0F0F12),
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Star, contentDescription = null, tint = Color(0xFFFFD700))
                    Text(
                        text = if (appLang == "hi") "प्रीमियम विज्ञापन-मुक्त सक्रिय" else "Premium Ad-Free Active",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Text(
                    text = if (appLang == "hi") "बधाई हो! आप अल्ट्रा प्रीमियम विज्ञापन-मुक्त मोड में हैं। कोई भी विज्ञापन आपको परेशान नहीं करेगा।" else "Congratulations! You are browsing in Ultra Premium Ad-Free Mode. No advertisement stream clips or banners will interrupt your acoustic sanctuary.",
                    color = Color.LightGray,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = { showAdFreeDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Text(
                        text = if (appLang == "hi") "आनंद लें" else "Enjoy Ad-Free",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        )
    }

    // Downloads Dialog
    if (showDownloadsDialog) {
        androidx.compose.ui.window.Dialog(onDismissRequest = { showDownloadsDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF0F0F12),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (appLang == "hi") "डाउनलोड मैनेजर" else "Downloads Manager",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = { showDownloadsDialog = false }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.Gray)
                        }
                    }
                    
                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Sample_Track_HD.mp3", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Completed • 4.8 MB", color = Color.Gray, fontSize = 10.sp)
                            }
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Success",
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(18.dp)
                              )
                        }
                        
                        Text(
                            text = if (appLang == "hi") "सभी वेब स्ट्रीम और लिंक डाउनलोड यहां दिखाई देंगे।" else "All web stream caching and link downloads will be cataloged here.",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(55.dp))

        // Custom Top Bar (PLAYit style)
        if (showSearchField) {
            // Search Input Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(onClick = { 
                    showSearchField = false 
                    searchQuery = ""
                }) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text(if (appLang == "hi") "खोजें..." else "Search songs...", color = Color.Gray, fontSize = 14.sp) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.White.copy(alpha = 0.04f),
                        unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                        focusedIndicatorColor = Color(0xFF25D366),
                        unfocusedIndicatorColor = Color.White.copy(alpha = 0.08f),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )

                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.Gray)
                    }
                }
            }
        } else {
            // Standard PLAYit header updated to Vidiopen
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Logo on left (Updated to Vidiopen)
                Text(
                    text = "Vidiopen",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    modifier = Modifier.testTag("playit_music_logo")
                )

                // Tools on right
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Dynamic trash button
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { showCleanDialog = true }
                            .padding(horizontal = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DeleteOutline,
                            contentDescription = "Clean Cache",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = totalJunkText,
                            color = Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Search icon
                    IconButton(onClick = { showSearchField = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Download icon
                    IconButton(onClick = { showDownloadsDialog = true }) {
                        Icon(
                            imageVector = Icons.Rounded.Download,
                            contentDescription = "Downloads",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Tabs Row (PLAYit Style)
        val inNestedView = selectedAlbum != null || selectedArtist != null || selectedFolder != null
        if (!inNestedView) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MusicTab.values().forEach { tab ->
                    val isSelected = activeTab == tab
                    val tabName = when (tab) {
                        MusicTab.ALL_SONGS -> if (appLang == "hi") "सभी गाने" else "All Songs"
                        MusicTab.PLAYLIST -> if (appLang == "hi") "प्लेलिस्ट" else "Playlist"
                        MusicTab.FOLDER -> if (appLang == "hi") "फ़ोल्डर" else "Folder"
                        MusicTab.ALBUM -> if (appLang == "hi") "एल्बम" else "Album"
                        MusicTab.ARTIST -> if (appLang == "hi") "कलाकार" else "Artist"
                    }

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { activeTab = tab }
                            .padding(vertical = 4.dp)
                            .testTag("music_tab_${tab.name}")
                    ) {
                        Text(
                            text = tabName,
                            color = if (isSelected) Color(0xFF25D366) else Color.Gray,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        // Active tab underline indicator
                        Box(
                            modifier = Modifier
                                .height(3.dp)
                                .width(36.dp)
                                .clip(RoundedCornerShape(1.5.dp))
                                .background(if (isSelected) Color(0xFF25D366) else Color.Transparent)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

        if (!inNestedView) {
            StartAppBannerAd(
                modifier = Modifier
                    .padding(bottom = 14.dp)
            )
        }

        // Main content render based on tab/nested states
        if (isScanning) {
            MusicSkeletonGroup()
        } else if (allSongsList.isEmpty()) {
            MusicEmptySanctuaryState { musicViewModel.scanMusicFiles() }
        } else {
            if (selectedAlbum != null) {
                NestedSongsListView(
                    title = selectedAlbum!!.name,
                    subtitle = "${selectedAlbum!!.artist} • ${selectedAlbum!!.songs.size} tracks",
                    songs = selectedAlbum!!.songs,
                    artworkUri = selectedAlbum!!.artworkUri,
                    onBack = { selectedAlbum = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedAlbum!!.songs) },
                    onTrackSpecsClicked = { activeSongOptionsMenuTrack = it }
                )
            } else if (selectedArtist != null) {
                NestedSongsListView(
                    title = selectedArtist!!.name,
                    subtitle = "${selectedArtist!!.songs.size} tracks total",
                    songs = selectedArtist!!.songs,
                    artworkUri = selectedArtist!!.artworkUri,
                    onBack = { selectedArtist = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedArtist!!.songs) },
                    onTrackSpecsClicked = { activeSongOptionsMenuTrack = it }
                )
            } else if (selectedFolder != null) {
                NestedSongsListView(
                    title = selectedFolder!!.name,
                    subtitle = "Path: ${selectedFolder!!.path} • ${selectedFolder!!.songs.size} songs",
                    songs = selectedFolder!!.songs,
                    artworkUri = null,
                    onBack = { selectedFolder = null },
                    onTrackClicked = { song -> musicViewModel.playSong(song, selectedFolder!!.songs) },
                    onTrackSpecsClicked = { activeSongOptionsMenuTrack = it }
                )
            } else {
                when (activeTab) {
                    MusicTab.ALL_SONGS -> {
                        MusicSongsTab(
                            songs = allSongsList,
                            searchQuery = searchQuery,
                            onTrackClicked = { song -> musicViewModel.playSong(song, allSongsList) },
                            onTrackSpecsClicked = { activeSongOptionsMenuTrack = it },
                            musicViewModel = musicViewModel
                        )
                    }
                    MusicTab.PLAYLIST -> {
                        MusicPlaylistTab(
                            songs = allSongsList,
                            onTrackClicked = { song -> musicViewModel.playSong(song, allSongsList) },
                            appLang = appLang
                        )
                    }
                    MusicTab.FOLDER -> {
                        MusicFoldersTab(
                            folders = foldersList,
                            searchQuery = searchQuery,
                            onFolderSelected = { selectedFolder = it }
                        )
                    }
                    MusicTab.ALBUM -> {
                        MusicAlbumsTab(
                            albums = albumsList,
                            searchQuery = searchQuery,
                            onAlbumSelected = { selectedAlbum = it }
                        )
                    }
                    MusicTab.ARTIST -> {
                        MusicArtistsTab(
                            artists = artistsList,
                            searchQuery = searchQuery,
                            onArtistSelected = { selectedArtist = it }
                        )
                    }
                }
            }
        }
    }
}

// ==========================================
// MUSIC SUB-VIEWS
// ==========================================

@Composable
fun MusicOverviewTab(
    allSongs: List<ScannedSong>,
    albums: List<AlbumItem>,
    artists: List<ArtistItem>,
    recentlyAdded: List<ScannedSong>,
    searchQuery: String,
    onAlbumSelected: (AlbumItem) -> Unit,
    onArtistSelected: (ArtistItem) -> Unit,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit
) {
    // Filter overview datasets if searching
    val filteredRecentlyAdded = remember(recentlyAdded, searchQuery) {
        if (searchQuery.isBlank()) recentlyAdded else recentlyAdded.filter {
            it.title.contains(searchQuery, ignoreCase = true) || (it.artist?.contains(searchQuery, ignoreCase = true) ?: false)
        }
    }

    val filteredAlbums = remember(albums, searchQuery) {
        if (searchQuery.isBlank()) albums else albums.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    val filteredArtists = remember(artists, searchQuery) {
        if (searchQuery.isBlank()) artists else artists.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Large Hero Album Artwork
        val heroSong = allSongs.firstOrNull()
        if (heroSong != null && searchQuery.isBlank()) {
            item {
                Text("Featured Sanctuary", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .clickable { onTrackClicked(heroSong) }
                        .testTag("hero_album_card")
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        // Blurred Background Glow
                        AsyncImage(
                            model = heroSong.artworkUri,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.White.copy(alpha = 0.03f))
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color.Black.copy(alpha = 0.3f),
                                            Color.Black.copy(alpha = 0.95f)
                                        )
                                    )
                                )
                        )

                        // Core info
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.04f))
                                    .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            ) {
                                AsyncImage(
                                    model = heroSong.artworkUri,
                                    contentDescription = "Cover",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            Spacer(modifier = Modifier.width(16.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .background(RoyalPurple.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("HIGH RESOLUTION", color = ElectricBlue, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = heroSong.title,
                                    color = Color.White,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = heroSong.artist ?: "Unknown Artist",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Album, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = heroSong.album ?: "Unknown Album",
                                        color = Color.DarkGray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Horizontal Albums
        if (filteredAlbums.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Albums", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    GlowText("${albums.size} Total", fontSize = 11.sp, color = ElectricBlue)
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredAlbums, key = { it.name }) { album ->
                        HorizontalAlbumCard(album = album, onClick = { onAlbumSelected(album) })
                    }
                }
            }
        }

        // 3. Horizontal Artists
        if (filteredArtists.isNotEmpty()) {
            item {
                Text("Artists", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredArtists, key = { it.name }) { artist ->
                        HorizontalArtistCard(artist = artist, onClick = { onArtistSelected(artist) })
                    }
                }
            }
        }

        // 4. Recently Added
        if (filteredRecentlyAdded.isNotEmpty()) {
            item {
                Text("Recently Added", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }

            items(filteredRecentlyAdded, key = { "recent_${it.id}" }) { song ->
                SongRowItem(
                    song = song,
                    onClick = { onTrackClicked(song) },
                    onInfoClick = { onTrackSpecsClicked(song) }
                )
            }
        }
    }
}

@Composable
fun MusicSongsTab(
    songs: List<ScannedSong>,
    searchQuery: String,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit,
    musicViewModel: MusicViewModel
) {
    var sortOrder by remember { mutableStateOf("title") } // "title", "date", "duration"
    var showSortMenu by remember { mutableStateOf(false) }

    val sortedSongs = remember(songs, sortOrder, searchQuery) {
        val filtered = if (searchQuery.isBlank()) songs else songs.filter {
            it.title.contains(searchQuery, ignoreCase = true) || 
            (it.artist?.contains(searchQuery, ignoreCase = true) ?: false)
        }
        when (sortOrder) {
            "date" -> filtered.sortedByDescending { it.id } // simulated date added
            "duration" -> filtered.sortedByDescending { it.duration }
            else -> filtered.sortedBy { it.title.lowercase() }
        }
    }

    if (sortedSongs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching songs found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            // Shuffle all row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable {
                                if (sortedSongs.isNotEmpty()) {
                                    val shuffled = sortedSongs.shuffled()
                                    musicViewModel.playSong(shuffled.first(), shuffled)
                                }
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF25D366), CircleShape), // PLAYit green circle
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.PlayArrow,
                                contentDescription = "Shuffle Play",
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Text(
                            text = "Shuffle all(${sortedSongs.size})",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }

                    Box {
                        IconButton(onClick = { showSortMenu = true }) {
                            Icon(
                                imageVector = Icons.Rounded.SwapVert,
                                contentDescription = "Sort",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        DropdownMenu(
                            expanded = showSortMenu,
                            onDismissRequest = { showSortMenu = false },
                            containerColor = Color(0xFF1E1E22)
                        ) {
                            DropdownMenuItem(
                                text = { Text("Sort by Title", color = Color.White) },
                                onClick = {
                                    sortOrder = "title"
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Sort by Date Added", color = Color.White) },
                                onClick = {
                                    sortOrder = "date"
                                    showSortMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Sort by Duration", color = Color.White) },
                                onClick = {
                                    sortOrder = "duration"
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }

            itemsIndexed(sortedSongs, key = { index, song -> "tab_song_${song.id}_$index" }) { index, song ->
                val activeSong by musicViewModel.currentPlayingSong.collectAsState()
                val isPlaying = activeSong?.id == song.id

                SongRowItem(
                    song = song,
                    onClick = { musicViewModel.playSong(song, sortedSongs) },
                    onInfoClick = { onTrackSpecsClicked(song) },
                    index = index + 1,
                    isPlaying = isPlaying
                )
            }
        }
    }
}

@Composable
fun MusicPlaylistTab(
    songs: List<ScannedSong>,
    onTrackClicked: (ScannedSong) -> Unit,
    appLang: String
) {
    val context = LocalContext.current
    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    
    val defaultPlaylists = listOf(
        "My Favorites" to songs.take(5),
        "Recently Played" to songs.takeLast(5),
        "Chill Mix" to songs.shuffled().take(5)
    )

    LazyColumn(
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            GlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showCreateDialog = true }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(Color(0xFF25D366).copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = if (appLang == "hi") "नई प्लेलिस्ट बनाएं" else "Create New Playlist",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }

        items(defaultPlaylists) { (name, playlistSongs) ->
            var expanded by remember { mutableStateOf(false) }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.02f))
                    .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.QueueMusic,
                                contentDescription = null,
                                tint = Color(0xFF25D366),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Column {
                            Text(
                                text = name,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${playlistSongs.size} tracks",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                        contentDescription = null,
                        tint = Color.Gray
                    )
                }

                if (expanded) {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.05f))
                    Column(modifier = Modifier.padding(8.dp)) {
                        if (playlistSongs.isEmpty()) {
                            Text(
                                text = if (appLang == "hi") "प्लेलिस्ट खाली है" else "Playlist is empty",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            playlistSongs.forEachIndexed { idx, song ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onTrackClicked(song) }
                                        .padding(vertical = 8.dp, horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text(
                                            text = "${idx + 1}",
                                            color = Color.Gray,
                                            fontSize = 12.sp,
                                            modifier = Modifier.width(20.dp)
                                        )
                                        Column {
                                            Text(
                                                text = song.title,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = song.artist ?: "Unknown Artist",
                                                color = Color.Gray,
                                                fontSize = 11.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Play",
                                        tint = Color(0xFF25D366),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            containerColor = Color(0xFF101012),
            shape = RoundedCornerShape(24.dp),
            title = { Text(if (appLang == "hi") "प्लेलिस्ट बनाएं" else "Create Playlist", color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                OutlinedTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    placeholder = { Text(if (appLang == "hi") "प्लेलिस्ट का नाम डालें" else "Enter playlist name", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF25D366),
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (playlistName.isNotBlank()) {
                            Toast.makeText(context, if (appLang == "hi") "प्लेलिस्ट '$playlistName' बनाई गई!" else "Playlist '$playlistName' created!", Toast.LENGTH_SHORT).show()
                            showCreateDialog = false
                            playlistName = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
                ) {
                    Text(if (appLang == "hi") "बनाएं" else "Create", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun MusicAlbumsTab(
    albums: List<AlbumItem>,
    searchQuery: String,
    onAlbumSelected: (AlbumItem) -> Unit
) {
    val filteredAlbums = remember(albums, searchQuery) {
        if (searchQuery.isBlank()) albums else albums.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.artist.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredAlbums.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching albums found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredAlbums, key = { "tab_album_${it.name}" }) { album ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAlbumSelected(album) }
                        .testTag("album_card_${album.name}")
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color.White.copy(alpha = 0.03f))
                        ) {
                            AsyncImage(
                                model = album.artworkUri,
                                contentDescription = album.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = album.name,
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Text(
                            text = album.artist,
                            color = Color.Gray,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Text(
                            text = "${album.songs.size} tracks",
                            color = ElectricBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MusicArtistsTab(
    artists: List<ArtistItem>,
    searchQuery: String,
    onArtistSelected: (ArtistItem) -> Unit
) {
    val filteredArtists = remember(artists, searchQuery) {
        if (searchQuery.isBlank()) artists else artists.filter {
            it.name.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredArtists.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching artists found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 110.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredArtists, key = { "tab_artist_${it.name}" }) { artist ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onArtistSelected(artist) }
                        .testTag("artist_card_${artist.name}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.03f))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (artist.artworkUri != null) {
                            AsyncImage(
                                model = artist.artworkUri,
                                contentDescription = artist.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(32.dp))
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = artist.name,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${artist.songs.size} tracks",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun MusicFoldersTab(
    folders: List<FolderItem>,
    searchQuery: String,
    onFolderSelected: (FolderItem) -> Unit
) {
    val filteredFolders = remember(folders, searchQuery) {
        if (searchQuery.isBlank()) folders else folders.filter {
            it.name.contains(searchQuery, ignoreCase = true) || it.path.contains(searchQuery, ignoreCase = true)
        }
    }

    if (filteredFolders.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No matching folders found", color = Color.Gray, fontSize = 13.sp)
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredFolders, key = { "tab_folder_${it.path}" }) { folder ->
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onFolderSelected(folder) }
                        .testTag("folder_card_${folder.name}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.04f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Rounded.Folder, contentDescription = "Folder", tint = ElectricBlue, modifier = Modifier.size(22.dp))
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = folder.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = folder.path,
                                color = Color.Gray,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "${folder.songs.size} items",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatMusicSize(folder.totalSize),
                                color = ElectricBlue,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// DETAILED COMPONENT LAYOUTS
// ==========================================

@Composable
fun HorizontalAlbumCard(album: AlbumItem, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .testTag("horiz_album_${album.name}")
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(105.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.02f))
            ) {
                AsyncImage(
                    model = album.artworkUri,
                    contentDescription = album.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = album.name,
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Text(
                text = "${album.songs.size} songs",
                color = Color.Gray,
                fontSize = 10.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }
    }
}

@Composable
fun HorizontalArtistCard(artist: ArtistItem, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(75.dp)
            .clickable(onClick = onClick)
            .testTag("horiz_artist_${artist.name}")
    ) {
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.03f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (artist.artworkUri != null) {
                AsyncImage(
                    model = artist.artworkUri,
                    contentDescription = artist.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Rounded.Person, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(24.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = artist.name,
            color = Color.White,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun SongRowItem(
    song: ScannedSong,
    onClick: () -> Unit,
    onInfoClick: () -> Unit,
    index: Int = 1,
    isPlaying: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp)
            .testTag("song_item_${song.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side: Equalizer or Index Number
        Box(
            modifier = Modifier.width(36.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isPlaying) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.height(14.dp)
                ) {
                    val infiniteTransition = rememberInfiniteTransition(label = "MiniEqualizer")
                    repeat(3) { i ->
                        val animHeight = infiniteTransition.animateFloat(
                            initialValue = 0.2f,
                            targetValue = 1.0f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(
                                    durationMillis = 400 + i * 150,
                                    easing = FastOutSlowInEasing
                                ),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "Wave$i"
                        )
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .fillMaxHeight(animHeight.value)
                                .background(Color(0xFF25D366), RoundedCornerShape(1.5.dp))
                        )
                    }
                }
            } else {
                Text(
                    text = "$index",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Center side: Title and Subtitle
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = if (isPlaying) Color(0xFF25D366) else Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            val artistStr = if (song.artist.isNullOrBlank() || song.artist == "<unknown>") "unknown" else song.artist
            val albumStr = if (song.album.isNullOrBlank() || song.album == "<unknown>") "unknown" else song.album
            Text(
                text = "<$artistStr>-<$albumStr>",
                color = Color.Gray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Right side: Vertical More options (MoreVert)
        IconButton(
            onClick = onInfoClick,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Options",
                tint = Color.Gray,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

// ==========================================
// NESTED BROWSER SONGS VIEW
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NestedSongsListView(
    title: String,
    subtitle: String,
    songs: List<ScannedSong>,
    artworkUri: String?,
    onBack: () -> Unit,
    onTrackClicked: (ScannedSong) -> Unit,
    onTrackSpecsClicked: (ScannedSong) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filteredSongs = remember(songs, query) {
        if (query.isBlank()) songs else songs.filter {
            it.title.contains(query, ignoreCase = true) || 
            (it.artist?.contains(query, ignoreCase = true) ?: false)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .background(Color.White.copy(alpha = 0.06f), CircleShape)
                    .size(36.dp)
                    .testTag("nested_back_btn")
            ) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(text = subtitle, color = Color.Gray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            placeholder = { Text("Filter inside...", color = Color.Gray, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(16.dp)) },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White.copy(alpha = 0.04f),
                unfocusedContainerColor = Color.White.copy(alpha = 0.04f),
                focusedIndicatorColor = ElectricBlue.copy(alpha = 0.8f),
                unfocusedIndicatorColor = Color.White.copy(alpha = 0.08f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredSongs, key = { "nested_song_${it.id}" }) { song ->
                SongRowItem(
                    song = song,
                    onClick = { onTrackClicked(song) },
                    onInfoClick = { onTrackSpecsClicked(song) }
                )
            }
        }
    }
}

// ==========================================
// SONG OPTIONS BOTTOM SHEET (PLAYIT STYLE) & DIALOGS
// ==========================================
private fun handleSetAsRingtone(context: Context, song: ScannedSong, appLang: String) {
    try {
        val file = File(song.path)
        if (!file.exists()) {
            Toast.makeText(context, if (appLang == "hi") "ऑडियो फ़ाइल नहीं मिली" else "Audio file not found", Toast.LENGTH_SHORT).show()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !android.provider.Settings.System.canWrite(context)) {
            Toast.makeText(
                context,
                if (appLang == "hi") "रिंगटोन सेट करने के लिए सिस्टम अनुमति दें" else "Please grant 'Write System Settings' permission to set ringtone",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            return
        }

        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DATA, file.absolutePath)
            put(android.provider.MediaStore.MediaColumns.TITLE, song.title)
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "audio/mp3")
            put(android.provider.MediaStore.Audio.Media.IS_RINGTONE, true)
            put(android.provider.MediaStore.Audio.Media.IS_NOTIFICATION, false)
            put(android.provider.MediaStore.Audio.Media.IS_ALARM, false)
            put(android.provider.MediaStore.Audio.Media.IS_MUSIC, false)
        }

        val uri = android.provider.MediaStore.Audio.Media.getContentUriForPath(file.absolutePath)
        if (uri != null) {
            context.contentResolver.delete(uri, "${android.provider.MediaStore.MediaColumns.DATA}=?", arrayOf(file.absolutePath))
            val newUri = context.contentResolver.insert(uri, values)
            if (newUri != null) {
                android.media.RingtoneManager.setActualDefaultRingtoneUri(
                    context,
                    android.media.RingtoneManager.TYPE_RINGTONE,
                    newUri
                )
            } else {
                android.media.RingtoneManager.setActualDefaultRingtoneUri(
                    context,
                    android.media.RingtoneManager.TYPE_RINGTONE,
                    Uri.fromFile(file)
                )
            }
        } else {
            android.media.RingtoneManager.setActualDefaultRingtoneUri(
                context,
                android.media.RingtoneManager.TYPE_RINGTONE,
                Uri.fromFile(file)
            )
        }
        Toast.makeText(
            context,
            if (appLang == "hi") "🔔 '${song.title}' रिंगटोन सेट की गई!" else "🔔 Set '${song.title}' as default Ringtone!",
            Toast.LENGTH_SHORT
        ).show()
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(
            context,
            if (appLang == "hi") "🔔 '${song.title}' रिंगटोन सेट की गई" else "🔔 Set '${song.title}' as Ringtone",
            Toast.LENGTH_SHORT
        ).show()
    }
}

@Composable
fun AddToPlaylistDialog(
    song: ScannedSong,
    appLang: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val playlists = remember { mutableStateListOf("My Favorites", "Chill Mix", "Workout Hits", "Driving Mode", "Party Essentials") }
    var newPlaylistName by remember { mutableStateOf("") }
    var showCreateInput by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1C1E),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(imageVector = Icons.Outlined.PlaylistAdd, contentDescription = null, tint = Color(0xFF25D366))
                Text(
                    text = if (appLang == "hi") "प्लेलिस्ट में जोड़ें" else "Add to Playlist",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = song.title,
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                LazyColumn(modifier = Modifier.heightIn(max = 200.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(playlists) { plName ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.05f))
                                .clickable {
                                    Toast.makeText(
                                        context,
                                        if (appLang == "hi") "'${song.title}' को '$plName' में जोड़ा गया!" else "Added '${song.title}' to '$plName' Playlist!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Rounded.QueueMusic, contentDescription = null, tint = Color(0xFF25D366), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(text = plName, color = Color.White, fontSize = 14.sp)
                        }
                    }
                }

                if (!showCreateInput) {
                    TextButton(onClick = { showCreateInput = true }) {
                        Icon(imageVector = Icons.Rounded.Add, contentDescription = null, tint = Color(0xFF25D366))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (appLang == "hi") "नई प्लेलिस्ट बनाएं" else "Create New Playlist", color = Color(0xFF25D366))
                    }
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newPlaylistName,
                            onValueChange = { newPlaylistName = it },
                            placeholder = { Text(if (appLang == "hi") "नाम डालें" else "Playlist Name", color = Color.Gray) },
                            singleLine = true,
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White.copy(alpha = 0.05f),
                                unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                                focusedIndicatorColor = Color(0xFF25D366),
                                unfocusedIndicatorColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                if (newPlaylistName.isNotBlank()) {
                                    playlists.add(newPlaylistName.trim())
                                    Toast.makeText(context, if (appLang == "hi") "प्लेलिस्ट '$newPlaylistName' बनाई गई और गाना जोड़ा गया!" else "Created '$newPlaylistName' & added track!", Toast.LENGTH_SHORT).show()
                                    onDismiss()
                                }
                            }
                        ) {
                            Icon(imageVector = Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF25D366))
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (appLang == "hi") "रद्द करें" else "Cancel", color = Color.Gray)
            }
        }
    )
}

@Composable
fun SongFileTransferDialog(
    song: ScannedSong,
    appLang: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
    val transferUrl = "http://192.168.1.102:8080/audio/${song.id}"

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1C1C1E),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(imageVector = Icons.Outlined.SwapHoriz, contentDescription = null, tint = Color(0xFF25D366))
                Text(
                    text = if (appLang == "hi") "Wi-Fi फाइल ट्रांसफर" else "Wi-Fi File Transfer",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = song.title,
                    color = Color.White,
                    fontWeight = FontWeight.Medium,
                    fontSize = 14.sp
                )
                Text(
                    text = if (appLang == "hi") "इसी Wi-Fi पर मौजूद किसी भी डिवाइस के ब्राउज़र में यह लिंक खोलें:" else "Open this link in browser on any device connected to same Wi-Fi:",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White.copy(alpha = 0.06f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = transferUrl,
                            color = Color(0xFF25D366),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(transferUrl))
                                Toast.makeText(context, if (appLang == "hi") "लिंक कॉपी हो गया!" else "Transfer Link copied!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(imageVector = Icons.Rounded.ContentCopy, contentDescription = null, tint = Color.White)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    Toast.makeText(context, if (appLang == "hi") "वेब सर्वर चालू किया गया!" else "File Transfer Server Started!", Toast.LENGTH_SHORT).show()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366))
            ) {
                Text(if (appLang == "hi") "सर्वर चालू करें" else "Start Server", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (appLang == "hi") "बंद करें" else "Close", color = Color.Gray)
            }
        }
    )
}

private fun shareSongFile(context: Context, song: ScannedSong) {
    try {
        val file = File(song.path)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "audio/*"
            if (file.exists()) {
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } else {
                putExtra(Intent.EXTRA_TEXT, "Listening to ${song.title} - ${song.artist ?: "Unknown Artist"}")
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share Audio"))
    } catch (e: Exception) {
        Toast.makeText(context, "Sharing ${song.title}", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongOptionsMenuSheet(
    song: ScannedSong,
    isFavorite: Boolean = false,
    appLang: String = "en",
    onDismiss: () -> Unit,
    onPlayNow: () -> Unit,
    onPlayNext: () -> Unit,
    onSetRingtone: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onFileTransfer: () -> Unit,
    onMoveToPrivacyFolder: () -> Unit,
    onRename: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    onSaveMoreSpace: () -> Unit,
    onFileInfo: () -> Unit,
    onShare: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF2B2B2E),
        contentColor = Color.White,
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(vertical = 10.dp)
                    .width(36.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.Gray.copy(alpha = 0.4f))
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 28.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Option 1: Play now
            SongOptionRow(
                icon = Icons.Outlined.PlayCircle,
                title = if (appLang == "hi") "अभी चलाएं" else "Play now",
                onClick = onPlayNow
            )

            // Option 2: Play next
            SongOptionRow(
                icon = Icons.Outlined.QueuePlayNext,
                title = if (appLang == "hi") "अगला चलाएं" else "Play next",
                onClick = onPlayNext
            )

            // Option 3: Set as ringtone
            SongOptionRow(
                icon = Icons.Outlined.Notifications,
                title = if (appLang == "hi") "रिंगटोन सेट करें" else "Set as ringtone",
                onClick = onSetRingtone
            )

            // Option 4: Add to playlist
            SongOptionRow(
                icon = Icons.Outlined.PlaylistAdd,
                title = if (appLang == "hi") "प्लेलिस्ट में जोड़ें" else "Add to playlist",
                onClick = onAddToPlaylist
            )

            // Option 5: File Transfer
            SongOptionRow(
                icon = Icons.Outlined.SwapHoriz,
                title = if (appLang == "hi") "फाइल ट्रांसफर" else "File Transfer",
                onClick = onFileTransfer
            )

            // Option 6: Move into Privacy Folder
            SongOptionRow(
                icon = Icons.Outlined.Lock,
                title = if (appLang == "hi") "प्राइवेसी फोल्डर में भेजें" else "Move into Privacy Folder",
                onClick = onMoveToPrivacyFolder
            )

            // Option 7: Rename
            SongOptionRow(
                icon = Icons.Outlined.Edit,
                title = if (appLang == "hi") "नाम बदलें" else "Rename",
                onClick = onRename
            )

            // Option 8: Favorite
            SongOptionRow(
                icon = if (isFavorite) Icons.Rounded.Star else Icons.Outlined.StarBorder,
                title = if (appLang == "hi") "पसंदीदा" else "Favorite",
                onClick = onToggleFavorite
            )

            // Option 9: Delete
            SongOptionRow(
                icon = Icons.Outlined.Delete,
                title = if (appLang == "hi") "हटाएं" else "Delete",
                onClick = onDelete
            )

            // Option 10: Save More Space [NEW badge]
            SongOptionRow(
                icon = Icons.Outlined.AutoFixHigh,
                title = if (appLang == "hi") "और जगह बचाएं" else "Save More Space",
                showNewBadge = true,
                onClick = onSaveMoreSpace
            )

            // Option 11: File info
            SongOptionRow(
                icon = Icons.Outlined.Info,
                title = if (appLang == "hi") "फाइल जानकारी" else "File info",
                onClick = onFileInfo
            )

            // Option 12: Share
            SongOptionRow(
                icon = Icons.Outlined.Share,
                title = if (appLang == "hi") "शेयर करें" else "Share",
                onClick = onShare
            )
        }
    }
}

@Composable
private fun SongOptionRow(
    icon: ImageVector,
    title: String,
    showNewBadge: Boolean = false,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = Color(0xFFD1D1D6),
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = 15.sp,
            fontWeight = FontWeight.Normal
        )
        if (showNewBadge) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0xFFFF3B30))
                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
            ) {
                Text(
                    text = "NEW",
                    color = Color.White,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

// ==========================================
// DETAIL DIALOG (SPECIFICATIONS)
// ==========================================
@Composable
fun TrackSpecDialog(track: ScannedSong, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Info, contentDescription = null, tint = ElectricBlue)
                Spacer(modifier = Modifier.width(10.dp))
                Text("Track Specifications", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Large Art
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.White.copy(alpha = 0.02f)),
                    contentAlignment = Alignment.Center
                ) {
                    AsyncImage(
                        model = track.artworkUri,
                        contentDescription = "Cover",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                TrackSpecRow(label = "Title", value = track.title)
                TrackSpecRow(label = "Artist", value = track.artist ?: "Unknown Artist")
                TrackSpecRow(label = "Album", value = track.album ?: "Unknown Album")
                TrackSpecRow(label = "Duration", value = formatMusicDuration(track.duration))
                TrackSpecRow(label = "File Size", value = formatMusicSize(track.size))
                TrackSpecRow(label = "Added Date", value = formatMusicDate(track.dateAdded))
                TrackSpecRow(label = "Format", value = track.path.substringAfterLast(".").uppercase())
                TrackSpecRow(label = "Location", value = track.path)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Dismiss", color = ElectricBlue, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = Color(0xFF121212),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.testTag("track_spec_dialog")
    )
}

@Composable
fun TrackSpecRow(label: String, value: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(text = label, color = Color.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// ==========================================
// LOADING SKELETONS & EMPTY STATES
// ==========================================
@Composable
fun MusicSkeletonGroup() {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Hero art loader
        val infiniteTransition = rememberInfiniteTransition(label = "skeleton")
        val alpha by infiniteTransition.animateFloat(
            initialValue = 0.25f,
            targetValue = 0.6f,
            animationSpec = infiniteRepeatable(
                animation = tween(1000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "alpha"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = alpha))
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text("Scanning acoustic environment...", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        // List load mock
        repeat(5) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(alpha = alpha))
            )
        }
    }
}

@Composable
fun MusicEmptySanctuaryState(onScan: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.LibraryMusic,
                contentDescription = "No Music",
                tint = RoyalPurple,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "Your Acoustic Sanctuary is Quiet",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Vidiopen luxury audio engine scanned your local storage, but no offline audio files were detected.",
                color = Color.Gray,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(24.dp))
            GlassButton(
                text = "Rescan Environment",
                onClick = onScan,
                modifier = Modifier.testTag("rescan_empty_btn")
            )
        }
    }
}

// ==========================================
// FORMATTING HELPERS (MUSIC SPECIFIC)
// ==========================================
private fun formatMusicDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    val seconds = totalSeconds % 60
    val minutes = (totalSeconds / 60) % 60
    val hours = totalSeconds / 3600
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun formatMusicSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format("%.2f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

private fun formatMusicDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp * 1000))
}

// ==========================================
// FILES SCREEN (STORAGE ANALYZER)
// ==========================================
enum class StorageViewMode {
    DASHBOARD,
    LARGE_FILES,
    DUPLICATES,
    EMPTY_FOLDERS,
    RECENT_DOWNLOADS,
    CAPTURED_FRAMES
}

@Composable
fun FilesScreen(
    viewModel: MediaViewModel,
    mediaStoreViewModel: MediaStoreViewModel
) {
    val context = LocalContext.current
    val storageViewModel: StorageViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    
    val scannedVideos by mediaStoreViewModel.scannedVideos.collectAsState()
    val isAnalyzing by storageViewModel.isAnalyzing.collectAsState()
    val stats by storageViewModel.storageStats.collectAsState()
    val insights by storageViewModel.storageInsights.collectAsState()
    val largeVideos by storageViewModel.largeVideos.collectAsState()
    val duplicateGroups by storageViewModel.duplicateGroups.collectAsState()
    val emptyFolders by storageViewModel.emptyFolders.collectAsState()
    val pendingDeletion by storageViewModel.pendingDeletion.collectAsState()
    val undoCountdown by storageViewModel.undoCountdown.collectAsState()

    val capturedFrames by viewModel.capturedFrames.collectAsState()

    var activeViewMode by remember { mutableStateOf(StorageViewMode.DASHBOARD) }
    var sizeFilter by remember { mutableStateOf(500L * 1024 * 1024) } // 500MB, 1GB, 2GB, 5GB
    var itemToDelete by remember { mutableStateOf<Any?>(null) } // ScannedVideo or String (folder path)

    // Trigger analysis when scanned videos change
    LaunchedEffect(scannedVideos) {
        storageViewModel.analyzeStorage(scannedVideos)
    }

    val customBgUri by viewModel.customBackgroundUri.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(60.dp))

            // Header block
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (activeViewMode != StorageViewMode.DASHBOARD) {
                    IconButton(
                        onClick = { activeViewMode = StorageViewMode.DASHBOARD },
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .background(Color.White.copy(alpha = 0.05f), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                }

                Column {
                    Text(
                        text = when (activeViewMode) {
                            StorageViewMode.DASHBOARD -> "Storage Center"
                            StorageViewMode.LARGE_FILES -> "Large File Finder"
                            StorageViewMode.DUPLICATES -> "Duplicate Detector"
                            StorageViewMode.EMPTY_FOLDERS -> "Empty Folder Finder"
                            StorageViewMode.RECENT_DOWNLOADS -> "Recent Downloads"
                            StorageViewMode.CAPTURED_FRAMES -> "Captured Frames"
                        },
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    GlowText(
                        text = when (activeViewMode) {
                            StorageViewMode.DASHBOARD -> "Premium Media & Storage Optimizer"
                            StorageViewMode.LARGE_FILES -> "Easily locate and clean space hogs"
                            StorageViewMode.DUPLICATES -> "Find identical video copies"
                            StorageViewMode.EMPTY_FOLDERS -> "Clear empty directories instantly"
                            StorageViewMode.RECENT_DOWNLOADS -> "Check recent download files"
                            StorageViewMode.CAPTURED_FRAMES -> "Browse and manage saved video frames"
                        },
                        color = ElectricBlue,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (isAnalyzing) {
                // Elegant loading shimmer/placeholder
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(
                            color = ElectricBlue,
                            strokeWidth = 4.dp,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Analyzing Storage Engine...",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Processing duplicates, files and empty folders...",
                            color = Color.DarkGray,
                            fontSize = 11.sp
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (activeViewMode) {
                        StorageViewMode.DASHBOARD -> {
                            DashboardView(
                                stats = stats,
                                insights = insights,
                                largeVideos = largeVideos,
                                duplicateGroups = duplicateGroups,
                                emptyFolders = emptyFolders,
                                scannedVideos = scannedVideos,
                                capturedFramesCount = capturedFrames.size,
                                onNavigateTo = { activeViewMode = it }
                            )
                        }
                        StorageViewMode.LARGE_FILES -> {
                            LargeFilesView(
                                largeVideos = largeVideos,
                                sizeFilter = sizeFilter,
                                onSizeFilterChanged = { sizeFilter = it },
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.DUPLICATES -> {
                            DuplicatesView(
                                duplicateGroups = duplicateGroups,
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.EMPTY_FOLDERS -> {
                            EmptyFoldersView(
                                emptyFolders = emptyFolders,
                                onDeleteFolder = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.RECENT_DOWNLOADS -> {
                            RecentDownloadsView(
                                scannedVideos = scannedVideos,
                                onPlayVideo = { video ->
                                    val mediaEntity = MediaStoreViewModel.run { video.toMediaEntity() }
                                    viewModel.playMedia(mediaEntity)
                                },
                                onDeleteVideo = { itemToDelete = it }
                            )
                        }
                        StorageViewMode.CAPTURED_FRAMES -> {
                            CapturedFramesView(
                                capturedFrames = capturedFrames,
                                onOpenFrame = { frame ->
                                    try {
                                        val file = java.io.File(frame.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "image/*")
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "No app found to open images: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onShareFrame = { frame ->
                                    try {
                                        val file = java.io.File(frame.filePath)
                                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.example.fileprovider", file)
                                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                                            type = "image/*"
                                            putExtra(android.content.Intent.EXTRA_STREAM, uri)
                                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(android.content.Intent.createChooser(intent, "Share Captured Frame"))
                                    } catch (e: Exception) {
                                        Toast.makeText(context, "Sharing failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                onDeleteFrame = { frame ->
                                    viewModel.deleteCapturedFrame(frame)
                                    Toast.makeText(context, "Deleted captured frame", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }

        // Deletion Confirmation Dialog
        itemToDelete?.let { item ->
            AlertDialog(
                onDismissRequest = { itemToDelete = null },
                title = {
                    Column {
                        Text(
                            text = "Confirm Deletion",
                            color = Color.White,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "This action is safe & supports 5-second undo",
                            color = ElectricBlue,
                            fontSize = 11.sp
                        )
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "Are you sure you want to delete this?",
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        when (item) {
                            is ScannedVideo -> {
                                Text(
                                    text = "Video: ${item.title}",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Size: ${MediaStoreViewModel.formatSize(item.size)}",
                                    color = Color.Gray,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Path: ${item.path}",
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            is String -> {
                                Text(
                                    text = "Folder: ${File(item).name}",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Path: $item",
                                    color = Color.DarkGray,
                                    fontSize = 10.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            when (item) {
                                is ScannedVideo -> storageViewModel.requestDeleteVideo(item)
                                is String -> storageViewModel.requestDeleteFolder(item)
                            }
                            itemToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text("Delete", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { itemToDelete = null }) {
                        Text("Cancel", color = Color.Gray)
                    }
                },
                containerColor = Color(0xFF121212)
            )
        }

        // Undo Overlay Banner
        pendingDeletion?.let { deletion ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 100.dp, start = 16.dp, end = 16.dp)
            ) {
                GlassCard(
                    cornerRadius = 16.dp,
                    borderWidth = 1.dp,
                    glowing = true,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = when (deletion) {
                                    is DeletionItem.Video -> "Deleting video..."
                                    is DeletionItem.Folder -> "Deleting empty folder..."
                                },
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = when (deletion) {
                                    is DeletionItem.Video -> deletion.video.title
                                    is DeletionItem.Folder -> File(deletion.path).name
                                },
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            // Countdown progress bar
                            LinearProgressIndicator(
                                progress = { undoCountdown / 5f },
                                color = ElectricBlue,
                                trackColor = Color.White.copy(alpha = 0.1f),
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .height(3.dp)
                                    .clip(RoundedCornerShape(2.dp))
                            )
                        }
                        GlassButton(
                            onClick = { storageViewModel.undoDeletion() },
                            text = "UNDO",
                            glowColor = ElectricBlue,
                            cornerRadius = 12.dp,
                            modifier = Modifier.height(40.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardView(
    stats: StorageStats,
    insights: StorageInsights,
    largeVideos: List<ScannedVideo>,
    duplicateGroups: List<DuplicateGroup>,
    emptyFolders: List<String>,
    scannedVideos: List<ScannedVideo>,
    capturedFramesCount: Int,
    onNavigateTo: (StorageViewMode) -> Unit
) {
    val usedPercent = if (stats.totalStorage > 0) stats.usedStorage.toFloat() / stats.totalStorage.toFloat() else 0f
    val sweepAngle = 270f * usedPercent
    val animatedSweepAngle by animateFloatAsState(
        targetValue = sweepAngle,
        animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
        label = "MainGaugeSweep"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // 1. Storage circular gauge indicators
        item {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Device Storage Hub",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    if (stats.sdCardAvailable) {
                        // Dual side-by-side circular indicators for Internal vs SD Card
                        val intUsedPercent = if (stats.totalInternal > 0) stats.usedInternal.toFloat() / stats.totalInternal.toFloat() else 0f
                        val sdUsedPercent = if (stats.totalSdCard > 0) stats.usedSdCard.toFloat() / stats.totalSdCard.toFloat() else 0f

                        val animIntSweep by animateFloatAsState(
                            targetValue = 270f * intUsedPercent,
                            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                            label = "InternalGauge"
                        )
                        val animSdSweep by animateFloatAsState(
                            targetValue = 270f * sdUsedPercent,
                            animationSpec = tween(durationMillis = 1000, easing = FastOutSlowInEasing),
                            label = "SdGauge"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Internal
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                                    Canvas(modifier = Modifier.size(90.dp)) {
                                        drawArc(
                                            color = Color.White.copy(alpha = 0.05f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            brush = Brush.sweepGradient(listOf(ElectricBlue, RoyalPurple, ElectricBlue)),
                                            startAngle = 135f,
                                            sweepAngle = animIntSweep,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Text("${(intUsedPercent * 100).toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Internal", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${MediaStoreViewModel.formatSize(stats.usedInternal)} / ${MediaStoreViewModel.formatSize(stats.totalInternal)}",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }

                            // SD Card
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(110.dp)) {
                                    Canvas(modifier = Modifier.size(90.dp)) {
                                        drawArc(
                                            color = Color.White.copy(alpha = 0.05f),
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            brush = Brush.sweepGradient(listOf(RoyalPurple, ElectricBlue, RoyalPurple)),
                                            startAngle = 135f,
                                            sweepAngle = animSdSweep,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Text("${(sdUsedPercent * 100).toInt()}%", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("SD Card", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    text = "${MediaStoreViewModel.formatSize(stats.usedSdCard)} / ${MediaStoreViewModel.formatSize(stats.totalSdCard)}",
                                    color = Color.Gray,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    } else {
                        // Large circular indicator for total internal storage
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.size(150.dp)
                        ) {
                            Canvas(modifier = Modifier.size(130.dp)) {
                                drawArc(
                                    color = Color.White.copy(alpha = 0.05f),
                                    startAngle = 135f,
                                    sweepAngle = 270f,
                                    useCenter = false,
                                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                )
                                drawArc(
                                    brush = Brush.sweepGradient(
                                        colors = listOf(ElectricBlue, RoyalPurple, ElectricBlue)
                                    ),
                                    startAngle = 135f,
                                    sweepAngle = animatedSweepAngle,
                                    useCenter = false,
                                    style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${(usedPercent * 100).toInt()}%", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Used Space", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${MediaStoreViewModel.formatSize(stats.usedStorage)} used of ${MediaStoreViewModel.formatSize(stats.totalStorage)}",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Detailed Legend with dynamic storage partitions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        LegendItem("Videos", MediaStoreViewModel.formatSize(insights.totalVideoSize), ElectricBlue)
                        LegendItem("Free Space", MediaStoreViewModel.formatSize(stats.freeStorage), RoyalPurple)
                        LegendItem("Other Files", MediaStoreViewModel.formatSize(maxOf(0L, stats.usedStorage - insights.totalVideoSize)), Color.Gray)
                    }
                }
            }
        }

        // 2. Quick Actions Shortcuts
        item {
            Text(
                text = "Smart Storage Actions",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    QuickActionCard(
                        title = "Large Files",
                        subtitle = "${largeVideos.size} items detect",
                        icon = Icons.Rounded.Storage,
                        tint = Color(0xFF00D9FF),
                        onClick = { onNavigateTo(StorageViewMode.LARGE_FILES) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Duplicates",
                        subtitle = "${duplicateGroups.size} groups found",
                        icon = Icons.Rounded.FileCopy,
                        tint = Color(0xFFFF9800),
                        onClick = { onNavigateTo(StorageViewMode.DUPLICATES) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Empty Folders",
                        subtitle = "${emptyFolders.size} empty folders",
                        icon = Icons.Rounded.FolderOff,
                        tint = Color(0xFFFF2E93),
                        onClick = { onNavigateTo(StorageViewMode.EMPTY_FOLDERS) }
                    )
                }
                item {
                    // Filter recent downloads
                    val recentDownloadCount = scannedVideos.filter {
                        it.path.contains("Download", ignoreCase = true)
                    }.size
                    QuickActionCard(
                        title = "Downloads",
                        subtitle = "$recentDownloadCount downloaded",
                        icon = Icons.Rounded.Download,
                        tint = Color(0xFF00FFCC),
                        onClick = { onNavigateTo(StorageViewMode.RECENT_DOWNLOADS) }
                    )
                }
                item {
                    QuickActionCard(
                        title = "Captured Frames",
                        subtitle = "$capturedFramesCount frames",
                        icon = Icons.Rounded.PhotoCamera,
                        tint = Color(0xFF7C4DFF),
                        onClick = { onNavigateTo(StorageViewMode.CAPTURED_FRAMES) }
                    )
                }
            }
        }

        // 3. Storage Insights
        item {
            Text(
                text = "Storage Insights",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                InsightCardRow("Total Video Count", "${insights.totalVideoCount} files", Icons.Rounded.VideoLibrary, Color(0xFF00D9FF))
                InsightCardRow("Total Video Size", MediaStoreViewModel.formatSize(insights.totalVideoSize), Icons.Rounded.Storage, Color(0xFF00FFCC))
                InsightCardRow("Average Video Size", MediaStoreViewModel.formatSize(insights.averageVideoSize), Icons.Rounded.DataUsage, Color(0xFFFF9800))
                InsightCardRow("Largest Video", "${insights.largestVideo} (${MediaStoreViewModel.formatSize(insights.largestVideoSize)})", Icons.Rounded.Movie, Color(0xFFFF2E93))
                InsightCardRow("Largest Folder", "${insights.largestFolder} (${MediaStoreViewModel.formatSize(insights.largestFolderSize)})", Icons.Rounded.FolderSpecial, Color(0xFF7C4DFF))
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color = ElectricBlue,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "QuickActionScale"
    )

    Box(
        modifier = Modifier
            .width(130.dp)
            .height(120.dp)
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.Start
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tint.copy(alpha = 0.12f), CircleShape)
                        .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = tint,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = subtitle,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun InsightCardRow(
    label: String,
    value: String,
    icon: ImageVector,
    tint: Color = RoyalPurple
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(tint.copy(alpha = 0.12f), CircleShape)
                        .border(1.5.dp, tint.copy(alpha = 0.25f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = tint,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = label,
                    color = Color.LightGray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }
            Text(
                text = value,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f, fill = false)
                    .padding(start = 16.dp)
            )
        }
    }
}

@Composable
fun LargeFilesView(
    largeVideos: List<ScannedVideo>,
    sizeFilter: Long,
    onSizeFilterChanged: (Long) -> Unit,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    val filteredList = remember(largeVideos, sizeFilter) {
        largeVideos.filter { it.size >= sizeFilter }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Size filters Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val sizes = listOf(
                500L * 1024 * 1024 to "500 MB+",
                1024L * 1024 * 1024 to "1 GB+",
                2L * 1024 * 1024 * 1024 to "2 GB+",
                5L * 1024 * 1024 * 1024 to "5 GB+"
            )
            sizes.forEach { (bytes, label) ->
                val active = sizeFilter == bytes
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (active) ElectricBlue else Color.White.copy(alpha = 0.05f))
                        .clickable { onSizeFilterChanged(bytes) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = label,
                        color = if (active) Color.Black else Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No large files found matching this filter",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredList, key = { it.id }) { video ->
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.DarkGray.copy(alpha = 0.3f))
                                    .clickable { onPlayVideo(video) }
                            ) {
                                AsyncImage(
                                    model = video.thumbnailUrl,
                                    contentDescription = video.title,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Icon(
                                    imageVector = Icons.Rounded.PlayArrow,
                                    contentDescription = "Preview",
                                    tint = Color.White,
                                    modifier = Modifier.align(Alignment.Center)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = video.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Size: ${MediaStoreViewModel.formatSize(video.size)}",
                                    color = ElectricBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Path: ${video.path}",
                                    color = Color.Gray,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { onDeleteVideo(video) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Delete",
                                    tint = Color.Red.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DuplicatesView(
    duplicateGroups: List<DuplicateGroup>,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    if (duplicateGroups.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.CheckCircleOutline,
                    contentDescription = "Clean",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "Zero Duplicates Found!",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Your library is clean and perfectly optimized.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(duplicateGroups) { group ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Duplicate Set",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "File size: ${MediaStoreViewModel.formatSize(group.size)}",
                                    color = ElectricBlue,
                                    fontSize = 11.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ElectricBlue.copy(alpha = 0.1f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${group.videos.size} copies",
                                    color = ElectricBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        group.videos.forEach { video ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.DarkGray)
                                        .clickable { onPlayVideo(video) }
                                ) {
                                    AsyncImage(
                                        model = video.thumbnailUrl,
                                        contentDescription = video.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Icon(
                                        imageVector = Icons.Rounded.PlayArrow,
                                        contentDescription = "Play",
                                        tint = Color.White,
                                        modifier = Modifier.align(Alignment.Center)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = video.title,
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = video.path,
                                        color = Color.Gray,
                                        fontSize = 9.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                IconButton(
                                    onClick = { onDeleteVideo(video) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Delete,
                                        contentDescription = "Delete copy",
                                        tint = Color.Red.copy(alpha = 0.8f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyFoldersView(
    emptyFolders: List<String>,
    onDeleteFolder: (String) -> Unit
) {
    if (emptyFolders.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.FolderSpecial,
                    contentDescription = "Clean",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Empty Folders Found",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "All folder hierarchies contain active media resources.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "The following directories contain no recognized media files:",
                color = Color.Gray,
                fontSize = 11.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(emptyFolders, key = { it }) { path ->
                    val name = File(path).name
                    GlassCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.FolderOff,
                                        contentDescription = name,
                                        tint = Color.Red.copy(alpha = 0.8f)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = path,
                                        color = Color.Gray,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton(
                                onClick = { onDeleteFolder(path) }
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Delete empty folder",
                                    tint = Color.Red
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RecentDownloadsView(
    scannedVideos: List<ScannedVideo>,
    onPlayVideo: (ScannedVideo) -> Unit,
    onDeleteVideo: (ScannedVideo) -> Unit
) {
    val downloadVideos = remember(scannedVideos) {
        scannedVideos.filter { it.path.contains("Download", ignoreCase = true) }
            .sortedByDescending { it.dateAdded }
    }

    if (downloadVideos.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Rounded.DownloadDone,
                    contentDescription = "Downloads",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No Downloaded Videos",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "No video files found inside your Download directories.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(downloadVideos, key = { it.id }) { video ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.DarkGray.copy(alpha = 0.3f))
                                .clickable { onPlayVideo(video) }
                        ) {
                            AsyncImage(
                                model = video.thumbnailUrl,
                                contentDescription = video.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                              )
                              Icon(
                                  imageVector = Icons.Rounded.PlayArrow,
                                  contentDescription = "Preview",
                                  tint = Color.White,
                                  modifier = Modifier.align(Alignment.Center)
                              )
                          }
                          Spacer(modifier = Modifier.width(12.dp))
                          Column(modifier = Modifier.weight(1f)) {
                              Text(
                                  text = video.title,
                                  color = Color.White,
                                  fontWeight = FontWeight.Bold,
                                  fontSize = 13.sp,
                                  maxLines = 1,
                                  overflow = TextOverflow.Ellipsis
                              )
                              Text(
                                  text = MediaStoreViewModel.formatSize(video.size),
                                  color = ElectricBlue,
                                  fontSize = 11.sp,
                                  fontWeight = FontWeight.Bold
                              )
                              Text(
                                  text = video.path,
                                  color = Color.Gray,
                                  fontSize = 9.sp,
                                  maxLines = 1,
                                  overflow = TextOverflow.Ellipsis
                              )
                          }
                          IconButton(
                              onClick = { onDeleteVideo(video) }
                          ) {
                              Icon(
                                  imageVector = Icons.Rounded.Delete,
                                  contentDescription = "Delete download",
                                  tint = Color.Red.copy(alpha = 0.8f)
                              )
                          }
                      }
                  }
              }
          }
      }
  }

@Composable
fun StorageAnalysisCompactCard(onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("storage_compact_card")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Storage, contentDescription = "Storage Analyzer", tint = ElectricBlue, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Storage Usage 66%", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("84.2 GB used of 128 GB", color = Color.Gray, fontSize = 11.sp)
                }
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = "View details", tint = Color.Gray)
        }
    }
}

@Composable
fun LegendItem(label: String, size: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(label, color = Color.Gray, fontSize = 11.sp)
        }
        Text(size, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun FolderRow(name: String, count: String, size: String, icon: ImageVector) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = name, tint = ElectricBlue)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(count, color = Color.Gray, fontSize = 11.sp)
                }
            }
            Text(size, color = ElectricBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

// ==========================================
// REDESIGNED SETTINGS SCREEN (ME SCREEN)
// ==========================================

@Composable
fun DownloadsDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(28.dp)) {
            val w = size.width
            val h = size.height
            val path = androidx.compose.ui.graphics.Path().apply {
                moveTo(w * 0.2f, h * 0.6f)
                lineTo(w * 0.2f, h * 0.8f)
                lineTo(w * 0.8f, h * 0.8f)
                lineTo(w * 0.8f, h * 0.6f)
            }
            drawPath(
                path = path,
                color = Color(0xFF10B981),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
            )
        }
        Icon(
            imageVector = Icons.Rounded.ArrowDownward,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(18.dp).offset(y = (-3).dp)
        )
    }
}

@Composable
fun Mp3ConverterDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Headphones,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(26.dp)
        )
        Icon(
            imageVector = Icons.Rounded.MusicNote,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(12.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun Mp3ConverterRewardedAdModal(
    appLang: String,
    onRewardEarned: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isWatchingAd by remember { mutableStateOf(false) }
    var adSecondsRemaining by remember { mutableIntStateOf(8) }
    var isRewardUnlocked by remember { mutableStateOf(false) }

    LaunchedEffect(isWatchingAd) {
        if (isWatchingAd) {
            adSecondsRemaining = 8
            while (adSecondsRemaining > 0) {
                kotlinx.coroutines.delay(1000)
                adSecondsRemaining -= 1
            }
            isRewardUnlocked = true
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "mp3_reward_anim")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val rotateAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(6000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotate"
    )
    val buttonGlowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    androidx.compose.ui.window.Dialog(
        onDismissRequest = {
            if (isWatchingAd) {
                if (isRewardUnlocked) {
                    onRewardEarned()
                } else {
                    android.widget.Toast.makeText(
                        context,
                        if (appLang == "hi") "पूरा वीडियो विज्ञापन देखें!" else "Please watch full video ad!",
                        android.widget.Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                onDismiss()
            }
        },
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFF13131A),
            tonalElevation = 8.dp,
            shadowElevation = 16.dp,
            border = BorderStroke(
                1.5.dp, Brush.horizontalGradient(
                    listOf(Color(0xFFFF5722), Color(0xFFFF007A), Color(0xFF9C27B0))
                )
            )
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Top-Right Close Button [X]
                IconButton(
                    onClick = {
                        if (isWatchingAd) {
                            if (isRewardUnlocked) {
                                onRewardEarned()
                            } else {
                                android.widget.Toast.makeText(
                                    context,
                                    if (appLang == "hi") "पूरा वीडियो देखें। विज्ञापन बीच में बंद नहीं किया जा सकता।" else "Please watch full 8s ad to unlock!",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                            }
                        } else {
                            onDismiss()
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .size(36.dp)
                        .background(Color.White.copy(alpha = 0.1f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Close",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                if (!isWatchingAd) {
                    // MODAL PRE-WATCH UI
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(8.dp))

                        // Animated Video / Reward Icon Badge
                        Box(
                            modifier = Modifier.size(100.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(90.dp)
                                    .graphicsLayer(rotationZ = rotateAngle, scaleX = scale, scaleY = scale)
                                    .background(
                                        brush = Brush.sweepGradient(
                                            listOf(
                                                Color(0xFFFF5722),
                                                Color(0xFFFF007A),
                                                Color(0xFF9C27B0),
                                                Color(0xFF00E5FF),
                                                Color(0xFFFF5722)
                                            )
                                        ),
                                        shape = CircleShape
                                    )
                            )
                            Box(
                                modifier = Modifier
                                    .size(76.dp)
                                    .background(Color(0xFF1A1A26), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.OndemandVideo,
                                    contentDescription = "Watch Video Ad",
                                    tint = Color(0xFFFF007A),
                                    modifier = Modifier
                                        .size(40.dp)
                                        .graphicsLayer(scaleX = scale, scaleY = scale)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = Color(0xFFFF007A).copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, Color(0xFFFF007A).copy(alpha = 0.3f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Stars,
                                    contentDescription = null,
                                    tint = Color(0xFFFFD700),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (appLang == "hi") "Start.io रीवर्ड ऑफर" else "Start.io Reward Offer",
                                    color = Color(0xFFFFD700),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = if (appLang == "hi")
                                "एक विज्ञापन देखें और पाएँ 1-Time असीमित MP3 कनवर्टर"
                            else
                                "Watch 1 Ad & Get 1-Time Unlimited MP3 Converter",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Center,
                            lineHeight = 24.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (appLang == "hi")
                                "1 वीडियो विज्ञापन देखकर इस सेशन के लिए असीमित MP3 कनवर्टर अनलॉक करें।"
                            else
                                "Watch 1 quick video ad to unlock fast, high-quality audio extraction instantly.",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(22.dp))

                        Button(
                            onClick = {
                                isWatchingAd = true
                                com.example.utils.StartAppInterstitialHelper.showRewardedVideoAd(context) {
                                    isRewardUnlocked = true
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .graphicsLayer(scaleX = scale),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                            contentPadding = PaddingValues()
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        brush = Brush.horizontalGradient(
                                            listOf(
                                                Color(0xFFFF5722),
                                                Color(0xFFFF007A),
                                                Color(0xFF9C27B0)
                                            )
                                        ),
                                        shape = RoundedCornerShape(16.dp)
                                    )
                                    .border(
                                        1.5.dp,
                                        Color.White.copy(alpha = buttonGlowAlpha),
                                        RoundedCornerShape(16.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.PlayCircle,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (appLang == "hi")
                                            "🎬 1 विज्ञापन देखें और अनलॉक करें"
                                        else
                                            "🎬 Watch Video Ad to Unlock",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        TextButton(
                            onClick = onDismiss
                        ) {
                            Text(
                                text = if (appLang == "hi") "बाद में (Later)" else "Maybe Later",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                        }
                    }
                } else {
                    // REWARDED VIDEO AD PLAYER INTERACTIVE OVERLAY
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFFFD700),
                                contentColor = Color.Black
                            ) {
                                Text(
                                    text = "AD",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "Start.io Sponsored Video",
                                color = Color.Gray,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Video Frame Preview
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    brush = Brush.verticalGradient(
                                        listOf(Color(0xFF2A0845), Color(0xFF6441A5))
                                    )
                                )
                                .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayCircleFilled,
                                    contentDescription = null,
                                    tint = Color.White.copy(alpha = 0.9f),
                                    modifier = Modifier
                                        .size(56.dp)
                                        .graphicsLayer(scaleX = scale, scaleY = scale)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Vidiopen Ultra HD Converter",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (appLang == "hi") "सुपरफ़ास्ट MP3 निष्कर्षण तकनीक" else "Superfast MP3 Extraction Tech",
                                    color = Color.White.copy(alpha = 0.7f),
                                    fontSize = 11.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Progress Bar
                        val progress = ((8 - adSecondsRemaining) / 8f).coerceIn(0f, 1f)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.15f))
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(progress)
                                    .background(
                                        brush = Brush.horizontalGradient(
                                            listOf(Color(0xFFFF5722), Color(0xFFFF007A))
                                        )
                                    )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (isRewardUnlocked) {
                            Text(
                                text = if (appLang == "hi") "🎉 रीवर्ड अनलॉक हुआ! ऊपर का [X] बटन दबाएँ या नीचे क्लेम करें।" else "🎉 Reward Unlocked! Tap top-right [X] button or Claim below.",
                                color = Color(0xFF10B981),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = if (appLang == "hi") "⏳ रीवर्ड ${adSecondsRemaining} सेकेण्ड में अनलॉक होगा..." else "⏳ Reward unlocking in ${adSecondsRemaining}s...",
                                color = Color(0xFFFFD700),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (isRewardUnlocked) {
                                    onRewardEarned()
                                } else {
                                    android.widget.Toast.makeText(
                                        context,
                                        if (appLang == "hi") "कृपया पूरा ${adSecondsRemaining} सेकेण्ड वीडियो विज्ञापन देखें" else "Please watch full ${adSecondsRemaining}s video ad",
                                        android.widget.Toast.LENGTH_SHORT
                                    ).show()
                                }
                            },
                            enabled = isRewardUnlocked,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isRewardUnlocked) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                contentColor = Color.White,
                                disabledContainerColor = Color.White.copy(alpha = 0.1f),
                                disabledContentColor = Color.Gray
                            )
                        ) {
                            Text(
                                text = if (isRewardUnlocked) {
                                    if (appLang == "hi") "✅ अनलॉक करें और जारी रखें [X]" else "✅ Claim Reward & Exit [X]"
                                } else {
                                    if (appLang == "hi") "🎬 वीडियो चल रहा है (${adSecondsRemaining}s)" else "🎬 Playing Video Ad (${adSecondsRemaining}s)"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Icon(
            imageVector = Icons.Rounded.Lock,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(11.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun FileTransferDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Icon(
            imageVector = Icons.Rounded.SwapHoriz,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(14.dp).offset(y = 2.dp)
        )
    }
}

@Composable
fun MediaManageDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.FolderOpen,
            contentDescription = null,
            tint = Color(0xFF10B981),
            modifier = Modifier.size(28.dp)
        )
        Canvas(modifier = Modifier.size(12.dp)) {
            val w = size.width
            val h = size.height
            drawLine(
                color = Color.White,
                start = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.5f),
                end = androidx.compose.ui.geometry.Offset(w * 0.8f, h * 0.5f),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = Color.White,
                start = androidx.compose.ui.geometry.Offset(w * 0.2f, h * 0.8f),
                end = androidx.compose.ui.geometry.Offset(w * 0.6f, h * 0.8f),
                strokeWidth = 2.dp.toPx()
            )
        }
    }
}

@Composable
fun TShirtIconComposed() {
    Canvas(modifier = Modifier.size(28.dp)) {
        val w = size.width
        val h = size.height
        val path = androidx.compose.ui.graphics.Path().apply {
            moveTo(w * 0.35f, h * 0.15f)
            quadraticTo(w * 0.5f, h * 0.25f, w * 0.65f, h * 0.15f)
            lineTo(w * 0.8f, h * 0.25f)
            lineTo(w * 0.95f, h * 0.45f)
            lineTo(w * 0.8f, h * 0.55f)
            lineTo(w * 0.75f, h * 0.5f)
            lineTo(w * 0.75f, h * 0.85f)
            lineTo(w * 0.25f, h * 0.85f)
            lineTo(w * 0.25f, h * 0.5f)
            lineTo(w * 0.2f, h * 0.55f)
            lineTo(w * 0.05f, h * 0.45f)
            lineTo(w * 0.2f, h * 0.25f)
            close()
        }
        drawPath(
            path = path,
            color = Color.White,
            style = androidx.compose.ui.graphics.drawscope.Fill
        )
        drawPath(
            path = path,
            color = Color(0xFF10B981),
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.dp.toPx())
        )
    }
}

@Composable
fun ThemeDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        TShirtIconComposed()
    }
}

@Composable
fun HistoryDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.History,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
        Box(
            modifier = Modifier
                .size(4.dp)
                .background(Color(0xFF10B981), CircleShape)
        )
    }
}

@Composable
fun AdFreeGiftDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Icon(
            imageVector = Icons.Rounded.Block,
            contentDescription = null,
            tint = Color(0xFFFF9800),
            modifier = Modifier.size(26.dp)
        )
        Text(
            text = "AD",
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.offset(y = (-1).dp)
        )
    }
}

@Composable
fun CleanDualIcon() {
    Box(modifier = Modifier.size(36.dp), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Color.White.copy(alpha = 0.3f),
                radius = size.minDimension / 2.2f,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.5.dp.toPx())
              )
              drawCircle(
                  color = Color(0xFF10B981),
                  radius = size.minDimension / 2.2f,
                  style = androidx.compose.ui.graphics.drawscope.Stroke(
                      width = 2.5.dp.toPx(),
                      pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                  )
              )
          }
          Text(
              text = "87%",
              color = Color.White,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold
          )
      }
  }

@Composable
fun MeGridItem(
    title: String,
    showNewBadge: Boolean = false,
    badgeText: String? = null,
    icon: @Composable () -> Unit,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                icon()
                
                if (showNewBadge) {
                    Box(
                        modifier = Modifier
                            .offset(x = 12.dp, y = (-4).dp)
                            .background(Color(0xFFEF4444), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = badgeText ?: "NEW",
                            color = Color.White,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                maxLines = 2,
                lineHeight = 14.sp
            )
        }
    }
}

@Composable
fun MeListRow(
    title: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White.copy(alpha = 0.85f),
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = Icons.Rounded.ChevronRight,
                contentDescription = null,
                tint = Color.Gray.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp)
            )
        }
        Divider(
            color = Color.White.copy(alpha = 0.08f),
            thickness = 0.5.dp,
            modifier = Modifier.padding(start = 42.dp)
        )
    }
}

@Composable
fun MadeInIndiaSection() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_animation")
    
    // Smooth breathing scale animation
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier
                .graphicsLayer(
                    scaleX = scale,
                    scaleY = scale,
                    clip = false
                )
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color(0xFFFF9933).copy(alpha = 0.12f), // Beautiful Saffron glow
                            Color(0xFF128807).copy(alpha = 0.12f), // Beautiful Green glow
                            Color.Transparent
                        )
                    )
                )
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            // Elegant Vector Indian Flag
            Box(
                modifier = Modifier
                    .size(width = 24.dp, height = 16.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .border(0.5.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(2.dp))
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Saffron Row
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFFFF9933))
                    )
                    // White Row with blue Ashoka Chakra
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(4.dp)) {
                            drawCircle(
                                color = Color(0xFF000080),
                                radius = size.minDimension / 2f,
                                style = Stroke(width = 0.8f)
                            )
                        }
                    }
                    // Green Row
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .background(Color(0xFF128807))
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Premium bold letter-spaced text
            Text(
                text = "MADE IN INDIA",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.5.sp,
                    fontSize = 11.sp
                ),
                color = Color.White.copy(alpha = 0.9f)
            )
        }
        
        Spacer(modifier = Modifier.height(4.dp))
        
        Text(
            text = "Vidiopen Luxury Edition",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 9.sp,
                letterSpacing = 1.2.sp
            )
        )
    }
}

@Composable
fun SettingsScreen(
    viewModel: MediaViewModel,
    musicViewModel: MusicViewModel,
    onNavigateToSection: (String) -> Unit = {},
    onOpenVault: () -> Unit = {}
) {
    val customBgUri by viewModel.customBackgroundUri.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val context = LocalContext.current
    val appLang by viewModel.appLanguage.collectAsState()

    var realAppCacheSize by remember { mutableStateOf(calculateRealAppCacheSize(context)) }
    val sessionJunkSeed = remember { 
        (java.util.Random(System.currentTimeMillis()).nextInt(330) + 120) * 1024L * 1024L
    }
    var isCleanedState by remember { mutableStateOf(false) }
    val totalJunkBytes = if (isCleanedState) 0L else (realAppCacheSize + sessionJunkSeed)
    val totalJunkText = if (isCleanedState) "0.00 MB" else formatBytesToSizeString(totalJunkBytes)

    // Dialog state controllers
    var showDownloadsDialog by remember { mutableStateOf(false) }
    var showMp3ConverterDialog by remember { mutableStateOf(false) }
    var isMp3ConverterUnlocked by remember { mutableStateOf(false) }
    var showMp3RewardedAdModal by remember { mutableStateOf(false) }
    var showPinDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showHistoryDialog by remember { mutableStateOf(false) }
    var showCleanDialog by remember { mutableStateOf(false) }
    var showSettingsDetailsDialog by remember { mutableStateOf(false) }
    var showRecycleBinDialog by remember { mutableStateOf(false) }
    var showRateUsDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }

    val isAnySettingsDialogOpen = showDownloadsDialog || showMp3ConverterDialog || showPinDialog ||
            showPrivacyDialog || showThemeDialog || showHistoryDialog || showCleanDialog ||
            showRecycleBinDialog || showRateUsDialog || showAboutDialog || showLanguageDialog

    androidx.activity.compose.BackHandler(enabled = isAnySettingsDialogOpen) {
        showDownloadsDialog = false
        showMp3ConverterDialog = false
        showPinDialog = false
        showPrivacyDialog = false
        showThemeDialog = false
        showHistoryDialog = false
        showCleanDialog = false
        showRecycleBinDialog = false
        showRateUsDialog = false
        showAboutDialog = false
        showLanguageDialog = false
    }

    // Logic and data models
    val allMedia by viewModel.allMedia.collectAsState()
    val watchHistory by viewModel.watchHistory.collectAsState()
    val conversionState by viewModel.conversionState.collectAsState()

    var isVaultUnlocked by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }
    var savedPin by remember { mutableStateOf("1234") } // Default PIN
    var isSettingNewPin by remember { mutableStateOf(false) }

    // Theme selector
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val file = java.io.File(context.filesDir, "custom_theme_bg.jpg")
                    file.outputStream().use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                    val localUri = android.net.Uri.fromFile(file).toString()
                    com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                        viewModel.setCustomBackgroundUri(localUri)
                        viewModel.setSelectedThemeId("custom_image")
                        musicViewModel.setCustomThemeImage(localUri)
                        android.widget.Toast.makeText(context, if (appLang == "hi") "कस्टम थीम लागू हो गई है!" else "Custom theme applied successfully!", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                android.widget.Toast.makeText(context, if (appLang == "hi") "छवि लोड करने में विफल" else "Failed to load image", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Support Email Composer Intent
    fun sendSupportEmail() {
        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf("abhayshukla8498@gmail.com"))
                putExtra(Intent.EXTRA_SUBJECT, "Vidiopen Pro - Support Request")
                putExtra(Intent.EXTRA_TEXT, "Hello Developer,\n\nI am using Vidiopen Pro Luxury Edition...")
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "No email app found! Email developer at abhayshukla8498@gmail.com", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Transparent)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 48.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Banner Ad (Me Section)
        item {
            StartAppBannerAd(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp)
            )
        }

        // 1. GRID SECTION (3 Columns, 9 items)
        item {
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                // Row 1
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "डाउनलोड" else "Downloads",
                            icon = { DownloadsDualIcon() }
                        ) {
                            showDownloadsDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "एमपी3 कनवर्टर" else "MP3 Converter",
                            icon = { Mp3ConverterDualIcon() }
                        ) {
                            if (com.example.utils.StartAppInterstitialHelper.isNetworkAvailable(context) && !isMp3ConverterUnlocked) {
                                showMp3RewardedAdModal = true
                            }
                            showMp3ConverterDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "गोपनीयता" else "Privacy",
                            icon = { PrivacyDualIcon() }
                        ) {
                            showPinDialog = true
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 2
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "फ़ाइल ट्रांसफर" else "File Transfer",
                            showNewBadge = true,
                            icon = { FileTransferDualIcon() }
                        ) {
                            onNavigateToSection("wifi_transfer")
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "मीडिया प्रबंधन" else "Media Manage",
                            icon = { MediaManageDualIcon() }
                        ) {
                            onNavigateToSection("files")
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "थीम" else "Theme",
                            icon = { ThemeDualIcon() }
                        ) {
                            com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                showThemeDialog = true
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Row 3
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "इतिहास" else "History",
                            icon = { HistoryDualIcon() }
                        ) {
                            showHistoryDialog = true
                        }
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        MeGridItem(
                            title = if (appLang == "hi") "साफ़ करें" else "Clean",
                            showNewBadge = true,
                            icon = { CleanDualIcon() }
                        ) {
                            showCleanDialog = true
                        }
                    }
                }
            }
        }

        // 3. LIST SECTION
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
            ) {
                MeListRow(
                    title = if (appLang == "hi") "सेटिंग्स (Settings)" else "Settings",
                    icon = Icons.Rounded.Settings
                ) {
                    showSettingsDetailsDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "ऐप की भाषा (App Language)" else "App Language / भाषा",
                    icon = Icons.Rounded.Language
                ) {
                    showLanguageDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "रीसायकल बिन (Recycle Bin)" else "Recycle Bin",
                    icon = Icons.Rounded.DeleteOutline
                ) {
                    com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                        showRecycleBinDialog = true
                    }
                }

                MeListRow(
                    title = if (appLang == "hi") "वीआईपी पाने के लिए साझा करें" else "Share to get VIP",
                    icon = Icons.Rounded.Share
                ) {
                    try {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Vidiopen Pro")
                            putExtra(Intent.EXTRA_TEXT, "Hey, download Vidiopen Pro Luxury Edition - the best private secure player! Offline-only and zero tracker ads!")
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "Share with friends"))
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(context, "Sharing not supported on this device.", android.widget.Toast.LENGTH_SHORT).show()
                    }
                }

                MeListRow(
                    title = if (appLang == "hi") "सहायता और प्रतिक्रिया" else "Help & Feedback",
                    icon = Icons.Rounded.ChatBubbleOutline
                ) {
                    sendSupportEmail()
                }

                MeListRow(
                    title = if (appLang == "hi") "हमें रेट करें (Rate us)" else "Rate us",
                    icon = Icons.Rounded.ThumbUp
                ) {
                    showRateUsDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "गोपनीयता नीति (Privacy Policy)" else "Privacy Policy",
                    icon = Icons.Rounded.Security
                ) {
                    showPrivacyDialog = true
                }

                MeListRow(
                    title = if (appLang == "hi") "इसके बारे में (About)" else "About",
                    icon = Icons.Rounded.Info
                ) {
                    showAboutDialog = true
                }
            }
        }

        item {
            MadeInIndiaSection()
        }
    }

    // ==========================================
    // INTERACTIVE DIALOGS IMPLEMENTATION
    // ==========================================

    // 1. DOWNLOADS DIALOG
    if (showDownloadsDialog) {
        val downloadedMedia = allMedia.filter { it.category == "Downloaded" || it.url.startsWith("file://") }
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showDownloadsDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showDownloadsDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "ऑफ़लाइन डाउनलोड" else "Offline Downloads",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Downloaded Library Files",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(ElectricBlue.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, ElectricBlue.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.CloudDownload,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (downloadedMedia.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Rounded.CloudDownload, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "अभी तक कोई ऑफ़लाइन डाउनलोड नहीं है" else "No offline downloads yet",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "आपके डाउनलोड या कनवर्ट किए गए गाने यहाँ दिखाई देंगे।" else "Your downloaded or converted items will appear here.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 32.dp)
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(downloadedMedia) { video ->
                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                viewModel.playMedia(video)
                                                showDownloadsDialog = false
                                            },
                                        cornerRadius = 14.dp
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(ElectricBlue.copy(alpha = 0.1f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.PlayArrow,
                                                    contentDescription = null,
                                                    tint = ElectricBlue,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = video.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = if (appLang == "hi") "ऑफ़लाइन फ़ाइल • ${video.artist ?: "Unknown"}" else "Offline File • ${video.artist ?: "Unknown"}",
                                                    color = Color.Gray,
                                                    fontSize = 12.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 2. MP3 CONVERTER DIALOG
    if (showMp3ConverterDialog) {
        var selectedVideoIndex by remember { mutableStateOf(-1) }
        var dropdownExpanded by remember { mutableStateOf(false) }

        if (showMp3RewardedAdModal) {
            Mp3ConverterRewardedAdModal(
                appLang = appLang,
                onRewardEarned = {
                    isMp3ConverterUnlocked = true
                    showMp3RewardedAdModal = false
                    val toastMsg = if (appLang == "hi")
                        "🎉 1-टाइम असीमित MP3 कनवर्टर अनलॉक हो गया!"
                    else
                        "🎉 1-Time Unlimited MP3 Converter Unlocked!"
                    android.widget.Toast.makeText(context, toastMsg, android.widget.Toast.LENGTH_LONG).show()
                },
                onDismiss = {
                    showMp3RewardedAdModal = false
                }
            )
        }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { 
                showMp3ConverterDialog = false 
                viewModel.resetConversionState()
            },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { 
                                showMp3ConverterDialog = false 
                                viewModel.resetConversionState()
                            },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "एमपी3 कनवर्टर" else "MP3 Converter",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Extract Audio Track",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(RoyalPurple.copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, RoyalPurple.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Headphones,
                                contentDescription = null,
                                tint = RoyalPurple,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        when (val state = conversionState) {
                            is MediaConversionState.Idle -> {
                                val videos = allMedia.filter { it.category != "Music" }.ifEmpty { allMedia }

                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Header Info Banner
                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (!isMp3ConverterUnlocked && com.example.utils.StartAppInterstitialHelper.isNetworkAvailable(context)) {
                                                    showMp3RewardedAdModal = true
                                                }
                                            },
                                        cornerRadius = 12.dp
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(40.dp)
                                                    .background(
                                                        if (isMp3ConverterUnlocked) Color(0xFF10B981).copy(alpha = 0.15f)
                                                        else Color(0xFFFF007A).copy(alpha = 0.15f),
                                                        CircleShape
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = if (isMp3ConverterUnlocked) Icons.Rounded.CheckCircle else Icons.Rounded.OndemandVideo,
                                                    contentDescription = null,
                                                    tint = if (isMp3ConverterUnlocked) Color(0xFF10B981) else Color(0xFFFF007A),
                                                    modifier = Modifier.size(22.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = if (isMp3ConverterUnlocked) {
                                                        if (appLang == "hi") "✅ 1-Time असीमित MP3 कनवर्टर अनलॉक है" else "✅ 1-Time Unlimited MP3 Converter Unlocked"
                                                    } else {
                                                        if (appLang == "hi") "🎬 एक विज्ञापन देखें और पाएँ 1-Time असीमित MP3 कनवर्टर" else "🎬 Watch 1 Ad & Get 1-Time Unlimited MP3 Converter"
                                                    },
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 13.sp
                                                )
                                                Text(
                                                    text = if (isMp3ConverterUnlocked) {
                                                        if (appLang == "hi") "आप असीमित ऑडियो निष्कर्षण का उपयोग कर सकते हैं" else "You have unlocked 1-time unlimited conversions"
                                                    } else {
                                                        if (appLang == "hi") "अनलॉक करने के लिए यहाँ टैप करें" else "Tap here or watch video ad to unlock"
                                                    },
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // List of Videos
                                    if (videos.isEmpty()) {
                                        Box(
                                            modifier = Modifier.fillMaxSize(),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = if (appLang == "hi") "कोई वीडियो फ़ाइल उपलब्ध नहीं है" else "No video files available",
                                                color = Color.Gray,
                                                fontSize = 14.sp
                                            )
                                        }
                                    } else {
                                        LazyColumn(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalArrangement = Arrangement.spacedBy(10.dp),
                                            contentPadding = PaddingValues(bottom = 24.dp)
                                        ) {
                                            items(videos) { video ->
                                                Card(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable {
                                                            com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 1) {
                                                                viewModel.convertVideoToMp3(
                                                                    videoUrl = video.url,
                                                                    title = video.title,
                                                                    artist = video.artist ?: "Vidiopen Pro",
                                                                    durationMs = video.duration,
                                                                    thumbnailUrl = video.thumbnailUrl
                                                                )
                                                            }
                                                        },
                                                    shape = RoundedCornerShape(12.dp),
                                                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                                                ) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(10.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        // Video Thumbnail with custom loader support
                                                        Box(
                                                            modifier = Modifier
                                                                .size(width = 100.dp, height = 62.dp)
                                                                .clip(RoundedCornerShape(8.dp))
                                                                .background(Color.White.copy(alpha = 0.1f))
                                                        ) {
                                                            val resolvedThumbnail: Any = when (video.thumbnailUrl) {
                                                                "tears_of_steel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg"
                                                                "sintel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg"
                                                                "bunny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg"
                                                                "elephants" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg"
                                                                "cosmic" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg"
                                                                "quantum" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg"
                                                                null, "" -> "https://picsum.photos/seed/${video.id}/400/250"
                                                                else -> {
                                                                    if (video.thumbnailUrl.startsWith("http://") || video.thumbnailUrl.startsWith("https://") || video.thumbnailUrl.startsWith("/") || video.thumbnailUrl.startsWith("content://") || video.thumbnailUrl.startsWith("file://")) {
                                                                        video.thumbnailUrl
                                                                    } else {
                                                                        "https://picsum.photos/seed/${video.id}/400/250"
                                                                    }
                                                                }
                                                            }

                                                            AsyncImage(
                                                                model = resolvedThumbnail,
                                                                contentDescription = video.title,
                                                                contentScale = ContentScale.Crop,
                                                                modifier = Modifier.fillMaxSize()
                                                            )

                                                            // Duration Overlay
                                                            Box(
                                                                modifier = Modifier
                                                                    .align(Alignment.BottomEnd)
                                                                    .padding(4.dp)
                                                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                                            ) {
                                                                Text(
                                                                    text = formatMillis(video.duration),
                                                                    color = Color.White,
                                                                    fontSize = 9.sp,
                                                                    fontWeight = FontWeight.Bold
                                                                )
                                                            }
                                                        }

                                                        Spacer(modifier = Modifier.width(12.dp))

                                                        // Info
                                                        Column(
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Text(
                                                                text = video.title,
                                                                color = Color.White,
                                                                fontSize = 13.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = video.artist ?: "Vidiopen Pro",
                                                                color = Color.Gray,
                                                                fontSize = 11.sp,
                                                                maxLines = 1,
                                                                overflow = TextOverflow.Ellipsis
                                                            )
                                                            Spacer(modifier = Modifier.height(2.dp))
                                                            Text(
                                                                text = video.category,
                                                                color = Color(0xFF10B981),
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold
                                                            )
                                                        }

                                                        Spacer(modifier = Modifier.width(8.dp))

                                                        // Superfast Lightning Action Icon
                                                        Box(
                                                            modifier = Modifier
                                                                .size(36.dp)
                                                                .background(Color(0xFF10B981).copy(alpha = 0.12f), CircleShape)
                                                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.3f), CircleShape),
                                                            contentAlignment = Alignment.Center
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Rounded.Bolt,
                                                                contentDescription = "Convert",
                                                                tint = Color(0xFF10B981),
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            is MediaConversionState.Converting -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    if (state.videoTitle != null) {
                                        // Video Thumbnail and Title Preview Card
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp),
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // Real Video Thumbnail
                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 120.dp, height = 75.dp)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(Color.White.copy(alpha = 0.1f))
                                                ) {
                                                    val resolvedThumbnail: Any = when (state.thumbnailUrl) {
                                                        "tears_of_steel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg"
                                                        "sintel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg"
                                                        "bunny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg"
                                                        "elephants" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg"
                                                        "cosmic" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg"
                                                        "quantum" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg"
                                                        null, "" -> "https://picsum.photos/seed/${state.videoTitle}/400/250"
                                                        else -> {
                                                            if (state.thumbnailUrl.startsWith("http://") || state.thumbnailUrl.startsWith("https://") || state.thumbnailUrl.startsWith("/") || state.thumbnailUrl.startsWith("content://") || state.thumbnailUrl.startsWith("file://")) {
                                                                state.thumbnailUrl
                                                            } else {
                                                                "https://picsum.photos/seed/${state.videoTitle}/400/250"
                                                            }
                                                        }
                                                    }
                                                    AsyncImage(
                                                        model = resolvedThumbnail,
                                                        contentDescription = state.videoTitle,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                                
                                                Spacer(modifier = Modifier.width(16.dp))
                                                
                                                // Real Video Name / Title
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = state.videoTitle ?: "",
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = if (appLang == "hi") "मूल वीडियो" else "Source Video",
                                                        color = Color(0xFF10B981),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    CircularProgressIndicator(
                                        progress = state.progress,
                                        color = Color(0xFF10B981),
                                        trackColor = Color.White.copy(alpha = 0.1f),
                                        modifier = Modifier.size(56.dp)
                                    )
                                    Text(
                                        text = if (appLang == "hi") "कनवर्ट हो रहा है: ${(state.progress * 100).toInt()}%" else "Converting: ${(state.progress * 100).toInt()}%",
                                        color = Color.White,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.statusMessage,
                                        color = Color.Gray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
 
                            is MediaConversionState.Success -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    if (state.videoTitle != null) {
                                        // Successful Video Conversion Preview Card
                                        Card(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 16.dp),
                                            shape = RoundedCornerShape(16.dp),
                                            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.05f)),
                                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.08f))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // Real Video Thumbnail
                                                Box(
                                                    modifier = Modifier
                                                        .size(width = 120.dp, height = 75.dp)
                                                        .clip(RoundedCornerShape(10.dp))
                                                        .background(Color.White.copy(alpha = 0.1f))
                                                ) {
                                                    val resolvedThumbnail: Any = when (state.thumbnailUrl) {
                                                        "tears_of_steel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg"
                                                        "sintel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg"
                                                        "bunny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg"
                                                        "elephants" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg"
                                                        "cosmic" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg"
                                                        "quantum" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg"
                                                        null, "" -> "https://picsum.photos/seed/${state.videoTitle}/400/250"
                                                        else -> {
                                                            if (state.thumbnailUrl.startsWith("http://") || state.thumbnailUrl.startsWith("https://") || state.thumbnailUrl.startsWith("/") || state.thumbnailUrl.startsWith("content://") || state.thumbnailUrl.startsWith("file://")) {
                                                                state.thumbnailUrl
                                                            } else {
                                                                "https://picsum.photos/seed/${state.videoTitle}/400/250"
                                                            }
                                                        }
                                                    }
                                                    AsyncImage(
                                                        model = resolvedThumbnail,
                                                        contentDescription = state.videoTitle,
                                                        contentScale = ContentScale.Crop,
                                                        modifier = Modifier.fillMaxSize()
                                                    )
                                                }
                                                
                                                Spacer(modifier = Modifier.width(16.dp))
                                                
                                                // Real Video Name / Title
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = state.videoTitle ?: "",
                                                        color = Color.White,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        maxLines = 2,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text(
                                                        text = if (appLang == "hi") "कनवर्ट किया गया वीडियो" else "Converted Video Source",
                                                        color = Color(0xFF10B981),
                                                        fontSize = 11.sp,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    Box(
                                        modifier = Modifier
                                            .size(72.dp)
                                            .background(Color(0xFF10B981).copy(alpha = 0.1f), CircleShape)
                                            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF10B981),
                                            modifier = Modifier.size(36.dp)
                                        )
                                    }
                                    Text(
                                        text = if (appLang == "hi") "कनवर्ट पूरा हुआ!" else "Conversion Complete!",
                                        color = Color.White,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.fileName,
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 24.dp)
                                    )
                                    
                                    Button(
                                        onClick = {
                                            val newTrack = MediaEntity(
                                                id = "conv_${System.currentTimeMillis()}",
                                                title = state.fileName.substringBeforeLast("."),
                                                url = state.filePath,
                                                duration = 180000L,
                                                artist = "Converted MP3",
                                                thumbnailUrl = null,
                                                category = "Music"
                                            )
                                            viewModel.playMedia(newTrack)
                                            showMp3ConverterDialog = false
                                            viewModel.resetConversionState()
                                        },
                                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "एमपी3 स्ट्रीम चलाएं" else "Play MP3 Stream",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }

                            is MediaConversionState.Error -> {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(vertical = 48.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = Color.Red, modifier = Modifier.size(64.dp))
                                    Text(
                                        text = if (appLang == "hi") "निकालने में विफल" else "Extraction Failed",
                                        color = Color.Red,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = state.errorMessage,
                                        color = Color.Gray,
                                        fontSize = 12.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    
                                    Button(
                                        onClick = { viewModel.resetConversionState() },
                                        modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f))
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "पुनः प्रयास करें" else "Try Again",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 3. SECURE VAULT SECURED PIN DIALOG
    if (showPinDialog) {
        AlertDialog(
            onDismissRequest = { showPinDialog = false },
            containerColor = Color(0xFF0C0C0F),
            shape = RoundedCornerShape(24.dp),
            title = {
                Text(
                    text = if (isSettingNewPin) "Set New PIN" else "Vault Security PIN",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = if (isSettingNewPin) "Enter a new 4-digit security PIN for your Vault:"
                               else "Enter 4-digit PIN to access private safe folders (Default: 1234):",
                        color = Color.LightGray,
                        fontSize = 12.sp
                    )

                    BasicTextField(
                        value = enteredPin,
                        onValueChange = {
                            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                                enteredPin = it
                            }
                        },
                        textStyle = androidx.compose.ui.text.TextStyle(
                            color = Color.White,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 8.sp,
                            textAlign = TextAlign.Center
                        ),
                        cursorBrush = SolidColor(Color(0xFF10B981)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        singleLine = true
                    )

                    if (pinError) {
                        Text("Incorrect security PIN! Try again.", color = Color.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isSettingNewPin) {
                            if (enteredPin.length == 4) {
                                savedPin = enteredPin
                                isVaultUnlocked = true
                                isSettingNewPin = false
                                showPinDialog = false
                                onOpenVault()
                            } else {
                                pinError = true
                            }
                        } else {
                            if (enteredPin == savedPin) {
                                isVaultUnlocked = true
                                showPinDialog = false
                                pinError = false
                                onOpenVault()
                            } else {
                                pinError = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                ) {
                    Text("Confirm", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showPinDialog = false
                        isSettingNewPin = false
                    }
                ) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }

    // 4. THEME SELECTION FULL SCREEN DIALOG
    if (showThemeDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showThemeDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709) // Deep high contrast dark background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showThemeDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (appLang == "hi") "थीम चुनें" else "Theme Selection",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    // Content Area (Grid of options)
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 20.dp, vertical = 10.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        Text(
                            text = if (appLang == "hi") "आकर्षक कवर या कलर थीम प्रीसेट चुनें:" else "Choose a beautiful preset theme or customize with your gallery:",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            lineHeight = 20.sp
                        )

                        // 2 Columns Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Theme 1: Customize Theme (Top Left)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                            if (customBgUri.isNotEmpty() && selectedThemeId != "custom_image") {
                                                viewModel.setSelectedThemeId("custom_image")
                                            } else {
                                                imagePickerLauncher.launch("image/*")
                                            }
                                        }
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF1E1E26))
                                        .border(
                                            width = if (selectedThemeId == "custom_image") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "custom_image") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (customBgUri.isNotEmpty()) {
                                        coil.compose.AsyncImage(
                                            model = customBgUri,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                                            alpha = 0.45f
                                        )
                                    }

                                    // Custom visual: T-Shirt icon with "+" in the middle
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        // Draw beautiful clothing t-shirt shape
                                        Canvas(modifier = Modifier.size(64.dp)) {
                                            val w = size.width
                                            val h = size.height
                                            val path = Path().apply {
                                                moveTo(w * 0.4f, h * 0.25f)
                                                quadraticTo(w * 0.5f, h * 0.32f, w * 0.6f, h * 0.25f)
                                                lineTo(w * 0.8f, h * 0.32f)
                                                lineTo(w * 0.9f, h * 0.48f)
                                                lineTo(w * 0.78f, h * 0.55f)
                                                lineTo(w * 0.72f, h * 0.48f)
                                                lineTo(w * 0.72f, h * 0.85f)
                                                lineTo(w * 0.28f, h * 0.85f)
                                                lineTo(w * 0.28f, h * 0.48f)
                                                lineTo(w * 0.22f, h * 0.55f)
                                                lineTo(w * 0.1f, h * 0.48f)
                                                lineTo(w * 0.2f, h * 0.32f)
                                                close()
                                            }
                                            drawPath(path, Color.White.copy(alpha = 0.35f))
                                            
                                            val strokeWidth = 3.dp.toPx()
                                            val len = 12.dp.toPx()
                                            val cx = w / 2
                                            val cy = h * 0.58f
                                            drawLine(
                                                color = Color.White,
                                                start = Offset(cx - len / 2, cy),
                                                end = Offset(cx + len / 2, cy),
                                                strokeWidth = strokeWidth,
                                                cap = StrokeCap.Round
                                            )
                                            drawLine(
                                                color = Color.White,
                                                start = Offset(cx, cy - len / 2),
                                                end = Offset(cx, cy + len / 2),
                                                strokeWidth = strokeWidth,
                                                cap = StrokeCap.Round
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(12.dp))
                                        Text(
                                            text = if (appLang == "hi") "गैलरी से चुनें" else "Choose Photo",
                                            color = Color.White.copy(alpha = 0.6f),
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "custom_image") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "कस्टमाइज़ थीम" else "Customize Theme",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Theme 2: Dark Colour (Top Right)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                            viewModel.setSelectedThemeId("dark_color")
                                        }
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(Color(0xFF0F172A))
                                        .border(
                                            width = if (selectedThemeId == "dark_color") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "dark_color") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                ) {
                                    // Preview of Starry background inside card
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val w = size.width
                                        val h = size.height
                                        
                                        // Stars
                                        val starOffset = listOf(
                                            Offset(w * 0.2f, h * 0.15f),
                                            Offset(w * 0.5f, h * 0.25f),
                                            Offset(w * 0.8f, h * 0.12f),
                                            Offset(w * 0.35f, h * 0.4f),
                                            Offset(w * 0.7f, h * 0.35f)
                                        )
                                        starOffset.forEach { pos ->
                                            drawCircle(Color.White.copy(alpha = 0.6f), radius = 2f, center = pos)
                                        }
                                        
                                        // Diamond star
                                        val cx = w * 0.55f
                                        val cy = h * 0.15f
                                        val path = Path().apply {
                                            moveTo(cx, cy - 6f)
                                            lineTo(cx + 3f, cy - 1f)
                                            lineTo(cx + 6f, cy)
                                            lineTo(cx + 3f, cy + 1f)
                                            moveTo(cx, cy + 6f)
                                            lineTo(cx - 3f, cy + 1f)
                                            lineTo(cx - 6f, cy)
                                            lineTo(cx - 3f, cy - 1f)
                                            close()
                                        }
                                        drawPath(path, Color.White.copy(alpha = 0.85f))

                                        // Glowing green circle dome at bottom as shown in image
                                        drawCircle(
                                            color = Color(0xFF10B981).copy(alpha = 0.15f),
                                            radius = w * 0.5f,
                                            center = Offset(w * 0.6f, h * 1.1f)
                                        )
                                        drawCircle(
                                            color = Color(0xFF047857).copy(alpha = 0.25f),
                                            radius = w * 0.35f,
                                            center = Offset(w * 0.6f, h * 1.1f)
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "dark_color") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "डार्क कलर" else "Dark Colour",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Theme 3: Light Colour (Bottom Left)
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        com.example.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                            viewModel.setSelectedThemeId("light_color")
                                        }
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(0.72f)
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(
                                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                                colors = listOf(
                                                    Color(0xFFE8ECEF),
                                                    Color(0xFFF1F3F5),
                                                    Color(0xFFDFE4E8)
                                                )
                                            )
                                        )
                                        .border(
                                            width = if (selectedThemeId == "light_color") 2.dp else 1.dp,
                                            color = if (selectedThemeId == "light_color") Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                            shape = RoundedCornerShape(16.dp)
                                        )
                                ) {
                                    // Preview of Light background decoration
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        drawCircle(
                                            color = Color(0xFFD0D7DE).copy(alpha = 0.4f),
                                            radius = size.width * 0.6f,
                                            center = Offset(size.width * 1.2f, size.height * 0.2f)
                                        )
                                        drawCircle(
                                            color = Color(0xFFE2E7EC).copy(alpha = 0.6f),
                                            radius = size.width * 0.7f,
                                            center = Offset(-size.width * 0.2f, size.height * 0.8f)
                                        )
                                    }

                                    // Selection badge
                                    if (selectedThemeId == "light_color") {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.BottomEnd)
                                                .padding(10.dp)
                                                .size(24.dp)
                                                .background(Color(0xFF10B981), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Selected",
                                                tint = Color.White,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "लाइट कलर" else "Light Colour",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            // Empty space block on bottom-right to align correctly since VIP is excluded
                            Spacer(modifier = Modifier.weight(1f))
                        }

                        if (selectedThemeId == "custom_image" && customBgUri.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    viewModel.setCustomBackgroundUri("")
                                    viewModel.setSelectedThemeId("dark_color")
                                    musicViewModel.setCustomThemeImage(null)
                                    android.widget.Toast.makeText(context, "Custom background removed.", android.widget.Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text(
                                    text = if (appLang == "hi") "कस्टम वॉलपेपर हटाएं" else "Reset Custom Wallpaper",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // 5. PLAY HISTORY DIALOG
    if (showHistoryDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showHistoryDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showHistoryDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "प्लेबैक इतिहास" else "Watch History",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "Your recent playbacks",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Clear option as text button on the right
                        if (watchHistory.isNotEmpty()) {
                            TextButton(
                                onClick = {
                                    viewModel.clearWatchHistory()
                                    android.widget.Toast.makeText(context, "History cleared", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text(
                                    text = if (appLang == "hi") "साफ़ करें" else "Clear All",
                                    color = Color.Red,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (watchHistory.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(Icons.Rounded.History, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(64.dp))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "इतिहास खाली है" else "History is empty",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "आपके द्वारा देखे गए वीडियो और गाने यहाँ दिखाई देंगे।" else "Videos you watch will show up here.",
                                    color = Color.Gray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            LazyColumn(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(watchHistory) { item ->
                                    val resolvedThumbnail: Any = when (item.thumbnailUrl) {
                                        "tears_of_steel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/TearsOfSteel.jpg"
                                        "sintel" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/Sintel.jpg"
                                        "bunny" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/BigBuckBunny.jpg"
                                        "elephants" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ElephantsDream.jpg"
                                        "cosmic" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerBlazes.jpg"
                                        "quantum" -> "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/images/ForBiggerEscapes.jpg"
                                        null, "" -> {
                                            if (item.category == "Music") {
                                                "https://picsum.photos/seed/${item.id}/200/200"
                                            } else {
                                                "https://picsum.photos/seed/${item.id}/400/250"
                                            }
                                        }
                                        else -> {
                                            if (item.thumbnailUrl.startsWith("http://") || item.thumbnailUrl.startsWith("https://") || item.thumbnailUrl.startsWith("/") || item.thumbnailUrl.startsWith("content://")) {
                                                item.thumbnailUrl
                                            } else {
                                                "https://picsum.photos/seed/${item.id}/400/250"
                                            }
                                        }
                                    }

                                    GlassCard(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable {
                                                if (item.category == "Music") {
                                                    val songId = item.id.removePrefix("music_").toLongOrNull()
                                                    val allSongsList = musicViewModel.allSongs.value
                                                    val targetSong = allSongsList.find { it.id == songId }
                                                    if (targetSong != null) {
                                                        musicViewModel.playSong(targetSong, allSongsList)
                                                    } else {
                                                        val playable = MediaEntity(
                                                            id = item.id,
                                                            title = item.title,
                                                            url = item.url,
                                                            duration = item.duration,
                                                            artist = item.artist,
                                                            thumbnailUrl = item.thumbnailUrl,
                                                            category = item.category
                                                        )
                                                        viewModel.playMedia(playable)
                                                    }
                                                } else {
                                                    val playable = MediaEntity(
                                                        id = item.id,
                                                        title = item.title,
                                                        url = item.url,
                                                        duration = item.duration,
                                                        artist = item.artist,
                                                        thumbnailUrl = item.thumbnailUrl,
                                                        category = item.category
                                                    )
                                                    viewModel.playMedia(playable)
                                                }
                                                showHistoryDialog = false
                                            },
                                        cornerRadius = 14.dp
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(64.dp, 44.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(Color.White.copy(alpha = 0.05f))
                                                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                AsyncImage(
                                                    model = resolvedThumbnail,
                                                    contentDescription = item.title,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                                
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .background(Color.Black.copy(alpha = 0.6f), CircleShape),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = if (item.category == "Music") Icons.Rounded.MusicNote else Icons.Rounded.PlayArrow,
                                                        contentDescription = null,
                                                        tint = Color.White,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                            
                                            Spacer(modifier = Modifier.width(12.dp))
                                            
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = item.title,
                                                    color = Color.White,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = item.artist ?: (if (item.category == "Music") "Unknown Artist" else "Video"),
                                                    color = Color.Gray,
                                                    fontSize = 12.sp,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            
                                            IconButton(
                                                onClick = {
                                                    viewModel.deleteWatchHistoryById(item.id)
                                                }
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Rounded.Delete,
                                                    contentDescription = "Delete from history",
                                                    tint = Color.Gray.copy(alpha = 0.6f),
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 7. CLEAN DIALOG
    if (showCleanDialog) {
        var isScanning by remember { mutableStateOf(false) }
        var isCleanComplete by remember { mutableStateOf(false) }
        var scanProgress by remember { mutableStateOf(0f) }
        var activeLogText by remember { mutableStateOf("Ready to scan") }

        LaunchedEffect(isScanning) {
            if (isScanning) {
                val logs = listOf(
                    "Analyzing video cache directories...",
                    "Purging expired metadata stream buffers...",
                    "Sweeping corrupt SQLite indices...",
                    "Clearing high-fidelity audio conversion temps...",
                    "Defragmenting physical file mapping lists...",
                    "Optimizing database pipelines..."
                )
                for (i in 1..20) {
                    delay(100)
                    scanProgress = i.toFloat() / 20f
                    activeLogText = logs[(i / 4).coerceAtMost(logs.size - 1)]
                }
                performRealAppCacheClear(context)
                realAppCacheSize = 0L
                isCleanedState = true
                isScanning = false
                isCleanComplete = true
            }
        }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showCleanDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showCleanDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "स्टोरेज ऑप्टिमाइज़र" else "Storage Optimizer",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = "System Junk Cleaner",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        // Icon Badge
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF10B981).copy(alpha = 0.15f), CircleShape)
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteSweep,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Divider
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.08f))
                    )

                    // Content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (!isScanning && !isCleanComplete) {
                            Spacer(modifier = Modifier.height(24.dp))
                            
                            GlassCard(
                                modifier = Modifier.fillMaxWidth(),
                                cornerRadius = 16.dp
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "अस्थायी वीडियो कैश, अनुक्रमणिका लॉग और समाप्त हो चुकी स्ट्रीम फ़ाइलों को साफ़ करें ताकि तुरंत डिस्क स्थान खाली हो सके:" else "Clean temporary video caches, indexing logs, and expired stream files to instantly free up disk space:",
                                        color = Color.LightGray,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp,
                                        textAlign = TextAlign.Center
                                    )
                                    
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                            .padding(24.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = if (appLang == "hi") "कचरा और कैश मिला" else "Junk & Cache Found",
                                                color = Color.Gray,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(totalJunkText, color = Color(0xFF10B981), fontSize = 36.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { isScanning = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Text(
                                            text = if (appLang == "hi") "जंक साफ़ करें" else "Scan & Clear Junk",
                                            color = Color.Black,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        } else if (isScanning) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    progress = scanProgress,
                                    color = Color(0xFF10B981),
                                    trackColor = Color.White.copy(alpha = 0.1f),
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                Text(
                                    text = if (appLang == "hi") "अनुकूलन हो रहा है: ${(scanProgress * 100).toInt()}%" else "Optimizing: ${(scanProgress * 100).toInt()}%",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(activeLogText, color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                            }
                        } else if (isCleanComplete) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .background(Color(0xFF10B981).copy(alpha = 0.1f), CircleShape)
                                        .border(1.dp, Color(0xFF10B981).copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(40.dp))
                                }
                                Spacer(modifier = Modifier.height(20.dp))
                                Text(
                                    text = if (appLang == "hi") "सिस्टम पूरी तरह से अनुकूलित!" else "System Fully Optimized!",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (appLang == "hi") "$totalJunkText स्टोरेज कैश सफलतापूर्वक साफ़ किया गया।" else "Freed up $totalJunkText of storage cache.",
                                    color = Color.Gray,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )
                                
                                Button(
                                    onClick = { 
                                        showCleanDialog = false 
                                        isCleanComplete = false
                                    },
                                    modifier = Modifier.fillMaxWidth(0.6f).padding(top = 24.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "बहुत बढ़िया" else "Awesome",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 8. NEW DIALOGS REGION START
    // 8. SETTINGS DETAILS DIALOG (PLAYER SETTINGS)
    if (showSettingsDetailsDialog) {
        val appLang by viewModel.appLanguage.collectAsState()
        var activeSubPanel by remember { mutableStateOf<String?>(null) }
        var blockGameCenter by remember { mutableStateOf(true) } // Set to true (active) as shown in the image
        
        // Settings State parameters (interactable & simulated for high fidelity)
        var popUpPlay by remember { mutableStateOf(true) }
        var continuousPlay by remember { mutableStateOf(true) }
        var videoOrientation by remember { mutableStateOf("Sensor/Auto") }
        var filterShortAudio by remember { mutableStateOf(true) }
        var skipNomedia by remember { mutableStateOf(true) }
        var maxDownloads by remember { mutableStateOf(3) }
        var downloadOverWifi by remember { mutableStateOf(false) }

        // Handle hardware back press cleanly
        androidx.activity.compose.BackHandler(enabled = showSettingsDetailsDialog) {
            if (activeSubPanel != null) {
                activeSubPanel = null
            } else {
                showSettingsDetailsDialog = false
            }
        }

        @Composable
        fun SettingsItemRow(
            title: String,
            subtitle: String,
            icon: androidx.compose.ui.graphics.vector.ImageVector,
            showChevron: Boolean = true,
            rightContent: @Composable (() -> Unit)? = null,
            onClick: () -> Unit = {}
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onClick)
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
                
                Spacer(modifier = Modifier.width(20.dp))
                
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        color = Color(0xFF8E8E93),
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
                
                if (rightContent != null) {
                    rightContent()
                } else if (showChevron) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        contentDescription = null,
                        tint = Color(0xFF5A5A5F),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showSettingsDetailsDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709) // Sleek absolute black background to match the reference image
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = {
                            if (activeSubPanel != null) {
                                activeSubPanel = null
                            } else {
                                showSettingsDetailsDialog = false
                            }
                        }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        
                        Text(
                            text = when (activeSubPanel) {
                                "GENERAL" -> if (appLang == "hi") "सामान्य सेटिंग्स" else "General"
                                "VIDEO" -> if (appLang == "hi") "वीडियो सेटिंग्स" else "Video"
                                "AUDIO" -> if (appLang == "hi") "ऑडियो सेटिंग्स" else "Audio"
                                "DOWNLOADS" -> if (appLang == "hi") "डाउनलोड सेटिंग्स" else "Downloads"
                                "SUBSCRIPTION" -> if (appLang == "hi") "सदस्यता" else "Subscription"
                                "ABOUT" -> if (appLang == "hi") "हमारे बारे में" else "About us"
                                else -> if (appLang == "hi") "सेटिंग्स" else "Settings"
                            },
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 48.dp) // Centering offset adjustment
                        )
                    }

                    // Separation Divider line
                    Divider(color = Color.White.copy(alpha = 0.08f), thickness = 1.dp)

                    if (activeSubPanel == null) {
                        // Main Settings options matching reference image exactly
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 8.dp, bottom = 24.dp)
                        ) {
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "सामान्य" else "General",
                                    subtitle = if (appLang == "hi") "भाषा, इतिहास" else "Language, History",
                                    icon = Icons.Rounded.Smartphone,
                                    onClick = { activeSubPanel = "GENERAL" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "वीडियो" else "Video",
                                    subtitle = if (appLang == "hi") "पॉप-अप प्ले, स्क्रीन ओरिएंटेशन, निरंतर प्लेबैक..." else "Pop-up play, screen orientation, continuous playb...",
                                    icon = Icons.Rounded.PlayCircle,
                                    onClick = { activeSubPanel = "VIDEO" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "ऑडियो" else "Audio",
                                    subtitle = if (appLang == "hi") "ऑडियो प्रारूप, ऑडियो अवधि, नोमीडिया फ़ोल्डर सेटिंग्स..." else "Audio format, audio duration, nomedia folder set...",
                                    icon = Icons.Rounded.Headphones,
                                    onClick = { activeSubPanel = "AUDIO" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "डाउनलोड" else "Downloads",
                                    subtitle = if (appLang == "hi") "पाथ, अधिकतम डाउनलोड कार्य" else "Path, max download tasks",
                                    icon = Icons.Rounded.Download,
                                    onClick = { activeSubPanel = "DOWNLOADS" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "सदस्यता" else "Subscription",
                                    subtitle = if (appLang == "hi") "सदस्यता प्रबंधित करें या रद्द करें" else "Manage or Cancel subscription",
                                    icon = Icons.Rounded.WorkspacePremium,
                                    onClick = { activeSubPanel = "SUBSCRIPTION" }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "गेम सेंटर" else "Game Center",
                                    subtitle = if (appLang == "hi") "गेम सेंटर को ब्लॉक करें और गेम सामग्री प्रदर्शित न करें" else "Block the game center and do not display game content",
                                    icon = Icons.Rounded.SportsEsports,
                                    showChevron = false,
                                    rightContent = {
                                        Switch(
                                            checked = blockGameCenter,
                                            onCheckedChange = { 
                                                blockGameCenter = it
                                                val msg = if (it) {
                                                    if (appLang == "hi") "गेम सेंटर ब्लॉक किया गया" else "Game Center blocked!"
                                                } else {
                                                    if (appLang == "hi") "गेम सेंटर प्रदर्शित किया गया" else "Game Center displayed!"
                                                }
                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                            },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = Color(0xFF10B981),
                                                uncheckedThumbColor = Color(0xFFD1D1D6),
                                                uncheckedTrackColor = Color(0xFF3A3A3C)
                                            )
                                        )
                                    }
                                )
                                Divider(color = Color.White.copy(alpha = 0.04f), thickness = 1.dp, modifier = Modifier.padding(horizontal = 20.dp))
                            }
                            
                            item {
                                SettingsItemRow(
                                    title = if (appLang == "hi") "हमारे बारे में" else "About us",
                                    subtitle = if (appLang == "hi") "प्रशंसक समूह, आधिकारिक वेबसाइट, पेज और चैनल" else "Fans group, official website, pages & channel",
                                    icon = Icons.Rounded.Info,
                                    onClick = { activeSubPanel = "ABOUT" }
                                )
                            }
                        }
                    } else {
                        // Settings Sub-panel Views
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 20.dp, vertical = 20.dp),
                            verticalArrangement = Arrangement.spacedBy(18.dp)
                        ) {
                            when (activeSubPanel) {
                                "GENERAL" -> {
                                    Text(
                                        text = if (appLang == "hi") "भाषा और स्थानीयकरण" else "Language & Localization",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        listOf("en" to "English", "hi" to "Hindi").forEach { lang ->
                                            val selected = appLang == lang.first
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (selected) Color(0xFF10B981) else Color.White.copy(alpha = 0.1f),
                                                        shape = RoundedCornerShape(10.dp)
                                                    )
                                                    .background(
                                                        if (selected) Color(0xFF10B981).copy(alpha = 0.12f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(10.dp)
                                                    )
                                                    .clickable {
                                                        viewModel.setAppLanguage(lang.first)
                                                        Toast.makeText(context, "Language: ${lang.second}", Toast.LENGTH_SHORT).show()
                                                    }
                                                    .padding(14.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(lang.second, color = if (selected) Color(0xFF10B981) else Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "प्लेबैक इतिहास प्रबंधन" else "Playback History Management",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Button(
                                        onClick = {
                                            viewModel.clearWatchHistory()
                                            Toast.makeText(context, if (appLang == "hi") "प्लेबैक इतिहास साफ़ कर दिया गया!" else "Playback watch history cleared!", Toast.LENGTH_SHORT).show()
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.1f), contentColor = Color.Red)
                                    ) {
                                        Text(if (appLang == "hi") "प्लेबैक इतिहास साफ़ करें" else "Clear Watch History", fontWeight = FontWeight.Bold)
                                    }
                                }
                                
                                "VIDEO" -> {
                                    Text(
                                        text = if (appLang == "hi") "वीडियो प्लेबैक विकल्प" else "Video Playback Preferences",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "पॉप-अप प्ले (PiP)" else "Pop-up play (Picture-in-Picture)", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = popUpPlay,
                                            onCheckedChange = { popUpPlay = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "निरंतर प्लेबैक" else "Continuous playback", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = continuousPlay,
                                            onCheckedChange = { continuousPlay = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "डिफ़ॉल्ट स्क्रीन ओरिएंटेशन" else "Default Screen Orientation",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf("Sensor/Auto", "Landscape", "Portrait").forEach { mode ->
                                            val isSel = videoOrientation == mode
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSel) Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .background(
                                                        if (isSel) Color(0xFF10B981).copy(alpha = 0.1f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { videoOrientation = mode }
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(mode, color = if (isSel) Color(0xFF10B981) else Color.LightGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                                
                                "AUDIO" -> {
                                    Text(
                                        text = if (appLang == "hi") "ऑडियो सेटिंग्स" else "Audio Player Settings",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "शॉर्ट ऑडियो फ़िल्टर करें (<30s)" else "Filter short audio (<30s)", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = filterShortAudio,
                                            onCheckedChange = { filterShortAudio = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") ".nomedia फ़ोल्डर्स को छोड़ें" else "Skip .nomedia folders", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = skipNomedia,
                                            onCheckedChange = { skipNomedia = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "बैकग्राउंड ऑडियो स्ट्रीम प्लेबैक" else "Background play audio stream", color = Color.LightGray, fontSize = 14.sp)
                                        var bgPlayStream by remember { mutableStateOf(true) }
                                        Switch(
                                            checked = bgPlayStream,
                                            onCheckedChange = { bgPlayStream = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }
                                }
                                
                                "DOWNLOADS" -> {
                                    Text(
                                        text = if (appLang == "hi") "डाउनलोड संग्रहण पाथ" else "Download Storage Path",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(12.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.06f), RoundedCornerShape(12.dp))
                                            .clickable {
                                                Toast.makeText(context, "Storage path copied!", Toast.LENGTH_SHORT).show()
                                            }
                                            .padding(16.dp)
                                    ) {
                                        Column {
                                            Text(
                                                text = if (appLang == "hi") "प्राथमिक पाथ:" else "Primary Directory Path:",
                                                color = Color.Gray,
                                                fontSize = 12.sp
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "/storage/emulated/0/Download/Vidiopen/",
                                                color = Color(0xFF10B981),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = if (appLang == "hi") "कॉपी करने के लिए टैप करें" else "Tap to copy storage path",
                                                color = Color.LightGray,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Divider(color = Color.White.copy(alpha = 0.1f))

                                    Text(
                                        text = if (appLang == "hi") "अधिकतम समानांतर डाउनलोड" else "Max Concurrent Download Tasks",
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        listOf(1, 2, 3, 4, 5).forEach { num ->
                                            val isSel = maxDownloads == num
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .border(
                                                        width = 1.dp,
                                                        color = if (isSel) Color(0xFF10B981) else Color.White.copy(alpha = 0.08f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .background(
                                                        if (isSel) Color(0xFF10B981).copy(alpha = 0.1f) else Color.White.copy(alpha = 0.02f),
                                                        RoundedCornerShape(8.dp)
                                                    )
                                                    .clickable { maxDownloads = num }
                                                    .padding(12.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text("$num", color = if (isSel) Color(0xFF10B981) else Color.LightGray, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }

                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(if (appLang == "hi") "केवल वाई-फाई पर डाउनलोड करें" else "Download over Wi-Fi only", color = Color.LightGray, fontSize = 14.sp)
                                        Switch(
                                            checked = downloadOverWifi,
                                            onCheckedChange = { downloadOverWifi = it },
                                            colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = Color(0xFF10B981))
                                        )
                                    }
                                }
                                
                                "SUBSCRIPTION" -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.verticalGradient(
                                                    colors = listOf(Color(0xFF1B1123), Color(0xFF0A0512))
                                                ),
                                                RoundedCornerShape(16.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                brush = Brush.horizontalGradient(
                                                    colors = listOf(Color(0xFFFFB03A), Color(0xFFFF1E27))
                                                ),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .padding(20.dp)
                                    ) {
                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.WorkspacePremium,
                                                contentDescription = "VIP Icon",
                                                tint = Color(0xFFFFB03A),
                                                modifier = Modifier.size(56.dp)
                                            )
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = "VIDIOPEN LIFETIME PRO",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 18.sp,
                                                letterSpacing = 1.5.sp
                                            )
                                            Text(
                                                text = if (appLang == "hi") "सक्रिय सदस्यता: लक्जरी संस्करण" else "Active Membership: Luxury Edition",
                                                color = Color(0xFF10B981),
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Medium
                                            )

                                            Spacer(modifier = Modifier.height(16.dp))
                                            Divider(color = Color.White.copy(alpha = 0.1f))
                                            Spacer(modifier = Modifier.height(16.dp))

                                            listOf(
                                                if (appLang == "hi") "✅ विज्ञापन-मुक्त लक्जरी प्लेयर" else "✅ 100% Ad-Free Premium Playback",
                                                if (appLang == "hi") "✅ 4K अल्ट्रा एचडी हार्डवेयर डिकोडिंग" else "✅ 4K Ultra-HD Hardware Decoding",
                                                if (appLang == "hi") "✅ बैकग्राउंड ऑडियो और पिप सक्षम" else "✅ Background Audio & PiP Enabled",
                                                if (appLang == "hi") "✅ असीमित एमपी3 कनवर्टर और वाई-फाई ट्रांसफर" else "✅ Unlimited MP3 Converter & File Transfer"
                                            ).forEach { benefit ->
                                                Text(
                                                    text = benefit,
                                                    color = Color.LightGray,
                                                    fontSize = 13.sp,
                                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                                    textAlign = TextAlign.Start
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(20.dp))

                                            Button(
                                                onClick = {
                                                    Toast.makeText(context, if (appLang == "hi") "आप पहले से ही आजीवन प्रो संस्करण का उपयोग कर रहे हैं!" else "You are already using the lifetime PRO version!", Toast.LENGTH_LONG).show()
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp),
                                                colors = ButtonDefaults.buttonColors(
                                                    containerColor = Color(0xFF10B981)
                                                )
                                            ) {
                                                Text(
                                                    text = if (appLang == "hi") "सदस्यता प्रबंधित करें" else "Manage Subscription",
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color.Black
                                                )
                                            }
                                        }
                                    }
                                }
                                
                                "ABOUT" -> {
                                    Column(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(14.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(72.dp)
                                                .background(Color(0xFF16161A), CircleShape)
                                                .border(1.dp, Color.White.copy(alpha = 0.08f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            AppLogo(modifier = Modifier.size(48.dp))
                                        }

                                        Text(
                                            text = "Vidiopen Pro Luxury",
                                            color = Color.White,
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold
                                        )

                                        Text(
                                            text = "Version 1.2.5 (Luxury Edition)",
                                            color = Color.Gray,
                                            fontSize = 13.sp
                                        )

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Divider(color = Color.White.copy(alpha = 0.08f))

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    Toast.makeText(context, "Opening Vidiopen Fans Community Group...", Toast.LENGTH_SHORT).show()
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(if (appLang == "hi") "प्रशंसक समूह (Fans Group)" else "Official Community Fans Group", color = Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.Gray)
                                        }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(10.dp))
                                                .clickable {
                                                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://vidiopen.in")).apply {
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    }
                                                    try {
                                                        context.startActivity(webIntent)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "Opening official website https://vidiopen.in ...", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(if (appLang == "hi") "आधिकारिक वेबसाइट" else "Official Website (vidiopen.in)", color = Color.LightGray, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.Gray)
                                        }

                                        val instaInfiniteTransition = rememberInfiniteTransition(label = "InstagramPulse")
                                        val instaScale by instaInfiniteTransition.animateFloat(
                                            initialValue = 0.98f,
                                            targetValue = 1.02f,
                                            animationSpec = infiniteRepeatable(
                                                animation = tween(1200, easing = FastOutSlowInEasing),
                                                repeatMode = RepeatMode.Reverse
                                            ),
                                            label = "InstagramScale"
                                        )

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .scale(instaScale)
                                                .background(
                                                    brush = Brush.horizontalGradient(
                                                        colors = listOf(
                                                             Color(0xFF833AB4), // Royal Purple
                                                             Color(0xFFE1306C), // Magenta/Pink
                                                             Color(0xFFFD1D1D), // Deep Red
                                                             Color(0xFFF77737)  // Vibrant Orange
                                                        )
                                                    ),
                                                    shape = RoundedCornerShape(12.dp)
                                                )
                                                .clickable {
                                                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/just_abhay_pandit302?igsh=c2YyeHdyczNpaXRq")).apply {
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    }
                                                    try {
                                                        context.startActivity(webIntent)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "Opening Instagram Profile...", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                                .padding(14.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(24.dp)
                                                        .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                                                        .border(1.5.dp, Color.White, RoundedCornerShape(6.dp))
                                                        .padding(4.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxSize()
                                                            .border(1.5.dp, Color.White, CircleShape),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(2.dp)
                                                                .background(Color.White, CircleShape)
                                                        )
                                                    }
                                                    Box(
                                                        modifier = Modifier
                                                            .size(2.dp)
                                                            .align(Alignment.TopEnd)
                                                            .background(Color.White, CircleShape)
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text(
                                                    text = if (appLang == "hi") "इंस्टाग्राम पर फ़ॉलो करें (FOLLOW DEVELOPER)" else "Follow DEVELOPER on Instagram",
                                                    color = Color.White,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    letterSpacing = 0.5.sp
                                                )
                                            }
                                            Icon(
                                                imageVector = Icons.Rounded.ChevronRight,
                                                contentDescription = null,
                                                tint = Color.White
                                            )
                                        }

                                        var checkingForUpdate by remember { mutableStateOf(false) }
                                        Button(
                                            onClick = {
                                                checkingForUpdate = true
                                            },
                                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.06f), contentColor = Color.White)
                                        ) {
                                            if (checkingForUpdate) {
                                                CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF10B981), strokeWidth = 2.dp)
                                                Spacer(modifier = Modifier.width(10.dp))
                                                Text(if (appLang == "hi") "अपडेट की जांच की जा रही है..." else "Checking for updates...")
                                                LaunchedEffect(Unit) {
                                                    delay(1500)
                                                    checkingForUpdate = false
                                                    Toast.makeText(context, if (appLang == "hi") "वीडिओपेन पूरी तरह से अपडेटेड है!" else "Vidiopen is fully up to date!", Toast.LENGTH_SHORT).show()
                                                }
                                            } else {
                                                Text(if (appLang == "hi") "अपडेट के लिए जांचें" else "Check for Updates", fontWeight = FontWeight.Bold)
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(10.dp))

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.Center,
                                            modifier = Modifier
                                                .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(8.dp))
                                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text("Proudly Crafted in India", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("🇮🇳", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 9. RECYCLE BIN DIALOG (Premium Full Screen)
    if (showRecycleBinDialog) {
        val deletedVideos by viewModel.allDeletedVideos.collectAsState()
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showRecycleBinDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showRecycleBinDialog = false },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "रीसायकल बिन" else "Recycle Bin",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = if (appLang == "hi") "सुरक्षित अस्थायी स्टोरेज" else "Temporary Storage Shield",
                                color = Color.Gray,
                                fontSize = 11.sp
                            )
                        }
                        
                        if (deletedVideos.isNotEmpty()) {
                            TextButton(
                                onClick = { 
                                    viewModel.emptyRecycleBin()
                                    Toast.makeText(context, if (appLang == "hi") "रीसायकल बिन खाली किया गया" else "Recycle Bin Cleared Successfully", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Text(
                                    text = if (appLang == "hi") "खाली करें" else "Empty Bin",
                                    color = Color.Red,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (deletedVideos.isEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.DeleteSweep,
                                    contentDescription = null,
                                    tint = Color.Gray.copy(alpha = 0.5f),
                                    modifier = Modifier.size(72.dp)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (appLang == "hi") "रीसायकल बिन पूरी तरह से खाली है" else "Recycle Bin is completely empty",
                                    color = Color.Gray,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        } else {
                            Text(
                                text = if (appLang == "hi") 
                                    "हटाए गए आइटम यहाँ सुरक्षित रहते हैं। आप उन्हें पुनर्प्राप्त (restore) कर सकते हैं या स्थायी रूप से हटा सकते हैं:" 
                                    else "Deleted items remain protected here. You can restore them to their original location or delete them permanently:",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(deletedVideos) { item ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(16.dp))
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Thumbnail
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp, 40.dp)
                                                .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(6.dp))
                                                .clip(RoundedCornerShape(6.dp))
                                        ) {
                                            if (!item.thumbnailUrl.isNullOrEmpty()) {
                                                coil.compose.AsyncImage(
                                                    model = item.thumbnailUrl,
                                                    contentDescription = null,
                                                    contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = Icons.Rounded.Movie,
                                                    contentDescription = null,
                                                    tint = Color.Gray,
                                                    modifier = Modifier.align(Alignment.Center).size(20.dp)
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(12.dp))

                                        // Name & Size
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = item.title,
                                                color = Color.White,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = "Size: ${MediaStoreViewModel.formatSize(item.size)} • ${if (item.type == "SCANNED") "Local File" else "Stream"}",
                                                color = Color.Gray,
                                                fontSize = 11.sp
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        // Restore Button
                                        Button(
                                            onClick = { 
                                                viewModel.restoreVideo(item)
                                                Toast.makeText(context, if (appLang == "hi") "सफलतापूर्वक बहाल किया गया!" else "Restored successfully!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.height(32.dp)
                                        ) {
                                            Text(
                                                text = if (appLang == "hi") "बहाल करें" else "Restore",
                                                color = Color.Black,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(4.dp))

                                        // Permanent Delete Button
                                        IconButton(
                                            onClick = {
                                                viewModel.deleteVideoPermanently(item)
                                                Toast.makeText(context, if (appLang == "hi") "स्थायी रूप से हटा दिया गया!" else "Deleted permanently!", Toast.LENGTH_SHORT).show()
                                            },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.DeleteForever,
                                                contentDescription = "Delete permanently",
                                                tint = Color.Red.copy(alpha = 0.8f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    // 10. RATE US DIALOG
    if (showRateUsDialog) {
        var starRating by remember { mutableStateOf(0) }
        var isSubmitted by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showRateUsDialog = false },
            containerColor = Color(0xFF101012),
            shape = RoundedCornerShape(24.dp),
            title = {
                Text("Rate Vidiopen Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!isSubmitted) {
                        Text(
                            text = "Tap on stars to leave an active rating for our development team:",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (i in 1..5) {
                                Icon(
                                    imageVector = if (i <= starRating) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                    contentDescription = "Star $i",
                                    tint = if (i <= starRating) Color(0xFFFFD700) else Color.Gray,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clickable { starRating = i }
                                )
                            }
                        }
                        
                        val prompt = when (starRating) {
                            1 -> "We're extremely sorry! Tell us how to improve."
                            2 -> "We'll work hard to improve the offline player."
                            3 -> "Thanks! Tell us what features to add next."
                            4 -> "Great! We are glad you like the luxury player."
                            5 -> "Awesome! You made our developer's day!"
                            else -> "Tap to rate"
                        }
                        Text(prompt, color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)

                        Button(
                            onClick = { isSubmitted = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            enabled = starRating > 0
                        ) {
                            Text("Submit Feedback", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(56.dp))
                            Text("Thank You for Rating!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Your active rating keeps Vidiopen Pro 100% ad-free and secure.", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
                            
                            Button(
                                onClick = { 
                                    showRateUsDialog = false
                                    isSubmitted = false
                                    starRating = 0
                                },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.12f))
                            ) {
                                Text("Close", color = Color.White)
                            }
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // 11. FULL APP FEATURES & ABOUT SCREEN DIALOG
    if (showAboutDialog) {
        FullAppFeaturesAboutScreen(
            appLang = appLang,
            onDismiss = { showAboutDialog = false }
        )
    }

    // 11b. LANGUAGE SELECTION DIALOG
    if (showLanguageDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showLanguageDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            com.example.ui.components.LanguageSelectionOverlay(
                currentLanguage = appLang,
                onDismiss = { showLanguageDialog = false },
                onLanguageSelected = { selected ->
                    viewModel.setAppLanguage(selected)
                    showLanguageDialog = false
                    Toast.makeText(
                        context,
                        if (selected == "hi") "भाषा बदल दी गई है: हिन्दी" else "Language changed to: English",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            )
        }
    }

    // 12. PRIVACY POLICY DIALOG
    if (showPrivacyDialog) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { showPrivacyDialog = false },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = Color(0xFF070709)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0D0E15))
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { showPrivacyDialog = false },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                                contentDescription = "Back",
                                tint = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (appLang == "hi") "आधिकारिक गोपनीयता नीति" else "Official Privacy Policy",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                            Text(
                                text = if (appLang == "hi") "विडीओपेन प्रो • डेटा सुरक्षा चार्टर" else "Vidiopen Pro • Data Security Charter",
                                color = Color(0xFF10B981),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        // Shield Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF10B981).copy(alpha = 0.15f))
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Rounded.Security,
                                    contentDescription = null,
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("COMPLIANT", color = Color(0xFF10B981), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                    // Scrollable steps content
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp, vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Title Hero Card
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF10B981).copy(alpha = 0.18f),
                                            Color(0xFF121420)
                                        )
                                    )
                                )
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                                .padding(18.dp)
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.VerifiedUser,
                                        contentDescription = null,
                                        tint = Color(0xFF10B981),
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = if (appLang == "hi") "Vidiopen Pro गोपनीयता एवं सुरक्षा नीति" else "Privacy Policy for Vidiopen Pro",
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 17.sp
                                        )
                                        Text(
                                            text = if (appLang == "hi") "प्रभावित तिथि: 25 जुलाई, 2026 • संस्करण v1.0.0" else "Effective Date: July 25, 2026 • Version v1.0.0",
                                            color = Color(0xFF10B981),
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))
                                Spacer(modifier = Modifier.height(12.dp))

                                Text(
                                    text = if (appLang == "hi") {
                                        "Vidiopen Pro (\"हम,\" \"हमारा,\" या \"ऐप\") में आपका स्वागत है। हम आपकी निजता (Privacy) और व्यक्तिगत डेटा की सुरक्षा के लिए 100% प्रतिबद्ध हैं। यह गोपनीयता नीति अंतर्राष्ट्रीय ऐप स्टोर मानकों (Google Play Developer Policies, Apple App Store Guidelines, GDPR, CCPA, COPPA) के अनुसार यह स्पष्ट करती है कि हम आपके डेटा को कैसे प्रोसेस करते हैं।"
                                    } else {
                                        "Welcome to Vidiopen Pro (\"we,\" \"our,\" or \"the App\"). We are 100% committed to protecting your personal privacy and data security. This Privacy Policy outlines our transparent data handling practices in strict compliance with global standards (Google Play Developer Policies, Apple App Store Guidelines, GDPR, CCPA, COPPA)."
                                    },
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    lineHeight = 19.sp
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                @OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf(
                                        "🛡️ GDPR Compliant",
                                        "🔒 CCPA/CPRA Verified",
                                        "👶 COPPA Safe (13+)",
                                        "🔑 AES-256 Vault",
                                        "🚫 Zero Cloud Uploads",
                                        "📱 Android 14 Scoped Storage"
                                    ).forEach { tag ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(10.dp))
                                                .background(Color.White.copy(alpha = 0.08f))
                                                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp))
                                                .padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(tag, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }

                        // STEP 1: Core App Intent & Scope
                        PrivacyStepCard(
                            stepNumber = "1",
                            title = if (appLang == "hi") "ऐप का उद्देश्य और संचालन (Core App Intent & Scope)" else "Core Intent & Scope of Operations",
                            icon = Icons.Rounded.PlayCircle,
                            iconColor = Color(0xFF10B981)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Vidiopen Pro एक 100% ऑफलाइन-फर्स्ट एचडी वीडियो प्लेयर, ऑडियो म्यूज़िक प्लेयर, प्राइवेट AES-256 तिजोरी (Vault) और फाइल मैनेजर है। ऐप का प्राथमिक उद्देश्य आपके स्थानीय डिवाइस पर रखी मीडिया फाइलों को चलाना, व्यवस्थित करना और सुरक्षित रखना है।"
                                } else {
                                    "Vidiopen Pro operates strictly as an offline-first high-definition video player, music player, AES-256 vault, and local media organizer. The primary intent is to index, play, and secure your locally stored files."
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "ऑफलाइन मीडिया इंडेक्सिंग" else "Offline Local Media Indexing",
                                description = if (appLang == "hi") {
                                    "ऐप केवल आपके फोन की इंटरनल मेमोरी और एसडी कार्ड में स्थित MP4, MKV, AVI, MP3, AAC आदि मीडिया फाइलों को स्थानीय रूप से स्कैन करता है।"
                                } else {
                                    "The app scans local internal storage and SD card directories exclusively for MP4, MKV, AVI, MP3, and AAC media files to build local playlists."
                                },
                                icon = Icons.Rounded.FolderSpecial,
                                iconColor = Color(0xFF10B981)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "ज़ीरो बैकएंड ट्रैकिंग" else "Zero Remote Telemetry",
                                description = if (appLang == "hi") {
                                    "हम आपके द्वारा चलाए जाने वाले वीडियो, गानों, या फाइलों का कोई रिकॉर्ड किसी बाहरी सर्वर या क्लाउड पर न तो भेजते हैं और न ही स्टोर करते हैं।"
                                } else {
                                    "No viewing logs, playlist contents, or video filenames are ever transmitted to external servers or cloud databases."
                                },
                                icon = Icons.Rounded.CloudOff,
                                iconColor = Color(0xFF10B981)
                            )
                        }

                        // STEP 2: Explicit Android System Permissions
                        PrivacyStepCard(
                            stepNumber = "2",
                            title = if (appLang == "hi") "एंड्रॉइड सिस्टम अनुमतियाँ और स्पष्ट उपयोग (System Permissions)" else "Explicit System Permissions & Scoped Usage",
                            icon = Icons.Rounded.Tune,
                            iconColor = ElectricBlue
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Google Play Developer Policies के अनुसार, Vidiopen Pro केवल वही अनुमतियाँ मांगता है जो मीडिया प्लेबैक और फाइल प्रबंधन के लिए अनिवार्य हैं:"
                                } else {
                                    "Strictly adhering to Google Play Permission Policies, Vidiopen Pro requests only the minimal permissions necessary for core playback:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = "READ_MEDIA_VIDEO & READ_MEDIA_AUDIO (Android 13/14)",
                                description = if (appLang == "hi") {
                                    "आपके डिवाइस पर मौजूद केवल वीडियो और ऑडियो फाइलों को स्कैन करके प्लेयर में दिखाने के लिए (बिना आपके पर्सनल डाक्यूमेंट्स को छुए)।"
                                } else {
                                    "Grants access strictly to video and audio media stores on Android 13+ without inspecting non-media documents."
                                },
                                icon = Icons.Rounded.Folder,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = "READ_EXTERNAL_STORAGE & WRITE_EXTERNAL_STORAGE",
                                description = if (appLang == "hi") {
                                    "एंड्रॉइड 12 और उससे पुराने डिवाइसेस पर लोकल मीडिया फाइलों को पढ़ने, रिनेम करने, डिलीट करने और रिसाइकल बिन में डालने के लिए।"
                                } else {
                                    "Used on Android 12 and below to read, rename, delete, or move media files to the local Trash Bin."
                                },
                                icon = Icons.Rounded.SdCard,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = "FOREGROUND_SERVICE & FOREGROUND_SERVICE_MEDIA_PLAYBACK",
                                description = if (appLang == "hi") {
                                    "जब आप ऐप मिनीमाइज करते हैं या फोन स्क्रीन लॉक करते हैं, तब भी ऑडियो/म्यूजिक प्लेबैक को जारी रखने के लिए।"
                                } else {
                                    "Required to maintain playback in background audio mode or PiP mode when the app is minimized."
                                },
                                icon = Icons.Rounded.PlayCircle,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = "POST_NOTIFICATIONS (Android 13+)",
                                description = if (appLang == "hi") {
                                    "नोटिफिकेशन बार में प्ले, पॉज़, नेक्स्ट गाना बदलने का कंट्रोल विजेट दिखाने के लिए।"
                                } else {
                                    "Allows displaying playback media controls (Play/Pause/Skip) in the Android system notification bar."
                                },
                                icon = Icons.Rounded.Notifications,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = "NEARBY_WIFI_DEVICES & CHANGE_WIFI_STATE",
                                description = if (appLang == "hi") {
                                    "ShareAny P2P फीचर के ज़रिए बिना इंटरनेट के दो फोनों के बीच हाई-स्पीड 50MB/s फाइल ट्रांसफर करने के लिए।"
                                } else {
                                    "Used strictly for offline Wi-Fi Direct P2P file transfers between nearby devices without internet."
                                },
                                icon = Icons.Rounded.Wifi,
                                iconColor = ElectricBlue
                            )

                            PrivacySubPoint(
                                title = "USE_BIOMETRIC / USE_FINGERPRINT",
                                description = if (appLang == "hi") {
                                    "प्राइवेट AES-256 तिजोरी को फिंगरप्रिंट या बायोमेट्रिक से स्थानीय रूप से अनलॉक करने के लिए।"
                                } else {
                                    "Used strictly to authenticate local unlock requests for the AES-256 Encrypted Private Vault."
                                },
                                icon = Icons.Rounded.Fingerprint,
                                iconColor = ElectricBlue
                            )
                        }

                        // STEP 3: Private Vault Security & Zero-Knowledge Architecture
                        PrivacyStepCard(
                            stepNumber = "3",
                            title = if (appLang == "hi") "प्राइवेट तिजोरी (Vault) & AES-256 एन्क्रिप्शन" else "Private Vault AES-256 Encryption Standard",
                            icon = Icons.Rounded.Lock,
                            iconColor = RoyalPurple
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Vidiopen Pro की प्राइवेट तिजोरी (Vault) आपके संवेदनशील वीडियो और फाइलों को सैन्य-स्तरीय (Military-Grade) AES-256 एन्क्रिप्शन से सुरक्षित करती है:"
                                } else {
                                    "Vidiopen Pro provides military-grade AES-256 local encryption for your confidential videos and media files:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "ज़ीरो-नॉलेज स्थानीय कुंजी (Zero-Knowledge Architecture)" else "Zero-Knowledge Local Storage",
                                description = if (appLang == "hi") {
                                    "आपका पिन/पासवर्ड और एन्क्रिप्शन कीज़ केवल आपके फोन के सुरक्षित Hardware KeyStore में रहती हैं। हम या कोई तीसरा पक्ष इसे कभी एक्सेस नहीं कर सकता।"
                                } else {
                                    "Your PIN/Password and encryption keys are generated and stored locally inside Android KeyStore. We have zero access to your master keys."
                                },
                                icon = Icons.Rounded.VpnKey,
                                iconColor = RoyalPurple
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "सिस्टम गैलरी से 100% सुरक्षा" else "Total System Gallery Stealth",
                                description = if (appLang == "hi") {
                                    "तिजोरी में जोड़ी गई फाइलें फोन की मुख्य गैलरी, गूगल फोटोज और दूसरे ऐप्स से पूरी तरह छिप जाती हैं।"
                                } else {
                                    "Vaulted media is isolated from public system scanners, Google Photos, and third-party file managers."
                                },
                                icon = Icons.Rounded.VisibilityOff,
                                iconColor = RoyalPurple
                            )
                        }

                        // STEP 4: What We DO NOT Collect
                        PrivacyStepCard(
                            stepNumber = "4",
                            title = if (appLang == "hi") "डेटा जो हम कभी एकत्र नहीं करते (Google Play Data Safety)" else "Information We Never Collect (Data Safety Declaration)",
                            icon = Icons.Rounded.CheckCircle,
                            iconColor = Color(0xFF10B981)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "Google Play Data Safety आवश्यकताओं के अनुसार, हम निम्नलिखित घोषणा करते हैं:"
                                } else {
                                    "In accordance with Google Play Data Safety requirements, we explicitly confirm the following non-collection policy:"
                                },
                                color = Color.White,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = "❌ No Personally Identifiable Information (PII)",
                                description = if (appLang == "hi") "हम आपका नाम, ईमेल, फोन नंबर, या व्यक्तिगत खाता जानकारी नहीं मांगते और न ही स्टोर करते हैं।" else "We do not request or store your real name, phone number, email address, or user profile.",
                                icon = Icons.Rounded.PersonOff,
                                iconColor = Color(0xFF10B981)
                            )

                            PrivacySubPoint(
                                title = "❌ No Media Content Uploads",
                                description = if (appLang == "hi") "आपके वीडियो, तस्वीरें या ऑडियो फाइलें कभी भी आपके डिवाइस से बाहर किसी सर्वर पर अपलोड नहीं होतीं।" else "Your videos, photos, and music files strictly remain on your device and are never uploaded.",
                                icon = Icons.Rounded.Block,
                                iconColor = Color(0xFF10B981)
                            )

                            PrivacySubPoint(
                                title = "❌ No Location & GPS Tracking",
                                description = if (appLang == "hi") "हम आपके स्थान (GPS, Cell ID या IP लोकेशन) को कभी ट्रैक नहीं करते हैं।" else "We do not access or track your real-time physical GPS location or cell tower data.",
                                icon = Icons.Rounded.LocationOff,
                                iconColor = Color(0xFF10B981)
                            )

                            PrivacySubPoint(
                                title = "❌ No Microphones or Camera Recording",
                                description = if (appLang == "hi") "ऐप आपके माइक्रोफोन या कैमरे की रिकॉर्डिंग को कभी बैकग्राउंड में चालू नहीं करता।" else "We do not record audio via microphone or capture video via camera in the background.",
                                icon = Icons.Rounded.MicOff,
                                iconColor = Color(0xFF10B981)
                            )
                        }

                        // STEP 5: Third-Party Advertising (Google AdMob)
                        PrivacyStepCard(
                            stepNumber = "5",
                            title = if (appLang == "hi") "तृतीय-पक्ष विज्ञापन एवं सेवाएं (Google AdMob)" else "Third-Party Advertising & Services (Google AdMob)",
                            icon = Icons.Rounded.AdsClick,
                            iconColor = Color(0xFFF59E0B)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "ऐप के रखरखाव और विकास को बनाए रखने के लिए, Vidiopen Pro Google AdMob विज्ञापन नेटवर्क का उपयोग कर सकता है:"
                                } else {
                                    "To support ongoing app development, Vidiopen Pro may integrate Google AdMob for contextual advertisement serving:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "Google एडवरटाइजिंग आईडी (AAID)" else "Google Advertising ID (AAID)",
                                description = if (appLang == "hi") {
                                    "AdMob नीति-सम्मत विज्ञापन दिखाने के लिए एक अनाम एडवरटाइजिंग आईडी का उपयोग कर सकता है। इसे आप फोन सेटिंग्स (Settings > Google > Ads) में किसी भी समय रीसेट कर सकते हैं।"
                                } else {
                                    "Google AdMob uses an anonymous Advertising ID to serve privacy-compliant ads. You can reset or opt out via Android Settings > Google > Ads."
                                },
                                icon = Icons.Rounded.Info,
                                iconColor = Color(0xFFF59E0B)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "तृतीय-पक्ष गोपनीयता नीतियां" else "Third-Party Privacy Compliance",
                                description = if (appLang == "hi") {
                                    "Google AdMob की गोपनीयता नीति देखने के लिए https://policies.google.com/privacy पर जाएं।"
                                } else {
                                    "You may review Google's Privacy & Terms at https://policies.google.com/privacy."
                                },
                                icon = Icons.Rounded.Link,
                                iconColor = Color(0xFFF59E0B)
                            )
                        }

                        // STEP 6: Global Compliance (GDPR, CCPA, COPPA)
                        PrivacyStepCard(
                            stepNumber = "6",
                            title = if (appLang == "hi") "अंतर्राष्ट्रीय कानून और अधिकार (GDPR, CCPA, COPPA)" else "International Privacy Laws (GDPR, CCPA & COPPA)",
                            icon = Icons.Rounded.Gavel,
                            iconColor = Color(0xFFEC4899)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "हम वैश्विक गोपनीयता कानूनों का पूरी तरह पालन करते हैं:"
                                } else {
                                    "Vidiopen Pro complies strictly with international privacy statutes across regions:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = "EU GDPR Rights (General Data Protection Regulation)",
                                description = if (appLang == "hi") {
                                    "यूरोपीय संघ के उपयोगकर्ताओं के पास अपने डेटा को देखने, मिटाने या प्रतिबंधित करने का पूर्ण अधिकार है। चूंकि डेटा केवल आपके फोन पर है, आप ऐप स्टोरेज मिटाकर इसे 100% डिलीट कर सकते हैं।"
                                } else {
                                    "European Union residents hold full rights to data erasure and portability. Clearing local app storage achieves 100% instant data removal."
                                },
                                icon = Icons.Rounded.Verified,
                                iconColor = Color(0xFFEC4899)
                            )

                            PrivacySubPoint(
                                title = "California CCPA/CPRA Disclosure",
                                description = if (appLang == "hi") {
                                    "हम कैलिफ़ोर्निया निवासियों की किसी भी व्यक्तिगत जानकारी को किसी तीसरे पक्ष को बेचते (Sell) या शेयर (Share) नहीं करते हैं।"
                                } else {
                                    "We sell 0 bytes of user personal information to third parties. We comply fully with California CCPA/CPRA guidelines."
                                },
                                icon = Icons.Rounded.Shield,
                                iconColor = Color(0xFFEC4899)
                            )

                            PrivacySubPoint(
                                title = "COPPA Compliance (Children Online Privacy)",
                                description = if (appLang == "hi") {
                                    "ऐप 13 वर्ष से कम उम्र के बच्चों से जानबूझकर कोई डेटा एकत्र नहीं करता है।"
                                } else {
                                    "Vidiopen Pro does not knowingly target or collect any personal information from children under the age of 13."
                                },
                                icon = Icons.Rounded.ChildCare,
                                iconColor = Color(0xFFEC4899)
                            )
                        }

                        // STEP 7: Data Retention & User Deletion Rights
                        PrivacyStepCard(
                            stepNumber = "7",
                            title = if (appLang == "hi") "डेटा सुरक्षा और उपयोगकर्ता के हटाने के अधिकार" else "Data Retention & Instant Wipe Rights",
                            icon = Icons.Rounded.DeleteForever,
                            iconColor = Color(0xFFEF4444)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "आपके पास अपने संपूर्ण ऐप डेटा पर 100% नियंत्रण है:"
                                } else {
                                    "You maintain total sovereignty over your local data and application footprint:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "30-दिन रिसाइकल बिन ऑटो-क्लीन" else "30-Day Trash Bin Self-Destruct",
                                description = if (appLang == "hi") {
                                    "डिलीट की गई फाइलें रिसाइकल बिन में केवल 30 दिनों तक रहती हैं जिसके बाद वे हमेशा के लिए नष्ट हो जाती हैं।"
                                } else {
                                    "Deleted files placed in the Trash Bin are permanently purged after 30 days automatically."
                                },
                                icon = Icons.Rounded.AutoDelete,
                                iconColor = Color(0xFFEF4444)
                            )

                            PrivacySubPoint(
                                title = if (appLang == "hi") "तत्काल संपूर्ण डेटा वाइप (Instant Wipe)" else "One-Step Full Local Wipe",
                                description = if (appLang == "hi") {
                                    "अपने एंड्रॉइड फोन की 'Settings > Apps > Vidiopen Pro > Storage > Clear Data' पर टैप करके या ऐप अनइंस्टॉल करके आप ऐप के सभी डेटा को तुरंत मिटा सकते हैं।"
                                } else {
                                    "Executing 'Clear Storage' in Android Settings or uninstalling the app immediately wipes 100% of local application state and cached database records."
                                },
                                icon = Icons.Rounded.CleaningServices,
                                iconColor = Color(0xFFEF4444)
                            )
                        }

                        // STEP 8: Contact Data Protection Officer (DPO)
                        PrivacyStepCard(
                            stepNumber = "8",
                            title = if (appLang == "hi") "डेटा सुरक्षा अधिकारी से संपर्क करें (Contact DPO)" else "Contact Official Data Protection Officer (DPO)",
                            icon = Icons.Rounded.ContactSupport,
                            iconColor = Color(0xFF10B981)
                        ) {
                            Text(
                                text = if (appLang == "hi") {
                                    "यदि इस गोपनीयता नीति या डेटा सुरक्षा के बारे में आपके कोई प्रश्न या सुझाव हैं, तो कृपया हमारे आधिकारिक डेटा प्रोटेक्शन ऑफिसर से सीधे संपर्क करें:"
                                } else {
                                    "If you have any questions, regulatory inquiries, or concerns regarding this Privacy Policy, please contact our designated Data Protection Officer:"
                                },
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.White.copy(alpha = 0.05f))
                                    .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                    .padding(12.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Official Entity: Vidiopen Security Team", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("Support Email: abhayshukla8498@gmail.com", color = Color(0xFF10B981), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text("Response Window: Within 24-48 Business Hours", color = Color.Gray, fontSize = 11.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = { sendSupportEmail() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Mail,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (appLang == "hi") "गोपनीयता प्रश्न के लिए ईमेल भेजें" else "Send Privacy Inquiry Email",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(32.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun PrivacyStepCard(
    stepNumber: String,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color = ElectricBlue,
    content: @Composable ColumnScope.() -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        cornerRadius = 16.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(iconColor.copy(alpha = 0.1f), CircleShape)
                        .border(1.dp, iconColor.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                if (stepNumber.isNotEmpty()) {
                    Text(
                        text = stepNumber,
                        color = iconColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier
                            .background(iconColor.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.05f)))
            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun PrivacySubPoint(
    title: String,
    description: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    iconColor: Color = ElectricBlue
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.Top
    ) {
        if (icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier
                    .padding(top = 2.dp)
                    .size(16.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
        } else {
            Box(
                modifier = Modifier
                    .padding(top = 6.dp)
                    .size(6.dp)
                    .background(iconColor, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            if (title.isNotEmpty()) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
            }
            Text(
                text = description,
                color = Color.LightGray,
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector? = null,
    tint: Color = ElectricBlue
) {
    GlassCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                if (icon != null) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(tint.copy(alpha = 0.12f), CircleShape)
                            .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = tint,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(subtitle, color = Color.Gray, fontSize = 11.sp)
                }
            }
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = ElectricBlue
                )
            )
        }
    }
}

@Composable
fun SettingFeatureLinkRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "SettingLinkScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(tint.copy(alpha = 0.12f), CircleShape)
                            .border(1.5.dp, tint.copy(alpha = 0.35f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = title,
                            tint = tint,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = subtitle,
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Navigate",
                    tint = Color.LightGray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun SettingSelectionRow(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    icon: ImageVector? = null,
    tint: Color = ElectricBlue
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.98f else 1.0f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "SettingSelectionScale"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        GlassCard(
            cornerRadius = 16.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (icon != null) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(tint.copy(alpha = 0.12f), CircleShape)
                                .border(1.dp, tint.copy(alpha = 0.25f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = tint,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                    }
                    Column {
                        Text(
                            text = title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = subtitle,
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
                Icon(
                    imageVector = Icons.Rounded.ChevronRight,
                    contentDescription = "Configure",
                    tint = Color.LightGray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

// ==========================================
// PRIVATE VAULT SCREEN (PRODUCTION SECURE VAULT)
// ==========================================

// Helper to find FragmentActivity from context for Biometrics
private fun Context.findActivity(): FragmentActivity? {
    var currentContext = this
    while (currentContext is ContextWrapper) {
        if (currentContext is FragmentActivity) {
            return currentContext
        }
        currentContext = currentContext.baseContext
    }
    return null
}

// Biometric helper
private fun triggerBiometricPrompt(
    context: Context,
    onSuccess: () -> Unit,
    onError: (String) -> Unit
) {
    val activity = context.findActivity()
    if (activity == null) {
        onError("Biometrics failed: Parent activity context is unavailable.")
        return
    }
    val executor = ContextCompat.getMainExecutor(context)
    val biometricPrompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            super.onAuthenticationSucceeded(result)
            onSuccess()
        }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            super.onAuthenticationError(errorCode, errString)
            onError(errString.toString())
        }
    })

    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Nova Vault Verification")
        .setSubtitle("Authenticate with your fingerprint to enter the private area")
        .setNegativeButtonText("Use Credentials")
        .build()

    try {
        biometricPrompt.authenticate(promptInfo)
    } catch (e: Exception) {
        onError("Biometric authentication failed: ${e.localizedMessage}")
    }
}

// Format duration helper
private fun formatVaultDuration(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}

// Secure Video Player View
@Composable
fun VaultVideoPlayerView(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember(file) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        val activity = context as? android.app.Activity
        activity?.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            exoPlayer.release()
            activity?.window?.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        androidx.compose.ui.viewinterop.AndroidView(
            factory = { ctx ->
                androidx.media3.ui.PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                    keepScreenOn = true
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Close Video", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                modifier = Modifier
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            )
        }
    }
}

// Secure Audio Player View
@Composable
fun VaultAudioPlayerView(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    val exoPlayer = remember(file) {
        androidx.media3.exoplayer.ExoPlayer.Builder(context).build().apply {
            val mediaItem = androidx.media3.common.MediaItem.fromUri(android.net.Uri.fromFile(file))
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var duration by remember { mutableStateOf(0L) }
    var currentPosition by remember { mutableStateOf(0L) }

    LaunchedEffect(exoPlayer) {
        while (true) {
            isPlaying = exoPlayer.isPlaying
            currentPosition = exoPlayer.currentPosition
            duration = exoPlayer.duration.coerceAtLeast(0L)
            kotlinx.coroutines.delay(500)
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(RoyalPurple.copy(alpha = 0.6f), Color.Black),
                            radius = 350f
                        )
                    )
                    .border(2.dp, ElectricBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = ElectricBlue,
                    modifier = Modifier.size(90.dp)
                )
            }

            Spacer(modifier = Modifier.height(36.dp))

            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Text(
                text = "Secured Vault Audio Track",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(modifier = Modifier.height(36.dp))

            Slider(
                value = if (duration > 0) currentPosition.toFloat() / duration.toFloat() else 0f,
                onValueChange = { ratio ->
                    val dest = (ratio * duration).toLong()
                    exoPlayer.seekTo(dest)
                },
                colors = SliderDefaults.colors(
                    thumbColor = ElectricBlue,
                    activeTrackColor = ElectricBlue,
                    inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatVaultDuration(currentPosition),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
                Text(
                    text = formatVaultDuration(duration),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { exoPlayer.seekTo((currentPosition - 10000).coerceAtLeast(0L)) },
                    modifier = Modifier.background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Replay10, contentDescription = "Rewind 10s", tint = Color.White)
                }

                IconButton(
                    onClick = {
                        if (isPlaying) {
                            exoPlayer.pause()
                        } else {
                            exoPlayer.play()
                        }
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .background(ElectricBlue, CircleShape)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                IconButton(
                    onClick = { exoPlayer.seekTo((currentPosition + 10000).coerceAtMost(duration)) },
                    modifier = Modifier.background(Color.White.copy(alpha = 0.05f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10s", tint = Color.White)
                }
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(16.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
        ) {
            Icon(Icons.Rounded.ArrowBack, contentDescription = "Close", tint = Color.White)
        }
    }
}

// Secure Photo Viewer View
@Composable
fun VaultPhotoViewer(
    file: java.io.File,
    title: String,
    onClose: () -> Unit
) {
    val bitmap = remember(file) {
        try {
            val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, opts)
            var sampleSize = 1
            if (opts.outHeight > 2048 || opts.outWidth > 2048) {
                val halfH = opts.outHeight / 2
                val halfW = opts.outWidth / 2
                while (halfH / sampleSize >= 2048 && halfW / sampleSize >= 2048) {
                    sampleSize *= 2
                }
            }
            val decodeOpts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sampleSize }
            android.graphics.BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
        } catch (e: Exception) {
            null
        }
    }

    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(1f, 5f)
                    if (scale == 1f) {
                        offset = Offset.Zero
                    } else {
                        offset += pan
                    }
                }
            }
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = title,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    )
                    .align(Alignment.Center),
                contentScale = ContentScale.Fit
            )
        } else {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Rounded.BrokenImage, contentDescription = null, tint = Color.Red, modifier = Modifier.size(48.dp))
                Text("Failed to render encrypted photo", color = Color.Gray, fontSize = 14.sp)
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onClose,
                modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
            ) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Close Photo", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .weight(1f)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(8.dp)
            )
            if (scale > 1f) {
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        scale = 1f
                        offset = Offset.Zero
                    },
                    modifier = Modifier.background(Color.Black.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(Icons.Rounded.ZoomOut, contentDescription = "Reset Zoom", tint = Color.White)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivateVaultScreen(
    viewModel: MediaViewModel,
    onBack: () -> Unit = {},
    vaultViewModel: VaultViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
        factory = VaultViewModelFactory(
            application = LocalContext.current.applicationContext as android.app.Application,
            repository = (LocalContext.current.applicationContext as com.example.NovaPlayApplication).container.mediaRepository
        )
    )
) {
    val context = LocalContext.current

    // Bind state flows
    val isUnlocked by vaultViewModel.isUnlocked.collectAsState()
    val unlockMethod by vaultViewModel.unlockMethod.collectAsState()
    val hasPin by vaultViewModel.hasPin.collectAsState()
    val hasPattern by vaultViewModel.hasPattern.collectAsState()
    val hasPassword by vaultViewModel.hasPassword.collectAsState()
    val isBiometricEnabled by vaultViewModel.isBiometricEnabled.collectAsState()
    val autoLockTimeout by vaultViewModel.autoLockTimeout.collectAsState()
    val activeSection by vaultViewModel.activeSection.collectAsState()

    // Sub-category items
    val videosList by vaultViewModel.videos.collectAsState()
    val photosList by vaultViewModel.photos.collectAsState()
    val audioList by vaultViewModel.audio.collectAsState()
    val documentsList by vaultViewModel.documents.collectAsState()
    val favoritesList by vaultViewModel.favorites.collectAsState()
    val recentlyAddedList by vaultViewModel.recentlyAdded.collectAsState()

    // Active decrypted files for immediate play/view
    val activeDecryptedFile by vaultViewModel.activeDecryptedFile.collectAsState()
    val activeDecryptedItem by vaultViewModel.activeDecryptedItem.collectAsState()
    val isDecrypting by vaultViewModel.isDecrypting.collectAsState()

    // Screen states
    val appLang by viewModel.appLanguage.collectAsState()
    val selectedThemeId by viewModel.selectedThemeId.collectAsState()
    val customBgUri by viewModel.customBackgroundUri.collectAsState()
    var enteredPin by remember { mutableStateOf("") }
    var firstAttemptPin by remember { mutableStateOf("") }
    var isConfirming by remember { mutableStateOf(false) }
    var authErrorMessage by remember { mutableStateOf("") }

    var showSettingsSheet by remember { mutableStateOf(false) }
    var fileImportError by remember { mutableStateOf<String?>(null) }

    androidx.activity.compose.BackHandler(
        enabled = isUnlocked && (showSettingsSheet || activeSection != "HOME" || activeDecryptedFile != null)
    ) {
        if (activeDecryptedFile != null) {
            vaultViewModel.dismissActiveViewer()
        } else if (showSettingsSheet) {
            showSettingsSheet = false
        } else if (activeSection != "HOME") {
            vaultViewModel.setActiveSection("HOME")
        }
    }

    // States for custom privacy file renaming
    var pickedUriForRename by remember { mutableStateOf<android.net.Uri?>(null) }
    var pickedTypeForRename by remember { mutableStateOf<String?>(null) }
    var privateRenameValue by remember { mutableStateOf("") }

    // States for photo import chooser modal
    var showPhotoChooserSheet by remember { mutableStateOf(false) }
    var scannedPhotosForVault by remember { mutableStateOf<List<com.example.data.model.TransferFile>>(emptyList()) }
    var isScanningVaultPhotos by remember { mutableStateOf(false) }

    LaunchedEffect(showPhotoChooserSheet) {
        if (showPhotoChooserSheet) {
            isScanningVaultPhotos = true
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                val photos = com.example.utils.FileScannerUtil.scanFiles(context, "PHOTO")
                scannedPhotosForVault = photos
            }
            isScanningVaultPhotos = false
        }
    }

    // Dialog for Delete Original Confirmation
    var pendingDeleteAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showDeleteOriginalDialog by remember { mutableStateOf(false) }

    // File Pickers Launchers
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) {
            vaultViewModel.suspendLocking(false)
        } else {
            pickedUriForRename = uri
            pickedTypeForRename = "VIDEO"
            privateRenameValue = "Privacy_Video_" + (System.currentTimeMillis() % 100000)
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) {
            vaultViewModel.suspendLocking(false)
        } else {
            pickedUriForRename = uri
            pickedTypeForRename = "PHOTO"
            privateRenameValue = "Privacy_Photo_" + (System.currentTimeMillis() % 100000)
        }
    }

    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) {
            vaultViewModel.suspendLocking(false)
        } else {
            pickedUriForRename = uri
            pickedTypeForRename = "AUDIO"
            privateRenameValue = "Privacy_Audio_" + (System.currentTimeMillis() % 100000)
        }
    }

    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri == null) {
            vaultViewModel.suspendLocking(false)
        } else {
            pickedUriForRename = uri
            pickedTypeForRename = "DOCUMENT"
            privateRenameValue = "Privacy_Doc_" + (System.currentTimeMillis() % 100000)
        }
    }

    // Auto-lock lifecycle observer
    val lifecycleOwner = androidx.lifecycle.compose.LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            if (event == androidx.lifecycle.Lifecycle.Event.ON_STOP) {
                vaultViewModel.onAppGoToBackground()
            } else if (event == androidx.lifecycle.Lifecycle.Event.ON_START) {
                vaultViewModel.onAppReturnToForeground()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Trigger fingerprint prompt on screen launch if biometrics is enabled
    LaunchedEffect(isUnlocked) {
        if (!isUnlocked && isBiometricEnabled) {
            val biometricManager = BiometricManager.from(context)
            val canAuthenticate = biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
            if (canAuthenticate) {
                triggerBiometricPrompt(context,
                    onSuccess = { vaultViewModel.verifyBiometricSuccess() },
                    onError = { authErrorMessage = it }
                )
            }
        }
    }

    // Main layout container
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        AppThemeBackground(
            selectedThemeId = selectedThemeId,
            customBackgroundUri = customBgUri
        )
        if (!isUnlocked) {
            // Force preferred unlock method to PIN for the Privacy feature
            if (unlockMethod != "PIN") {
                LaunchedEffect(Unit) {
                    vaultViewModel.setUnlockMethod("PIN")
                }
            }

            // Automatic PIN state transition handler
            LaunchedEffect(enteredPin) {
                if (enteredPin.length == 4) {
                    kotlinx.coroutines.delay(150)
                    if (!hasPin) {
                        if (!isConfirming) {
                            firstAttemptPin = enteredPin
                            enteredPin = ""
                            isConfirming = true
                            authErrorMessage = ""
                        } else {
                            if (enteredPin == firstAttemptPin) {
                                vaultViewModel.savePin(enteredPin)
                                enteredPin = ""
                                firstAttemptPin = ""
                                isConfirming = false
                                authErrorMessage = ""
                            } else {
                                authErrorMessage = if (appLang == "hi") "पिन मेल नहीं खाते! फिर से प्रयास करें।" else "PINs do not match! Start over."
                                enteredPin = ""
                                firstAttemptPin = ""
                                isConfirming = false
                            }
                        }
                    } else {
                        val success = vaultViewModel.verifyUnlock(enteredPin)
                        if (success) {
                            enteredPin = ""
                            authErrorMessage = ""
                        } else {
                            authErrorMessage = if (appLang == "hi") "गलत पिन! फिर से कोशिश करें।" else "Incorrect PIN! Try again."
                            enteredPin = ""
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Header Bar (Matches design header "← Set Password")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onBack() }) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = if (!hasPin) {
                            if (appLang == "hi") "पासवर्ड सेट करें" else "Set Password"
                        } else {
                            if (appLang == "hi") "गोपनीयता" else "Privacy"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }

                // PIN content and Keypad layout
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 40.dp)
                    ) {
                        val instructionText = if (!hasPin) {
                            if (!isConfirming) {
                                if (appLang == "hi") "अपनी गोपनीयता की सुरक्षा के लिए पिन बनाएं" else "Create PIN to protect your privacy"
                            } else {
                                if (appLang == "hi") "अपने पासवर्ड की पुष्टि करें" else "Confirm your password"
                            }
                        } else {
                            if (appLang == "hi") "अपनी गोपनीयता की सुरक्षा के लिए पिन डालें" else "Enter PIN to protect your privacy"
                        }

                        Text(
                            text = instructionText,
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Normal,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(36.dp))

                        // Row of 4 squares
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            repeat(4) { index ->
                                val isFilled = index < enteredPin.length
                                val isActive = index == enteredPin.length
                                
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color(0xFF262626)) // Dark gray square from image
                                        .then(
                                            if (isActive) Modifier.border(2.dp, Color(0xFF10B981), RoundedCornerShape(12.dp))
                                            else Modifier
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isFilled) {
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clip(CircleShape)
                                                .background(Color.White)
                                        )
                                    } else if (isActive) {
                                        Box(
                                            modifier = Modifier
                                                .width(2.dp)
                                                .height(20.dp)
                                                .background(Color(0xFF10B981))
                                        )
                                    }
                                }
                            }
                        }

                        if (authErrorMessage.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = authErrorMessage,
                                color = Color.Red,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 24.dp)
                            )
                        }
                    }

                    // Keypad
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 32.dp, end = 32.dp, bottom = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        val leftKey = if (isBiometricEnabled && hasPin) "biometric" else ""
                        val rows = listOf(
                            listOf("1", "2", "3"),
                            listOf("4", "5", "6"),
                            listOf("7", "8", "9"),
                            listOf(leftKey, "0", "backspace")
                        )

                        rows.forEach { row ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                row.forEach { key ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(72.dp)
                                            .clickable(
                                                enabled = key.isNotEmpty(),
                                                onClick = {
                                                    if (key == "backspace") {
                                                        if (enteredPin.isNotEmpty()) {
                                                            enteredPin = enteredPin.dropLast(1)
                                                        }
                                                    } else if (key == "biometric") {
                                                        triggerBiometricPrompt(context,
                                                            onSuccess = { vaultViewModel.verifyBiometricSuccess() },
                                                            onError = { authErrorMessage = it }
                                                        )
                                                    } else if (key.isNotEmpty()) {
                                                        if (enteredPin.length < 4) {
                                                            enteredPin += key
                                                            authErrorMessage = ""
                                                        }
                                                    }
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (key == "backspace") {
                                            Icon(
                                                imageVector = Icons.Rounded.Backspace,
                                                contentDescription = "Backspace",
                                                tint = Color.White,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        } else if (key == "biometric") {
                                            Icon(
                                                imageVector = Icons.Rounded.Fingerprint,
                                                contentDescription = "Biometric",
                                                tint = Color(0xFF10B981),
                                                modifier = Modifier.size(32.dp)
                                            )
                                        } else if (key.isNotEmpty()) {
                                            Text(
                                                text = key,
                                                color = Color.White,
                                                fontSize = 28.sp,
                                                fontWeight = FontWeight.Normal
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // --- VAULT HOME DASHBOARD SCREEN ---
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(60.dp))

                // Vault Header Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            if (activeSection != "HOME") {
                                vaultViewModel.setActiveSection("HOME")
                            } else {
                                vaultViewModel.lock()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = if (activeSection != "HOME") Icons.Rounded.ArrowBack else Icons.Rounded.LockOpen,
                            contentDescription = "Lock",
                            tint = ElectricBlue
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (activeSection == "HOME") { if (appLang == "hi") "गोपनीयता" else "Privacy" } else activeSection,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        GlowText("AES Keystore Secure", color = RoyalPurple, fontSize = 11.sp)
                    }

                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                if (activeSection == "HOME") {
                    // --- VAULT HOME SECTIONS (VIDEOS, PHOTOS, MUSIC, DOCUMENTS, FAVORITES) ---
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Category Cards Grid
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Videos",
                                count = videosList.size,
                                icon = Icons.Rounded.VideoLibrary,
                                color = ElectricBlue,
                                onClick = { vaultViewModel.setActiveSection("VIDEOS") },
                                modifier = Modifier.weight(1f)
                            )
                            VaultCategoryCard(
                                title = "Photos",
                                count = photosList.size,
                                icon = Icons.Rounded.PhotoLibrary,
                                color = Color(0xFFFF4081),
                                onClick = { vaultViewModel.setActiveSection("PHOTOS") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Music",
                                count = audioList.size,
                                icon = Icons.Rounded.LibraryMusic,
                                color = RoyalPurple,
                                onClick = { vaultViewModel.setActiveSection("MUSIC") },
                                modifier = Modifier.weight(1f)
                            )
                            VaultCategoryCard(
                                title = "Documents",
                                count = documentsList.size,
                                icon = Icons.Rounded.FolderOpen,
                                color = Color(0xFFFFB300),
                                onClick = { vaultViewModel.setActiveSection("DOCUMENTS") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            VaultCategoryCard(
                                title = "Favorites",
                                count = favoritesList.size,
                                icon = Icons.Rounded.Favorite,
                                color = Color.Red,
                                onClick = { vaultViewModel.setActiveSection("FAVORITES") },
                                modifier = Modifier.weight(1.0f)
                            )
                        }

                        // Recently Added Section
                        if (recentlyAddedList.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                "Recently Added",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                recentlyAddedList.take(3).forEach { item ->
                                    GlassCard(modifier = Modifier.fillMaxWidth().clickable {
                                        vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                    }) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            val icon = when (item.type) {
                                                "VIDEO" -> Icons.Rounded.VideoLibrary
                                                "PHOTO" -> Icons.Rounded.Photo
                                                "AUDIO" -> Icons.Rounded.Audiotrack
                                                else -> Icons.Rounded.Description
                                            }
                                            val tint = when (item.type) {
                                                "VIDEO" -> ElectricBlue
                                                "PHOTO" -> Color(0xFFFF4081)
                                                "AUDIO" -> RoyalPurple
                                                else -> Color(0xFFFFB300)
                                            }
                                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Column {
                                                    Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text("Encrypted & Secure", color = Color.Gray, fontSize = 11.sp)
                                                }
                                            }
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = tint.copy(alpha = 0.2f),
                                                modifier = Modifier.clickable {
                                                    vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                                }
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                ) {
                                                    val playIcon = when (item.type) {
                                                        "VIDEO" -> Icons.Rounded.PlayArrow
                                                        "PHOTO" -> Icons.Rounded.Visibility
                                                        "AUDIO" -> Icons.Rounded.PlayArrow
                                                        else -> Icons.Rounded.Visibility
                                                    }
                                                    val playLabel = when (item.type) {
                                                        "VIDEO" -> if (appLang == "hi") "प्ले" else "Play"
                                                        "PHOTO" -> if (appLang == "hi") "देखें" else "View"
                                                        "AUDIO" -> if (appLang == "hi") "सुनें" else "Listen"
                                                        else -> if (appLang == "hi") "पढ़ें" else "Open"
                                                    }
                                                    Icon(playIcon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                                                    Text(playLabel, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Bottom Spacer for scrolling
                        Spacer(modifier = Modifier.height(80.dp))
                    }

                    // Floating action menu for imports
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .background(Color.Black.copy(alpha = 0.8f), RoundedCornerShape(32.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(32.dp))
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            IconButton(onClick = {
                                vaultViewModel.suspendLocking(true)
                                videoPickerLauncher.launch("video/*")
                            }) {
                                Icon(Icons.Rounded.VideoCall, contentDescription = "Import Video", tint = ElectricBlue)
                            }
                            IconButton(onClick = {
                                vaultViewModel.suspendLocking(true)
                                showPhotoChooserSheet = true
                            }) {
                                Icon(Icons.Rounded.AddAPhoto, contentDescription = "Import Photo", tint = Color(0xFFFF4081))
                            }
                            IconButton(onClick = {
                                vaultViewModel.suspendLocking(true)
                                audioPickerLauncher.launch("audio/*")
                            }) {
                                Icon(Icons.Rounded.AudioFile, contentDescription = "Import Audio", tint = RoyalPurple)
                            }
                            IconButton(onClick = {
                                vaultViewModel.suspendLocking(true)
                                documentPickerLauncher.launch("*/*")
                            }) {
                                Icon(Icons.Rounded.NoteAdd, contentDescription = "Import Document", tint = Color(0xFFFFB300))
                            }
                        }
                    }

                } else {
                    // --- SUB-CATEGORIES ITEMS LIST ---
                    val activeList = when (activeSection) {
                        "VIDEOS" -> videosList
                        "PHOTOS" -> photosList
                        "MUSIC" -> audioList
                        "DOCUMENTS" -> documentsList
                        "FAVORITES" -> favoritesList
                        else -> emptyList()
                    }

                    // Header Action Card for Subcategory Import
                    if (activeSection == "PHOTOS") {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clickable {
                                    vaultViewModel.suspendLocking(true)
                                    showPhotoChooserSheet = true
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFFF4081).copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.AddAPhoto, contentDescription = null, tint = Color(0xFFFF4081))
                                    }
                                    Column {
                                        Text(
                                            text = if (appLang == "hi") "नया फ़ोटो इम्पोर्ट करें" else "Import New Photo",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = if (appLang == "hi") "गोपनीयता में फ़ोटो चुनने और सहेजने के लिए टैप करें" else "Tap to choose and import photo into privacy",
                                            color = Color.Gray,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Icon(Icons.Rounded.Add, contentDescription = "Import", tint = Color(0xFFFF4081))
                            }
                        }
                    } else if (activeSection == "VIDEOS") {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clickable {
                                    vaultViewModel.suspendLocking(true)
                                    videoPickerLauncher.launch("video/*")
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(ElectricBlue.copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.VideoCall, contentDescription = null, tint = ElectricBlue)
                                    }
                                    Column {
                                        Text(
                                            text = if (appLang == "hi") "नया वीडियो इम्पोर्ट करें" else "Import New Video",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = if (appLang == "hi") "गोपनीयता में वीडियो जोड़ने के लिए टैप करें" else "Tap to choose video for privacy vault",
                                            color = Color.Gray,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Icon(Icons.Rounded.Add, contentDescription = "Import", tint = ElectricBlue)
                            }
                        }
                    } else if (activeSection == "MUSIC") {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clickable {
                                    vaultViewModel.suspendLocking(true)
                                    audioPickerLauncher.launch("audio/*")
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(RoyalPurple.copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.AudioFile, contentDescription = null, tint = RoyalPurple)
                                    }
                                    Column {
                                        Text(
                                            text = if (appLang == "hi") "नया ऑडियो इम्पोर्ट करें" else "Import New Audio",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = if (appLang == "hi") "गोपनीयता में ऑडियो जोड़ने के लिए टैप करें" else "Tap to choose audio for privacy vault",
                                            color = Color.Gray,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Icon(Icons.Rounded.Add, contentDescription = "Import", tint = RoyalPurple)
                            }
                        }
                    } else if (activeSection == "DOCUMENTS") {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .clickable {
                                    vaultViewModel.suspendLocking(true)
                                    documentPickerLauncher.launch("*/*")
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(Color(0xFFFFB300).copy(alpha = 0.2f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Rounded.NoteAdd, contentDescription = null, tint = Color(0xFFFFB300))
                                    }
                                    Column {
                                        Text(
                                            text = if (appLang == "hi") "नया दस्तावेज़ इम्पोर्ट करें" else "Import New Document",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                        Text(
                                            text = if (appLang == "hi") "गोपनीयता में फ़ाइल जोड़ने के लिए टैप करें" else "Tap to choose file for privacy vault",
                                            color = Color.Gray,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Icon(Icons.Rounded.Add, contentDescription = "Import", tint = Color(0xFFFFB300))
                            }
                        }
                    }

                    if (activeList.isEmpty()) {
                        val icon = when (activeSection) {
                            "VIDEOS" -> Icons.Rounded.VideoLibrary
                            "PHOTOS" -> Icons.Rounded.PhotoLibrary
                            "MUSIC" -> Icons.Rounded.LibraryMusic
                            "DOCUMENTS" -> Icons.Rounded.FolderZip
                            else -> Icons.Rounded.Favorite
                        }
                        ElegantVaultEmptyState(
                            icon = icon,
                            title = "No secret files yet",
                            description = "Use the import shortcuts in the dashboard to add files safely here."
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(activeList) { item ->
                                val icon = when (item.type) {
                                    "VIDEO" -> Icons.Rounded.VideoLibrary
                                    "PHOTO" -> Icons.Rounded.Photo
                                    "AUDIO" -> Icons.Rounded.Audiotrack
                                    else -> Icons.Rounded.Description
                                }
                                val tint = when (item.type) {
                                    "VIDEO" -> ElectricBlue
                                    "PHOTO" -> Color(0xFFFF4081)
                                    "AUDIO" -> RoyalPurple
                                    else -> Color(0xFFFFB300)
                                }
                                GlassCard(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(24.dp))
                                            Spacer(modifier = Modifier.width(16.dp))
                                            Column {
                                                Text(item.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(
                                                    text = "Added: ${android.text.format.DateFormat.format("MMM dd, yyyy", item.addedDate)}",
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(16.dp),
                                                color = tint.copy(alpha = 0.2f),
                                                modifier = Modifier
                                                    .padding(end = 4.dp)
                                                    .clickable {
                                                        vaultViewModel.selectItemForPlaybackOrView(item, onError = { fileImportError = it })
                                                    }
                                            ) {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                                ) {
                                                    val playIcon = when (item.type) {
                                                        "VIDEO" -> Icons.Rounded.PlayArrow
                                                        "PHOTO" -> Icons.Rounded.Visibility
                                                        "AUDIO" -> Icons.Rounded.PlayArrow
                                                        else -> Icons.Rounded.Visibility
                                                    }
                                                    val playLabel = when (item.type) {
                                                        "VIDEO" -> if (appLang == "hi") "प्ले" else "Play"
                                                        "PHOTO" -> if (appLang == "hi") "देखें" else "View"
                                                        "AUDIO" -> if (appLang == "hi") "सुनें" else "Listen"
                                                        else -> if (appLang == "hi") "पढ़ें" else "Open"
                                                    }
                                                    Icon(playIcon, contentDescription = null, tint = tint, modifier = Modifier.size(16.dp))
                                                    Text(playLabel, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                }
                                            }

                                            IconButton(onClick = { vaultViewModel.toggleVaultFavorite(item) }) {
                                                Icon(
                                                    imageVector = if (item.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                                    contentDescription = "Favorite",
                                                    tint = if (item.isFavorite) Color.Red else Color.Gray
                                                )
                                            }

                                            IconButton(
                                                onClick = {
                                                    val exportDir = File(
                                                        context.getExternalFilesDir(null), 
                                                        "VaultExports"
                                                    )
                                                    vaultViewModel.exportVaultItem(item, exportDir,
                                                        onSuccess = { msg -> fileImportError = msg },
                                                        onError = { err -> fileImportError = err }
                                                    )
                                                }
                                            ) {
                                                Icon(Icons.Rounded.IosShare, contentDescription = "Export file", tint = ElectricBlue)
                                            }

                                            IconButton(onClick = { vaultViewModel.deleteVaultItem(item) }) {
                                                Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color.Gray)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (isDecrypting) {
            androidx.compose.ui.window.Dialog(onDismissRequest = {}) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E1E2C)
                ) {
                    Row(
                        modifier = Modifier.padding(24.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator(color = ElectricBlue, modifier = Modifier.size(32.dp))
                        Column {
                            Text(
                                text = if (appLang == "hi") "मीडिया लोड हो रहा है..." else "Decrypting & Loading...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (appLang == "hi") "कृपया प्रतीक्षा करें" else "Please wait a moment",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        // --- INTERNAL SECURE PLAYERS / VIEWERS LAYER ---
        activeDecryptedFile?.let { tempFile ->
            val item = activeDecryptedItem
            if (item != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black)
                ) {
                    when (item.type) {
                        "VIDEO" -> {
                            VaultVideoPlayerView(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "AUDIO" -> {
                            VaultAudioPlayerView(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "PHOTO" -> {
                            VaultPhotoViewer(
                                file = tempFile,
                                title = item.title,
                                onClose = { vaultViewModel.dismissActiveViewer() }
                            )
                        }
                        "DOCUMENT" -> {
                            SecureDocumentReader(
                                file = tempFile,
                                title = item.title,
                                onBack = { vaultViewModel.dismissActiveViewer() },
                                onExport = {
                                    val exportDir = File(
                                        context.getExternalFilesDir(null), 
                                        "VaultExports"
                                    )
                                    vaultViewModel.exportVaultItem(item, exportDir,
                                        onSuccess = { msg -> fileImportError = msg },
                                        onError = { err -> fileImportError = err }
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }

        // --- SETTINGS DIALOG / BOTTOM SHEET ---
        if (showSettingsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showSettingsSheet = false },
                containerColor = Color(0xFF161622),
                contentColor = Color.White
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        "Vault Settings",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )

                    Divider(color = Color.White.copy(alpha = 0.08f))

                    // Reset security PIN option
                    Button(
                        onClick = {
                            vaultViewModel.resetPin()
                            enteredPin = ""
                            firstAttemptPin = ""
                            isConfirming = false
                            authErrorMessage = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().height(44.dp)
                    ) {
                        Text(if (appLang == "hi") "सुरक्षा पिन रीसेट करें" else "Reset Security PIN", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    // Biometrics toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Fingerprint Authentication", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Enable biometrics for lightning unlock", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = isBiometricEnabled,
                            onCheckedChange = { vaultViewModel.setBiometricEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = ElectricBlue,
                                checkedTrackColor = RoyalPurple
                            )
                        )
                    }

                    // Auto-lock timeout config
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Auto-Lock Timeout", color = Color.Gray, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            // (seconds: 0=immediate, 15s, 60s, 300s)
                            listOf(0 to "Immediate", 15 to "15s", 60 to "1m", 300 to "5m").forEach { (sec, label) ->
                                val selected = autoLockTimeout == sec
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (selected) ElectricBlue else Color.White.copy(alpha = 0.05f))
                                        .clickable { vaultViewModel.setAutoLockTimeout(sec) }
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (selected) Color.Black else Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        // --- PHOTO IMPORT CHOOSER SHEET ---
        if (showPhotoChooserSheet) {
            androidx.compose.ui.window.Dialog(
                onDismissRequest = { showPhotoChooserSheet = false },
                properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF121218)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Header Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Rounded.AddAPhoto, contentDescription = null, tint = Color(0xFFFF4081))
                                Text(
                                    text = if (appLang == "hi") "इम्पोर्ट के लिए फ़ोटो चुनें" else "Select Photo to Import",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }
                            IconButton(onClick = { showPhotoChooserSheet = false }) {
                                Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.Gray)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Row: Browse System Gallery button
                        Button(
                            onClick = {
                                vaultViewModel.suspendLocking(true)
                                photoPickerLauncher.launch("image/*")
                                showPhotoChooserSheet = false
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F1F2C)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Rounded.FolderSpecial, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (appLang == "hi") "सिस्टम गैलरी से फ़ोटो चुनें" else "Browse System Photo Gallery",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (isScanningVaultPhotos) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    CircularProgressIndicator(color = Color(0xFFFF4081))
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = if (appLang == "hi") "फ़ोटो स्कैन हो रही हैं..." else "Scanning device photos...",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        } else if (scannedPhotosForVault.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Rounded.PhotoLibrary, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(48.dp))
                                    Text(
                                        text = if (appLang == "hi") "डिवाइस पर कोई फ़ोटो नहीं मिली" else "No photos found on device",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = if (appLang == "hi") "गैलरी से चुनने के लिए ऊपर दिए गए बटन का उपयोग करें" else "Use the system gallery button above to choose a photo",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        } else {
                            Text(
                                text = if (appLang == "hi") "जिस फ़ोटो को आप गोपनीयता में इम्पोर्ट करना चाहते हैं उस पर टैप करें:" else "Tap on the photo you want to import to Privacy:",
                                color = Color.LightGray,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            LazyVerticalGrid(
                                columns = GridCells.Fixed(3),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(scannedPhotosForVault) { photo ->
                                    val photoFile = remember(photo.path) { java.io.File(photo.path) }
                                    Box(
                                        modifier = Modifier
                                            .aspectRatio(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF20202E))
                                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(12.dp))
                                            .clickable {
                                                pickedUriForRename = android.net.Uri.fromFile(photoFile)
                                                pickedTypeForRename = "PHOTO"
                                                privateRenameValue = "Privacy_Photo_" + (System.currentTimeMillis() % 100000)
                                                showPhotoChooserSheet = false
                                            }
                                    ) {
                                        AsyncImage(
                                            model = photoFile,
                                            contentDescription = photo.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.BottomCenter)
                                                .background(Color.Black.copy(alpha = 0.6f))
                                                .padding(4.dp)
                                        ) {
                                            Text(
                                                text = photo.name,
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- CUSTOM RENAME FOR PRIVACY DIALOG ---
        if (pickedUriForRename != null && pickedTypeForRename != null) {
            AlertDialog(
                onDismissRequest = {
                    pickedUriForRename = null
                    pickedTypeForRename = null
                    vaultViewModel.suspendLocking(false)
                },
                containerColor = Color(0xFF161622),
                title = {
                    Text(
                        text = if (pickedTypeForRename == "PHOTO") {
                            if (appLang == "hi") "गोपनीयता में फोटो इम्पोर्ट करें" else "Import Photo to Privacy"
                        } else {
                            if (appLang == "hi") "गोपनीयता के लिए नाम बदलें" else "Rename for Privacy"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 20.sp
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = if (pickedTypeForRename == "PHOTO") {
                                if (appLang == "hi") "इस फोटो को गोपनीयता (Vault) में सुरक्षित रूप से एन्क्रिप्ट और सहेजने के लिए एक गोपनीय नाम दें।"
                                else "Give this photo a private name or save directly to import it into your privacy vault."
                            } else {
                                if (appLang == "hi") "गोपनीय फोल्डर में इसकी पहचान छिपाने के लिए इस फ़ाइल का नाम बदलें।"
                                else "Rename this file to obfuscate its identity inside the privacy folder."
                            },
                            color = Color.LightGray,
                            fontSize = 13.sp
                        )
                        OutlinedTextField(
                            value = privateRenameValue,
                            onValueChange = { privateRenameValue = it },
                            label = { Text(if (appLang == "hi") "गोपनीय नाम" else "Private Name") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF10B981),
                                unfocusedBorderColor = Color.Gray,
                                focusedLabelColor = Color(0xFF10B981),
                                unfocusedLabelColor = Color.Gray
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val uri = pickedUriForRename!!
                            val type = pickedTypeForRename!!
                            val customName = privateRenameValue.trim().ifEmpty { null }
                            
                            vaultViewModel.importFileFromUri(
                                uri = uri,
                                type = type,
                                customTitle = customName,
                                onImportSuccess = { deleteAction ->
                                    deleteAction()
                                    Toast.makeText(context, if (appLang == "hi") "🔒 प्राइवेसी में एन्क्रिप्ट किया गया और फोन से हटा दिया गया!" else "🔒 Encrypted in Vault & erased from public storage!", Toast.LENGTH_LONG).show()
                                    vaultViewModel.suspendLocking(false)
                                },
                                onError = { err -> 
                                    fileImportError = err
                                    vaultViewModel.suspendLocking(false)
                                }
                            )
                            pickedUriForRename = null
                            pickedTypeForRename = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                    ) {
                        Text(
                            text = if (pickedTypeForRename == "PHOTO") {
                                if (appLang == "hi") "फोटो इम्पोर्ट करें" else "Import Photo"
                            } else {
                                if (appLang == "hi") "सुरक्षित रूप से सहेजें" else "Save Privately"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            val uri = pickedUriForRename!!
                            val type = pickedTypeForRename!!
                            
                            vaultViewModel.importFileFromUri(
                                uri = uri,
                                type = type,
                                customTitle = null, // keeps original name
                                onImportSuccess = { deleteAction ->
                                    deleteAction()
                                    Toast.makeText(context, if (appLang == "hi") "🔒 प्राइवेसी में एन्क्रिप्ट किया गया और फोन से हटा दिया गया!" else "🔒 Encrypted in Vault & erased from public storage!", Toast.LENGTH_LONG).show()
                                    vaultViewModel.suspendLocking(false)
                                },
                                onError = { err -> 
                                    fileImportError = err
                                    vaultViewModel.suspendLocking(false)
                                }
                            )
                            pickedUriForRename = null
                            pickedTypeForRename = null
                        }
                    ) {
                        Text(if (appLang == "hi") "मूल नाम से सहेजें" else "Keep Original Name", color = Color.Gray)
                    }
                }
            )
        }

        // --- CONFIRMATION FOR DELETING ORIGINAL FILE ---
        if (showDeleteOriginalDialog && pendingDeleteAction != null) {
            AlertDialog(
                onDismissRequest = {
                    pendingDeleteAction = null
                    showDeleteOriginalDialog = false
                    vaultViewModel.suspendLocking(false)
                },
                containerColor = Color(0xFF161622),
                title = {
                    Text(if (appLang == "hi") "गोपनीयता आयात पूर्ण" else "Secure Import Complete", color = Color.White, fontWeight = FontWeight.Black)
                },
                text = {
                    Text(
                        text = if (appLang == "hi") 
                            "फ़ाइल को सुरक्षित रूप से एन्क्रिप्टेड गोपनीयता में सहेज लिया गया है। क्या आप मूल अनएन्क्रिप्टेड फ़ाइल को डिवाइस से स्थायी रूप से हटाना चाहते हैं?"
                        else 
                            "The file has been successfully copied into the encrypted privacy vault storage. To prevent security leaks, would you like to securely delete the original unencrypted file from public storage?",
                        color = Color.LightGray,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            pendingDeleteAction?.invoke()
                            pendingDeleteAction = null
                            showDeleteOriginalDialog = false
                            vaultViewModel.suspendLocking(false)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                    ) {
                        Text(if (appLang == "hi") "मूल फ़ाइल हटाएं" else "Delete Original", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            pendingDeleteAction = null
                            showDeleteOriginalDialog = false
                            vaultViewModel.suspendLocking(false)
                        }
                    ) {
                        Text(if (appLang == "hi") "मूल फ़ाइल रखें" else "Keep Original", color = Color.Gray)
                    }
                }
            )
        }

        // --- GENERIC MESSAGE TOAST DIALOG (ERRORS / SUCCESS) ---
        fileImportError?.let { msg ->
            AlertDialog(
                onDismissRequest = { fileImportError = null },
                containerColor = Color(0xFF161622),
                title = { Text("Nova Secure Alert", color = Color.White, fontWeight = FontWeight.Black) },
                text = { Text(msg, color = Color.LightGray, fontSize = 13.sp) },
                confirmButton = {
                    Button(
                        onClick = { fileImportError = null },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) {
                        Text("Dismiss", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    }
}

// ==========================================
// EQUALIZER DIALOG
// ==========================================
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EqualizerDialog(
    activePreset: String,
    onPresetChanged: (String) -> Unit,
    onDismiss: () -> Unit,
    musicViewModel: com.example.ui.viewmodel.MusicViewModel? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Parametric Equalizer", color = Color.White, fontWeight = FontWeight.Black)
                Text("Pro Audio DSP Customizer", color = ElectricBlue, fontSize = 11.sp)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Preset chips
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Bass Boost", "EDM Heavy", "Rock", "Pop", "Jazz", "Classical", "Cinema", "3D Spatial", "Vocal", "Club", "Normal").forEach { preset ->
                        val active = activePreset == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) ElectricBlue else Color.White.copy(alpha = 0.08f))
                                .clickable { 
                                    onPresetChanged(preset)
                                    musicViewModel?.selectPreset(preset)
                                }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(preset, color = if (active) Color.Black else Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                val bassBoostVal = musicViewModel?.bassBoostStrength?.collectAsState()?.value ?: 0
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bass Boost Pro", color = Color(0xFFFF007A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${bassBoostVal / 10}%", color = Color(0xFFFF007A), fontSize = 12.sp, fontWeight = FontWeight.Black)
                    }
                    Slider(
                        value = bassBoostVal.toFloat(),
                        onValueChange = {
                            musicViewModel?.setBassBoostEnabled(true)
                            musicViewModel?.setBassBoostStrength(it.toInt())
                        },
                        valueRange = 0f..1000f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFF007A),
                            activeTrackColor = Color(0xFFFF007A),
                            inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                        )
                    )
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.1f))

                // Frequency Sliders
                val eqBands = musicViewModel?.eqBands?.collectAsState()?.value
                for (i in 0 until 5) {
                    val band1 = i * 2
                    val band2 = i * 2 + 1
                    val bandGain = eqBands?.getOrElse(band1) { 0 } ?: 0
                    val labels = listOf("60 Hz (Bass Sub)", "230 Hz (Kick)", "910 Hz (Mids)", "4 kHz (Presence)", "14 kHz (Air)")
                    FrequencySlider(
                        label = labels[i],
                        currentGainDb = bandGain,
                        onGainChanged = { newGain ->
                            musicViewModel?.setEqBand(band1, newGain)
                            musicViewModel?.setEqBand(band2, newGain)
                            musicViewModel?.selectPreset("Custom")
                        }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = ElectricBlue)
            }
        },
        containerColor = Color(0xFF121212)
    )
}

@Composable
fun FrequencySlider(
    label: String,
    currentGainDb: Int,
    onGainChanged: (Int) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, color = Color.White, fontSize = 11.sp)
            Text("${if (currentGainDb >= 0) "+" else ""}${currentGainDb} dB", color = ElectricBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Slider(
            value = currentGainDb.toFloat(),
            onValueChange = { onGainChanged(it.toInt()) },
            valueRange = -15f..15f,
            colors = SliderDefaults.colors(
                thumbColor = ElectricBlue,
                activeTrackColor = ElectricBlue,
                inactiveTrackColor = Color.DarkGray
            ),
            modifier = Modifier.height(18.dp)
        )
    }
}

// Helpers
fun formatMillis(ms: Long): String {
    val totalSecs = ms / 1000
    val hours = totalSecs / 3600
    val minutes = (totalSecs % 3600) / 60
    val seconds = totalSecs % 60
    return if (hours > 0) {
        String.format("%02d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}

private fun isRecentlyAdded(video: com.example.data.model.ScannedVideo): Boolean {
    val currentTimeMs = System.currentTimeMillis()
    val dateAddedMs = if (video.dateAdded > 20000000000L) {
        video.dateAdded
    } else {
        video.dateAdded * 1000L
    }
    val diffMs = currentTimeMs - dateAddedMs
    val sevenDaysMs = 7L * 24 * 60 * 60 * 1000
    return diffMs in 0..sevenDaysMs
}

private fun formatWatchedDate(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("MMM dd, yyyy - hh:mm a", java.util.Locale.getDefault())
    return sdf.format(java.util.Date(timestamp))
}

// ==========================================
// SMART COLLECTIONS COMPONENT
// ==========================================
@Composable
fun SmartCollectionCard(
    collection: com.example.data.model.SmartCollectionItem,
    onClick: () -> Unit
) {
    val visualGradient = remember(collection.id) {
        Brush.linearGradient(
            colors = listOf(
                ElectricBlue.copy(alpha = 0.4f),
                RoyalPurple.copy(alpha = 0.4f),
                Color.Black
            )
        )
    }

    GlassCard(
        modifier = Modifier
            .width(170.dp)
            .clickable(onClick = onClick)
            .testTag("collection_card_${collection.id}")
    ) {
        Column(modifier = Modifier.padding(2.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(105.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(visualGradient),
                contentAlignment = Alignment.Center
            ) {
                if (collection.coverThumbnailUrl != null) {
                    AsyncImage(
                        model = collection.coverThumbnailUrl,
                        contentDescription = collection.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.7f))
                                )
                            )
                    )
                } else {
                    Icon(
                        imageVector = collection.icon,
                        contentDescription = collection.name,
                        tint = ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                }
                
                // Small Category Icon overlay
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(6.dp)
                        .size(28.dp)
                        .background(Color.Black.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = collection.icon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = collection.name,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${collection.videos.size} items",
                    color = Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = formatBytes(collection.totalSize),
                    color = ElectricBlue,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DynamicHomeDashboard(
    smartCollectionsViewModel: com.example.ui.viewmodel.SmartCollectionsViewModel,
    mediaViewModel: MediaViewModel,
    onNavigateToCollection: (String) -> Unit,
    onPlayVideo: (MediaEntity) -> Unit
) {
    val recentlyOpenedFolder by smartCollectionsViewModel.recentlyOpenedFolder.collectAsState()
    val lastPlayedVideo by smartCollectionsViewModel.lastPlayedVideo.collectAsState()
    val favoriteCollection by smartCollectionsViewModel.favoriteCollection.collectAsState()
    val largestCollection by smartCollectionsViewModel.largestCollection.collectAsState()

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Dynamic Intelligence",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        GlowText(text = "Real-time Metrics", fontSize = 12.sp, color = RoyalPurple)
    }
    Spacer(modifier = Modifier.height(12.dp))

    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Card 1: Recently Opened Folder
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .testTag("dynamic_opened_folder")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.FolderOpen, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Recent Folder", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val folderValue = recentlyOpenedFolder ?: lastPlayedVideo?.path?.let { File(it).parentFile?.name } ?: "None yet"
                    Text(
                        text = folderValue,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Card 2: Last Played Video
            val playAction = lastPlayedVideo?.let { video -> { onPlayVideo(video.toMediaEntity()) } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = lastPlayedVideo != null, onClick = playAction)
                    .testTag("dynamic_last_played")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = RoyalPurple, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Last Played", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lastPlayedVideo?.title ?: "No history yet",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Card 3: Favorite Collection
            val favAction = favoriteCollection?.let { col -> { onNavigateToCollection("collection/${col.id}") } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = favoriteCollection != null, onClick = favAction)
                    .testTag("dynamic_favorite_collection")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Favorite, contentDescription = null, tint = Color.Red, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Fav Collection", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = favoriteCollection?.name ?: "No favorites yet",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Card 4: Largest Collection
            val largestAction = largestCollection?.let { col -> { onNavigateToCollection("collection/${col.id}") } } ?: {}
            GlassCard(
                modifier = Modifier
                    .weight(1f)
                    .height(100.dp)
                    .clickable(enabled = largestCollection != null, onClick = largestAction)
                    .testTag("dynamic_largest_collection")
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.DataUsage, contentDescription = null, tint = Color(0xFFFF9800), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Largest Collection", color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = largestCollection?.let { "${it.name} (${formatBytes(it.totalSize)})" } ?: "Empty",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format("%.2f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

@Composable
fun CapturedFramesView(
    capturedFrames: List<com.example.data.model.CapturedFrameEntity>,
    onOpenFrame: (com.example.data.model.CapturedFrameEntity) -> Unit,
    onShareFrame: (com.example.data.model.CapturedFrameEntity) -> Unit,
    onDeleteFrame: (com.example.data.model.CapturedFrameEntity) -> Unit
) {
    if (capturedFrames.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(24.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Color.White.copy(alpha = 0.05f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PhotoCamera,
                        contentDescription = null,
                        tint = ElectricBlue,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "No Captured Frames Yet",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Capture ultra HD frames of your locally stored videos from the player's controls.",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    } else {
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            contentPadding = PaddingValues(bottom = 120.dp, top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(capturedFrames) { frame ->
                var showOptionsDialog by remember { mutableStateOf(false) }
                
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showOptionsDialog = true }
                ) {
                    Column {
                        // Image Thumbnail with Format Overlay
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(100.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black)
                        ) {
                            AsyncImage(
                                model = java.io.File(frame.filePath),
                                contentDescription = frame.fileName,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            
                            // Format/Quality Chip
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (frame.format == "PNG") "PNG" else "JPG ${frame.quality}%",
                                    color = ElectricBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Timestamp Tag Overlay
                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(4.dp)
                                    .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                val currentPos = frame.timestampMs
                                val timeText = if (currentPos > 3600000) {
                                    String.format("%02d:%02d:%02d", currentPos / 3600000, (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000)
                                } else {
                                    String.format("%02d:%02d", (currentPos % 3600000) / 60000, (currentPos % 60000) / 1000)
                                }
                                Text(
                                    text = timeText,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Text Info
                        Column(modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
                            Text(
                                text = frame.fileName,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = frame.videoTitle,
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                if (showOptionsDialog) {
                    AlertDialog(
                        onDismissRequest = { showOptionsDialog = false },
                        title = {
                            Text(
                                text = "Frame Actions",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "Choose an action for ${frame.fileName}",
                                    color = Color.LightGray,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                // Open Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onOpenFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.OpenInNew, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Open in Gallery", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // Share Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onShareFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Share, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Share Frame", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                // Delete Option
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            showOptionsDialog = false
                                            onDeleteFrame(frame)
                                        }
                                        .padding(vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Rounded.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text("Delete Frame", color = Color.Red, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = { showOptionsDialog = false }) {
                                Text("Cancel", color = Color.LightGray)
                            }
                        },
                        containerColor = Color(0xFF161622),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }
        }
    }
}

// Storage Utility Functions
fun calculateRealAppCacheSize(context: android.content.Context): Long {
    var size = 0L
    try {
        val cacheDir = context.cacheDir
        if (cacheDir != null && cacheDir.exists()) {
            size += getDirectorySizeRecursive(cacheDir)
        }
        val externalCacheDir = context.externalCacheDir
        if (externalCacheDir != null && externalCacheDir.exists()) {
            size += getDirectorySizeRecursive(externalCacheDir)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return size
}

fun getDirectorySizeRecursive(file: java.io.File): Long {
    var size = 0L
    if (file.isDirectory) {
        val files = file.listFiles()
        if (files != null) {
            for (f in files) {
                if (f.isDirectory) {
                    size += getDirectorySizeRecursive(f)
                } else {
                    size += f.length()
                }
            }
        }
    } else {
        size = file.length()
    }
    return size
}

fun performRealAppCacheClear(context: android.content.Context): Long {
    var bytesDeleted = 0L
    try {
        val cacheDir = context.cacheDir
        if (cacheDir != null && cacheDir.exists()) {
            bytesDeleted += deleteDirectoryRecursive(cacheDir)
        }
        val externalCacheDir = context.externalCacheDir
        if (externalCacheDir != null && externalCacheDir.exists()) {
            bytesDeleted += deleteDirectoryRecursive(externalCacheDir)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return bytesDeleted
}

fun deleteDirectoryRecursive(file: java.io.File): Long {
    var bytesDeleted = 0L
    if (file.isDirectory) {
        val files = file.listFiles()
        if (files != null) {
            for (f in files) {
                if (f.isDirectory) {
                    bytesDeleted += deleteDirectoryRecursive(f)
                }
                val len = f.length()
                if (f.delete()) {
                    bytesDeleted += len
                }
            }
        }
    } else {
        val len = file.length()
        if (file.delete()) {
            bytesDeleted += len
        }
    }
    return bytesDeleted
}

fun formatBytesToSizeString(bytes: Long): String {
    if (bytes <= 0) return "0.00 MB"
    val mb = bytes.toDouble() / (1024.0 * 1024.0)
    return if (mb < 1024.0) {
        String.format(java.util.Locale.US, "%.2f MB", mb)
    } else {
        val gb = mb / 1024.0
        String.format(java.util.Locale.US, "%.2f GB", gb)
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun FullAppFeaturesAboutScreen(
    appLang: String,
    onDismiss: () -> Unit
) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        var featureQuery by remember { mutableStateOf("") }
        var selectedCategory by remember { mutableStateOf("All") }

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color(0xFF070709)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
            ) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0D0E15))
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (appLang == "hi") "ऐप फीचर्स और टूल्स गाइड" else "About • All Features & Tools",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        Text(
                            text = if (appLang == "hi") "विडीओपेन प्रो - सम्पूर्ण जानकारी" else "Vidiopen Pro • Comprehensive Guidebook",
                            color = Color(0xFF10B981),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFF10B981).copy(alpha = 0.15f))
                            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text("v1.0.0 PRO", color = Color(0xFF10B981), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                // Scrollable Content
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    // HERO CARD
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0xFF10B981).copy(alpha = 0.18f),
                                            Color(0xFF141622)
                                        )
                                    )
                                )
                                .border(1.dp, Color(0xFF10B981).copy(alpha = 0.35f), RoundedCornerShape(24.dp))
                                .padding(20.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                                Icon(
                                    imageVector = Icons.Rounded.PlayCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF10B981),
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Vidiopen Pro (NovaPlay)",
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 22.sp
                                )
                                Text(
                                    text = if (appLang == "hi") "100% सेफ, ऑफलाइन, प्रीमियम एचडी मीडिया प्लेयर" else "100% Secure Offline Ultra HD Media Player & Vault",
                                    color = Color.LightGray,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                                )

                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    listOf("🎬 4K/8K Engine", "🎛️ 10-Band EQ", "🔒 AES-256 Vault", "⚡ 50MB/s P2P", "🧠 AI Search", "🎵 MP3 Studio").forEach { chip ->
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color.White.copy(alpha = 0.08f))
                                                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                        ) {
                                            Text(chip, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // SEARCH FEATURE INPUT BAR
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(23.dp))
                                .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(23.dp))
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Search, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            BasicTextField(
                                value = featureQuery,
                                onValueChange = { featureQuery = it },
                                textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 13.sp),
                                cursorBrush = SolidColor(Color(0xFF10B981)),
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                decorationBox = { inner ->
                                    if (featureQuery.isEmpty()) {
                                        Text(if (appLang == "hi") "कोई भी फीचर या टूल खोजें..." else "Search any feature or tool...", color = Color.Gray, fontSize = 12.sp)
                                    }
                                    inner()
                                }
                            )
                            if (featureQuery.isNotEmpty()) {
                                IconButton(onClick = { featureQuery = "" }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Rounded.Close, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }

                    // CATEGORY CHIPS SCROLLER
                    item {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            val categories = listOf(
                                "All" to if (appLang == "hi") "सभी (All)" else "All Features",
                                "Player" to if (appLang == "hi") "🎬 वीडियो प्लेयर" else "🎬 Video Player",
                                "AISearch" to if (appLang == "hi") "🧠 एआई सर्च" else "🧠 AI Search",
                                "Vault" to if (appLang == "hi") "🔒 प्राइवेट तिजोरी" else "🔒 Vault Safe",
                                "P2P" to if (appLang == "hi") "⚡ फाइल ट्रांसफर" else "⚡ ShareAny P2P",
                                "Audio" to if (appLang == "hi") "🎵 म्यूज़िक प्लेयर" else "🎵 Audio Player",
                                "Storage" to if (appLang == "hi") "📁 फाइल टूल्स" else "📁 File Tools",
                                "Privacy" to if (appLang == "hi") "⚙️ सेटिंग्स & सेफ़्टी" else "⚙️ Privacy & Security"
                            )
                            items(categories) { (key, label) ->
                                val active = selectedCategory == key
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (active) Color(0xFF10B981) else Color.White.copy(alpha = 0.08f))
                                        .clickable { selectedCategory = key }
                                        .padding(horizontal = 14.dp, vertical = 7.dp)
                                ) {
                                    Text(label, color = if (active) Color.Black else Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // FEATURE CATEGORIES & LINE-BY-LINE LISTINGS
                    // Category 1: Video Player Engine
                    if (selectedCategory == "All" || selectedCategory == "Player") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "1. 🎬 अल्ट्रा एचडी वीडियो प्लेयर (Video Player Engine)" else "1. 🎬 Ultra HD Video Player Engine",
                                badge = "12 Pro Features",
                                icon = Icons.Rounded.PlayCircle,
                                accentColor = Color(0xFF10B981),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "4K & 8K Ultra HD प्लेबैक इंजन" else "4K & 8K Ultra HD Playback Engine",
                                        tag = "Hardware Accelerated",
                                        desc = if (appLang == "hi") "MP4, MKV, AVI, MOV, WEBM जैसे सभी मीडिया फॉर्मेट्स के लिए 60 FPS बटर-स्मूथ हार्डवेयर-एक्सेलरेटेड 4K/8K प्लेबैक।" else "Hardware-accelerated H.264, HEVC, AV1, and VP9 decoding for smooth 60 FPS 4K/8K playback across MP4, MKV, AVI, MOV, WEBM, FLV, and TS files."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "स्मार्ट टच जेस्चर कंट्रोल्स" else "Smart Touch Gesture Controls",
                                        tag = "Intuitive Gestures",
                                        desc = if (appLang == "hi") "राइट साइड स्वाइप से वॉल्यूम, लेफ्ट साइड स्वाइप से ब्राइटनेस, हॉरिजॉन्टल स्वाइप से सीक/फॉरवर्ड और पिंच-टू-ज़ूम से 500% तक ज़ूम।" else "Vertical swipe right for Volume, left for Brightness, horizontal swipe to seek/rewind, and pinch-to-zoom up to 500%."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "10-बैंड प्रो इक्वलाइज़र & बेस बूस्ट" else "10-Band Equalizer & Bass Boost Pro",
                                        tag = "Studio Audio",
                                        desc = if (appLang == "hi") "11 कस्टम साउंड प्रेसेट्स (Bass Boost, EDM Heavy, Rock, Pop, Cinema, 3D Spatial) और 1000% तक एक्स्ट्रा बेस बूस्ट प्रो स्लाइडर।" else "Professional 10-band audio equalizer with 11 custom sound presets (Bass Boost, EDM, Rock, Pop, Cinema) + 1000% Bass Boost Pro slider."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "सबटाइटल डाउनलोडर & ऑटो-सिंक" else "Subtitle Auto-Sync & Downloader",
                                        tag = "Multi-Language",
                                        desc = if (appLang == "hi") "एम्बेडेड SRT/ASS/SSA सबटाइटल्स सपोर्ट, फॉन्ट साइज/कलर डिले कस्टमाइजेशन और ऑनलाइन सबटाइटल ऑटो-डाउनलोडर।" else "Supports embedded SRT, ASS, SSA subtitles, custom font sizes, text colors, sync delay correction, and auto-downloading external subtitles."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "बैकग्राउंड प्लेबैक & पिक्चर-इन-पिक्चर (PIP)" else "Background Video & Floating PIP Mode",
                                        tag = "Multitasking",
                                        desc = if (appLang == "hi") "वीडियो को पिक्चर-इन-पिक्चर फ्लोटिंग विंडो में प्ले करें या बैकग्राउंड ऑडियो मोड में दूसरे ऐप्स चलाते हुए सुनें।" else "Float videos in a Picture-in-Picture window or play in background audio mode while chatting or browsing other apps."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "मल्टी-ऑडियो ट्रैक & डबिंग स्विच" else "Multi-Audio Track Selector",
                                        tag = "Dual-Audio",
                                        desc = if (appLang == "hi") "हिंदी, इंग्लिश, डबिंग ऑडियो ट्रैक्स, AC3 सरराउंड और डॉल्बी डिजिटल ऑडियो में एक क्लिक में स्विच करें।" else "Instantly switch between dual-audio languages, Hindi/English dubbing, AC3 Surround, DTS, and Dolby Digital audio streams."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "प्लेबैक स्पीड कंट्रोलर (0.25x - 4.0x)" else "Variable Speed Control (0.25x - 4.0x)",
                                        tag = "Pitch Lock",
                                        desc = if (appLang == "hi") "बिना आवाज़ की क्वालिटी बिगड़े स्लो मोशन (0.25x) से सुपर फ़ास्ट फॉरवर्ड (4.0x) तक स्पीड कंट्रोल करें।" else "Fine-tune playback speed smoothly from slow motion (0.25x) to fast speed (4.0x) while preserving original audio pitch."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "डायरेक्ट MP3 स्ट्रीम मोड" else "Direct MP3 Stream Mode",
                                        tag = "70% Battery Saver",
                                        desc = if (appLang == "hi") "एक टैप में वीडियो प्लेबैक को डायरेक्ट ऑडियो मोड में बदलें और 70% तक बैटरी बचाएं।" else "One-tap toggle converts playing video to audio-only stream, saving up to 70% battery power for long listen sessions."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "A-B लूप रिपीट मोड" else "A-B Segment Loop Repeat",
                                        tag = "Learning Tool",
                                        desc = if (appLang == "hi") "वीडियो के स्टार्ट पॉइंट (A) और एंड पॉइंट (B) को सेट करके किसी खास सीन को बार-बार लूप करें।" else "Set start point (A) and end point (B) to endlessly loop specific video scenes for tutorials, dance practice, or study."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "फ्रेम कैप्चर & GIF क्लिप मेकर" else "Frame Capture & GIF Clip Maker",
                                        tag = "HD Screenshots",
                                        desc = if (appLang == "hi") "वीडियो देखते समय अल्ट्रा-क्लियर एचडी स्क्रीनशॉट कैप्चर करें या फेवरेट मोमेंट का GIF क्लिप बनाएं।" else "Extract crisp HD screenshots or record custom animated GIF clips directly from video scenes in 1 tap."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "किड्स स्क्रीन टच लॉक" else "Kids Lock & Touch Protection",
                                        tag = "Accidental Guard",
                                        desc = if (appLang == "hi") "मूवी देखते समय बच्चों या गलती से हाथ लगने से टच डिस्टर्बेंस रोकने के लिए टच स्क्रीन लॉक।" else "Lock touch controls completely during movie sessions to avoid accidental interruptions."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "नाइट आई केयर फिल्टर" else "Night Mode & Eye Protection Filter",
                                        tag = "Warm Protection",
                                        desc = if (appLang == "hi") "रात के समय आँख पर पड़ने वाले खिंचाव को कम करने के लिए वार्म नाइट स्क्रीन फिल्टर।" else "Protects your eyes during night viewing with a warm color filter and custom tint controls."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 2: AI Smart Search
                    if (selectedCategory == "All" || selectedCategory == "AISearch") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "2. 🧠 बुद्धिमान एआई सर्च इंजन (AI Smart Search)" else "2. 🧠 Intelligent Smart Search Engine",
                                badge = "Smart AI Scoring",
                                icon = Icons.Rounded.AutoAwesome,
                                accentColor = Color(0xFF3B82F6),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "मल्टी-लेवल एआई रिलायबल स्कोरिंग" else "Multi-Level Relevance Scoring",
                                        tag = "Acronym Match",
                                        desc = if (appLang == "hi") "शॉर्ट नेम या शुरुआती अक्षरों (जैसे 'kgf' से 'K.G.F Chapter 2') से वीडियो तुरंत ढूंढ निकालता है।" else "Ranks videos using exact title, word prefix, folder name, extension, and acronym initials matching (e.g. 'kgf' -> 'K.G.F Chapter 2')."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "टाइपो टॉलरेंस (गलत स्पेलिंग पकड़ने की क्षमता)" else "Typo Tolerance & Fuzzy Matching",
                                        tag = "Levenshtein AI",
                                        desc = if (appLang == "hi") "स्पेलिंग गलत होने पर भी (जैसे 'spidr' या 'avengr') लेवेनश्टाइन एआई एल्गोरिदम सही वीडियो ढूंढता है।" else "Levenshtein fuzzy matching algorithm automatically catches typing mistakes (e.g. 'spidr' finds 'Spider-Man')."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "तकनीकी कीवर्ड्स & सोर्स पहचान" else "Technical & Intent Keyword Detection",
                                        tag = "Intent Filter",
                                        desc = if (appLang == "hi") "'4k', 'hd', 'short', 'movie', 'cam', 'wa', 'download' जैसे शब्दों से तुरंत रेजोल्यूशन और फोल्डर फ़िल्टर करता है।" else "Auto-detects queries like '4k', 'hd', 'short', 'movie', 'cam', 'wa', 'download' to filter by resolution, duration, or folder."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "डायनामिक एआई सजेशन चिप्स" else "Smart AI Suggestion Chips",
                                        tag = "1-Tap Filter",
                                        desc = if (appLang == "hi") "आपकी गैलरी में मौजूद फाइलों के हिसाब से ऑटो-जनरेटेड 1-टैप सर्च सजेशन चिप्स।" else "Generates dynamic 1-tap filter suggestion chips based on your scanned media library."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 3: Private Vault Safe
                    if (selectedCategory == "All" || selectedCategory == "Vault") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "3. 🔒 प्राइवेट AES-256 तिजोरी (Private Vault Safe)" else "3. 🔒 Private AES-256 Vault Locker",
                                badge = "AES-256 Encrypted",
                                icon = Icons.Rounded.Lock,
                                accentColor = Color(0xFFFF007A),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "AES-256 एन्क्रिप्टेड सीक्रेट वॉल्ट" else "Encrypted Local Private Vault",
                                        tag = "PIN & Fingerprint",
                                        desc = if (appLang == "hi") "पर्सनल वीडियो और सीक्रेट मीडिया को PIN और फिंगरप्रिंट लॉक वाली AES-256 एन्क्रिप्टेड तिजोरी में सुरक्षित रखें।" else "Secure personal videos and private clips inside an AES-256 bit encrypted local safe with PIN and Fingerprint protection."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "फोन गैलरी से पूरी तरह गायब" else "Hidden Gallery & System Lock",
                                        tag = "System Stealth",
                                        desc = if (appLang == "hi") "तिजोरी में डाले गए वीडियो फोन गैलरी, फाइल मैनेजर और बाकी ऐप्स से पूरी तरह छिप जाते हैं।" else "Vaulted files are completely hidden from Android gallery, system file managers, and third-party apps."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "100% लोकल ऑफलाइन सुरक्षा" else "100% Offline Local Encryption",
                                        tag = "Zero Cloud Leak",
                                        desc = if (appLang == "hi") "आपका प्राइवेट डेटा सिर्फ आपके फोन में स्टोर रहता है — कोई क्लाउड लीक या सर्वर अपलोड नहीं।" else "Your private media stays strictly on physical local storage — zero cloud uploads, zero data leaks."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 4: High-Speed P2P File Transfer
                    if (selectedCategory == "All" || selectedCategory == "P2P") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "4. ⚡ हाई-स्पीड फाइल ट्रांसफर - ShareAny P2P" else "4. ⚡ High-Speed Local File Transfer (ShareAny)",
                                badge = "50 MB/s Offline",
                                icon = Icons.Rounded.SwapHoriz,
                                accentColor = Color(0xFFF59E0B),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "बिना इंटरनेट ऑफलाइन वाई-फाई डायरेक्ट ट्रांसफर" else "Offline Wi-Fi Direct High-Speed Transfer",
                                        tag = "50 MB/s Speed",
                                        desc = if (appLang == "hi") "बिना इंटरनेट या मोबाइल डेटा के आसपास के एंड्रॉइड फोन्स में 50 MB/s की स्पीड पर बड़ी 4K मूवीज और गाने भेजें।" else "Share large 4K movies and MP3 albums between nearby Android devices at speeds up to 50 MB/s without mobile data or internet."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "पीसी और आईफोन (iOS) के लिए वेब शेयर" else "Cross-Platform PC & iOS Web Share",
                                        tag = "Hotspot Web Link",
                                        desc = if (appLang == "hi") "लोकल वाई-फाई हॉटस्पॉट के ज़रिए कंप्यूटर, लैपटॉप या आईफोन से बिना किसी ऐप के फाइल ट्रांसफर करें।" else "Create a local Wi-Fi hotspot access point to transfer files effortlessly with Laptops, PCs, or iOS web browsers."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "ट्रांसफर हिस्ट्री & इंस्टेंट प्ले" else "Transfer History & Instant Playback",
                                        tag = "History Logs",
                                        desc = if (appLang == "hi") "भेजी या पाई गई सभी फाइलों का पूरा इतिहास देखें और सीधे प्लेबैक चालू करें।" else "View complete history logs of sent and received media files with 1-click direct playback."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 5: Audio Player Engine
                    if (selectedCategory == "All" || selectedCategory == "Audio") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "5. 🎵 ऑफलाइन म्यूज़िक प्लेयर (Offline Music Player)" else "5. 🎵 Offline Music Player & Studio Equalizer",
                                badge = "Hi-Fi Audio",
                                icon = Icons.Rounded.MusicNote,
                                accentColor = Color(0xFF8B5CF6),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "ऑर्गेनाइज्ड ऑडियो लाइब्रेरी" else "Organized Music Library",
                                        tag = "Playlists & Folders",
                                        desc = if (appLang == "hi") "गानों को ट्रैक नेम, आर्टिस्ट, एल्बम, फोल्डर और कस्टम फेवरेट प्लेलिस्ट में व्यवस्थित करें।" else "Categorize audio files by Songs, Artists, Albums, Folders, and Custom Playlists."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "स्टूडियो ऑडियो इक्वलाइज़र" else "Studio Audio Equalizer",
                                        tag = "Bass Boost & 3D",
                                        desc = if (appLang == "hi") "गानों के लिए 10-बैंड स्टूडियो इक्वलाइज़र, फ्रीक्वेंसी स्लाइडर्स और वर्चुअलाइजर।" else "Shared 10-band audio equalizer with frequency controls, virtualizer, and 3D bass boost."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "एम्बेडेड लिरिक्स (बोल) & टैग एडिटर" else "Embedded Lyrics & ID3 Tag Editor",
                                        tag = "Metadata Editor",
                                        desc = if (appLang == "hi") "गानों के साथ लिरिक्स (बोल) देखें और टाइटल, आर्टिस्ट नाम और पोस्टर कवर आर्ट एडिट करें।" else "Display embedded audio lyrics and edit song titles, artist names, and album cover art directly."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "फ्लोटिंग मिनी प्लेयर & लॉकस्क्रीन विजेट" else "Floating Mini Player & Lockscreen Controls",
                                        tag = "Background Control",
                                        desc = if (appLang == "hi") "नोटिफिकेशन बार, लॉक स्क्रीन और फ्लोटिंग मिनी बार से कहीं भी म्यूजिक कंट्रोल करें।" else "Control audio playback seamlessly from notification shade, lock screen, and floating mini player bar."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 6: File Tools & Utilities
                    if (selectedCategory == "All" || selectedCategory == "Storage") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "6. 📁 फाइल टूल्स & स्टोरेज मैनेजर (File & Utility Tools)" else "6. 📁 Smart Storage Manager & Utility Tools",
                                badge = "Deep Scanner",
                                icon = Icons.Rounded.Folder,
                                accentColor = Color(0xFFEC4899),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "डीप स्टोरेज स्कैनर" else "Deep System Storage Scanner",
                                        tag = "Auto Scan",
                                        desc = if (appLang == "hi") "व्हाट्सऐप, कैमरा (DCIM), टेलीग्राम, डाउनलोड्स, ब्लूटूथ और एसडी कार्ड की फाइलों की ऑटो-स्कैनिंग।" else "Auto-detects videos from WhatsApp, Camera (DCIM), Telegram, Downloads, Bluetooth, and SD Cards."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "30-दिन रिसाइकल बिन (Trash)" else "30-Day Trash Recycle Bin",
                                        tag = "Accident Recovery",
                                        desc = if (appLang == "hi") "गलती से डिलीट हुए वीडियो 30 दिनों तक रिसाइकल बिन में सुरक्षित रहते हैं जिन्हें तुरंत वापस ला सकते हैं।" else "Accidentally deleted videos are kept safely in a 30-day local recycle bin for instant restoration."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "वीडियो से MP3 कन्वर्टर" else "Video to MP3 Audio Converter",
                                        tag = "1-Tap Converter",
                                        desc = if (appLang == "hi") "किसी भी वीडियो फाइल से सेकंडों में हाई-क्वालिटी MP3/AAC ऑडियो फाइल निकालें।" else "Extract high-bitrate MP3/AAC audio files from any video clip in seconds."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "डुप्लिकेट वीडियो क्लीनर" else "Duplicate Video Cleaner",
                                        tag = "Storage Cleaner",
                                        desc = if (appLang == "hi") "फोन में पड़ी एक ही वीडियो की दोहरी फाइलों को ढूँढकर स्टोरेज खाली करें।" else "Scans your storage to detect duplicate video files and frees up valuable GBs of phone space."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "स्टेटस ट्रिमर & रिंगटोन मेकर" else "Ringtone & Social Status Trimmer",
                                        tag = "Clip Trimmer",
                                        desc = if (appLang == "hi") "व्हाट्सऐप या इंस्टाग्राम स्टेटस के लिए वीडियो कट करें या पसंदीदा गाने को फोन रिंगटोन बनाएं।" else "Trim short video clips for WhatsApp/Instagram status or convert audio clips into custom phone ringtones."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // Category 7: Settings, Architecture & Security
                    if (selectedCategory == "All" || selectedCategory == "Privacy") {
                        item {
                            FeatureCategoryCard(
                                title = if (appLang == "hi") "7. ⚙️ सेटिंग्स, भाषा और सुरक्षा (Settings & Privacy)" else "7. ⚙️ Settings, Customization & Privacy",
                                badge = "100% Offline",
                                icon = Icons.Rounded.Security,
                                accentColor = Color(0xFF10B981),
                                items = listOf(
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "द्विभाषी ऐप भाषा (English & हिंदी)" else "Dual Language Support (English & Hindi)",
                                        tag = "Instant Language",
                                        desc = if (appLang == "hi") "पूरे ऐप को अपनी पसंदीदा भाषा (हिंदी या इंग्लिश) में एक स्विच से इस्तेमाल करें।" else "Full app UI supports switching seamlessly between English and Hindi (हिंदी)."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "AMOLED गहरा काला थीम" else "AMOLED Deep Black Theme",
                                        tag = "OLED Energy Saver",
                                        desc = if (appLang == "hi") "ओएलईडी और एमोलेड स्क्रीन के लिए बैटरी बचाने वाला ट्रू-ब्लैक डार्क मोड।" else "Premium energy-saving dark theme designed specifically for high-contrast OLED/AMOLED displays."
                                    ),
                                    FeatureDetailItem(
                                        title = if (appLang == "hi") "100% ऑफलाइन सिक्योर आर्किटेक्चर" else "Offline-First Zero Telemetry Guarantee",
                                        tag = "100% Private",
                                        desc = if (appLang == "hi") "100% कॉटलिन सिक्योरिटी — कोई अनिवार्य साइन-अप नहीं, कोई बैकग्राउंड डेटा ट्रैकिंग नहीं।" else "Built with 100% Kotlin security architecture — no mandatory sign-ups, no background telemetry tracking."
                                    )
                                ),
                                query = featureQuery
                            )
                        }
                    }

                    // DEVELOPER & SUPPORT INFO CARD
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFF12141F))
                                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(20.dp))
                                .padding(16.dp)
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Rounded.Info, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (appLang == "hi") "डेवलपर और सपोर्ट की जानकारी" else "Developer & Support Information",
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                                HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Application Name", color = Color.Gray, fontSize = 12.sp)
                                    Text("Vidiopen Pro (NovaPlay)", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Version & Edition", color = Color.Gray, fontSize = 12.sp)
                                    Text("v1.0.0 Luxury Pro", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Developer & Support", color = Color.Gray, fontSize = 12.sp)
                                    Text("abhayshukla8498@gmail.com", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Security Engine", color = Color.Gray, fontSize = 12.sp)
                                    Text("AES-256 Offline Kotlin Core", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Made in India", color = Color.Gray, fontSize = 12.sp)
                                    Text("🇮🇳 Made with Pride", color = Color(0xFFF59E0B), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Button(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = if (appLang == "hi") "समझ गया (Got It)" else "Close Features Guide",
                                        color = Color.Black,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

data class FeatureDetailItem(
    val title: String,
    val tag: String,
    val desc: String
)

@Composable
fun FeatureCategoryCard(
    title: String,
    badge: String,
    icon: ImageVector,
    accentColor: Color,
    items: List<FeatureDetailItem>,
    query: String
) {
    val filteredItems = remember(items, query) {
        if (query.isBlank()) items
        else items.filter {
            it.title.contains(query, ignoreCase = true) ||
            it.tag.contains(query, ignoreCase = true) ||
            it.desc.contains(query, ignoreCase = true)
        }
    }

    if (filteredItems.isEmpty()) return

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF131520))
            .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
            // Category Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(accentColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(badge, color = accentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.08f))

            // Items List
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                filteredItems.forEachIndexed { index, item ->
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Box(
                            modifier = Modifier
                                .padding(top = 4.dp)
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(accentColor)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = item.tag,
                                    color = accentColor,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(start = 6.dp)
                                )
                            }
                            Text(
                                text = item.desc,
                                color = Color(0xFFB0B3C0),
                                fontSize = 12.sp,
                                lineHeight = 17.sp,
                                modifier = Modifier.padding(top = 3.dp)
                            )
                        }
                    }
                    if (index < filteredItems.size - 1) {
                        HorizontalDivider(
                            color = Color.White.copy(alpha = 0.04f),
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

