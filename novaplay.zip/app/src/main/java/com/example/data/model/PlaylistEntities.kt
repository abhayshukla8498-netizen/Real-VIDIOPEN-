package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "video_playlists")
data class VideoPlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_videos")
data class PlaylistVideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val playlistId: Long,
    val videoId: String,
    val title: String,
    val url: String,
    val duration: Long,
    val thumbnailUrl: String?,
    val orderIndex: Int
)

@Entity(tableName = "queue_videos")
data class QueueVideoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val videoId: String,
    val title: String,
    val url: String,
    val duration: Long,
    val thumbnailUrl: String?,
    val orderIndex: Int
)
