package com.example.data.model

data class VideoFolder(
    val path: String,
    val name: String,
    val videoCount: Int,
    val totalSize: Long,
    val latestVideoThumbnail: String?,
    val latestVideoDateAdded: Long,
    val videos: List<ScannedVideo>
)
