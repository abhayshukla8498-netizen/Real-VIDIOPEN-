package com.example.data.model

data class TransferFile(
    val id: String,
    val name: String,
    val size: Long,
    val path: String,
    val type: String, // "VIDEO", "PHOTO", "MUSIC", "DOCUMENT", "APK"
    val mimeType: String?,
    val dateModified: Long
)
