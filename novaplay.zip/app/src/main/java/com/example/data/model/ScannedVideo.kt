package com.example.data.model

data class ScannedVideo(
    val id: Long,
    val title: String,
    val path: String,
    val duration: Long,
    val size: Long,
    val dateAdded: Long,
    val uriString: String,
    val thumbnailUrl: String? = null,
    val width: Int = 0,
    val height: Int = 0
)
