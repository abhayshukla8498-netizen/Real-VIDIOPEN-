package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "captured_frames")
data class CapturedFrameEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val videoId: String,
    val videoTitle: String,
    val videoUrl: String,
    val timestampMs: Long,
    val filePath: String,
    val fileName: String,
    val folderPath: String,
    val format: String, // "PNG" or "JPEG"
    val quality: Int, // e.g. 100 for PNG, 50-100 for JPEG
    val dateCreated: Long = System.currentTimeMillis()
)
