package com.example.data.repository

import com.example.data.database.AppDatabase
import com.example.data.model.MediaEntity
import com.example.data.model.VaultEntity
import com.example.data.model.ConfigEntity
import com.example.data.model.WatchHistoryEntity
import com.example.data.model.PinnedFolderEntity
import com.example.data.model.VideoBookmarkEntity
import com.example.data.model.VideoPlaylistEntity
import com.example.data.model.PlaylistVideoEntity
import com.example.data.model.QueueVideoEntity
import com.example.data.model.CapturedFrameEntity
import com.example.data.model.RecycleBinEntity


import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.onStart
import android.content.Context
import java.io.File
import kotlinx.coroutines.launch

class MediaRepository(private val context: Context, private val database: AppDatabase) {
    private val mediaDao = database.mediaDao()
    private val vaultDao = database.vaultDao()
    private val configDao = database.configDao()
    private val watchHistoryDao = database.watchHistoryDao()
    private val pinnedFolderDao = database.pinnedFolderDao()
    private val videoBookmarkDao = database.videoBookmarkDao()
    private val capturedFrameDao = database.capturedFrameDao()
    private val recycleBinDao = database.recycleBinDao()

    val allDeletedVideos: Flow<List<RecycleBinEntity>> = recycleBinDao.getAllDeletedVideos()

    suspend fun insertDeletedVideo(item: RecycleBinEntity) {
        recycleBinDao.insertDeletedVideo(item)
    }

    suspend fun deleteDeletedVideo(id: String) {
        recycleBinDao.deleteDeletedVideo(id)
    }

    suspend fun clearRecycleBin() {
        recycleBinDao.clearRecycleBin()
    }

    suspend fun getDeletedVideoById(id: String): RecycleBinEntity? {
        return recycleBinDao.getDeletedVideoById(id)
    }

    fun getAllCapturedFrames(): Flow<List<CapturedFrameEntity>> {
        return capturedFrameDao.getAllCapturedFrames()
    }

    suspend fun insertCapturedFrame(frame: CapturedFrameEntity): Long {
        return capturedFrameDao.insertCapturedFrame(frame)
    }

    suspend fun deleteCapturedFrame(id: Long) {
        capturedFrameDao.deleteCapturedFrame(id)
    }

    fun getCapturedFramesForVideo(videoId: String): Flow<List<CapturedFrameEntity>> {
        return capturedFrameDao.getCapturedFramesForVideo(videoId)
    }

    fun getBookmarksForVideo(videoId: String): Flow<List<VideoBookmarkEntity>> {
        return videoBookmarkDao.getBookmarksForVideo(videoId)
    }

    fun getAllBookmarks(): Flow<List<VideoBookmarkEntity>> {
        return videoBookmarkDao.getAllBookmarks()
    }

    suspend fun insertBookmark(bookmark: VideoBookmarkEntity) {
        videoBookmarkDao.insertBookmark(bookmark)
    }

    suspend fun updateBookmark(bookmark: VideoBookmarkEntity) {
        videoBookmarkDao.updateBookmark(bookmark)
    }

    suspend fun deleteBookmark(id: Int) {
        videoBookmarkDao.deleteBookmark(id)
    }

    suspend fun renameBookmark(id: Int, newName: String) {
        videoBookmarkDao.renameBookmark(id, newName)
    }

    val vaultItems: Flow<List<VaultEntity>> = vaultDao.getVaultItems()

    val allMedia: Flow<List<MediaEntity>> = combine(
        mediaDao.getAllMedia(),
        vaultDao.getVaultItems()
    ) { mediaList, vaultList ->
        val vaultTitles = vaultList.map { it.title.lowercase() }.toSet()
        val vaultPaths = vaultList.map { it.path.lowercase() }.toSet()
        mediaList.filter { media ->
            val titleLower = media.title.lowercase()
            val urlLower = media.url.lowercase()
            !vaultTitles.contains(titleLower) &&
            !vaultPaths.contains(urlLower) &&
            !urlLower.contains("nova_vault")
        }
    }.onStart {
        prepopulateIfEmpty()
    }
    val favorites: Flow<List<MediaEntity>> = mediaDao.getFavorites()
    val continueWatching: Flow<List<MediaEntity>> = mediaDao.getContinueWatching()
    val watchHistory: Flow<List<WatchHistoryEntity>> = watchHistoryDao.getWatchHistory()
    val pinnedFolderPaths: Flow<List<String>> = pinnedFolderDao.getPinnedFolderPaths()

    fun getMediaByCategory(category: String): Flow<List<MediaEntity>> {
        return mediaDao.getMediaByCategory(category)
    }

    suspend fun insertMedia(media: MediaEntity) = mediaDao.insertMedia(media)

    suspend fun updateMedia(media: MediaEntity) = mediaDao.updateMedia(media)

    suspend fun updatePlaybackPosition(id: String, position: Long) = mediaDao.updatePlaybackPosition(id, position)

    suspend fun toggleFavorite(id: String, isFavorite: Boolean) = mediaDao.toggleFavorite(id, isFavorite)

    suspend fun deleteMedia(id: String) = mediaDao.deleteMedia(id)

    suspend fun getMediaById(id: String): MediaEntity? = mediaDao.getMediaById(id)

    // Private Vault
    suspend fun insertVaultItem(item: VaultEntity) = vaultDao.insertVaultItem(item)
    suspend fun toggleVaultFavorite(id: Int, isFavorite: Boolean) = vaultDao.toggleFavorite(id, isFavorite)
    suspend fun deleteVaultItem(id: Int) = vaultDao.deleteVaultItem(id)

    // Watch History
    suspend fun insertWatchHistory(history: WatchHistoryEntity) = watchHistoryDao.insertWatchHistory(history)
    suspend fun clearWatchHistory() = watchHistoryDao.clearWatchHistory()
    suspend fun deleteWatchHistoryById(id: String) = watchHistoryDao.deleteWatchHistoryById(id)

    // Pinned Folders
    suspend fun pinFolder(folderPath: String) = pinnedFolderDao.pinFolder(PinnedFolderEntity(folderPath))
    suspend fun unpinFolder(folderPath: String) = pinnedFolderDao.unpinFolder(folderPath)

    // Config (PIN Lock, theme, language, etc.)
    suspend fun setConfig(key: String, value: String) {
        configDao.insertConfig(ConfigEntity(key, value))
    }

    suspend fun getConfig(key: String): String? {
        return configDao.getConfig(key)?.value
    }

    private fun formatSize(sizeInBytes: Long): String {
        if (sizeInBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(sizeInBytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.2f %s", sizeInBytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }

    suspend fun syncRealLocalMedia() = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val mediaStoreRepo = MediaStoreRepository(context)
        val scannedVideos = mediaStoreRepo.scanVideos()
        
        val musicRepo = MusicRepository(context)
        val scannedAudio = musicRepo.scanAudio()
        
        val newMediaList = mutableListOf<MediaEntity>()
        
        // Convert scanned videos to MediaEntity
        for (video in scannedVideos) {
            newMediaList.add(
                MediaEntity(
                    id = "scanned_${video.id}",
                    title = video.title,
                    url = video.uriString,
                    duration = video.duration,
                    artist = formatSize(video.size),
                    thumbnailUrl = video.thumbnailUrl,
                    category = "Movies"
                )
            )
        }
        
        // Convert scanned audio to MediaEntity
        for (song in scannedAudio) {
            newMediaList.add(
                MediaEntity(
                    id = "scanned_${song.id}",
                    title = song.title,
                    url = song.path,
                    duration = song.duration,
                    artist = song.artist,
                    thumbnailUrl = song.artworkUri,
                    category = "Music"
                )
            )
        }
        
        // If the scanned list is empty (no media on device storage),
        // we create actual real physical files on local device storage
        if (newMediaList.isEmpty()) {
            createRealStorageFiles(newMediaList)
        }
        
        if (newMediaList.isNotEmpty()) {
            // Delete old mock items
            mediaDao.deleteMedia("vid_tears_of_steel")
            mediaDao.deleteMedia("vid_sintel")
            mediaDao.deleteMedia("vid_bunny")
            mediaDao.deleteMedia("vid_elephants")
            mediaDao.deleteMedia("vid_cosmic_voyage")
            mediaDao.deleteMedia("vid_quantum_nexus")
            mediaDao.deleteMedia("audio_neon_horizon")
            mediaDao.deleteMedia("audio_midnight_ride")
            mediaDao.deleteMedia("audio_stardust")
            mediaDao.deleteMedia("audio_chrome_pulse")
            
            // Insert real scanned items
            mediaDao.insertAllMedia(newMediaList)
        }
    }

    private fun downloadFile(urlString: String, outputFile: File) {
        try {
            val url = java.net.URL(urlString)
            val connection = url.openConnection() as java.net.HttpURLConnection
            connection.connectTimeout = 4000
            connection.readTimeout = 4000
            connection.requestMethod = "GET"
            connection.connect()
            if (connection.responseCode == java.net.HttpURLConnection.HTTP_OK) {
                connection.inputStream.use { input ->
                    outputFile.outputStream().use { output ->
                        input.copyTo(output)
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun createRealStorageFiles(outList: MutableList<MediaEntity>) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val moviesDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
        val musicDir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC)
        
        if (moviesDir != null && musicDir != null) {
            val localMovies = listOf(
                Pair("Tears_of_Steel_Local.mp4", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4"),
                Pair("Sintel_Local.mp4", "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4")
            )
            
            val localMusic = listOf(
                Pair("Neon_Horizon_Local.mp3", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"),
                Pair("Midnight_Ride_Local.mp3", "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3")
            )
            
            for ((name, url) in localMovies) {
                val file = File(moviesDir, name)
                if (!file.exists()) {
                    try {
                        downloadFile(url, file)
                    } catch (e: Exception) {
                        try {
                            file.writeBytes(ByteArray(1024 * 100))
                        } catch (ex: Exception) {
                            ex.printStackTrace()
                        }
                    }
                }
                
                if (file.exists()) {
                    outList.add(
                        MediaEntity(
                            id = "local_movie_${name.hashCode()}",
                            title = name.replace("_", " ").replace(".mp4", ""),
                            url = file.absolutePath,
                            duration = 734000L,
                            artist = "Local Storage Video",
                            thumbnailUrl = "tears_of_steel",
                            category = "Movies"
                        )
                    )
                }
            }
            
            for ((name, url) in localMusic) {
                val file = File(musicDir, name)
                if (!file.exists()) {
                    try {
                        downloadFile(url, file)
                    } catch (e: Exception) {
                        try {
                            file.writeBytes(ByteArray(1024 * 50))
                        } catch (ex: Exception) {
                            ex.printStackTrace()
                        }
                    }
                }
                
                if (file.exists()) {
                    outList.add(
                        MediaEntity(
                            id = "local_music_${name.hashCode()}",
                            title = name.replace("_", " ").replace(".mp3", ""),
                            url = file.absolutePath,
                            duration = 372000L,
                            artist = "Local Storage Audio",
                            thumbnailUrl = "neon_horizon",
                            category = "Music"
                        )
                    )
                }
            }
        }
    }

    private suspend fun prepopulateIfEmpty() {
        val current = mediaDao.getMediaByCategory("Movies").firstOrNull()
        if (current.isNullOrEmpty()) {
            val defaultMedia = listOf(
                MediaEntity(
                    id = "vid_tears_of_steel",
                    title = "Tears of Steel (Sci-Fi Cyberpunk)",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
                    duration = 734000L,
                    artist = "Blender Foundation",
                    thumbnailUrl = "tears_of_steel",
                    category = "Movies"
                ),
                MediaEntity(
                    id = "vid_sintel",
                    title = "Sintel (Fantasy Adventure)",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
                    duration = 888000L,
                    artist = "Durian Project",
                    thumbnailUrl = "sintel",
                    category = "Movies"
                ),
                MediaEntity(
                    id = "vid_bunny",
                    title = "Big Buck Bunny (Classic Animation)",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                    duration = 596000L,
                    artist = "Peach Open Movie",
                    thumbnailUrl = "bunny",
                    category = "Movies"
                ),
                MediaEntity(
                    id = "vid_elephants",
                    title = "Elephant's Dream (Abstract Surreal)",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                    duration = 653000L,
                    artist = "Orange Open Movie",
                    thumbnailUrl = "elephants",
                    category = "Movies"
                ),
                MediaEntity(
                    id = "vid_cosmic_voyage",
                    title = "Cosmic Voyage: Season 1 Trailer",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                    duration = 15000L,
                    artist = "Galaxy Studio",
                    thumbnailUrl = "cosmic",
                    category = "TV Shows"
                ),
                MediaEntity(
                    id = "vid_quantum_nexus",
                    title = "Quantum Nexus Preview",
                    url = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                    duration = 15000L,
                    artist = "Nexus Corp",
                    thumbnailUrl = "quantum",
                    category = "TV Shows"
                ),
                MediaEntity(
                    id = "audio_neon_horizon",
                    title = "Neon Horizon (Synthwave Beat)",
                    url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
                    duration = 372000L,
                    artist = "SoundHelix",
                    thumbnailUrl = "neon_horizon",
                    category = "Music"
                ),
                MediaEntity(
                    id = "audio_midnight_ride",
                    title = "Midnight Ride (Cyberpunk Electro)",
                    url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
                    duration = 423000L,
                    artist = "SoundHelix",
                    thumbnailUrl = "midnight_ride",
                    category = "Music"
                ),
                MediaEntity(
                    id = "audio_stardust",
                    title = "Stardust Echoes (Acoustic Ambient)",
                    url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
                    duration = 302000L,
                    artist = "SoundHelix",
                    thumbnailUrl = "stardust",
                    category = "Music"
                ),
                MediaEntity(
                    id = "audio_chrome_pulse",
                    title = "Pulse of Chrome (Future Bass)",
                    url = "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
                    duration = 350000L,
                    artist = "SoundHelix",
                    thumbnailUrl = "chrome_pulse",
                    category = "Music"
                )
            )
            mediaDao.insertAllMedia(defaultMedia)
        }
        // Background sync real local storage files and replace defaults asynchronously
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            syncRealLocalMedia()
        }
    }

    // Playlist APIs
    private val playlistDao = database.playlistDao()
    private val queueDao = database.queueDao()

    val allPlaylists: Flow<List<VideoPlaylistEntity>> = playlistDao.getAllPlaylists()

    fun getVideosForPlaylist(playlistId: Long): Flow<List<PlaylistVideoEntity>> =
        playlistDao.getVideosForPlaylist(playlistId)

    suspend fun getVideosForPlaylistList(playlistId: Long): List<PlaylistVideoEntity> =
        playlistDao.getVideosForPlaylistList(playlistId)

    suspend fun createPlaylist(name: String): Long =
        playlistDao.insertPlaylist(VideoPlaylistEntity(name = name))

    suspend fun renamePlaylist(playlistId: Long, newName: String) =
        playlistDao.renamePlaylist(playlistId, newName)

    suspend fun deletePlaylist(playlistId: Long) =
        playlistDao.deletePlaylistWithVideos(playlistId)

    suspend fun addVideoToPlaylist(playlistId: Long, video: MediaEntity) {
        val currentVideos = playlistDao.getVideosForPlaylistList(playlistId)
        val maxOrder = currentVideos.maxOfOrNull { it.orderIndex } ?: -1
        playlistDao.insertPlaylistVideo(
            PlaylistVideoEntity(
                playlistId = playlistId,
                videoId = video.id,
                title = video.title,
                url = video.url,
                duration = video.duration,
                thumbnailUrl = video.thumbnailUrl,
                orderIndex = maxOrder + 1
            )
        )
    }

    suspend fun removeVideoFromPlaylist(playlistVideoId: Long) =
        playlistDao.deletePlaylistVideo(playlistVideoId)

    suspend fun reorderPlaylistVideos(playlistId: Long, reorderedList: List<PlaylistVideoEntity>) =
        playlistDao.reorderVideos(playlistId, reorderedList)

    // Queue APIs
    val queueVideos: Flow<List<QueueVideoEntity>> = queueDao.getQueueVideos()

    suspend fun getQueueVideosList(): List<QueueVideoEntity> =
        queueDao.getQueueVideosList()

    suspend fun addToQueue(video: MediaEntity) {
        val currentQueue = queueDao.getQueueVideosList()
        val maxOrder = currentQueue.maxOfOrNull { it.orderIndex } ?: -1
        queueDao.insertQueueVideo(
            QueueVideoEntity(
                videoId = video.id,
                title = video.title,
                url = video.url,
                duration = video.duration,
                thumbnailUrl = video.thumbnailUrl,
                orderIndex = maxOrder + 1
            )
        )
    }

    suspend fun playNext(video: MediaEntity) {
        val currentQueue = queueDao.getQueueVideosList()
        val updated = mutableListOf<QueueVideoEntity>()
        updated.add(
            QueueVideoEntity(
                videoId = video.id,
                title = video.title,
                url = video.url,
                duration = video.duration,
                thumbnailUrl = video.thumbnailUrl,
                orderIndex = 0
            )
        )
        currentQueue.forEachIndexed { index, item ->
            updated.add(item.copy(id = 0L, orderIndex = index + 1))
        }
        queueDao.reorderQueue(updated)
    }

    suspend fun removeFromQueue(queueVideoId: Long) =
        queueDao.deleteQueueVideo(queueVideoId)

    suspend fun clearQueue() =
        queueDao.clearQueue()

    suspend fun reorderQueue(reorderedList: List<QueueVideoEntity>) =
        queueDao.reorderQueue(reorderedList)
}
