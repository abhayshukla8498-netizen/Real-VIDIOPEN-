package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transfer_history")
data class TransferHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val fileName: String,
    val fileSize: Long,
    val transferTime: Long = System.currentTimeMillis(),
    val deviceName: String,
    val status: String, // "Success", "Failed", "Cancelled", "In Progress"
    val isIncoming: Boolean // true for receive, false for send
)
