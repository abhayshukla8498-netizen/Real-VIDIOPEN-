package com.example.utils

import com.example.data.model.ScannedVideo
import com.example.data.model.VideoFolder
import com.example.data.model.MediaEntity
import com.example.data.model.ScannedSong
import java.io.File
import java.text.Normalizer
import kotlin.math.min

/**
 * Intelligent Smart Search Engine for Videos, Audio, and Folders.
 * Features:
 * - Multi-level relevance scoring (Exact, Prefix, Substring, Acronyms)
 * - Typo tolerance via Levenshtein Distance
 * - Technical intent detection (4K, HD, Short Clips, Movies, Extensions)
 * - Source/Folder intent detection (WhatsApp, Camera, Downloads, Telegram)
 * - Phonetic & acronym matching (e.g., "kgf" -> "K.G.F Chapter 2", "spidr" -> "Spider-Man")
 */
object SmartSearchEngine {

    data class ScoredResult<T>(val item: T, val score: Int, val matchTags: List<String>)

    // Technical & Smart Intent Keywords Mapping
    private val INTENT_4K = setOf("4k", "2160", "2160p", "uhd", "ultra hd")
    private val INTENT_HD = setOf("hd", "1080", "1080p", "fhd", "full hd", "720", "720p")
    private val INTENT_SHORT = setOf("short", "shorts", "reel", "reels", "status", "tiktok", "clip", "clips", "quick")
    private val INTENT_MOVIE = setOf("movie", "movies", "film", "films", "cinema", "full movie", "feature")
    private val INTENT_CAMERA = setOf("cam", "camera", "dcim", "rec", "recorded", "shot")
    private val INTENT_WHATSAPP = setOf("wa", "whatsapp", "status", "sent", "received")
    private val INTENT_DOWNLOAD = setOf("dwn", "download", "downloads", "tele", "telegram", "tube")
    private val INTENT_MUSIC = setOf("song", "songs", "music", "audio", "track", "beat", "sing", "gana", "gaana")
    private val EXTENSIONS = setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "flv", "wmv", "m4v", "ts")

    /**
     * Score a ScannedVideo against a query string. Returns score (> 0 if matched) + match tags.
     */
    fun scoreVideo(video: ScannedVideo, rawQuery: String): ScoredResult<ScannedVideo>? {
        if (rawQuery.isBlank()) return ScoredResult(video, 1, emptyList())

        val query = normalize(rawQuery)
        val queryTokens = query.split("\\s+".toRegex()).filter { it.isNotBlank() }
        if (queryTokens.isEmpty()) return ScoredResult(video, 1, emptyList())

        val title = normalize(video.title)
        val path = normalize(video.path)
        val parentFolder = normalize(File(video.path).parentFile?.name ?: "")
        val acronym = generateAcronym(title)

        var totalScore = 0
        val matchTags = mutableListOf<String>()

        // Check each query token
        for (qToken in queryTokens) {
            var tokenScore = 0

            // 1. Exact Title Match
            if (title == qToken) {
                tokenScore += 1000
                matchTags.add("Exact Match")
            }
            // 2. Title Starts With
            else if (title.startsWith(qToken)) {
                tokenScore += 800
                matchTags.add("Title Match")
            }
            // 3. Word Prefix Match
            else if (title.split("\\s+".toRegex()).any { it.startsWith(qToken) }) {
                tokenScore += 650
            }
            // 4. Substring Match
            else if (title.contains(qToken)) {
                tokenScore += 500
            }
            // 5. Acronym / Initials Match (e.g. "kgf" -> "K.G.F Chapter 2")
            else if (acronym.contains(qToken) || (qToken.contains(acronym) && acronym.length >= 2)) {
                tokenScore += 700
                matchTags.add("Acronym Match")
            }

            // 6. Parent Folder / Path Match
            if (parentFolder.contains(qToken) || path.contains(qToken)) {
                tokenScore += 350
                if (!matchTags.contains("Folder")) matchTags.add(parentFolder.ifBlank { "Folder" })
            }

            // 7. File Extension Match
            if (EXTENSIONS.contains(qToken) && path.endsWith(qToken)) {
                tokenScore += 400
                matchTags.add(qToken.uppercase())
            }

            // 8. Technical Intent Matching (Smart AI Resolution/Duration/Folder Detection)
            val maxRes = maxOf(video.width, video.height)
            if (INTENT_4K.contains(qToken) && (maxRes >= 3840 || title.contains("4k"))) {
                tokenScore += 600
                matchTags.add("🎬 4K Ultra HD")
            }
            if (INTENT_HD.contains(qToken) && (maxRes >= 1280 || title.contains("1080") || title.contains("720"))) {
                tokenScore += 500
                matchTags.add("📺 HD Quality")
            }
            if (INTENT_SHORT.contains(qToken) && (video.duration in 1..180000 || path.contains("shorts") || path.contains("status"))) {
                tokenScore += 550
                matchTags.add("⚡ Short Clip")
            }
            if (INTENT_MOVIE.contains(qToken) && (video.duration >= 1200000 || path.contains("movie"))) {
                tokenScore += 550
                matchTags.add("🍿 Movie")
            }
            if (INTENT_CAMERA.contains(qToken) && (path.contains("dcim") || path.contains("camera"))) {
                tokenScore += 500
                matchTags.add("📱 Camera")
            }
            if (INTENT_WHATSAPP.contains(qToken) && path.contains("whatsapp")) {
                tokenScore += 500
                matchTags.add("💬 WhatsApp")
            }
            if (INTENT_DOWNLOAD.contains(qToken) && (path.contains("download") || path.contains("telegram"))) {
                tokenScore += 500
                matchTags.add("📥 Downloaded")
            }

            // 9. Typo Tolerance via Levenshtein Distance
            if (tokenScore == 0 && qToken.length >= 3) {
                val words = title.split("\\s+".toRegex())
                for (word in words) {
                    if (word.length >= 3) {
                        val dist = levenshtein(qToken, word)
                        val maxAllowed = if (qToken.length <= 4) 1 else 2
                        if (dist <= maxAllowed) {
                            tokenScore += (400 - dist * 100)
                            matchTags.add("Did you mean: $word?")
                            break
                        }
                    }
                }
            }

            totalScore += tokenScore
        }

        return if (totalScore > 0) ScoredResult(video, totalScore, matchTags.distinct()) else null
    }

    /**
     * Score a VideoFolder against query.
     */
    fun scoreFolder(folder: VideoFolder, rawQuery: String): ScoredResult<VideoFolder>? {
        if (rawQuery.isBlank()) return ScoredResult(folder, 1, emptyList())

        val query = normalize(rawQuery)
        val folderName = normalize(folder.name)
        val folderPath = normalize(folder.path)

        var score = 0
        if (folderName == query) score += 1000
        else if (folderName.startsWith(query)) score += 800
        else if (folderName.contains(query)) score += 500
        else if (folderPath.contains(query)) score += 300

        // Check inner videos
        val videoMatches = folder.videos.mapNotNull { scoreVideo(it, rawQuery) }
        if (videoMatches.isNotEmpty()) {
            val maxVideoScore = videoMatches.maxOf { it.score }
            score += maxVideoScore / 2
        }

        return if (score > 0) ScoredResult(folder, score, emptyList()) else null
    }

    /**
     * Score a generic MediaEntity against query.
     */
    fun scoreMediaEntity(media: MediaEntity, rawQuery: String): ScoredResult<MediaEntity>? {
        if (rawQuery.isBlank()) return ScoredResult(media, 1, emptyList())

        val query = normalize(rawQuery)
        val title = normalize(media.title)
        val artist = normalize(media.artist ?: "")
        val category = normalize(media.category)
        val acronym = generateAcronym(title)

        var score = 0
        val tags = mutableListOf<String>()

        if (title == query) { score += 1000; tags.add("Exact Title") }
        else if (title.startsWith(query)) { score += 800; tags.add("Title Match") }
        else if (title.contains(query)) { score += 500 }
        else if (acronym.contains(query) && acronym.length >= 2) { score += 700; tags.add("Acronym Match") }

        if (artist.contains(query)) { score += 400; tags.add("Artist Match") }
        if (category.contains(query)) { score += 350; tags.add("Category") }

        // Typo tolerance
        if (score == 0 && query.length >= 3) {
            val words = title.split("\\s+".toRegex())
            for (w in words) {
                if (w.length >= 3 && levenshtein(query, w) <= 1) {
                    score += 300
                    tags.add("Typo Match")
                    break
                }
            }
        }

        return if (score > 0) ScoredResult(media, score, tags.distinct()) else null
    }

    /**
     * Score a ScannedSong against query.
     */
    fun scoreSong(song: ScannedSong, rawQuery: String): ScoredResult<ScannedSong>? {
        if (rawQuery.isBlank()) return ScoredResult(song, 1, emptyList())

        val query = normalize(rawQuery)
        val title = normalize(song.title)
        val artist = normalize(song.artist ?: "")
        val album = normalize(song.album ?: "")
        val acronym = generateAcronym(title)

        var score = 0
        if (title == query) score += 1000
        else if (title.startsWith(query)) score += 800
        else if (title.contains(query)) score += 500
        else if (acronym.contains(query) && acronym.length >= 2) score += 700

        if (artist.contains(query)) score += 450
        if (album.contains(query)) score += 350

        return if (score > 0) ScoredResult(song, score, emptyList()) else null
    }

    /**
     * Generate smart search suggestions based on current query and scanned videos.
     */
    fun getSmartSuggestions(query: String, videos: List<ScannedVideo>): List<String> {
        val suggestions = mutableListOf<String>()
        val trimmed = query.trim().lowercase()

        if (trimmed.isEmpty()) {
            return listOf("🎬 4K Movies", "⚡ Short Reels", "📱 Camera Records", "💬 WhatsApp", "📥 Downloads", "🎵 Songs & Beats")
        }

        // 1. Matching Folder Names
        val matchedFolders = videos.mapNotNull { File(it.path).parentFile?.name }
            .distinct()
            .filter { it.lowercase().contains(trimmed) }
            .take(2)
        matchedFolders.forEach { suggestions.add("📁 Folder: $it") }

        // 2. High scoring video title matches
        val topTitles = videos.mapNotNull { scoreVideo(it, query) }
            .sortedByDescending { it.score }
            .map { it.item.title }
            .distinct()
            .take(3)
        suggestions.addAll(topTitles)

        // 3. Technical intent chips
        if ("4k".startsWith(trimmed) || "uhd".startsWith(trimmed)) suggestions.add("🎬 Filter 4K Ultra HD")
        if ("hd".startsWith(trimmed) || "1080".startsWith(trimmed)) suggestions.add("📺 Filter Full HD 1080p")
        if ("short".startsWith(trimmed) || "reel".startsWith(trimmed)) suggestions.add("⚡ Filter Short Clips (<3 min)")
        if ("movie".startsWith(trimmed) || "film".startsWith(trimmed)) suggestions.add("🍿 Filter Feature Movies")
        if ("cam".startsWith(trimmed) || "camera".startsWith(trimmed)) suggestions.add("📱 Filter Camera Recordings")

        return suggestions.distinct().take(5)
    }

    /**
     * Helper to normalize string for fuzzy search (removes accents and punctuation).
     */
    private fun normalize(str: String): String {
        val nfdNormalizedString = Normalizer.normalize(str, Normalizer.Form.NFD)
        val pattern = "\\p{InCombiningDiacriticalMarks}+".toRegex()
        return pattern.replace(nfdNormalizedString, "")
            .lowercase()
            .replace("[^a-z0-9\\s]".toRegex(), " ")
            .trim()
    }

    /**
     * Generate acronym/initials from string (e.g. "Game of Thrones" -> "got").
     */
    private fun generateAcronym(str: String): String {
        return str.split("\\s+".toRegex())
            .filter { it.isNotBlank() }
            .map { it[0] }
            .joinToString("")
            .lowercase()
    }

    /**
     * Standard Levenshtein Distance algorithm.
     */
    private fun levenshtein(lhs: CharSequence, rhs: CharSequence): Int {
        val lhsLen = lhs.length
        val rhsLen = rhs.length

        var distance = IntArray(lhsLen + 1) { it }
        var newDistance = IntArray(lhsLen + 1)

        for (j in 1..rhsLen) {
            newDistance[0] = j
            for (i in 1..lhsLen) {
                val match = if (lhs[i - 1] == rhs[j - 1]) 0 else 1
                val costDelete = distance[i] + 1
                val costInsert = newDistance[i - 1] + 1
                val costReplace = distance[i - 1] + match
                newDistance[i] = min(min(costDelete, costInsert), costReplace)
            }
            val swap = distance
            distance = newDistance
            newDistance = swap
        }
        return distance[lhsLen]
    }
}
