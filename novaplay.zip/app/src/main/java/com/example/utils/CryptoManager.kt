package com.example.utils

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import timber.log.Timber

object CryptoManager {
    private const val ALGORITHM = "AES/GCM/NoPadding"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val KEY_ALIAS = "NovaVaultKeyAlias"
    private const val IV_SIZE = 12
    private const val TAG_SIZE_BITS = 128
    private const val BUFFER_SIZE = 8192

    init {
        initKeyStore()
    }

    private fun initKeyStore() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            if (!keyStore.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
                val spec = KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build()
                keyGenerator.init(spec)
                keyGenerator.generateKey()
                Timber.d("CryptoManager: AES Key generated in Android KeyStore")
            } else {
                Timber.d("CryptoManager: AES Key already exists in Android KeyStore")
            }
        } catch (e: Exception) {
            Timber.e(e, "CryptoManager: Failed to initialize KeyStore")
        }
    }

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
    }

    private fun readIv(fis: InputStream): ByteArray? {
        val iv = ByteArray(IV_SIZE)
        var totalRead = 0
        while (totalRead < IV_SIZE) {
            val read = fis.read(iv, totalRead, IV_SIZE - totalRead)
            if (read == -1) break
            totalRead += read
        }
        return if (totalRead == IV_SIZE) iv else null
    }

    /**
     * Encrypts a source file and writes the encrypted contents to a destination file.
     * Prepend the IV (12 bytes) to the file before writing the encrypted payload.
     */
    fun encryptFile(sourceFile: File, destFile: File): Boolean {
        if (!sourceFile.exists()) {
            Timber.e("CryptoManager: Source file does not exist: %s", sourceFile.absolutePath)
            return false
        }
        return try {
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())

            destFile.parentFile?.mkdirs()
            FileOutputStream(destFile).use { fos ->
                // Write IV first
                fos.write(cipher.iv)

                CipherOutputStream(fos, cipher).use { cos ->
                    FileInputStream(sourceFile).use { fis ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var bytesRead: Int
                        while (fis.read(buffer).also { bytesRead = it } != -1) {
                            cos.write(buffer, 0, bytesRead)
                        }
                    }
                }
            }
            Timber.d("CryptoManager: File successfully encrypted to %s", destFile.absolutePath)
            true
        } catch (e: Exception) {
            Timber.e(e, "CryptoManager: Encryption failed for %s", sourceFile.absolutePath)
            false
        }
    }

    /**
     * Encrypts from an InputStream (e.g. ContentResolver stream) directly to a destination file.
     * Prepend the IV (12 bytes) to the file before writing the encrypted payload.
     */
    fun encryptStream(inputStream: InputStream, destFile: File): Boolean {
        return try {
            val cipher = Cipher.getInstance(ALGORITHM)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())

            destFile.parentFile?.mkdirs()
            FileOutputStream(destFile).use { fos ->
                // Write IV first
                fos.write(cipher.iv)

                CipherOutputStream(fos, cipher).use { cos ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var bytesRead: Int
                    while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                        cos.write(buffer, 0, bytesRead)
                    }
                }
            }
            Timber.d("CryptoManager: Stream successfully encrypted to %s", destFile.absolutePath)
            true
        } catch (e: Exception) {
            Timber.e(e, "CryptoManager: Stream encryption failed for %s", destFile.absolutePath)
            false
        }
    }

    /**
     * Decrypts an encrypted source file and writes the decrypted contents to a destination file.
     */
    fun decryptFile(sourceFile: File, destFile: File): Boolean {
        if (!sourceFile.exists()) {
            Timber.e("CryptoManager: Encrypted source file does not exist: %s", sourceFile.absolutePath)
            return false
        }
        return try {
            destFile.parentFile?.mkdirs()
            FileInputStream(sourceFile).use { fis ->
                // Read IV reliably
                val iv = readIv(fis)
                if (iv == null) {
                    Timber.e("CryptoManager: Failed to read full IV")
                    return false
                }

                val cipher = Cipher.getInstance(ALGORITHM)
                val spec = GCMParameterSpec(TAG_SIZE_BITS, iv)
                cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)

                CipherInputStream(fis, cipher).use { cis ->
                    FileOutputStream(destFile).use { fos ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var bytesRead: Int
                        while (cis.read(buffer).also { bytesRead = it } != -1) {
                            fos.write(buffer, 0, bytesRead)
                        }
                    }
                }
            }
            Timber.d("CryptoManager: File successfully decrypted to %s", destFile.absolutePath)
            true
        } catch (e: Exception) {
            Timber.e(e, "CryptoManager: Decryption failed for %s", sourceFile.absolutePath)
            false
        }
    }

    /**
     * Decrypts an encrypted source file and returns the plaintext as a ByteArray.
     * Useful for smaller files like Photos or text documents.
     */
    fun decryptToByteArray(sourceFile: File): ByteArray? {
        if (!sourceFile.exists()) return null
        return try {
            FileInputStream(sourceFile).use { fis ->
                val iv = readIv(fis) ?: return null

                val cipher = Cipher.getInstance(ALGORITHM)
                val spec = GCMParameterSpec(TAG_SIZE_BITS, iv)
                cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)

                CipherInputStream(fis, cipher).use { cis ->
                    cis.readBytes()
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "CryptoManager: Decrypt to ByteArray failed")
            null
        }
    }
}
