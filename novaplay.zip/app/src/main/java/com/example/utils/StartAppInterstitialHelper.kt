package com.example.utils

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import com.startapp.sdk.adsbase.Ad
import com.startapp.sdk.adsbase.StartAppAd
import com.startapp.sdk.adsbase.adlisteners.AdEventListener
import com.startapp.sdk.adsbase.adlisteners.AdDisplayListener
import timber.log.Timber

fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}

object StartAppInterstitialHelper {
    private var startAppAd: StartAppAd? = null
    private var isLoading = false

    fun isNetworkAvailable(context: Context): Boolean {
        return try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager ?: return false
            val activeNetwork = connectivityManager.activeNetwork ?: return false
            val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
            capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    fun initAndLoad(context: Context) {
        try {
            if (startAppAd == null) {
                startAppAd = StartAppAd(context.applicationContext)
            }
            loadAd()
        } catch (e: Throwable) {
            Timber.e(e, "StartAppInterstitial: initAndLoad failed")
        }
    }

    fun loadAd() {
        try {
            val ad = startAppAd ?: return
            if (ad.isReady || isLoading) return

            isLoading = true
            ad.loadAd(object : AdEventListener {
                override fun onReceiveAd(ad: Ad) {
                    isLoading = false
                    Timber.d("StartAppInterstitial: Interstitial ad loaded successfully")
                }

                override fun onFailedToReceiveAd(ad: Ad?) {
                    isLoading = false
                    val errorMsg = ad?.errorMessage ?: "unknown error"
                    Timber.w("StartAppInterstitial: Failed to load interstitial ad: $errorMsg")
                }
            })
        } catch (e: Throwable) {
            isLoading = false
            Timber.e(e, "StartAppInterstitial: loadAd failed")
        }
    }

    fun showAd(context: Context, onAdClosed: () -> Unit = {}) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var isCallbackDone = false
        val safeOnAdClosed = {
            if (!isCallbackDone) {
                isCallbackDone = true
                mainHandler.post {
                    try {
                        onAdClosed()
                    } catch (e: Throwable) {
                        Timber.e(e, "StartAppInterstitial: Error in onAdClosed callback")
                    }
                }
            }
        }

        val activity = context.findActivity()
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            Timber.w("StartAppInterstitial: Valid Activity not found or finishing. Skipping ad display.")
            safeOnAdClosed()
            return
        }

        try {
            val cachedAd = startAppAd
            if (cachedAd != null && cachedAd.isReady) {
                val shown = cachedAd.showAd(object : AdDisplayListener {
                    override fun adDisplayed(ad: Ad?) {
                        Timber.d("StartAppInterstitial: Cached Ad displayed")
                    }

                    override fun adHidden(ad: Ad?) {
                        Timber.d("StartAppInterstitial: Cached Ad hidden")
                        loadAd()
                        safeOnAdClosed()
                    }

                    override fun adClicked(ad: Ad?) {
                        Timber.d("StartAppInterstitial: Ad clicked")
                    }

                    override fun adNotDisplayed(ad: Ad?) {
                        Timber.w("StartAppInterstitial: Cached Ad not displayed")
                        loadAd()
                        safeOnAdClosed()
                    }
                })
                if (shown) return
            }

            val ad = StartAppAd(activity).also { startAppAd = it }
            ad.loadAd(object : AdEventListener {
                override fun onReceiveAd(adObj: Ad) {
                    try {
                        val shown = ad.showAd(object : AdDisplayListener {
                            override fun adDisplayed(a: Ad?) {
                                Timber.d("StartAppInterstitial: Ad displayed")
                            }

                            override fun adHidden(a: Ad?) {
                                Timber.d("StartAppInterstitial: Ad hidden / closed")
                                loadAd()
                                safeOnAdClosed()
                            }

                            override fun adClicked(a: Ad?) {
                                Timber.d("StartAppInterstitial: Ad clicked")
                            }

                            override fun adNotDisplayed(a: Ad?) {
                                Timber.w("StartAppInterstitial: Ad not displayed")
                                safeOnAdClosed()
                            }
                        })
                        if (!shown) {
                            safeOnAdClosed()
                        }
                    } catch (e: Throwable) {
                        safeOnAdClosed()
                    }
                }

                override fun onFailedToReceiveAd(adObj: Ad?) {
                    Timber.w("StartAppInterstitial: loadAd failed on receive")
                    safeOnAdClosed()
                }
            })
        } catch (e: Throwable) {
            Timber.e(e, "StartAppInterstitial: Failed during showAd, falling back to callback")
            safeOnAdClosed()
        }
    }

    fun showMultipleAds(context: Context, count: Int, onComplete: () -> Unit = {}) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        
        val safeOnComplete = {
            mainHandler.post {
                try {
                    onComplete()
                } catch (e: Throwable) {
                    Timber.e(e, "StartAppInterstitial: Error in showMultipleAds onComplete")
                }
            }
        }

        if (count <= 0) {
            safeOnComplete()
            return
        }

        try {
            showAd(context) {
                if (count > 1) {
                    mainHandler.postDelayed({
                        showMultipleAds(context, count - 1, onComplete)
                    }, 400)
                } else {
                    showMultipleAds(context, count - 1, onComplete)
                }
            }
        } catch (e: Throwable) {
            Timber.e(e, "StartAppInterstitial: showMultipleAds failed, falling back to onComplete")
            safeOnComplete()
        }
    }

    fun showRewardedVideoAd(context: Context, onRewarded: () -> Unit) {
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        var rewardTriggered = false

        val safeOnRewarded = {
            if (!rewardTriggered) {
                rewardTriggered = true
                mainHandler.post {
                    try {
                        onRewarded()
                    } catch (e: Throwable) {
                        Timber.e(e, "StartAppRewarded: Error in onRewarded callback")
                    }
                }
            }
        }

        val activity = context.findActivity()
        if (activity == null || activity.isFinishing || activity.isDestroyed) {
            Timber.w("StartAppRewarded: Valid Activity not found. Granting reward directly.")
            safeOnRewarded()
            return
        }

        try {
            val rewardedAd = StartAppAd(activity)
            rewardedAd.setVideoListener(object : com.startapp.sdk.adsbase.adlisteners.VideoListener {
                override fun onVideoCompleted() {
                    Timber.d("StartAppRewarded: Video completed, granting reward")
                    safeOnRewarded()
                }
            })

            rewardedAd.loadAd(StartAppAd.AdMode.REWARDED_VIDEO, object : AdEventListener {
                override fun onReceiveAd(ad: Ad) {
                    Timber.d("StartAppRewarded: Rewarded video ad received, displaying now")
                    try {
                        val shown = rewardedAd.showAd(object : AdDisplayListener {
                            override fun adDisplayed(ad: Ad?) {
                                Timber.d("StartAppRewarded: Ad displayed")
                            }

                            override fun adHidden(ad: Ad?) {
                                Timber.d("StartAppRewarded: Ad hidden / closed")
                                safeOnRewarded()
                            }

                            override fun adClicked(ad: Ad?) {
                                Timber.d("StartAppRewarded: Ad clicked")
                            }

                            override fun adNotDisplayed(ad: Ad?) {
                                Timber.w("StartAppRewarded: Ad not displayed, using fallback interstitial")
                                showMultipleAds(context, 1) { safeOnRewarded() }
                            }
                        })
                        if (!shown) {
                            Timber.w("StartAppRewarded: showAd returned false, using fallback interstitial")
                            showMultipleAds(context, 1) { safeOnRewarded() }
                        }
                    } catch (e: Throwable) {
                        Timber.e(e, "StartAppRewarded: Error showing rewarded ad")
                        safeOnRewarded()
                    }
                }

                override fun onFailedToReceiveAd(ad: Ad?) {
                    Timber.w("StartAppRewarded: Failed to receive rewarded video, falling back to interstitial")
                    showMultipleAds(context, 1) { safeOnRewarded() }
                }
            })
        } catch (e: Throwable) {
            Timber.e(e, "StartAppRewarded: Exception during rewarded video ad flow, falling back")
            safeOnRewarded()
        }
    }
}
