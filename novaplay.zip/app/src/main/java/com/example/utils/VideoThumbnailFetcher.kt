package com.example.utils

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import coil.size.Dimension
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VideoThumbnailFetcher(
    private val context: Context,
    private val data: Uri,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val bitmap: Bitmap? = try {
            val scheme = data.scheme
            val pathStr = data.path ?: ""
            if (scheme == ContentResolver.SCHEME_CONTENT || data.toString().startsWith("content://")) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val widthPx = (options.size.width as? Dimension.Pixels)?.px ?: 320
                    val heightPx = (options.size.height as? Dimension.Pixels)?.px ?: 240
                    context.contentResolver.loadThumbnail(
                        data,
                        Size(widthPx.coerceAtLeast(120), heightPx.coerceAtLeast(120)),
                        null
                    )
                } else {
                    val id = try { ContentUris.parseId(data) } catch (e: Exception) { -1L }
                    if (id != -1L) {
                        MediaStore.Video.Thumbnails.getThumbnail(
                            context.contentResolver,
                            id,
                            MediaStore.Video.Thumbnails.MINI_KIND,
                            null
                        )
                    } else null
                }
            } else if (scheme == ContentResolver.SCHEME_FILE || pathStr.startsWith("/")) {
                val filePath = if (scheme == ContentResolver.SCHEME_FILE) data.path else data.toString()
                if (!filePath.isNullOrEmpty()) {
                    val file = java.io.File(filePath)
                    if (file.exists()) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            ThumbnailUtils.createVideoThumbnail(
                                file,
                                Size(320, 240),
                                null
                            )
                        } else {
                            @Suppress("DEPRECATION")
                            ThumbnailUtils.createVideoThumbnail(
                                filePath,
                                MediaStore.Images.Thumbnails.MINI_KIND
                            )
                        }
                    } else null
                } else null
            } else null
        } catch (e: Exception) {
            null
        }

        if (bitmap != null) {
            DrawableResult(
                drawable = bitmap.toDrawable(context.resources),
                isSampled = false,
                dataSource = DataSource.DISK
            )
        } else {
            null
        }
    }

    class Factory(private val context: Context) : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? {
            val str = data.toString()
            val scheme = data.scheme
            val path = data.path ?: ""
            val isVideo = (scheme == ContentResolver.SCHEME_CONTENT && str.contains("video")) ||
                    path.endsWith(".mp4", ignoreCase = true) ||
                    path.endsWith(".mkv", ignoreCase = true) ||
                    path.endsWith(".webm", ignoreCase = true) ||
                    path.endsWith(".3gp", ignoreCase = true) ||
                    path.endsWith(".avi", ignoreCase = true) ||
                    str.endsWith(".mp4", ignoreCase = true)
            
            if (isVideo) {
                return VideoThumbnailFetcher(context, data, options)
            }
            return null
        }
    }
}
