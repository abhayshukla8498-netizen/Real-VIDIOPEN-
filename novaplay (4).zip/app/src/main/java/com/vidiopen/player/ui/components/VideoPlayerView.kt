package com.vidiopen.player.ui.components

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.view.WindowManager
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.ui.viewmodel.MediaViewModel
import com.vidiopen.player.ui.viewmodel.MusicViewModel
import kotlinx.coroutines.delay
import kotlin.math.abs

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayerView(
    media: MediaEntity,
    viewModel: MediaViewModel,
    onClose: (Long) -> Unit,
    onAudioConverted: () -> Unit = {},
    onNavigateToMusic: () -> Unit = {},
    musicViewModel: MusicViewModel? = null
) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    // Core Player States
    var isControlsVisible by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(true) }
    var currentPosition by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var isMuted by remember { mutableStateOf(false) }

    // Aspect Ratio
    var resizeMode by remember { mutableIntStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }

    // Brightness Gesture State
    var brightnessPercent by remember { mutableIntStateOf(70) }
    var showBrightnessOverlay by remember { mutableStateOf(false) }

    // 200% Volume Booster State
    var volumePercent by remember { mutableIntStateOf(100) }
    var showVolumeOverlay by remember { mutableStateOf(false) }
    var loudnessEnhancer by remember { mutableStateOf<LoudnessEnhancer?>(null) }

    // Horizontal Seek Gesture State
    var showSeekOverlay by remember { mutableStateOf(false) }
    var seekTargetPosition by remember { mutableLongStateOf(0L) }
    var seekDeltaSeconds by remember { mutableLongStateOf(0L) }

    // Double Tap Ripple State (0: None, 1: Rewind 10s, 2: Forward 10s, 3: Pause, 4: Play)
    var doubleTapBadgeType by remember { mutableIntStateOf(0) }

    // Kids Screen Touch Lock State
    var isTouchLocked by remember { mutableStateOf(false) }
    var showUnlockHint by remember { mutableStateOf(false) }

    // Orientation State (0: Auto Sensor, 1: Landscape, 2: Portrait)
    var orientationMode by remember { mutableIntStateOf(0) }

    // Sleep Timer State (minutes remaining, 0 = off)
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }

    // Notification Pill State
    var pillMessage by remember { mutableStateOf("") }
    var pillIcon by remember { mutableStateOf<ImageVector?>(null) }
    var showPill by remember { mutableStateOf(false) }

    // Dialogs States
    var showSpeedDialog by remember { mutableStateOf(false) }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showAudioTrackDialog by remember { mutableStateOf(false) }
    var showSubtitlesDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var showVideoSwitcherDialog by remember { mutableStateOf(false) }

    // Tracks
    val audioTracks = remember { mutableStateListOf<String>() }
    var selectedAudioTrackIndex by remember { mutableIntStateOf(0) }
    val subtitleTracks = remember { mutableStateListOf<String>() }
    var selectedSubtitleIndex by remember { mutableIntStateOf(0) }
    var subtitlesEnabled by remember { mutableStateOf(false) }

    fun triggerPill(message: String, icon: ImageVector? = null) {
        pillMessage = message
        pillIcon = icon
        showPill = true
    }

    fun applyBrightness(fraction: Float) {
        val clamped = fraction.coerceIn(0.01f, 1.0f)
        activity?.window?.attributes = activity?.window?.attributes?.apply {
            screenBrightness = clamped
        }
    }

    val exoPlayer = remember {
        val renderersFactory = com.vidiopen.player.utils.SafeRenderersFactory(context)
        val audioAttributes = androidx.media3.common.AudioAttributes.Builder()
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .setUsage(C.USAGE_MEDIA)
            .build()
        ExoPlayer.Builder(context, renderersFactory)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .build().apply {
                val uri = Uri.parse(media.url)
                setMediaItem(MediaItem.fromUri(uri))
                prepare()
                seekTo(media.lastPlayedPosition)
                playWhenReady = true
            }
    }

    // Function to apply 0-200% volume
    fun setVolumeLevel(targetPercent: Int) {
        val clamped = targetPercent.coerceIn(0, 200)
        volumePercent = clamped
        isMuted = clamped == 0
        showVolumeOverlay = true

        if (clamped <= 100) {
            exoPlayer.volume = clamped / 100f
            try {
                loudnessEnhancer?.setTargetGain(0)
            } catch (_: Throwable) {}
        } else {
            exoPlayer.volume = 1.0f
            val boostGainMb = ((clamped - 100) / 100f * 1200).toInt()
            try {
                if (loudnessEnhancer == null && exoPlayer.audioSessionId != 0) {
                    loudnessEnhancer = LoudnessEnhancer(exoPlayer.audioSessionId).apply {
                        enabled = true
                    }
                }
                loudnessEnhancer?.setTargetGain(boostGainMb)
            } catch (_: Throwable) {}
        }
    }

    // Initialize LoudnessEnhancer for 200% Volume Boost safely
    LaunchedEffect(exoPlayer.audioSessionId) {
        try {
            if (exoPlayer.audioSessionId != 0) {
                loudnessEnhancer = LoudnessEnhancer(exoPlayer.audioSessionId).apply {
                    enabled = true
                }
            }
        } catch (_: Throwable) {}
    }

    // Dynamic video switching when media changes
    LaunchedEffect(media.id) {
        try {
            val uri = Uri.parse(media.url)
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
            if (media.lastPlayedPosition > 0L) {
                exoPlayer.seekTo(media.lastPlayedPosition)
            }
            exoPlayer.playWhenReady = true
            triggerPill("Now Playing: ${media.title}", Icons.Rounded.PlayArrow)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    // Player Listeners
    DisposableEffect(Unit) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    duration = exoPlayer.duration.coerceAtLeast(0L)
                }
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                triggerPill("Playback: ${error.errorCodeName}", Icons.Rounded.ErrorOutline)
            }

            override fun onTracksChanged(tracks: Tracks) {
                audioTracks.clear()
                subtitleTracks.clear()
                for (group in tracks.groups) {
                    if (group.type == C.TRACK_TYPE_AUDIO) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val name = format.label ?: format.language?.uppercase() ?: "Audio Track ${audioTracks.size + 1}"
                            audioTracks.add(name)
                        }
                    } else if (group.type == C.TRACK_TYPE_TEXT) {
                        for (i in 0 until group.length) {
                            val format = group.getTrackFormat(i)
                            val name = format.label ?: format.language?.uppercase() ?: "Subtitle Track ${subtitleTracks.size + 1}"
                            subtitleTracks.add(name)
                        }
                    }
                }
            }
        }
        exoPlayer.addListener(listener)

        onDispose {
            exoPlayer.removeListener(listener)
            try {
                loudnessEnhancer?.enabled = false
                loudnessEnhancer?.release()
                loudnessEnhancer = null
            } catch (_: Throwable) {}
            // Reset screen brightness and orientation
            activity?.window?.attributes = activity?.window?.attributes?.apply {
                screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
            }
            activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            try {
                exoPlayer.clearVideoSurface()
                exoPlayer.stop()
            } catch (_: Throwable) {}
            exoPlayer.release()
        }
    }

    // Periodic time tracking
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            currentPosition = exoPlayer.currentPosition
            delay(500)
        }
    }

    // Auto-hide controls
    LaunchedEffect(isControlsVisible) {
        if (isControlsVisible && !isTouchLocked && isPlaying) {
            delay(4000)
            isControlsVisible = false
        }
    }

    // Auto-hide overlays
    LaunchedEffect(showBrightnessOverlay) {
        if (showBrightnessOverlay) {
            delay(1500)
            showBrightnessOverlay = false
        }
    }

    LaunchedEffect(showVolumeOverlay) {
        if (showVolumeOverlay) {
            delay(1500)
            showVolumeOverlay = false
        }
    }

    LaunchedEffect(showSeekOverlay) {
        if (showSeekOverlay) {
            delay(1200)
            showSeekOverlay = false
        }
    }

    LaunchedEffect(doubleTapBadgeType) {
        if (doubleTapBadgeType != 0) {
            delay(750)
            doubleTapBadgeType = 0
        }
    }

    LaunchedEffect(showPill) {
        if (showPill) {
            delay(2200)
            showPill = false
        }
    }

    // Sleep Timer countdown
    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            var remaining = sleepTimerMinutes
            while (remaining > 0) {
                delay(60_000)
                remaining--
                sleepTimerMinutes = remaining
            }
            exoPlayer.pause()
            triggerPill("Sleep Timer: Video Paused ⏱️", Icons.Rounded.Timer)
        }
    }

    // Aspect Ratio mode cycling
    fun cycleAspectRatio() {
        resizeMode = when (resizeMode) {
            AspectRatioFrameLayout.RESIZE_MODE_FIT -> {
                triggerPill("Aspect: Zoom (Crop to Fill)", Icons.Rounded.AspectRatio)
                AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            }
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> {
                triggerPill("Aspect: Stretch (Full Screen)", Icons.Rounded.AspectRatio)
                AspectRatioFrameLayout.RESIZE_MODE_FILL
            }
            AspectRatioFrameLayout.RESIZE_MODE_FILL -> {
                triggerPill("Aspect: 16:9 Widescreen", Icons.Rounded.AspectRatio)
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
            }
            AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH -> {
                triggerPill("Aspect: 4:3 Standard", Icons.Rounded.AspectRatio)
                AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
            }
            else -> {
                triggerPill("Aspect: Fit to Screen", Icons.Rounded.AspectRatio)
                AspectRatioFrameLayout.RESIZE_MODE_FIT
            }
        }
    }

    val aspectRatioLabel = when (resizeMode) {
        AspectRatioFrameLayout.RESIZE_MODE_FIT -> "Fit"
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "Zoom"
        AspectRatioFrameLayout.RESIZE_MODE_FILL -> "Stretch"
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH -> "16:9"
        AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT -> "4:3"
        else -> "Fit"
    }

    // Repeat mode cycling
    fun cycleRepeatMode() {
        repeatMode = when (repeatMode) {
            Player.REPEAT_MODE_OFF -> {
                exoPlayer.repeatMode = Player.REPEAT_MODE_ONE
                triggerPill("Repeat: Loop One Video", Icons.Rounded.RepeatOne)
                Player.REPEAT_MODE_ONE
            }
            Player.REPEAT_MODE_ONE -> {
                exoPlayer.repeatMode = Player.REPEAT_MODE_ALL
                triggerPill("Repeat: Loop All", Icons.Rounded.Repeat)
                Player.REPEAT_MODE_ALL
            }
            else -> {
                exoPlayer.repeatMode = Player.REPEAT_MODE_OFF
                triggerPill("Repeat: Off", Icons.Rounded.Repeat)
                Player.REPEAT_MODE_OFF
            }
        }
    }

    val repeatModeLabel = when (repeatMode) {
        Player.REPEAT_MODE_ONE -> "One"
        Player.REPEAT_MODE_ALL -> "All"
        else -> "Off"
    }

    // Orientation toggle
    fun toggleOrientation() {
        orientationMode = (orientationMode + 1) % 3
        when (orientationMode) {
            0 -> {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                triggerPill("Orientation: Auto Sensor", Icons.Rounded.ScreenRotation)
            }
            1 -> {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                triggerPill("Orientation: Landscape", Icons.Rounded.ScreenLockLandscape)
            }
            2 -> {
                activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                triggerPill("Orientation: Portrait", Icons.Rounded.ScreenLockPortrait)
            }
        }
    }

    val orientationLabel = when (orientationMode) {
        1 -> "Landscape"
        2 -> "Portrait"
        else -> "Auto"
    }

    // Audio Track selector
    fun selectAudioTrack(index: Int) {
        selectedAudioTrackIndex = index
        val tracks = exoPlayer.currentTracks
        var count = 0
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    if (count == index) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setOverrideForType(override)
                            .build()
                        triggerPill("Audio: ${audioTracks.getOrNull(index) ?: "Selected"}", Icons.Rounded.Audiotrack)
                        return
                    }
                    count++
                }
            }
        }
    }

    // Subtitle Track selector
    fun selectSubtitleTrack(index: Int) {
        selectedSubtitleIndex = index
        subtitlesEnabled = true
        val tracks = exoPlayer.currentTracks
        var count = 0
        for (group in tracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    if (count == index) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                            .setOverrideForType(override)
                            .build()
                        triggerPill("Subtitles: ${subtitleTracks.getOrNull(index) ?: "Enabled"}", Icons.Rounded.ClosedCaption)
                        return
                    }
                    count++
                }
            }
        }
    }

    fun toggleSubtitles(enable: Boolean) {
        subtitlesEnabled = enable
        exoPlayer.trackSelectionParameters = exoPlayer.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !enable)
            .build()
        triggerPill(if (enable) "Subtitles: ON" else "Subtitles: OFF", Icons.Rounded.ClosedCaption)
    }

    // Gesture Tracking variables
    var gestureMode by remember { mutableIntStateOf(0) } // 0: None, 1: Brightness, 2: Volume, 3: Seek
    var accumulatedDragX by remember { mutableFloatStateOf(0f) }
    var accumulatedDragY by remember { mutableFloatStateOf(0f) }
    var dragStartSeekPos by remember { mutableLongStateOf(0L) }
    var dragSeekDeltaMs by remember { mutableLongStateOf(0L) }
    var dragIsLeftZone by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            // Tap Gestures (Single tap for HUD toggle, Double tap left/right/center)
            .pointerInput(isTouchLocked) {
                if (isTouchLocked) {
                    detectTapGestures(onTap = { showUnlockHint = true })
                } else {
                    detectTapGestures(
                        onTap = {
                            isControlsVisible = !isControlsVisible
                        },
                        onDoubleTap = { offset ->
                            val width = size.width.toFloat()
                            if (offset.x < width * 0.35f) {
                                // Double tap Left: Rewind 10s
                                val target = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                                exoPlayer.seekTo(target)
                                currentPosition = target
                                doubleTapBadgeType = 1
                            } else if (offset.x > width * 0.65f) {
                                // Double tap Right: Forward 10s
                                val target = (exoPlayer.currentPosition + 10000L).coerceAtMost(duration)
                                exoPlayer.seekTo(target)
                                currentPosition = target
                                doubleTapBadgeType = 2
                            } else {
                                // Double tap Center: Play / Pause
                                if (exoPlayer.isPlaying) {
                                    exoPlayer.pause()
                                    doubleTapBadgeType = 3
                                } else {
                                    exoPlayer.play()
                                    doubleTapBadgeType = 4
                                }
                            }
                        }
                    )
                }
            }
            // Drag Gestures (Left = Brightness, Right = Volume, Horizontal = Seek)
            .pointerInput(isTouchLocked) {
                if (!isTouchLocked) {
                    detectDragGestures(
                        onDragStart = { offset ->
                            dragIsLeftZone = offset.x < size.width * 0.5f
                            accumulatedDragX = 0f
                            accumulatedDragY = 0f
                            gestureMode = 0
                            dragStartSeekPos = exoPlayer.currentPosition
                            dragSeekDeltaMs = 0L
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val screenW = size.width.toFloat().coerceAtLeast(1f)
                            val screenH = size.height.toFloat().coerceAtLeast(1f)

                            if (gestureMode == 0) {
                                accumulatedDragX += dragAmount.x
                                accumulatedDragY += dragAmount.y
                                if (abs(accumulatedDragY) > 20f && abs(accumulatedDragY) > abs(accumulatedDragX) * 1.2f) {
                                    gestureMode = if (dragIsLeftZone) 1 else 2
                                } else if (abs(accumulatedDragX) > 20f && abs(accumulatedDragX) > abs(accumulatedDragY) * 1.2f) {
                                    gestureMode = 3
                                }
                            }

                            when (gestureMode) {
                                1 -> {
                                    // Left vertical swipe: Brightness
                                    val delta = -dragAmount.y / (screenH * 0.7f)
                                    val newFraction = (brightnessPercent / 100f + delta).coerceIn(0.01f, 1f)
                                    brightnessPercent = (newFraction * 100).toInt()
                                    applyBrightness(newFraction)
                                    showBrightnessOverlay = true
                                }
                                2 -> {
                                    // Right vertical swipe: Volume (0-200%)
                                    val delta = (-dragAmount.y / (screenH * 0.7f) * 200).toInt()
                                    val newVol = (volumePercent + delta).coerceIn(0, 200)
                                    setVolumeLevel(newVol)
                                    showVolumeOverlay = true
                                }
                                3 -> {
                                    // Horizontal swipe: Fast Seek
                                    val deltaMs = (dragAmount.x / (screenW * 0.8f) * 60_000L).toLong()
                                    dragSeekDeltaMs += deltaMs
                                    seekDeltaSeconds = dragSeekDeltaMs / 1000
                                    seekTargetPosition = (dragStartSeekPos + dragSeekDeltaMs).coerceIn(0L, duration)
                                    showSeekOverlay = true
                                }
                            }
                        },
                        onDragEnd = {
                            if (gestureMode == 3) {
                                exoPlayer.seekTo(seekTargetPosition)
                                currentPosition = seekTargetPosition
                            }
                            gestureMode = 0
                        },
                        onDragCancel = {
                            gestureMode = 0
                        }
                    )
                }
            }
    ) {
        // Video Surface
        AndroidView(
            factory = { ctx ->
                try {
                    val view = android.view.LayoutInflater.from(ctx).inflate(
                        com.vidiopen.player.R.layout.layout_player_view,
                        null,
                        false
                    ) as PlayerView
                    view.apply {
                        player = exoPlayer
                        useController = false
                        this.resizeMode = resizeMode
                    }
                } catch (_: Throwable) {
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        this.resizeMode = resizeMode
                    }
                }
            },
            update = { playerView ->
                playerView.resizeMode = resizeMode
            },
            onRelease = { playerView ->
                playerView.player = null
            },
            modifier = Modifier.fillMaxSize()
        )

        // Kids Touch Lock Active Overlay
        if (isTouchLocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
            ) {
                // Floating Unlock Button
                IconButton(
                    onClick = {
                        isTouchLocked = false
                        isControlsVisible = true
                        showUnlockHint = false
                        triggerPill("Touch Unlocked 🔓", Icons.Rounded.LockOpen)
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .align(Alignment.TopStart)
                        .background(Color(0xFFFF2E93).copy(alpha = 0.88f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = "Unlock Screen",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Unlock Hint Popup
                if (showUnlockHint) {
                    Card(
                        modifier = Modifier.align(Alignment.Center),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.88f))
                    ) {
                        Column(
                            modifier = Modifier.padding(22.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Rounded.LockOpen, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Touch Lock Active", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Tap the pink lock icon on top left to unlock", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // HUD Overlays
        // Brightness HUD (Left)
        BrightnessOverlay(
            brightnessPercent = brightnessPercent,
            visible = showBrightnessOverlay,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 24.dp)
        )

        // Volume HUD (Right)
        VolumeOverlay(
            volumePercent = volumePercent,
            visible = showVolumeOverlay,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 24.dp)
        )

        // Horizontal Seek HUD (Center)
        HorizontalSeekOverlay(
            targetPositionMs = seekTargetPosition,
            durationMs = duration,
            deltaSeconds = seekDeltaSeconds,
            visible = showSeekOverlay,
            modifier = Modifier.align(Alignment.Center)
        )

        // Double-Tap Ripple Badges
        // Left (-10s)
        DoubleTapBadge(
            text = "-10s",
            icon = Icons.Rounded.FastRewind,
            visible = doubleTapBadgeType == 1,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 48.dp)
        )

        // Right (+10s)
        DoubleTapBadge(
            text = "+10s",
            icon = Icons.Rounded.FastForward,
            visible = doubleTapBadgeType == 2,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 48.dp)
        )

        // Center (Pause)
        DoubleTapBadge(
            text = "Pause",
            icon = Icons.Rounded.Pause,
            visible = doubleTapBadgeType == 3,
            modifier = Modifier.align(Alignment.Center)
        )

        // Center (Play)
        DoubleTapBadge(
            text = "Play",
            icon = Icons.Rounded.PlayArrow,
            visible = doubleTapBadgeType == 4,
            modifier = Modifier.align(Alignment.Center)
        )

        // Top Notification Pill
        ScreenPillNotification(
            message = pillMessage,
            icon = pillIcon,
            visible = showPill,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 56.dp)
        )

        // Main Controls HUD
        AnimatedVisibility(
            visible = isControlsVisible && !isTouchLocked,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.52f))
            ) {
                // Top Bar
                VideoPlayerTopBar(
                    title = media.title,
                    volumePercent = volumePercent,
                    subtitlesEnabled = subtitlesEnabled,
                    orientationLabel = orientationLabel,
                    onBack = { onClose(exoPlayer.currentPosition) },
                    onToggleBoost = {
                        val nextVol = if (volumePercent < 100) 100 else if (volumePercent < 150) 150 else if (volumePercent < 200) 200 else 50
                        setVolumeLevel(nextVol)
                    },
                    onLockScreen = {
                        isTouchLocked = true
                        isControlsVisible = false
                    },
                    onPip = {
                        viewModel.setFloatingMode(true)
                    },
                    onToggleOrientation = { toggleOrientation() },
                    onOpenAudioTracks = { showAudioTrackDialog = true },
                    onOpenSubtitles = { showSubtitlesDialog = true },
                    onOpenSettings = { showSettingsDialog = true },
                    onOpenVideoSwitcher = { showVideoSwitcherDialog = true },
                    modifier = Modifier.align(Alignment.TopCenter)
                )

                // Center Play/Seek Controls
                VideoPlayerCenterControls(
                    isPlaying = isPlaying,
                    onRewind10 = {
                        val target = (exoPlayer.currentPosition - 10000L).coerceAtLeast(0L)
                        exoPlayer.seekTo(target)
                        currentPosition = target
                    },
                    onPlayPause = {
                        if (exoPlayer.isPlaying) {
                            exoPlayer.pause()
                        } else {
                            exoPlayer.play()
                        }
                    },
                    onForward10 = {
                        val target = (exoPlayer.currentPosition + 10000L).coerceAtMost(duration)
                        exoPlayer.seekTo(target)
                        currentPosition = target
                    },
                    onPreviousVideo = {
                        viewModel.playPreviousVideo(media) { }
                    },
                    onNextVideo = {
                        viewModel.playNextVideo(media) { }
                    },
                    modifier = Modifier.align(Alignment.Center)
                )

                // Bottom Bar
                VideoPlayerBottomBar(
                    currentPositionMs = currentPosition,
                    durationMs = duration,
                    playbackSpeed = playbackSpeed,
                    aspectRatioLabel = aspectRatioLabel,
                    repeatModeLabel = repeatModeLabel,
                    sleepTimerMinutes = sleepTimerMinutes,
                    volumePercent = volumePercent,
                    isMuted = isMuted,
                    onSeek = { targetPos ->
                        currentPosition = targetPos
                        exoPlayer.seekTo(targetPos)
                    },
                    onOpenSpeed = { showSpeedDialog = true },
                    onCycleAspectRatio = { cycleAspectRatio() },
                    onCycleRepeatMode = { cycleRepeatMode() },
                    onOpenSleepTimer = { showSleepTimerDialog = true },
                    onSetVolume = { setVolumeLevel(it) },
                    onToggleMute = {
                        if (isMuted) {
                            setVolumeLevel(100)
                            triggerPill("Unmuted 🔊", Icons.Rounded.VolumeUp)
                        } else {
                            setVolumeLevel(0)
                            triggerPill("Muted 🔇", Icons.Rounded.VolumeOff)
                        }
                    },
                    onOpenVideoSwitcher = { showVideoSwitcherDialog = true },
                    modifier = Modifier.align(Alignment.BottomCenter)
                )
            }
        }

        // Dialogs
        if (showSpeedDialog) {
            PlaybackSpeedDialog(
                currentSpeed = playbackSpeed,
                onSelectSpeed = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = PlaybackParameters(newSpeed)
                    triggerPill("Playback Speed: ${newSpeed}x", Icons.Rounded.Speed)
                },
                onDismiss = { showSpeedDialog = false }
            )
        }

        if (showSleepTimerDialog) {
            SleepTimerDialog(
                currentMinutesRemaining = sleepTimerMinutes,
                onSetTimerMinutes = { minutes ->
                    sleepTimerMinutes = minutes
                    if (minutes > 0) {
                        triggerPill("Sleep Timer set: $minutes min ⏱️", Icons.Rounded.Timer)
                    } else {
                        triggerPill("Sleep Timer turned off", Icons.Rounded.Timer)
                    }
                },
                onDismiss = { showSleepTimerDialog = false }
            )
        }

        if (showAudioTrackDialog) {
            AudioTrackDialog(
                audioTracks = audioTracks,
                selectedTrackIndex = selectedAudioTrackIndex,
                onSelectTrack = { selectAudioTrack(it) },
                onDismiss = { showAudioTrackDialog = false }
            )
        }

        if (showSubtitlesDialog) {
            SubtitlesDialog(
                subtitleTracks = subtitleTracks,
                selectedSubtitleIndex = selectedSubtitleIndex,
                subtitlesEnabled = subtitlesEnabled,
                onToggleSubtitles = { toggleSubtitles(it) },
                onSelectSubtitleTrack = { selectSubtitleTrack(it) },
                onDismiss = { showSubtitlesDialog = false }
            )
        }

        if (showSettingsDialog) {
            VideoPlayerSettingsDialog(
                playbackSpeed = playbackSpeed,
                aspectRatioLabel = aspectRatioLabel,
                repeatModeLabel = repeatModeLabel,
                sleepTimerMinutes = sleepTimerMinutes,
                subtitlesEnabled = subtitlesEnabled,
                onOpenSpeed = { showSpeedDialog = true },
                onCycleAspectRatio = { cycleAspectRatio() },
                onCycleRepeatMode = { cycleRepeatMode() },
                onOpenSleepTimer = { showSleepTimerDialog = true },
                onOpenAudioTracks = { showAudioTrackDialog = true },
                onOpenSubtitles = { showSubtitlesDialog = true },
                onDismiss = { showSettingsDialog = false }
            )
        }

        if (showVideoSwitcherDialog) {
            val allVideos by viewModel.allMedia.collectAsState()
            VideoSwitcherModal(
                videos = allVideos.filter { it.category != "Music" },
                currentMediaId = media.id,
                onSelectVideo = { nextMedia ->
                    showVideoSwitcherDialog = false
                    viewModel.playMedia(nextMedia)
                },
                onPlayNext = {
                    showVideoSwitcherDialog = false
                    viewModel.playNextVideo(media) { }
                },
                onPlayPrevious = {
                    showVideoSwitcherDialog = false
                    viewModel.playPreviousVideo(media) { }
                },
                onDismiss = { showVideoSwitcherDialog = false }
            )
        }
    }
}

/**
 * Finds the Activity from Context safely
 */
private fun Context.findActivity(): Activity? {
    var ctx = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
