package com.vidiopen.player.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.isActive
import kotlin.math.*

data class MusicTheme(
    val id: String,
    val name: String,
    val accentColor: Color = Color(0xFF00F0FF),
    val primaryColor: Color = Color(0xFF00F0FF),
    val cardBackground: Color = Color(0xFF16192E),
    val glassBorderColor: Color = Color(0x22FFFFFF),
    val description: String = "Dynamic animated theme",
    val bgImageUri: String? = null
)

object MusicThemeRegistry {
    val BuiltInThemes = listOf(
        MusicTheme(
            id = "cosmic_nebula",
            name = "Cosmic Nebula",
            accentColor = Color(0xFF00F0FF),
            primaryColor = Color(0xFF9D00FF),
            cardBackground = Color(0xFF111428),
            glassBorderColor = Color(0x4400F0FF),
            description = "Swirling deep space galaxy with glowing stars and nebula clouds"
        ),
        MusicTheme(
            id = "cyberpunk_neon",
            name = "Cyberpunk Wave",
            accentColor = Color(0xFFFF007F),
            primaryColor = Color(0xFF00F5FF),
            cardBackground = Color(0xFF1E0A2A),
            glassBorderColor = Color(0x44FF007F),
            description = "3D synthwave neon grid horizon with pulsing retro sun and embers"
        ),
        MusicTheme(
            id = "emerald_aurora",
            name = "Aurora Borealis",
            accentColor = Color(0xFF00FFB2),
            primaryColor = Color(0xFF00E5FF),
            cardBackground = Color(0xFF0A201A),
            glassBorderColor = Color(0x4400FFB2),
            description = "Mystical arctic aurora curtains waving across celestial skies"
        ),
        MusicTheme(
            id = "vinyl_pulse",
            name = "Retro Vinyl Pulse",
            accentColor = Color(0xFFFF9100),
            primaryColor = Color(0xFFFFD600),
            cardBackground = Color(0xFF221105),
            glassBorderColor = Color(0x44FF9100),
            description = "Rotating turntable grooves with expanding sound ripples and golden motes"
        ),
        MusicTheme(
            id = "ocean_abyss",
            name = "Ocean Abyss",
            accentColor = Color(0xFF00E5FF),
            primaryColor = Color(0xFF0077B6),
            cardBackground = Color(0xFF06182C),
            glassBorderColor = Color(0x4400E5FF),
            description = "Bioluminescent underwater deep-sea abyss with ascending translucent bubbles"
        ),
        MusicTheme(
            id = "sunset_dream",
            name = "Sunset Dream",
            accentColor = Color(0xFFFF5376),
            primaryColor = Color(0xFFFF9E00),
            cardBackground = Color(0xFF2E0F33),
            glassBorderColor = Color(0x44FF5376),
            description = "Vibrant dusk twilight with glowing retro sun, rising bokeh and warm horizons"
        ),
        MusicTheme(
            id = "quantum_vortex",
            name = "Quantum Vortex",
            accentColor = Color(0xFFE040FB),
            primaryColor = Color(0xFF7C4DFF),
            cardBackground = Color(0xFF18052B),
            glassBorderColor = Color(0x44E040FB),
            description = "Tilted 3D orbital rings with sparkling plasma particles and vortex energy"
        ),
        MusicTheme(
            id = "digital_matrix",
            name = "Digital Matrix",
            accentColor = Color(0xFF00FF66),
            primaryColor = Color(0xFF00E5FF),
            cardBackground = Color(0xFF02170B),
            glassBorderColor = Color(0x4400FF66),
            description = "High-tech green matrix digital rain streams with cyber pulses and scanlines"
        ),
        MusicTheme(
            id = "hyper_lumina",
            name = "Hyperdrive Lumina",
            accentColor = Color(0xFF00F0FF),
            primaryColor = Color(0xFF7000FF),
            cardBackground = Color(0xFF0D0324),
            glassBorderColor = Color(0x4400F0FF),
            description = "Hyperspace light-speed streaks with warp tunnel and neon stars"
        ),
        MusicTheme(
            id = "fire_phoenix",
            name = "Inferno Phoenix",
            accentColor = Color(0xFFFF3D00),
            primaryColor = Color(0xFFFF9100),
            cardBackground = Color(0xFF240700),
            glassBorderColor = Color(0x44FF3D00),
            description = "Blazing phoenix flame embers and swirling fire waves with pulsating core"
        ),
        MusicTheme(
            id = "custom_image",
            name = "Custom Wallpaper",
            accentColor = Color(0xFF00F0FF),
            primaryColor = Color(0xFF00F0FF),
            cardBackground = Color(0xCC131728),
            glassBorderColor = Color(0x33FFFFFF),
            description = "Custom personal photo wallpaper from device gallery"
        )
    )

    fun getThemeById(id: String): MusicTheme {
        val normalizedId = when (id) {
            "moonlight_night" -> "cosmic_nebula"
            "sunset_gold" -> "sunset_dream"
            "royal_amethyst" -> "quantum_vortex"
            else -> id
        }
        return BuiltInThemes.find { it.id == normalizedId } ?: BuiltInThemes.first()
    }
}

/**
 * 🌟 Dynamic, Attractive Animated Theme Visualizer for Music Player
 * Automatically animates at 60fps and reacts dynamically when music is playing!
 */
@Composable
fun AestheticThemeBackground(
    themeId: String,
    isPlaying: Boolean = false,
    modifier: Modifier = Modifier
) {
    val normalizedId = when (themeId) {
        "moonlight_night" -> "cosmic_nebula"
        "sunset_gold" -> "sunset_dream"
        "royal_amethyst" -> "quantum_vortex"
        else -> themeId
    }

    when (normalizedId) {
        "cyberpunk_neon" -> CyberpunkNeonThemeBackground(isPlaying, modifier)
        "emerald_aurora" -> AuroraBorealisThemeBackground(isPlaying, modifier)
        "vinyl_pulse" -> RetroVinylPulseThemeBackground(isPlaying, modifier)
        "ocean_abyss" -> OceanAbyssThemeBackground(isPlaying, modifier)
        "sunset_dream" -> SunsetDreamThemeBackground(isPlaying, modifier)
        "quantum_vortex" -> QuantumVortexThemeBackground(isPlaying, modifier)
        "digital_matrix" -> DigitalMatrixThemeBackground(isPlaying, modifier)
        "hyper_lumina" -> HyperdriveLuminaThemeBackground(isPlaying, modifier)
        "fire_phoenix" -> InfernoPhoenixThemeBackground(isPlaying, modifier)
        else -> CosmicNebulaThemeBackground(isPlaying, modifier) // Default & "cosmic_nebula"
    }
}

/**
 * Smooth 60fps progress that advances when [isPlaying] is true,
 * and completely freezes/pauses when [isPlaying] is false!
 */
@Composable
fun rememberThemeProgress(
    isPlaying: Boolean,
    durationMs: Int
): Float {
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(isPlaying, durationMs) {
        if (!isPlaying) return@LaunchedEffect
        var lastTime = withFrameNanos { it }
        val durationNanos = durationMs * 1_000_000L
        while (true) {
            withFrameNanos { now ->
                val dt = (now - lastTime).coerceAtLeast(0L)
                lastTime = now
                progress = (progress + dt.toFloat() / durationNanos) % 1f
            }
        }
    }
    return progress
}

/**
 * Smooth 60fps oscillation between [minVal] and [maxVal] that moves when [isPlaying] is true,
 * and completely freezes/returns to resting baseline when [isPlaying] is false!
 */
@Composable
fun rememberThemeOscillation(
    isPlaying: Boolean,
    durationMs: Int,
    minVal: Float = 0f,
    maxVal: Float = 1f
): Float {
    if (!isPlaying) return (minVal + maxVal) / 2f
    val progress = rememberThemeProgress(isPlaying = isPlaying, durationMs = durationMs)
    val sine = sin(progress * 2.0 * Math.PI).toFloat()
    val normalized = (sine + 1f) / 2f
    return minVal + normalized * (maxVal - minVal)
}

// ---------------------------------------------------------------------------
// 1. COSMIC NEBULA ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun CosmicNebulaThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val angle = rememberThemeProgress(isPlaying, 28000) * 360f
    val pulse = if (isPlaying) rememberThemeOscillation(isPlaying, 1800, 0.85f, 1.15f) else 1.0f
    val twinkle = if (isPlaying) rememberThemeOscillation(isPlaying, 2200, 0.25f, 1.0f) else 0.7f

    val stars = remember {
        val random = java.util.Random(101)
        List(50) {
            Triple(random.nextFloat(), random.nextFloat(), random.nextFloat() * 2.2f + 0.8f)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF080016), Color(0xFF02071C), Color(0xFF00030A))
                )
            )
    ) {
        val cx = size.width / 2f
        val cy = size.height * 0.44f
        val rad = angle * (PI / 180f).toFloat()

        // Swirling Purple Nebula
        val neb1X = cx + cos(rad) * (size.width * 0.22f)
        val neb1Y = cy + sin(rad) * (size.height * 0.12f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x66BD00FF), Color(0x228A2BE2), Color.Transparent),
                center = Offset(neb1X, neb1Y),
                radius = size.width * 0.65f * pulse
            ),
            radius = size.width * 0.65f * pulse,
            center = Offset(neb1X, neb1Y)
        )

        // Swirling Cyan Nebula
        val neb2X = cx - cos(rad) * (size.width * 0.20f)
        val neb2Y = cy - sin(rad) * (size.height * 0.10f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x5500F0FF), Color(0x180077B6), Color.Transparent),
                center = Offset(neb2X, neb2Y),
                radius = size.width * 0.55f * pulse
            ),
            radius = size.width * 0.55f * pulse,
            center = Offset(neb2X, neb2Y)
        )

        // Central Pulsar Aura (beats with song)
        if (isPlaying) {
            drawCircle(
                color = Color(0x2800F0FF),
                radius = size.width * 0.38f * pulse,
                center = Offset(cx, cy),
                style = Stroke(width = 2.5.dp.toPx())
            )
            drawCircle(
                color = Color(0x18BD00FF),
                radius = size.width * 0.52f * pulse,
                center = Offset(cx, cy),
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // Starfield
        stars.forEachIndexed { i, (sx, sy, sr) ->
            val starAlpha = if (isPlaying) ((twinkle + (i * 0.08f)) % 1f).coerceIn(0.2f, 1f) else 0.7f
            drawCircle(
                color = Color.White.copy(alpha = starAlpha),
                radius = sr.dp.toPx(),
                center = Offset(sx * size.width, sy * size.height)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 2. CYBERPUNK NEON WAVE ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun CyberpunkNeonThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val gridTravel = rememberThemeProgress(isPlaying, 1500)
    val glowPulse = if (isPlaying) rememberThemeOscillation(isPlaying, 1200, 0.8f, 1.25f) else 1.0f
    val emberTime = rememberThemeProgress(isPlaying, 4000)

    val emberSeeds = remember {
        val r = java.util.Random(202)
        List(24) { Pair(r.nextFloat(), r.nextFloat()) }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF150028), Color(0xFF090014), Color(0xFF020006))
                )
            )
    ) {
        val horizonY = size.height * 0.52f
        val cx = size.width / 2f

        // Retro Glowing Horizon Sun
        val sunRadius = size.width * 0.32f
        drawCircle(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFF007F), Color(0xFFFF8800)),
                startY = horizonY - sunRadius * 1.6f,
                endY = horizonY
            ),
            radius = sunRadius,
            center = Offset(cx, horizonY - sunRadius * 0.25f)
        )

        // Sun Horizontal Blinds
        for (i in 1..6) {
            val yOffset = horizonY - (i * 12.dp.toPx())
            drawLine(
                color = Color(0xFF090014),
                start = Offset(cx - sunRadius, yOffset),
                end = Offset(cx + sunRadius, yOffset),
                strokeWidth = (i * 1.5f).dp.toPx()
            )
        }

        // Glowing Horizon Line
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, Color(0xFFFF007F), Color(0xFF00F5FF), Color(0xFFFF007F), Color.Transparent)
            ),
            start = Offset(0f, horizonY),
            end = Offset(size.width, horizonY),
            strokeWidth = 3.dp.toPx()
        )

        // 3D Perspective Grid
        val gridHCount = 9
        for (i in 0 until gridHCount) {
            val progress = ((i + gridTravel) / gridHCount.toFloat()).coerceIn(0f, 1f)
            val y = horizonY + (progress * progress) * (size.height - horizonY)
            val alpha = (progress * glowPulse).coerceIn(0.15f, 0.85f)
            drawLine(
                color = Color(0xFF00F5FF).copy(alpha = alpha),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = (1f + progress * 2f).dp.toPx()
            )
        }

        // Radiating Perspective Lines
        val vLineCount = 11
        for (i in 0..vLineCount) {
            val bottomX = (i.toFloat() / vLineCount) * size.width
            drawLine(
                color = Color(0xFFFF007F).copy(alpha = 0.35f),
                start = Offset(cx, horizonY),
                end = Offset(bottomX, size.height),
                strokeWidth = 1.5.dp.toPx()
            )
        }

        // Rising Neon Embers
        emberSeeds.forEach { (ex, ey) ->
            val currY = ((ey - emberTime + 1f) % 1f) * size.height
            val currX = ex * size.width + sin(currY * 0.02f) * 16.dp.toPx()
            val color = if (ex > 0.5f) Color(0xFF00F5FF) else Color(0xFFFF007F)
            drawCircle(
                color = color.copy(alpha = 0.7f),
                radius = 2.dp.toPx(),
                center = Offset(currX, currY)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 3. AURORA BOREALIS ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun AuroraBorealisThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val phase1 = rememberThemeProgress(isPlaying, 6000) * (2 * PI.toFloat())
    val phase2 = rememberThemeProgress(isPlaying, 8500) * (2 * PI.toFloat())
    val shimmer = if (isPlaying) rememberThemeOscillation(isPlaying, 2400, 0.65f, 1.0f) else 0.8f

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF001217), Color(0xFF00090E), Color(0xFF000306))
                )
            )
    ) {
        val width = size.width
        val height = size.height

        // Aurora Wave 1: Emerald Shimmer
        val path1 = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, height * 0.28f)
            for (x in 0..width.toInt() step 20) {
                val fx = x.toFloat()
                val y = height * 0.32f +
                        sin(fx * 0.006f + phase1) * 65.dp.toPx() +
                        cos(fx * 0.003f + phase2) * 35.dp.toPx()
                lineTo(fx, y)
            }
            lineTo(width, 0f)
            close()
        }
        drawPath(
            path = path1,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF00FFB2).copy(alpha = 0.5f * shimmer), Color(0x3300FFB2), Color.Transparent),
                startY = 0f,
                endY = height * 0.45f
            )
        )

        // Aurora Wave 2: Arctic Turquoise
        val path2 = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, height * 0.36f)
            for (x in 0..width.toInt() step 20) {
                val fx = x.toFloat()
                val y = height * 0.40f +
                        cos(fx * 0.005f + phase2) * 55.dp.toPx() +
                        sin(fx * 0.004f + phase1) * 40.dp.toPx()
                lineTo(fx, y)
            }
            lineTo(width, 0f)
            close()
        }
        drawPath(
            path = path2,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.4f * shimmer), Color(0x2200E5FF), Color.Transparent),
                startY = height * 0.1f,
                endY = height * 0.55f
            )
        )

        // Aurora Wave 3: Deep Violet Twilight
        val path3 = Path().apply {
            moveTo(0f, 0f)
            lineTo(0f, height * 0.45f)
            for (x in 0..width.toInt() step 20) {
                val fx = x.toFloat()
                val y = height * 0.48f +
                        sin(fx * 0.004f + phase1 * 1.2f) * 45.dp.toPx()
                lineTo(fx, y)
            }
            lineTo(width, 0f)
            close()
        }
        drawPath(
            path = path3,
            brush = Brush.verticalGradient(
                colors = listOf(Color(0x448A2BE2), Color(0x158A2BE2), Color.Transparent),
                startY = height * 0.2f,
                endY = height * 0.65f
            )
        )

        // Soft Polar Glints
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x4400FFB2), Color.Transparent),
                center = Offset(width * 0.75f, height * 0.3f),
                radius = 140.dp.toPx()
            ),
            radius = 140.dp.toPx(),
            center = Offset(width * 0.75f, height * 0.3f)
        )
    }
}

// ---------------------------------------------------------------------------
// 4. RETRO VINYL PULSE ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun RetroVinylPulseThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val rotation = rememberThemeProgress(isPlaying, 5500) * 360f
    val ripple = rememberThemeProgress(isPlaying, 1800)
    val glow = if (isPlaying) rememberThemeOscillation(isPlaying, 2000, 0.8f, 1.2f) else 1.0f

    val dustMotes = remember {
        val r = java.util.Random(404)
        List(30) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat() * 1.5f + 1f) }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF1C0D03), Color(0xFF0E0501), Color(0xFF040200))
                )
            )
    ) {
        val cx = size.width / 2f
        val cy = size.height * 0.46f

        // Warm Golden Center Spotlight
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFF9100).copy(alpha = 0.22f * glow), Color(0x11FF6D00), Color.Transparent),
                center = Offset(cx, cy),
                radius = size.width * 0.6f
            ),
            radius = size.width * 0.6f,
            center = Offset(cx, cy)
        )

        // Pulsating Audio Acoustic Sound Rings (Soundwave ripples)
        val maxRipple = size.width * 0.72f
        for (i in 0..3) {
            val prog = (ripple + (i * 0.25f)) % 1f
            val r = prog * maxRipple
            val alpha = (1f - prog).coerceIn(0f, 0.6f) * (if (isPlaying) 1f else 0.2f)
            drawCircle(
                color = Color(0xFFFF9100).copy(alpha = alpha),
                radius = r,
                center = Offset(cx, cy),
                style = Stroke(width = (2.5f - prog * 1.5f).dp.toPx())
            )
        }

        // Rotating Vinyl Turntable Representation
        rotate(rotation, Offset(cx, cy)) {
            val vinylRadius = size.width * 0.42f
            drawCircle(
                color = Color(0xFF0D0B0A),
                radius = vinylRadius,
                center = Offset(cx, cy)
            )

            // Vinyl Grooves
            val grooveCount = 14
            for (g in 1..grooveCount) {
                val gr = (vinylRadius / grooveCount) * g
                drawCircle(
                    color = Color(0x22FFFFFF),
                    radius = gr,
                    center = Offset(cx, cy),
                    style = Stroke(width = 0.8.dp.toPx())
                )
            }

            // Stylized Vinyl Sheen Reflection (2 opposing arcs)
            drawLine(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x33FFFFFF), Color.Transparent),
                    center = Offset(cx, cy),
                    radius = vinylRadius
                ),
                start = Offset(cx - vinylRadius * 0.8f, cy - vinylRadius * 0.8f),
                end = Offset(cx + vinylRadius * 0.8f, cy + vinylRadius * 0.8f),
                strokeWidth = 24.dp.toPx()
            )

            // Golden Center Vinyl Label
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFFFD600), Color(0xFFFF9100), Color(0xFFB26A00)),
                    center = Offset(cx, cy),
                    radius = vinylRadius * 0.32f
                ),
                radius = vinylRadius * 0.32f,
                center = Offset(cx, cy)
            )
            // Center spindle
            drawCircle(
                color = Color(0xFF040200),
                radius = 8.dp.toPx(),
                center = Offset(cx, cy)
            )
        }

        // Warm Floating Golden Dust Motes
        dustMotes.forEach { (dx, dy, dr) ->
            val my = ((dy - ripple * 0.5f + 1f) % 1f) * size.height
            val mx = dx * size.width
            drawCircle(
                color = Color(0xFFFFD600).copy(alpha = 0.6f),
                radius = dr.dp.toPx(),
                center = Offset(mx, my)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 5. OCEAN ABYSS ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun OceanAbyssThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val bubbleTime = rememberThemeProgress(isPlaying, 3200)
    val rayPhase = rememberThemeProgress(isPlaying, 6000) * (2 * PI.toFloat())
    val bioGlow = if (isPlaying) rememberThemeOscillation(isPlaying, 2200, 0.6f, 1.0f) else 0.8f

    val bubbles = remember {
        val r = java.util.Random(505)
        List(26) {
            // (xRatio, ySeed, size, wobbleSpeed)
            listOf(r.nextFloat(), r.nextFloat(), r.nextFloat() * 7f + 3f, r.nextFloat() * 4f + 2f)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF00192F), Color(0xFF000E1C), Color(0xFF00050B))
                )
            )
    ) {
        val w = size.width
        val h = size.height

        // Downward Caustic Light Rays
        for (i in 0..4) {
            val rayX = (w * 0.2f * i) + sin(rayPhase + i) * 25.dp.toPx()
            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF00E5FF).copy(alpha = 0.22f * bioGlow), Color(0x100077B6), Color.Transparent),
                    startY = 0f,
                    endY = h * 0.75f
                ),
                start = Offset(rayX, 0f),
                end = Offset(rayX + 60.dp.toPx(), h * 0.75f),
                strokeWidth = (28 + i * 8).dp.toPx()
            )
        }

        // Bioluminescent Abyssal Glow Aura
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x3500E5FF), Color(0x120077B6), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.65f),
                radius = w * 0.65f
            ),
            radius = w * 0.65f,
            center = Offset(w * 0.5f, h * 0.65f)
        )

        // Ascending Translucent Bubbles with specular highlight
        bubbles.forEach { b ->
            val bx = b[0]
            val bySeed = b[1]
            val bSize = b[2]
            val bWobble = b[3]

            val currY = ((bySeed - bubbleTime + 1f) % 1f) * h
            val wobbleX = bx * w + sin(currY * 0.02f * bWobble) * 12.dp.toPx()
            val radiusPx = bSize.dp.toPx()

            // Bubble body (glassy translucent cyan)
            drawCircle(
                color = Color(0x2800E5FF),
                radius = radiusPx,
                center = Offset(wobbleX, currY)
            )
            drawCircle(
                color = Color(0x7700E5FF),
                radius = radiusPx,
                center = Offset(wobbleX, currY),
                style = Stroke(width = 1.2.dp.toPx())
            )
            // Specular glint
            drawCircle(
                color = Color.White.copy(alpha = 0.8f),
                radius = radiusPx * 0.28f,
                center = Offset(wobbleX - radiusPx * 0.35f, currY - radiusPx * 0.35f)
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 6. SUNSET DREAM ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun SunsetDreamThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val sunBeat = if (isPlaying) rememberThemeOscillation(isPlaying, 1200, 0.92f, 1.12f) else 1.0f
    val bokehTime = rememberThemeProgress(isPlaying, 3800)

    val bokehSeeds = remember {
        val r = java.util.Random(606)
        List(22) {
            // (x, y, radius, colorIdx)
            listOf(r.nextFloat(), r.nextFloat(), r.nextFloat() * 16f + 8f, r.nextInt(2).toFloat())
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF330C3E), Color(0xFF1E0628), Color(0xFF0D0114))
                )
            )
    ) {
        val cx = size.width / 2f
        val sunY = size.height * 0.40f
        val sunR = size.width * 0.32f * sunBeat

        // Giant Radiant Sunset Sun
        drawCircle(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFFF5376), Color(0xFFFF9E00), Color(0xFFFFD600)),
                startY = sunY - sunR,
                endY = sunY + sunR
            ),
            radius = sunR,
            center = Offset(cx, sunY)
        )

        // Sun Retro Horizontal Blinds
        val blindsCount = 6
        for (i in 1..blindsCount) {
            val by = sunY + (i * 10.dp.toPx())
            drawLine(
                color = Color(0xFF1E0628),
                start = Offset(cx - sunR, by),
                end = Offset(cx + sunR, by),
                strokeWidth = (i * 1.8f).dp.toPx()
            )
        }

        // Floating Bokeh Circles (Romantic Twilight Glow)
        bokehSeeds.forEach { b ->
            val bx = b[0] * size.width
            val bySeed = b[1]
            val br = b[2].dp.toPx()
            val colorType = b[3]

            val cy = ((bySeed - bokehTime + 1f) % 1f) * size.height
            val color = if (colorType == 0f) Color(0xFFFF5376) else Color(0xFFFF9E00)
            val alpha = (1f - (cy / size.height)).coerceIn(0.15f, 0.45f)

            drawCircle(
                color = color.copy(alpha = alpha),
                radius = br,
                center = Offset(bx, cy)
            )
        }

        // Horizon mountain silhouette
        val mPath = Path().apply {
            moveTo(0f, size.height)
            lineTo(0f, size.height * 0.78f)
            lineTo(size.width * 0.35f, size.height * 0.68f)
            lineTo(size.width * 0.65f, size.height * 0.74f)
            lineTo(size.width, size.height * 0.65f)
            lineTo(size.width, size.height)
            close()
        }
        drawPath(
            path = mPath,
            color = Color(0xFF0D0114).copy(alpha = 0.85f)
        )
    }
}

// ---------------------------------------------------------------------------
// 7. QUANTUM VORTEX ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun QuantumVortexThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val spin = rememberThemeProgress(isPlaying, 6500) * 360f
    val pulse = if (isPlaying) rememberThemeOscillation(isPlaying, 1600, 0.8f, 1.25f) else 1.0f

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF16002A), Color(0xFF0A0016), Color(0xFF030008))
                )
            )
    ) {
        val cx = size.width / 2f
        val cy = size.height * 0.45f

        // Central Quantum Plasma Core
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x99E040FB), Color(0x337C4DFF), Color.Transparent),
                center = Offset(cx, cy),
                radius = size.width * 0.45f * pulse
            ),
            radius = size.width * 0.45f * pulse,
            center = Offset(cx, cy)
        )

        // 3 Tilted Elliptical Orbital Rings
        val angles = listOf(spin, spin + 120f, spin + 240f)
        val colors = listOf(Color(0xFFE040FB), Color(0xFF7C4DFF), Color(0xFF00E5FF))

        angles.forEachIndexed { idx, ang ->
            val col = colors[idx]
            rotate(ang, Offset(cx, cy)) {
                // Outer ring
                drawOval(
                    color = col.copy(alpha = 0.55f),
                    topLeft = Offset(cx - size.width * 0.38f, cy - size.height * 0.16f),
                    size = Size(size.width * 0.76f, size.height * 0.32f),
                    style = Stroke(width = 2.dp.toPx())
                )

                // Quantum Node orbiting on the ring
                val nodeAngle = (ang * 2f * (PI / 180f)).toFloat()
                val nx = cx + cos(nodeAngle) * (size.width * 0.38f)
                val ny = cy + sin(nodeAngle) * (size.height * 0.16f)

                drawCircle(
                    color = Color.White,
                    radius = 4.dp.toPx(),
                    center = Offset(nx, ny)
                )
                drawCircle(
                    color = col,
                    radius = 9.dp.toPx(),
                    center = Offset(nx, ny)
                )
            }
        }

        // Concentric Shockwave Pulse (when playing)
        if (isPlaying) {
            val shockR = (pulse * size.width * 0.48f)
            drawCircle(
                color = Color(0x44E040FB),
                radius = shockR,
                center = Offset(cx, cy),
                style = Stroke(width = 2.dp.toPx())
            )
        }
    }
}

// ---------------------------------------------------------------------------
// 8. DIGITAL MATRIX ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun DigitalMatrixThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val rainTime = rememberThemeProgress(isPlaying, 1600)
    val glow = if (isPlaying) rememberThemeOscillation(isPlaying, 1400, 0.75f, 1.15f) else 0.9f

    val streams = remember {
        val r = java.util.Random(808)
        List(18) {
            // (xColRatio, yOffsetRatio, speed, lengthRatio)
            listOf(r.nextFloat(), r.nextFloat(), r.nextFloat() * 0.6f + 0.8f, r.nextFloat() * 0.22f + 0.15f)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF01180A), Color(0xFF000B04), Color(0xFF000401))
                )
            )
    ) {
        val w = size.width
        val h = size.height

        // Subtle Cyber Matrix Grid
        for (gx in 0..12) {
            val x = (gx.toFloat() / 12f) * w
            drawLine(
                color = Color(0x1200FF66),
                start = Offset(x, 0f),
                end = Offset(x, h),
                strokeWidth = 1.dp.toPx()
            )
        }

        // Falling Digital Matrix Streams
        streams.forEach { s ->
            val x = s[0] * w
            val ySeed = s[1]
            val speed = s[2]
            val streamLen = s[3] * h

            val headY = ((ySeed + rainTime * speed) % 1f) * (h + streamLen) - streamLen
            val tailY = headY - streamLen

            // Vertical fading matrix stream tail
            drawLine(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, Color(0xFF00FF66).copy(alpha = 0.4f * glow), Color(0xFF00FF66)),
                    startY = tailY,
                    endY = headY
                ),
                start = Offset(x, tailY),
                end = Offset(x, headY),
                strokeWidth = 2.5.dp.toPx()
            )

            // High-luminance leading head spark
            if (headY in 0f..h) {
                drawCircle(
                    color = Color(0xFFE5FFF0),
                    radius = 3.dp.toPx(),
                    center = Offset(x, headY)
                )
                drawCircle(
                    color = Color(0x8800FF66),
                    radius = 7.dp.toPx(),
                    center = Offset(x, headY)
                )
            }
        }

        // Ambient cyber pulse in the center
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF00FF66).copy(alpha = 0.18f * glow), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.48f),
                radius = w * 0.55f
            ),
            radius = w * 0.55f,
            center = Offset(w * 0.5f, h * 0.48f)
        )
    }
}

// ---------------------------------------------------------------------------
// 9. HYPERDRIVE LUMINA ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun HyperdriveLuminaThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val warpProgress = rememberThemeProgress(isPlaying, 1800)
    val corePulse = if (isPlaying) rememberThemeOscillation(isPlaying, 1300, 0.85f, 1.25f) else 1.0f

    val starStreaks = remember {
        val r = java.util.Random(909)
        List(40) {
            val angle = r.nextFloat() * 2f * PI.toFloat()
            val speed = r.nextFloat() * 0.6f + 0.7f
            val baseRadius = r.nextFloat()
            Triple(angle, speed, baseRadius)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF07001C), Color(0xFF03000E), Color(0xFF000412))
                )
            )
    ) {
        val cx = size.width / 2f
        val cy = size.height * 0.45f
        val maxDist = hypot(size.width, size.height) * 0.6f

        // Central Warp Core Glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x9900F0FF), Color(0x337000FF), Color.Transparent),
                center = Offset(cx, cy),
                radius = size.width * 0.42f * corePulse
            ),
            radius = size.width * 0.42f * corePulse,
            center = Offset(cx, cy)
        )

        // Concentric Warp Tunnel Rings
        val ringCount = 5
        for (i in 0 until ringCount) {
            val p = ((warpProgress + i.toFloat() / ringCount) % 1f)
            val ringRadius = (p * p) * maxDist
            val alpha = (p * (1f - p) * 3.5f * corePulse).coerceIn(0f, 0.65f)
            if (ringRadius > 10f) {
                drawCircle(
                    color = Color(0xFF00F0FF).copy(alpha = alpha),
                    radius = ringRadius,
                    center = Offset(cx, cy),
                    style = Stroke(width = (1f + p * 3f).dp.toPx())
                )
            }
        }

        // Hyperdrive Star Streaks
        starStreaks.forEach { (ang, spd, baseR) ->
            val p = ((baseR + warpProgress * spd) % 1f)
            val rStart = (p * p) * maxDist
            val streakLen = (p * 45f + 10f).dp.toPx()
            val rEnd = rStart + streakLen

            val x1 = cx + cos(ang) * rStart
            val y1 = cy + sin(ang) * rStart
            val x2 = cx + cos(ang) * rEnd
            val y2 = cy + sin(ang) * rEnd

            val alpha = (p * corePulse).coerceIn(0.2f, 0.95f)
            drawLine(
                brush = Brush.linearGradient(
                    colors = listOf(Color.Transparent, Color(0xFF00F0FF).copy(alpha = alpha), Color(0xFFE040FB)),
                    start = Offset(x1, y1),
                    end = Offset(x2, y2)
                ),
                start = Offset(x1, y1),
                end = Offset(x2, y2),
                strokeWidth = (1f + p * 2.5f).dp.toPx()
            )
        }

        // Core Pulsar Point
        drawCircle(
            color = Color.White,
            radius = 5.dp.toPx(),
            center = Offset(cx, cy)
        )
    }
}

// ---------------------------------------------------------------------------
// 10. INFERNO PHOENIX ANIMATION
// ---------------------------------------------------------------------------
@Composable
private fun InfernoPhoenixThemeBackground(isPlaying: Boolean, modifier: Modifier) {
    val emberProgress = rememberThemeProgress(isPlaying, 2400)
    val flameBeat = if (isPlaying) rememberThemeOscillation(isPlaying, 1100, 0.85f, 1.25f) else 1.0f

    val embers = remember {
        val r = java.util.Random(1010)
        List(32) {
            // (x, ySeed, size, wobbleSpeed)
            listOf(r.nextFloat(), r.nextFloat(), r.nextFloat() * 4f + 2f, r.nextFloat() * 3f + 1.5f)
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF280600), Color(0xFF140200), Color(0xFF0A0100))
                )
            )
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h * 0.48f

        // Giant Blazing Phoenix Sun Core
        val coreRadius = w * 0.40f * flameBeat
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFFFF3D00), Color(0xFFFF9100).copy(alpha = 0.5f), Color.Transparent),
                center = Offset(cx, cy),
                radius = coreRadius
            ),
            radius = coreRadius,
            center = Offset(cx, cy)
        )

        // Swirling Flame Wings (Arcs)
        for (i in 0..2) {
            val wingRadius = coreRadius * (0.7f + i * 0.28f)
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(Color(0xFFFF3D00), Color(0xFFFFD600), Color(0xFFFF0055), Color(0xFFFF3D00)),
                    center = Offset(cx, cy)
                ),
                radius = wingRadius,
                center = Offset(cx, cy),
                style = Stroke(width = 2.dp.toPx()),
                alpha = 0.45f * flameBeat
            )
        }

        // Rising Fire Embers
        embers.forEach { e ->
            val ex = e[0]
            val eySeed = e[1]
            val eSize = e[2]
            val eWobble = e[3]

            val currY = ((eySeed - emberProgress + 1f) % 1f) * h
            val wobbleX = ex * w + sin(currY * 0.015f * eWobble) * 14.dp.toPx()
            val alpha = (1f - (currY / h)).coerceIn(0.2f, 0.9f) * flameBeat

            drawCircle(
                color = if (ex > 0.5f) Color(0xFFFFD600).copy(alpha = alpha) else Color(0xFFFF3D00).copy(alpha = alpha),
                radius = eSize.dp.toPx(),
                center = Offset(wobbleX, currY)
            )
        }

        // Bottom Intense Inferno Glow
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color(0x66FF3D00), Color(0x99FF1744)),
                startY = h * 0.78f,
                endY = h
            ),
            topLeft = Offset(0f, h * 0.78f),
            size = Size(w, h * 0.22f)
        )
    }
}

