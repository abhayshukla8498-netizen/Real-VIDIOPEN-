package com.vidiopen.player.domain.usecase

import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.data.repository.MediaRepository
import kotlinx.coroutines.flow.Flow

class GetMediaUseCase(private val repository: MediaRepository) {
    operator fun invoke(): Flow<List<MediaEntity>> {
        return repository.allMedia
    }
}
