package com.vidiopen.player.utils

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import androidx.core.graphics.drawable.toDrawable
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.request.Options
import coil.size.Dimension
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Fast in-memory LRU cache for audio album artworks to ensure 60fps/120fps smooth scrolling.
 */
object AudioArtworkMemoryCache {
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = (maxMemory / 10).coerceIn(8 * 1024, 32 * 1024)

    val cache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, value: Bitmap): Int {
            return value.byteCount / 1024
        }
    }

    // Negative cache to avoid repeatedly querying files known to have no artwork (prevents JNI logcat lag)
    val noArtCache = object : LruCache<String, Boolean>(1000) {}

    fun clear() {
        cache.evictAll()
        noArtCache.evictAll()
    }
}

/**
 * Custom Coil Fetcher that extracts embedded album artwork from audio files (MP3, M4A, FLAC, WAV, AAC)
 * or loads thumbnails from MediaStore for audio content URIs.
 */
class AudioArtworkFetcher(
    private val context: Context,
    private val data: Uri,
    private val options: Options
) : Fetcher {

    override suspend fun fetch(): FetchResult? = withContext(Dispatchers.IO) {
        val cacheKey = data.toString()

        // 1. Instant Memory Cache Hit
        val cached = AudioArtworkMemoryCache.cache.get(cacheKey)
        if (cached != null && !cached.isRecycled) {
            return@withContext DrawableResult(
                drawable = cached.toDrawable(context.resources),
                isSampled = false,
                dataSource = DataSource.MEMORY
            )
        }

        // Fast skip if known to have no embedded artwork
        if (AudioArtworkMemoryCache.noArtCache.get(cacheKey) == true) {
            return@withContext null
        }

        // 2. Decode embedded picture or MediaStore thumbnail
        val bitmap: Bitmap? = try {
            val scheme = data.scheme
            val uriStr = data.toString()
            val pathStr = data.path ?: ""

            if (scheme == ContentResolver.SCHEME_CONTENT || uriStr.startsWith("content://")) {
                if (uriStr.contains("albumart")) {
                    try {
                        context.contentResolver.openInputStream(data)?.use { stream ->
                            BitmapFactory.decodeStream(stream)
                        }
                    } catch (_: Exception) {
                        null
                    }
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    // Only invoke loadThumbnail if it's not a raw audio URI without art
                    val widthPx = (options.size.width as? Dimension.Pixels)?.px ?: 240
                    val heightPx = (options.size.height as? Dimension.Pixels)?.px ?: 240
                    try {
                        // Check if path can be resolved first
                        var filePath: String? = null
                        try {
                            context.contentResolver.query(data, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { cursor ->
                                if (cursor.moveToFirst()) {
                                    filePath = cursor.getString(0)
                                }
                            }
                        } catch (_: Throwable) {}

                        if (filePath == null || EmbeddedPictureDetector.hasEmbeddedPicture(filePath)) {
                            context.contentResolver.loadThumbnail(
                                data,
                                Size(widthPx.coerceIn(80, 400), heightPx.coerceIn(80, 400)),
                                null
                            )
                        } else {
                            null
                        }
                    } catch (_: Exception) {
                        null
                    }
                } else {
                    null
                }
            } else if (scheme == ContentResolver.SCHEME_FILE || pathStr.startsWith("/")) {
                val filePath = if (scheme == ContentResolver.SCHEME_FILE) data.path else uriStr
                if (!filePath.isNullOrEmpty()) {
                    val file = File(filePath)
                    if (file.exists() && file.canRead()) {
                        extractEmbeddedArt(filePath)
                    } else null
                } else null
            } else null
        } catch (_: Exception) {
            null
        }

        if (bitmap != null) {
            AudioArtworkMemoryCache.cache.put(cacheKey, bitmap)
            DrawableResult(
                drawable = bitmap.toDrawable(context.resources),
                isSampled = true,
                dataSource = DataSource.DISK
            )
        } else {
            AudioArtworkMemoryCache.noArtCache.put(cacheKey, true)
            null
        }
    }

    private fun extractEmbeddedArt(filePath: String): Bitmap? {
        if (!EmbeddedPictureDetector.hasEmbeddedPicture(filePath)) {
            return null
        }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(filePath)
            val pictureBytes = retriever.embeddedPicture
            if (pictureBytes != null && pictureBytes.isNotEmpty()) {
                val opts = BitmapFactory.Options().apply {
                    inSampleSize = 2
                }
                BitmapFactory.decodeByteArray(pictureBytes, 0, pictureBytes.size, opts)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
    }

    class Factory(private val context: Context) : Fetcher.Factory<Uri> {
        override fun create(data: Uri, options: Options, imageLoader: ImageLoader): Fetcher? {
            val str = data.toString().lowercase()
            val path = (data.path ?: "").lowercase()
            val isAudio = str.contains("audio") ||
                    str.contains("albumart") ||
                    path.endsWith(".mp3") ||
                    path.endsWith(".m4a") ||
                    path.endsWith(".flac") ||
                    path.endsWith(".wav") ||
                    path.endsWith(".aac") ||
                    path.endsWith(".ogg") ||
                    path.endsWith(".opus")

            return if (isAudio) AudioArtworkFetcher(context, data, options) else null
        }
    }
}
