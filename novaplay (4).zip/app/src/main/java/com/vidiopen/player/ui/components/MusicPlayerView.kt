package com.vidiopen.player.ui.components

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.vidiopen.player.data.model.ScannedSong
import com.vidiopen.player.ui.theme.ElectricBlue
import com.vidiopen.player.ui.theme.LocalIsLightTheme
import com.vidiopen.player.ui.components.MusicTheme
import com.vidiopen.player.ui.components.MusicThemeRegistry
import com.vidiopen.player.ui.viewmodel.MediaViewModel
import com.vidiopen.player.ui.viewmodel.MusicViewModel
import kotlin.math.cos
import kotlin.math.sin

val TShirtIcon: ImageVector
    get() = Icons.Rounded.Style

@Composable
private fun PlayerFeatureItem(
    icon: ImageVector,
    title: String,
    description: String,
    isActive: Boolean = false,
    activeColor: Color = Color.White,
    badgeText: String? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
            .width(88.dp)
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(horizontal = 4.dp, vertical = 6.dp)
    ) {
        // Icon Container with glassmorphism + glow + active badge
        Box(
            modifier = Modifier.size(52.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        if (isActive) {
                            Brush.linearGradient(
                                listOf(
                                    activeColor.copy(alpha = 0.32f),
                                    activeColor.copy(alpha = 0.14f)
                                )
                            )
                        } else {
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF222230).copy(alpha = 0.90f),
                                    Color(0xFF13131D).copy(alpha = 0.90f)
                                )
                            )
                        }
                    )
                    .border(
                        width = if (isActive) 1.5.dp else 1.dp,
                        brush = if (isActive) {
                            Brush.verticalGradient(
                                listOf(
                                    activeColor,
                                    activeColor.copy(alpha = 0.40f)
                                )
                            )
                        } else {
                            Brush.verticalGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.16f),
                                    Color.White.copy(alpha = 0.05f)
                                )
                            )
                        },
                        shape = RoundedCornerShape(18.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isActive) activeColor else Color(0xFFE2E8F0),
                    modifier = Modifier.size(25.dp)
                )
            }

            // Small active indicator badge on top-right if enabled
            if (isActive || badgeText != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = 3.dp, y = (-3).dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(activeColor)
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = badgeText ?: "ON",
                        color = Color.Black,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(7.dp))

        // Feature Title (e.g. Vocal Remover, Themes, Equalizer)
        Text(
            text = title,
            color = if (isActive) Color.White else Color(0xFFF1F5F9),
            fontSize = 11.5.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Feature Description / Helper Tag (e.g. "Karaoke Mute", "Skins & Styles", "Auto Off Song")
        Text(
            text = description,
            color = if (isActive) activeColor.copy(alpha = 0.95f) else Color(0xFF94A3B8),
            fontSize = 9.sp,
            fontWeight = FontWeight.Normal,
            lineHeight = 11.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun MusicPlayerView(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    onCollapse: () -> Unit
) {
    val context = LocalContext.current
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val themeItem by musicViewModel.currentTheme.collectAsState()
    val theme = remember(themeItem) { MusicThemeRegistry.getThemeById(themeItem.id) }
    val customImageUri by musicViewModel.customThemeImageUri.collectAsState()
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()
    val repeatMode by musicViewModel.repeatMode.collectAsState()
    val shuffleEnabled by musicViewModel.shuffleModeEnabled.collectAsState()
    val favoriteSongIds by musicViewModel.favoriteSongIds.collectAsState()
    val playbackSpeed by musicViewModel.playbackSpeed.collectAsState()
    val songList by musicViewModel.songs.collectAsState()

    var showAudioSettings by remember { mutableStateOf(false) }
    var showEqualizerSettings by remember { mutableStateOf(false) }
    var initialAudioSettingsTab by remember { mutableStateOf("Audio Tuning") }
    var showSleepTimerDialog by remember { mutableStateOf(false) }
    var showQueueBottomSheet by remember { mutableStateOf(false) }
    var showLyricsOverlay by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showSongInfoDialog by remember { mutableStateOf(false) }
    var showRingtoneCutterDialog by remember { mutableStateOf(false) }
    var showEdgeLightingDialog by remember { mutableStateOf(false) }
    var showVocalRemoverDialog by remember { mutableStateOf(false) }
    var showShakeToChangeDialog by remember { mutableStateOf(false) }
    var showTagEditorDialog by remember { mutableStateOf(false) }

    val edgeLightingEnabled by musicViewModel.edgeLightingEnabled.collectAsState()
    val edgeLightingStyle by musicViewModel.edgeLightingStyle.collectAsState()
    val edgeLightingIntensity by musicViewModel.edgeLightingIntensity.collectAsState()
    val edgeLightingThickness by musicViewModel.edgeLightingThickness.collectAsState()
    val edgeLightingSpeed by musicViewModel.edgeLightingSpeed.collectAsState()
    val edgeLightingBeatPulse by musicViewModel.edgeLightingBeatPulse.collectAsState()
    val edgeLightingAlbumArtSync by musicViewModel.edgeLightingAlbumArtSync.collectAsState()
    val edgeLightingAnimationMode by musicViewModel.edgeLightingAnimationMode.collectAsState()

    val vocalRemoverEnabled by musicViewModel.vocalRemoverEnabled.collectAsState()
    val shakeToChangeEnabled by musicViewModel.shakeToChangeEnabled.collectAsState()

    val song = activeTrack ?: return

    val currentIndex = songList.indexOfFirst { it.id == song.id }
    val nextSong = if (currentIndex != -1 && currentIndex + 1 < songList.size) songList[currentIndex + 1] else if (songList.isNotEmpty()) songList.first() else null
    val nextSongTitle = nextSong?.title ?: "Queue end"
    val nextSongArtist = nextSong?.artist ?: "Vidiopen Pro"

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("expanded_music_player")
    ) {
        // Background - if custom photo theme is active, render user's photo background
        val isCustomImageTheme = theme.id == "custom_image"
        val effectiveUri = if (isCustomImageTheme) (theme.bgImageUri ?: customImageUri) else null
        if (isCustomImageTheme && !effectiveUri.isNullOrEmpty()) {
            val fileModel = remember(effectiveUri) {
                if (effectiveUri.startsWith("file://")) {
                    val path = Uri.parse(effectiveUri).path
                    if (path != null) java.io.File(path) else effectiveUri
                } else if (effectiveUri.startsWith("/")) {
                    java.io.File(effectiveUri)
                } else {
                    effectiveUri
                }
            }

            val scaleType = mediaViewModel?.customThemeScaleType?.collectAsState()?.value ?: "CROP"
            val zoom = mediaViewModel?.customThemeZoom?.collectAsState()?.value ?: 1.0f
            val opacity = mediaViewModel?.customThemeOpacity?.collectAsState()?.value ?: 0.55f
            val alignmentStr = mediaViewModel?.customThemeAlignment?.collectAsState()?.value ?: "CENTER"

            val contentScale = when (scaleType) {
                "FIT" -> ContentScale.Fit
                "FILL_BOUNDS" -> ContentScale.FillBounds
                "INSIDE" -> ContentScale.Inside
                else -> ContentScale.Crop
            }

            val contentAlignment = when (alignmentStr) {
                "TOP" -> Alignment.TopCenter
                "BOTTOM" -> Alignment.BottomCenter
                else -> Alignment.Center
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = fileModel,
                    contentDescription = "Custom theme background",
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = zoom.coerceIn(0.5f, 3.0f),
                            scaleY = zoom.coerceIn(0.5f, 3.0f)
                        ),
                    contentScale = contentScale,
                    alignment = contentAlignment
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = opacity.coerceIn(0.05f, 0.95f)))
                )
            }
        } else {
            AestheticThemeBackground(
                themeId = theme.id,
                isPlaying = isPlaying,
                modifier = Modifier.fillMaxSize()
            )
        }

        if (theme.id == "cyber_neon_feel") {
            CyberNeonPlayerContent(
                song = song,
                isPlaying = isPlaying,
                currentPosition = currentPosition,
                duration = duration,
                repeatMode = repeatMode,
                shuffleEnabled = shuffleEnabled,
                isFav = favoriteSongIds.contains(song.id),
                playbackSpeed = playbackSpeed,
                nextSongTitle = nextSongTitle,
                nextSongArtist = nextSongArtist,
                onCollapse = onCollapse,
                onTogglePlayPause = { musicViewModel.togglePlayPause() },
                onNext = { musicViewModel.next() },
                onPrevious = { musicViewModel.previous() },
                onSeek = { musicViewModel.seekTo(it) },
                onToggleFavorite = { musicViewModel.toggleFavorite(song.id) },
                onSetRepeatMode = { musicViewModel.setRepeatMode(it) },
                onOpenEqualizer = { showEqualizerSettings = true },
                onOpenSleepTimer = { showSleepTimerDialog = true },
                onOpenAudioSettings = { tab ->
                    initialAudioSettingsTab = tab
                    showAudioSettings = true
                },
                onOpenLyrics = { showLyricsOverlay = true },
                onOpenMoreMenu = { showMoreMenu = true },
                onOpenQueue = { showQueueBottomSheet = true }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(top = 16.dp, start = 24.dp, end = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Top Header Row (Back, Title & Artist, Share)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onCollapse) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            tint = Color.White,
                            contentDescription = "Back",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    Column(
                        modifier = Modifier.weight(1f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = song.title,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = song.artist ?: "<unknown>",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    IconButton(onClick = {
                        val sendIntent = android.content.Intent().apply {
                            action = android.content.Intent.ACTION_SEND
                            putExtra(android.content.Intent.EXTRA_TEXT, "Listening to: ${song.title} by ${song.artist ?: "Unknown"}")
                            type = "text/plain"
                        }
                        val shareIntent = android.content.Intent.createChooser(sendIntent, null)
                        context.startActivity(shareIntent)
                    }) {
                        Icon(
                            imageVector = Icons.Rounded.Share,
                            tint = Color.White,
                            contentDescription = "Share",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // 2. Central Rotating Disc & Circular Visualizer
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier.size(320.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularAudioVisualizer(
                            isPlaying = isPlaying,
                            modifier = Modifier.fillMaxSize()
                        )
                        
                        RotatingVinylDisc(
                            song = song,
                            isPlaying = isPlaying,
                            modifier = Modifier.size(242.dp)
                        )
                    }
                }

                // 3. Feature Action Buttons Row with Labels, Descriptions, and Spacious Glassmorphic Icons
                val isFav = favoriteSongIds.contains(song.id)
                val sleepTimerMode by musicViewModel.sleepTimerMode.collectAsState()
                val eqEnabled by musicViewModel.eqEnabled.collectAsState()

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. Vocal Remover (Karaoke)
                    PlayerFeatureItem(
                        icon = if (vocalRemoverEnabled) Icons.Rounded.MicExternalOn else Icons.Rounded.Mic,
                        title = "Vocal Remover",
                        description = if (vocalRemoverEnabled) "Karaoke Active" else "Karaoke Mute",
                        isActive = vocalRemoverEnabled,
                        activeColor = Color(0xFFFF4081),
                        badgeText = if (vocalRemoverEnabled) "ON" else null,
                        onClick = { showVocalRemoverDialog = true }
                    )

                    // 2. Edge Lighting (Neon Side Lights)
                    PlayerFeatureItem(
                        icon = Icons.Rounded.LightMode,
                        title = "Edge Light",
                        description = if (edgeLightingEnabled) "Glow Active" else "Neon Border",
                        isActive = edgeLightingEnabled,
                        activeColor = Color(0xFF00E5FF),
                        badgeText = if (edgeLightingEnabled) "ON" else null,
                        onClick = { showEdgeLightingDialog = true }
                    )

                    // 3. Studio Equalizer
                    PlayerFeatureItem(
                        icon = Icons.Rounded.Tune,
                        title = "Equalizer",
                        description = if (eqEnabled) "EQ Active" else "Bass & 3D Audio",
                        isActive = eqEnabled,
                        activeColor = Color(0xFF10B981),
                        badgeText = if (eqEnabled) "ON" else null,
                        onClick = { showEqualizerSettings = true }
                    )

                    // 4. Sleep Timer
                    PlayerFeatureItem(
                        icon = Icons.Rounded.Timer,
                        title = "Sleep Timer",
                        description = if (sleepTimerMode != null) "Timer Active" else "Auto Off Song",
                        isActive = sleepTimerMode != null,
                        activeColor = Color(0xFF818CF8),
                        badgeText = if (sleepTimerMode != null) "ON" else null,
                        onClick = { showSleepTimerDialog = true }
                    )

                    // 5. Themes
                    val isCustomTheme = theme.id != "default" && theme.id != "cosmic_nebula" && theme.id != "moonlight_night"
                    PlayerFeatureItem(
                        icon = TShirtIcon,
                        title = "Themes",
                        description = "Player Skins",
                        isActive = isCustomTheme,
                        activeColor = Color(0xFFA855F7),
                        badgeText = if (isCustomTheme) "ACTIVE" else null,
                        onClick = {
                            initialAudioSettingsTab = "Premium Themes"
                            showAudioSettings = true
                        }
                    )

                    // 6. Shake to Change Song
                    PlayerFeatureItem(
                        icon = Icons.Rounded.ScreenRotation,
                        title = "Shake Skip",
                        description = if (shakeToChangeEnabled) "Shake Active" else "Shake Phone",
                        isActive = shakeToChangeEnabled,
                        activeColor = Color(0xFFFF9800),
                        badgeText = if (shakeToChangeEnabled) "ON" else null,
                        onClick = { showShakeToChangeDialog = true }
                    )

                    // 7. Favorite
                    PlayerFeatureItem(
                        icon = if (isFav) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                        title = "Favorite",
                        description = if (isFav) "Liked Song" else "Save to Liked",
                        isActive = isFav,
                        activeColor = Color(0xFFFFD700),
                        badgeText = if (isFav) "SAVED" else null,
                        onClick = { musicViewModel.toggleFavorite(song.id) }
                    )

                    // 8. More Options
                    Box {
                        PlayerFeatureItem(
                            icon = Icons.Rounded.MoreVert,
                            title = "More Tools",
                            description = "Speed & Cutter",
                            isActive = false,
                            activeColor = Color.White,
                            onClick = { showMoreMenu = true }
                        )

                        val isLightMenu = LocalIsLightTheme.current
                        DropdownMenu(
                            expanded = showMoreMenu,
                            onDismissRequest = { showMoreMenu = false },
                            modifier = Modifier.background(if (isLightMenu) Color.White else Color(0xFF1E1E1E))
                        ) {
                            DropdownMenuItem(
                                text = { Text("🏷️ Edit Tags & Cover / नाम व पोस्टर बदलें", color = Color(0xFF00F0FF), fontWeight = FontWeight.Bold) },
                                onClick = {
                                    showMoreMenu = false
                                    showTagEditorDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("🎤 Vocal Remover: " + if (vocalRemoverEnabled) "ON (Karaoke)" else "OFF", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    showVocalRemoverDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("💡 Edge Lighting: " + if (edgeLightingEnabled) "ON" else "OFF", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    showEdgeLightingDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("📳 Shake to Change: " + if (shakeToChangeEnabled) "ON" else "OFF", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    showShakeToChangeDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Song Information", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    showSongInfoDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Shuffle: " + if (shuffleEnabled) "ON" else "OFF", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    musicViewModel.setShuffleMode(!shuffleEnabled)
                                    Toast.makeText(context, if (!shuffleEnabled) "Shuffle Enabled" else "Shuffle Disabled", Toast.LENGTH_SHORT).show()
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Speed: ${playbackSpeed}x", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    initialAudioSettingsTab = "Audio Tuning"
                                    showAudioSettings = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("✂️ Set as Ringtone", color = if (isLightMenu) Color.Black else Color.White) },
                                onClick = {
                                    showMoreMenu = false
                                    showRingtoneCutterDialog = true
                                }
                            )
                        }
                    }
                }

                // 4. Timeline Seek Slider
                val effectiveDuration = if (duration > 0) duration else if (song.duration > 0) song.duration else 0L
                val progress = if (effectiveDuration > 0) (currentPosition.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f) else 0f
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatMusicMillis(currentPosition),
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                    
                    Slider(
                        value = progress,
                        onValueChange = {
                            val targetMs = (it * effectiveDuration).toLong()
                            musicViewModel.seekTo(targetMs)
                        },
                        colors = SliderDefaults.colors(
                            thumbColor = Color.White,
                            activeTrackColor = Color.White,
                            inactiveTrackColor = Color.White.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 16.dp)
                    )
                    
                    Text(
                        text = formatMusicMillis(effectiveDuration),
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }

                // 5. Bottom Playback Controls (Repeat, Skip Previous, Play/Pause Circle, Skip Next, Queue)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val repeatIcon = when (repeatMode) {
                        1 -> Icons.Rounded.RepeatOne
                        else -> Icons.Rounded.Repeat
                    }
                    val repeatTint = if (repeatMode != 0) theme.accentColor else Color.White
                    
                    IconButton(onClick = {
                        val nextMode = (repeatMode + 1) % 3
                        musicViewModel.setRepeatMode(nextMode)
                        val modeLabel = when (nextMode) {
                            0 -> "Repeat Off"
                            1 -> "Repeat One"
                            else -> "Repeat All"
                        }
                        Toast.makeText(context, modeLabel, Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(
                            imageVector = repeatIcon,
                            tint = repeatTint,
                            contentDescription = "Repeat Mode",
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    
                    IconButton(onClick = { musicViewModel.previous() }) {
                        Icon(
                            imageVector = Icons.Rounded.SkipPrevious,
                            tint = Color.White,
                            contentDescription = "Previous",
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    
                    IconButton(
                        onClick = {
                            musicViewModel.togglePlayPause()
                        },
                        modifier = Modifier
                            .size(72.dp)
                            .background(Color.White, CircleShape)
                            .testTag("expanded_play_pause_btn")
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            tint = Color.Black,
                            contentDescription = "Play/Pause",
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    
                    IconButton(onClick = { musicViewModel.next() }) {
                        Icon(
                            imageVector = Icons.Rounded.SkipNext,
                            tint = Color.White,
                            contentDescription = "Next",
                            modifier = Modifier.size(36.dp)
                        )
                    }
                    
                    IconButton(onClick = { showQueueBottomSheet = true }) {
                        Icon(
                            imageVector = Icons.Rounded.PlaylistPlay,
                            tint = Color.White,
                            contentDescription = "Queue",
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                // 6. Bottom Lyrics Preview Panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                        .background(Color.White.copy(alpha = 0.08f))
                        .clickable { showLyricsOverlay = true }
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Lyrics preview",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        
                        Icon(
                            imageVector = Icons.Rounded.KeyboardArrowUp,
                            tint = Color.White,
                            contentDescription = "Expand Lyrics",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }

        // Full-screen audio settings sheet
        if (showAudioSettings) {
            AudioSettingsSheet(
                musicViewModel = musicViewModel,
                mediaViewModel = mediaViewModel,
                initialTab = initialAudioSettingsTab,
                onDismiss = { showAudioSettings = false }
            )
        }

        // Equalizer settings sheet
        if (showEqualizerSettings) {
            EqualizerSettingsSheet(
                musicViewModel = musicViewModel,
                onDismiss = { showEqualizerSettings = false },
                onExploreMore = {
                    showEqualizerSettings = false
                    initialAudioSettingsTab = "Audio Tuning"
                    showAudioSettings = true
                }
            )
        }

        // Sleep Timer Selection Dialog
        if (showSleepTimerDialog) {
            val sleepTimerMode by musicViewModel.sleepTimerMode.collectAsState()
            val sleepTimerRemaining by musicViewModel.sleepTimerRemaining.collectAsState()
            
            AlertDialog(
                onDismissRequest = { showSleepTimerDialog = false },
                title = { Text("Sleep Timer", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF1E1E24),
                text = {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    ) {
                        if (sleepTimerMode != null) {
                            Text(
                                text = "Active: $sleepTimerMode" + if (sleepTimerRemaining != null) " (${formatMusicMillis(sleepTimerRemaining!!)} remaining)" else "",
                                color = theme.accentColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }
                        
                        val timerOptions = listOf(
                            "Off" to null,
                            "5 Minutes" to 5,
                            "10 Minutes" to 10,
                            "15 Minutes" to 15,
                            "30 Minutes" to 30,
                            "45 Minutes" to 45,
                            "60 Minutes" to 60,
                            "End of Song" to -1
                        )
                        
                        timerOptions.forEach { (label, minutes) ->
                            TextButton(
                                onClick = {
                                    if (minutes == null) {
                                        musicViewModel.setSleepTimer(0)
                                        Toast.makeText(context, "Sleep Timer turned off", Toast.LENGTH_SHORT).show()
                                    } else if (minutes == -1) {
                                        musicViewModel.setSleepTimerEndOfSong()
                                        Toast.makeText(context, "Sleep Timer set to End of Song", Toast.LENGTH_SHORT).show()
                                    } else {
                                        musicViewModel.setSleepTimer(minutes)
                                        Toast.makeText(context, "Sleep Timer set for $minutes minutes", Toast.LENGTH_SHORT).show()
                                    }
                                    showSleepTimerDialog = false
                                },
                                modifier = Modifier.fillMaxWidth(),
                                contentPadding = PaddingValues(vertical = 12.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = if (label == "Off" && sleepTimerMode == null) theme.accentColor else Color.White,
                                    textAlign = TextAlign.Start,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSleepTimerDialog = false }) {
                        Text("Cancel", color = theme.accentColor)
                    }
                }
            )
        }

        // Song Info Dialog
        if (showSongInfoDialog) {
            AlertDialog(
                onDismissRequest = { showSongInfoDialog = false },
                title = { Text("Song Information", color = Color.White, fontWeight = FontWeight.Bold) },
                containerColor = Color(0xFF1A1A1E),
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        InfoRow("Title", song.title)
                        InfoRow("Artist", song.artist ?: "Unknown")
                        InfoRow("Album", song.album ?: "Unknown")
                        InfoRow("Duration", formatMusicMillis(song.duration))
                        InfoRow("File Size", String.format("%.2f MB", song.size / (1024f * 1024f)))
                        InfoRow("File Path", song.path)
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { showSongInfoDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = theme.primaryColor)
                    ) {
                        Text("Close", color = Color.White)
                    }
                }
            )
        }

        if (showRingtoneCutterDialog) {
            RingtoneCutterDialog(
                song = song,
                appLang = "en",
                onDismiss = { showRingtoneCutterDialog = false }
            )
        }

        // Edge Lighting Settings Dialog
        if (showEdgeLightingDialog) {
            EdgeLightingDialog(
                musicViewModel = musicViewModel,
                onDismiss = { showEdgeLightingDialog = false }
            )
        }

        // Vocal Remover (Karaoke) Settings Dialog
        if (showVocalRemoverDialog) {
            VocalRemoverDialog(
                musicViewModel = musicViewModel,
                onDismiss = { showVocalRemoverDialog = false }
            )
        }

        // Shake to Change Song Settings Dialog
        if (showShakeToChangeDialog) {
            ShakeToChangeDialog(
                musicViewModel = musicViewModel,
                onDismiss = { showShakeToChangeDialog = false }
            )
        }

        // ID3 Tag & Cover Photo Editor Dialog
        if (showTagEditorDialog) {
            TagEditorDialog(
                song = song,
                musicViewModel = musicViewModel,
                onDismiss = { showTagEditorDialog = false }
            )
        }

        // Beat-reactive Edge Lighting side screen effect
        if (edgeLightingEnabled) {
            EdgeLightingOverlay(
                isPlaying = isPlaying,
                style = edgeLightingStyle,
                animationMode = edgeLightingAnimationMode,
                intensity = edgeLightingIntensity,
                thickness = edgeLightingThickness,
                speed = edgeLightingSpeed,
                beatPulse = edgeLightingBeatPulse,
                albumArtSync = edgeLightingAlbumArtSync,
                song = song,
                cornerRadius = 24.dp
            )
        }

        // Full Screen Lyrics Overlay
        AnimatedVisibility(
            visible = showLyricsOverlay,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable(enabled = true, onClick = {})
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(24.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Lyrics",
                            color = Color.White,
                            fontWeight = FontWeight.Black,
                            fontSize = 22.sp
                        )
                        IconButton(
                            onClick = { showLyricsOverlay = false },
                            modifier = Modifier.background(Color.White.copy(alpha = 0.1f), CircleShape)
                        ) {
                            Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(song.title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                        Text(song.artist ?: "Unknown Artist", color = theme.accentColor, fontSize = 13.sp, textAlign = TextAlign.Center)
                    }

                    Spacer(modifier = Modifier.height(32.dp))

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 12.dp)
                        ) {
                            LyricLine("Deep beats echoing in the silence", active = false)
                            LyricLine("Streaming high-fidelity pure frequency", active = false)
                            LyricLine("We are floating in the acoustic sanctuary", active = true)
                            LyricLine("Offline tranquility wash away your worries", active = false)
                            LyricLine("Studio grade dynamic resonance", active = false)
                            LyricLine("Spinning clean on a physical drive", active = false)
                            LyricLine("Chasing notes until the sunrise breaks...", active = false)
                        }
                    }
                }
            }
        }

        // Queue list Bottom Drawer
        AnimatedVisibility(
            visible = showQueueBottomSheet,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
                    .clickable(enabled = true, onClick = {})
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Current Queue",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp
                            )
                            val qSize by musicViewModel.queue.collectAsState()
                            Text(
                                text = "${qSize.size} tracks loaded",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                        
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { musicViewModel.clearQueue() }) {
                                Text("Clear All", color = Color.Red, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            IconButton(
                                onClick = { showQueueBottomSheet = false },
                                modifier = Modifier.background(Color.White.copy(alpha = 0.1f), CircleShape)
                            ) {
                                Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(modifier = Modifier.weight(1f)) {
                        QueueTab(musicViewModel = musicViewModel, theme = theme)
                    }
                }
            }
        }
    }
}

@Composable
fun RotatingVinylDisc(
    song: ScannedSong,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val rotationAngle = rememberThemeProgress(isPlaying = isPlaying, durationMs = 10000) * 360f

    Box(
        modifier = modifier
            .shadow(24.dp, CircleShape, ambientColor = Color.White, spotColor = Color.White)
            .border(2.dp, Color.White.copy(alpha = 0.3f), CircleShape)
            .rotate(rotationAngle)
            .background(
                Brush.sweepGradient(
                    colors = listOf(Color.Black, Color.DarkGray, Color.Black, Color.DarkGray, Color.Black)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 2.3f, style = Stroke(1.5f))
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 3.0f, style = Stroke(1.5f))
            drawCircle(color = Color.White.copy(alpha = 0.08f), radius = size.minDimension / 4.0f, style = Stroke(1.5f))
        }

        SongArtworkThumbnail(
            song = song,
            size = 110.dp,
            shape = CircleShape,
            showPlayingAnimation = false
        )
    }
}

@Composable
fun CircularAudioVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val phase = rememberThemeProgress(isPlaying = isPlaying, durationMs = 1800) * 6.28318f

    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val baseRadius = size.width * 0.42f
        val barCount = 48

        for (i in 0 until barCount) {
            val angle = (i * 360f / barCount) * (Math.PI / 180f)
            val factor = if (isPlaying) (0.3f + 0.7f * kotlin.math.abs(sin(phase + i * 0.5f))) else 0.15f
            val barLen = 18.dp.toPx() * factor

            val startX = cx + baseRadius * cos(angle).toFloat()
            val startY = cy + baseRadius * sin(angle).toFloat()
            val endX = cx + (baseRadius + barLen) * cos(angle).toFloat()
            val endY = cy + (baseRadius + barLen) * sin(angle).toFloat()

            drawLine(
                color = Color.White.copy(alpha = 0.6f + factor * 0.4f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Column {
        Text(text = label, color = Color.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun QueueTab(musicViewModel: MusicViewModel, theme: MusicTheme) {
    val queueList by musicViewModel.queue.collectAsState()
    val activeTrack by musicViewModel.currentPlayingSong.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Playing Queue (${queueList.size} tracks)",
                color = Color.Gray,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            TextButton(
                onClick = { musicViewModel.clearQueue() },
                colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
            ) {
                Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Clear Queue", fontSize = 11.sp)
            }
        }
        Spacer(modifier = Modifier.height(12.dp))

        if (queueList.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("Queue is empty", color = Color.DarkGray, fontSize = 13.sp)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                itemsIndexed(queueList, key = { index, song -> "queue_${song.id}_$index" }) { index, song ->
                    val isActive = song.id == activeTrack?.id
                    val cardBg = if (isActive) theme.primaryColor.copy(alpha = 0.2f) else theme.cardBackground
                    val cardBorder = if (isActive) theme.accentColor else Color.Transparent

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(cardBg)
                            .border(1.dp, cardBorder, RoundedCornerShape(12.dp))
                            .clickable {
                                musicViewModel.playSong(song, queueList)
                            }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SongArtworkThumbnail(
                            song = song,
                            isPlaying = isActive,
                            size = 40.dp,
                            shape = RoundedCornerShape(8.dp),
                            showPlayingAnimation = true
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = song.title,
                                color = if (isActive) theme.accentColor else Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = song.artist ?: "Unknown Artist",
                                color = Color.Gray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        IconButton(onClick = { musicViewModel.removeFromQueue(index) }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = Color.DarkGray, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LyricLine(text: String, active: Boolean) {
    Text(
        text = text,
        color = if (active) ElectricBlue else Color.White.copy(alpha = 0.4f),
        fontWeight = if (active) FontWeight.Black else FontWeight.Normal,
        fontSize = if (active) 18.sp else 15.sp,
        textAlign = TextAlign.Center,
        style = androidx.compose.ui.text.TextStyle(
            shadow = if (active) Shadow(ElectricBlue, blurRadius = 8f) else null
        ),
        modifier = Modifier.fillMaxWidth()
    )
}

private fun formatMusicMillis(ms: Long): String {
    if (ms <= 0) return "00:00"
    val totalSecs = ms / 1000
    val minutes = totalSecs / 60
    val seconds = totalSecs % 60
    return String.format("%02d:%02d", minutes, seconds)
}

@Composable
fun AudioSettingsSheet(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    initialTab: String = "Audio Tuning",
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val currentThemeItem by musicViewModel.currentTheme.collectAsState()
    val currentTheme = remember(currentThemeItem) { MusicThemeRegistry.getThemeById(currentThemeItem.id) }
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val customThemeImageUri by musicViewModel.customThemeImageUri.collectAsState()
    var settingsTab by remember { mutableStateOf(initialTab) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val file = java.io.File(context.filesDir, "custom_theme_bg.jpg")
                    file.outputStream().use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                    val localUri = Uri.fromFile(file).toString()
                    com.vidiopen.player.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                        musicViewModel.setCustomThemeImage(localUri)
                        mediaViewModel?.setCustomBackgroundUri(localUri)
                        mediaViewModel?.setSelectedThemeId("custom_image")
                        Toast.makeText(context, "Custom theme applied successfully!", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(context, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
            .clickable(enabled = true, onClick = {})
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(20.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Audio Studio & Themes", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val tabs = listOf("Audio Tuning", "Premium Themes")
                tabs.forEach { tab ->
                    val isSelected = settingsTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) ElectricBlue else Color.White.copy(alpha = 0.08f))
                            .clickable { settingsTab = tab }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab,
                            color = if (isSelected) Color.Black else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (settingsTab == "Premium Themes") {
                // Theme Selection Tab
                Column(modifier = Modifier.fillMaxSize()) {
                    // Custom Photo Theme Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White.copy(alpha = 0.04f))
                            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(16.dp))
                            .clickable { launcher.launch("image/*") }
                            .padding(16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Set Custom Gallery Background", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Choose your favorite photo from phone storage", color = Color.Gray, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 👑 Featured Premium Theme Banner
                    // 👑 Active Premium Theme Live Showcase Banner
                    val activeThemeToFeature = currentTheme
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(Color(0xFF130A24), Color(0xFF09142A))
                                )
                            )
                            .border(
                                width = 2.dp,
                                brush = Brush.horizontalGradient(
                                    listOf(activeThemeToFeature.accentColor, activeThemeToFeature.primaryColor, ElectricBlue)
                                ),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                Brush.horizontalGradient(
                                                    listOf(activeThemeToFeature.accentColor, activeThemeToFeature.primaryColor)
                                                )
                                            )
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text("ACTIVE THEME 👑", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        activeThemeToFeature.name,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isPlaying) Color(0xFF10B981) else Color(0xFF475569))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        if (isPlaying) "Playing • Animated ⚡" else "Paused • Static ⏸",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .border(1.dp, activeThemeToFeature.accentColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                            ) {
                                AestheticThemeBackground(
                                    themeId = activeThemeToFeature.id,
                                    isPlaying = isPlaying,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.18f)),
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Text(
                                        "Themes animate with music & pause when music stops",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Soundscape Themes",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                    )

                    val allThemes = MusicThemeRegistry.BuiltInThemes
                    val themePairs = allThemes.chunked(2)

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(themePairs.size) { index ->
                            val pair = themePairs[index]
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                pair.forEach { theme ->
                                    val isCurrent = currentTheme.id == theme.id
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(Color.White.copy(alpha = 0.02f))
                                            .border(
                                                width = if (isCurrent) 2.dp else 1.dp,
                                                color = if (isCurrent) theme.accentColor else Color.White.copy(alpha = 0.08f),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                com.vidiopen.player.utils.StartAppInterstitialHelper.showMultipleAds(context, 2) {
                                                    musicViewModel.selectTheme(theme.id)
                                                    Toast.makeText(context, "Theme Applied: ${theme.name}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                            .padding(12.dp)
                                    ) {
                                        Column {
                                            // Mini visual preview card with active playback state
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(92.dp)
                                                    .clip(RoundedCornerShape(10.dp))
                                                    .border(1.dp, theme.glassBorderColor, RoundedCornerShape(10.dp))
                                            ) {
                                                AestheticThemeBackground(
                                                    themeId = theme.id,
                                                    isPlaying = isPlaying,
                                                    modifier = Modifier.fillMaxSize()
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        text = theme.name,
                                                        color = Color.White,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                    Text(
                                                        text = theme.description,
                                                        color = Color.LightGray.copy(alpha = 0.7f),
                                                        fontSize = 10.sp,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                                if (isCurrent) {
                                                    Box(
                                                        modifier = Modifier
                                                            .clip(RoundedCornerShape(6.dp))
                                                            .background(ElectricBlue)
                                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                                    ) {
                                                        Text("Active", color = Color.Black, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (pair.count() == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            } else {
                // Audio Tuning Panel
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.TopCenter
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        LuxurySettingsCard(title = "10-Band Equalizer", icon = Icons.Rounded.Equalizer, theme = currentTheme) {
                            Text("10-Band Precision Equalizer Active", color = Color.White, fontSize = 13.sp)
                        }

                        LuxurySettingsCard(title = "Studio Enhancements", icon = Icons.Rounded.SettingsVoice, theme = currentTheme) {
                            Text("Bass Boost & Virtualizer 3D Sound", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LuxurySettingsCard(
    title: String,
    icon: ImageVector,
    theme: MusicTheme,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, theme.glassBorderColor, RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, contentDescription = null, tint = theme.accentColor, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.height(14.dp))
            content()
        }
    }
}

@Composable
fun VerticalEqualizerSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = -15f..15f,
    enabled: Boolean = true
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxHeight()
            .width(42.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectTapGestures { offset ->
                    val pct = (1f - (offset.y / size.height.toFloat())).coerceIn(0f, 1f)
                    val newVal = range.start + pct * (range.endInclusive - range.start)
                    onValueChange(newVal)
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                detectDragGestures(
                    onDragStart = { offset ->
                        val pct = (1f - (offset.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val newVal = range.start + pct * (range.endInclusive - range.start)
                        onValueChange(newVal)
                    },
                    onDrag = { change, _ ->
                        val pct = (1f - (change.position.y / size.height.toFloat())).coerceIn(0f, 1f)
                        val newVal = range.start + pct * (range.endInclusive - range.start)
                        onValueChange(newVal)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        val percent = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)

        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val trackWidth = 3.dp.toPx()
            val thumbRadius = 7.dp.toPx()
            val thumbYPx = size.height * (1f - percent)
            
            drawLine(
                color = Color.White.copy(alpha = 0.15f),
                start = Offset(cx, 0f),
                end = Offset(cx, thumbYPx),
                strokeWidth = trackWidth,
                cap = StrokeCap.Round
            )

            drawLine(
                color = if (enabled) Color(0xFF2ECC71) else Color.Gray.copy(alpha = 0.5f),
                start = Offset(cx, thumbYPx),
                end = Offset(cx, size.height),
                strokeWidth = trackWidth,
                cap = StrokeCap.Round
            )

            drawCircle(
                color = if (enabled) Color.White else Color.Gray,
                radius = thumbRadius,
                center = Offset(cx, thumbYPx)
            )
        }
    }
}

@Composable
fun MusicExpandedPlayer(
    musicViewModel: MusicViewModel,
    mediaViewModel: MediaViewModel? = null,
    onCollapse: () -> Unit
) {
    MusicPlayerView(
        musicViewModel = musicViewModel,
        mediaViewModel = mediaViewModel,
        onCollapse = onCollapse
    )
}

@Composable
fun MusicMiniPlayer(
    musicViewModel: MusicViewModel,
    onExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val song by musicViewModel.currentPlayingSong.collectAsState()
    val isPlaying by musicViewModel.isPlaying.collectAsState()
    val theme by musicViewModel.currentTheme.collectAsState()
    val resolvedTheme = remember(theme) { MusicThemeRegistry.getThemeById(theme.id) }
    val currentPosition by musicViewModel.currentPosition.collectAsState()
    val duration by musicViewModel.duration.collectAsState()

    val activeSong = song ?: return
    val effectiveDuration = if (duration > 0) duration else if (activeSong.duration > 0) activeSong.duration else 1L
    val progress = (currentPosition.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f)

    Box(
        modifier = modifier
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF1E1E24).copy(alpha = 0.95f))
            .border(1.dp, resolvedTheme.glassBorderColor, RoundedCornerShape(16.dp))
            .clickable { onExpand() }
            .padding(8.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                SongArtworkThumbnail(
                    song = activeSong,
                    isPlaying = isPlaying,
                    size = 44.dp,
                    shape = RoundedCornerShape(10.dp),
                    showPlayingAnimation = false
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = activeSong.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = activeSong.artist ?: "Unknown Artist",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { musicViewModel.togglePlayPause() },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        tint = Color.White,
                        contentDescription = "Play/Pause",
                        modifier = Modifier.size(26.dp)
                    )
                }

                IconButton(
                    onClick = { musicViewModel.next() },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        tint = Color.White,
                        contentDescription = "Next",
                        modifier = Modifier.size(26.dp)
                    )
                }

                IconButton(
                    onClick = { musicViewModel.closePlayer() },
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("mini_player_close_btn")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        tint = Color.White.copy(alpha = 0.85f),
                        contentDescription = "Close Player",
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .fillMaxWidth(progress)
                        .background(resolvedTheme.accentColor)
                )
            }
        }
    }
}

@Composable
fun EqualizerSettingsSheet(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit,
    onExploreMore: () -> Unit
) {
    val eqEnabled by musicViewModel.eqEnabled.collectAsState()
    val selectedPreset by musicViewModel.selectedPreset.collectAsState()
    val eqBands by musicViewModel.eqBands.collectAsState()

    val bassBoostStrength by musicViewModel.bassBoostStrength.collectAsState()
    val virtualizerStrength by musicViewModel.virtualizerStrength.collectAsState()
    val reverbPreset by musicViewModel.reverbPreset.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(enabled = true, onClick = onDismiss)
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color(0xFF121212))
                .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .clickable(enabled = true, onClick = {})
                .padding(vertical = 20.dp, horizontal = 24.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Rounded.ChevronLeft,
                        tint = Color.White,
                        contentDescription = "Back",
                        modifier = Modifier.size(32.dp)
                    )
                }
                
                Text(
                    text = "Equalizer",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.weight(1f)
                )

                Text(
                    text = if (eqEnabled) "ON" else "OFF",
                    color = if (eqEnabled) Color(0xFF2ECC71) else Color.Gray,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(end = 8.dp)
                )

                Switch(
                    checked = eqEnabled,
                    onCheckedChange = { musicViewModel.setEqEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2ECC71),
                        uncheckedThumbColor = Color.Gray,
                        uncheckedTrackColor = Color.DarkGray
                    ),
                    modifier = Modifier.testTag("eq_switch")
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Preset Pills Row
            val presets = listOf("Bass Boost", "EDM Heavy", "Rock", "Pop", "Jazz", "Classical", "Cinema", "3D Spatial", "Vocal", "Club", "Normal", "Custom")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                presets.forEach { preset ->
                    val isSelected = selectedPreset == preset
                    val badgeColor = when (preset) {
                        "Bass Boost", "EDM Heavy" -> Color(0xFFFF0055)
                        "3D Spatial", "Cinema" -> Color(0xFF00E5FF)
                        "Rock", "Club" -> Color(0xFF9C27B0)
                        "Pop", "Vocal" -> Color(0xFFFF9800)
                        else -> Color(0xFF10B981)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                if (isSelected) Brush.horizontalGradient(
                                    listOf(badgeColor, badgeColor.copy(alpha = 0.7f))
                                ) else Brush.horizontalGradient(
                                    listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.05f))
                                )
                            )
                            .border(
                                width = 1.dp,
                                color = if (isSelected) badgeColor else Color.White.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .clickable {
                                musicViewModel.selectPreset(preset)
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            val icon = when (preset) {
                                "Bass Boost" -> Icons.Rounded.GraphicEq
                                "EDM Heavy" -> Icons.Rounded.ElectricBolt
                                "3D Spatial" -> Icons.Rounded.SurroundSound
                                "Cinema" -> Icons.Rounded.Movie
                                "Rock" -> Icons.Rounded.VolumeUp
                                "Vocal" -> Icons.Rounded.Mic
                                else -> Icons.Rounded.MusicNote
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else badgeColor,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = preset,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 5 Vertical Equalizer Sliders with dB Readouts
            val frequencies = listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(190.dp)
                    .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 5) {
                    val band1 = i * 2
                    val band2 = i * 2 + 1
                    val bandGain = eqBands.getOrElse(band1) { 0 }
                    
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Text(
                            text = if (bandGain > 0) "+${bandGain}dB" else "${bandGain}dB",
                            color = if (bandGain != 0) Color(0xFF10B981) else Color.Gray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        VerticalEqualizerSlider(
                            value = bandGain.toFloat(),
                            onValueChange = { newVal ->
                                musicViewModel.setEqBand(band1, newVal.toInt())
                                musicViewModel.setEqBand(band2, newVal.toInt())
                                musicViewModel.selectPreset("Custom")
                            },
                            range = -15f..15f,
                            enabled = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = frequencies[i],
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // BassBooster Pro and 3D Spatial Audio Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // BassBoost Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E1028)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFFFF007A).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.GraphicEq,
                                    contentDescription = null,
                                    tint = Color(0xFFFF007A),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("Bass Boost", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text("${bassBoostStrength / 10}%", color = Color(0xFFFF007A), fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Slider(
                            value = bassBoostStrength.toFloat(),
                            onValueChange = {
                                musicViewModel.setBassBoostEnabled(true)
                                musicViewModel.setBassBoostStrength(it.toInt())
                            },
                            valueRange = 0f..1000f,
                            enabled = true,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFFFF007A),
                                activeTrackColor = Color(0xFFFF007A),
                                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // 3D Virtualizer Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1B2A)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(
                                    imageVector = Icons.Rounded.SurroundSound,
                                    contentDescription = null,
                                    tint = Color(0xFF00E5FF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text("3D Spatial", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text("${virtualizerStrength / 10}%", color = Color(0xFF00E5FF), fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Slider(
                            value = virtualizerStrength.toFloat(),
                            onValueChange = {
                                musicViewModel.setVirtualizerEnabled(true)
                                musicViewModel.setVirtualizerStrength(it.toInt())
                            },
                            valueRange = 0f..1000f,
                            enabled = true,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFF00E5FF),
                                inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Bottom pill: "Explore more equalizer settings >"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
                    .clickable { onExploreMore() }
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Explore more equalizer settings ",
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Rounded.ChevronRight,
                        tint = Color.White.copy(alpha = 0.85f),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// CYBER NEON PREMIUM THEME PLAYER CONTENT (Exact to uploaded reference design)
// --------------------------------------------------------------------------------------------------
@Composable
fun CyberNeonPlayerContent(
    song: ScannedSong,
    isPlaying: Boolean,
    currentPosition: Long,
    duration: Long,
    repeatMode: Int,
    shuffleEnabled: Boolean,
    isFav: Boolean,
    playbackSpeed: Float,
    nextSongTitle: String,
    nextSongArtist: String,
    onCollapse: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Long) -> Unit,
    onToggleFavorite: () -> Unit,
    onSetRepeatMode: (Int) -> Unit,
    onOpenEqualizer: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onOpenAudioSettings: (String) -> Unit,
    onOpenLyrics: () -> Unit,
    onOpenMoreMenu: () -> Unit,
    onOpenQueue: () -> Unit
) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(top = 12.dp, start = 20.dp, end = 20.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 1. Header Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onCollapse) {
                Icon(
                    imageVector = Icons.Rounded.KeyboardArrowDown,
                    tint = Color.White,
                    contentDescription = "Collapse",
                    modifier = Modifier.size(30.dp)
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "PLAYING NOW",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Feel the Music",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(3.dp))
                Box(
                    modifier = Modifier
                        .width(36.dp)
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00F0FF))
                )
            }

            IconButton(onClick = onOpenMoreMenu) {
                Icon(
                    imageVector = Icons.Rounded.MoreVert,
                    tint = Color.White,
                    contentDescription = "More",
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        // 2. Center Album Art Container (Glow Border + "Feel THE MUSIC" Styling)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            contentAlignment = Alignment.Center
        ) {
            val glowScale = if (isPlaying) rememberThemeOscillation(isPlaying = true, durationMs = 1800, minVal = 0.98f, maxVal = 1.03f) else 1.0f

            // Rounded Square Artwork Container
            Box(
                modifier = Modifier
                    .size(270.dp)
                    .graphicsLayer(scaleX = glowScale, scaleY = glowScale)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF0D031F))
                    .border(
                        width = 2.5.dp,
                        brush = Brush.horizontalGradient(
                            listOf(Color(0xFFFF00D6), Color(0xFFBD00FF), Color(0xFF00F0FF))
                        ),
                        shape = RoundedCornerShape(28.dp)
                    )
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                // Inner Image or Fallback Aesthetic Artwork
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF14072B)),
                    contentAlignment = Alignment.Center
                ) {
                    val artUri = song.artworkUri
                    if (!artUri.isNullOrEmpty()) {
                        AsyncImage(
                            model = artUri,
                            contentDescription = "Album Art",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        // Aesthetic Cyber Neon Art matching reference image
                        Box(modifier = Modifier.fillMaxSize()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(Color(0xFF330066), Color(0xFF0A001A))
                                        )
                                    )
                            )
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Headphones,
                                    contentDescription = null,
                                    tint = Color(0xFF00F0FF),
                                    modifier = Modifier.size(68.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Feel",
                                    color = Color(0xFFFF00D6),
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    style = androidx.compose.ui.text.TextStyle(
                                        shadow = Shadow(Color(0xFFBD00FF), blurRadius = 12f)
                                    )
                                )
                                Text(
                                    text = "THE MUSIC",
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                )
                                Text(
                                    text = "LOSE YOURSELF",
                                    color = Color(0xFF00F0FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    letterSpacing = 1.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. Track Details (Title, Artist, Heart, Mini Visualizer)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = song.title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = if (isFav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                            contentDescription = "Heart",
                            tint = if (isFav) Color(0xFFFF007A) else Color(0xFFBD00FF),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = song.artist ?: "<unknown>",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Animated Equalizer Icon
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.05f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.GraphicEq,
                    contentDescription = "Visualizer",
                    tint = Color(0xFF00F0FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // 4. Timeline Slider
        val effectiveDuration = if (duration > 0) duration else if (song.duration > 0) song.duration else 0L
        val progress = if (effectiveDuration > 0) (currentPosition.toFloat() / effectiveDuration.toFloat()).coerceIn(0f, 1f) else 0f

        Column(modifier = Modifier.fillMaxWidth()) {
            Slider(
                value = progress,
                onValueChange = {
                    val targetMs = (it * effectiveDuration).toLong()
                    onSeek(targetMs)
                },
                colors = SliderDefaults.colors(
                    thumbColor = Color.White,
                    activeTrackColor = Color(0xFFBD00FF),
                    inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(formatMusicMillis(currentPosition), color = Color.Gray, fontSize = 11.sp)
                Text(formatMusicMillis(effectiveDuration), color = Color.Gray, fontSize = 11.sp)
            }
        }

        // 5. Main Playback Controls with Pulsating Neon Halo
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { /* Shuffle */ }) {
                Icon(
                    imageVector = Icons.Rounded.Shuffle,
                    tint = if (shuffleEnabled) Color(0xFF00F0FF) else Color.White.copy(alpha = 0.6f),
                    contentDescription = "Shuffle",
                    modifier = Modifier.size(24.dp)
                )
            }

            IconButton(onClick = onPrevious) {
                Icon(
                    imageVector = Icons.Rounded.SkipPrevious,
                    tint = Color.White,
                    contentDescription = "Previous",
                    modifier = Modifier.size(36.dp)
                )
            }

            // Central Play/Pause Button with Pulsating Outer Neon Ring
            val haloTransition = rememberInfiniteTransition(label = "HaloAnim")
            val haloPulse by haloTransition.animateFloat(
                initialValue = 0.92f,
                targetValue = 1.25f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1000, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "HaloPulse"
            )
            val currentHaloPulse = if (isPlaying) haloPulse else 1.0f

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(76.dp)
            ) {
                // Outer Pulsating Neon Ring
                Box(
                    modifier = Modifier
                        .size((68 * currentHaloPulse).dp)
                        .clip(CircleShape)
                        .border(
                            width = 2.dp,
                            brush = Brush.horizontalGradient(
                                listOf(Color(0xFFBD00FF), Color(0xFF00F0FF))
                            ),
                            shape = CircleShape
                        )
                )

                // Inner Main Play/Pause Button
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFFBD00FF), Color(0xFF00F0FF))
                            )
                        )
                        .clickable { onTogglePlayPause() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        tint = Color.White,
                        contentDescription = "Play/Pause",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            IconButton(onClick = onNext) {
                Icon(
                    imageVector = Icons.Rounded.SkipNext,
                    tint = Color.White,
                    contentDescription = "Next",
                    modifier = Modifier.size(36.dp)
                )
            }

            IconButton(onClick = {
                val nextMode = (repeatMode + 1) % 3
                onSetRepeatMode(nextMode)
            }) {
                Icon(
                    imageVector = if (repeatMode == 1) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    tint = if (repeatMode != 0) Color(0xFF00F0FF) else Color.White.copy(alpha = 0.6f),
                    contentDescription = "Repeat",
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // 6. Quick Action Bar (Equalizer, Sleep Timer, Play Speed, Lyrics)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.05f))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(20.dp))
                .padding(vertical = 10.dp, horizontal = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenEqualizer() }
                ) {
                    Icon(Icons.Rounded.Tune, contentDescription = null, tint = Color(0xFFBD00FF), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("Equalizer", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.White.copy(alpha = 0.12f)))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenSleepTimer() }
                ) {
                    Icon(Icons.Rounded.Timer, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("Sleep Timer", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.White.copy(alpha = 0.12f)))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenAudioSettings("Audio Tuning") }
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .border(1.dp, Color(0xFFBD00FF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("${playbackSpeed}x", color = Color.White, fontSize = 7.5.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("Play Speed", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }

                Box(modifier = Modifier.width(1.dp).height(20.dp).background(Color.White.copy(alpha = 0.12f)))

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onOpenLyrics() }
                ) {
                    Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.height(3.dp))
                    Text("Lyrics", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7. Next Track Mini Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.04f))
                .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                .clickable { onOpenQueue() }
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.QueueMusic,
                        contentDescription = null,
                        tint = Color(0xFFBD00FF),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Next: $nextSongTitle",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = nextSongArtist,
                            color = Color.Gray,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNext, modifier = Modifier.size(26.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Play Next",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = onOpenQueue, modifier = Modifier.size(26.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.List,
                            contentDescription = "Queue",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
