package com.vidiopen.player.data.model

data class ScannedSong(
    val id: Long,
    var title: String,
    var artist: String?,
    var album: String?,
    val duration: Long,
    val size: Long,
    val path: String,
    val dateAdded: Long,
    val albumId: Long,
    var artworkUri: String? = null,
    val contentUri: String? = null
) {
    val albumArtUri: String? get() = artworkUri
}
