package com.vidiopen.player.utils

import android.util.LruCache
import java.io.File
import java.io.FileInputStream
import java.io.InputStream

/**
 * High-performance, zero-JNI embedded picture detector for audio files.
 *
 * Inspects binary audio metadata headers (ID3v2 APIC/PIC, FLAC METADATA_BLOCK_PICTURE, MP4/M4A covr)
 * in pure Kotlin to determine if an audio file actually contains embedded cover art before invoking
 * MediaMetadataRetriever. This completely prevents the native Android logcat error:
 * "E/MediaMetadataRetrieverJNI: getEmbeddedPicture: Call to getEmbeddedPicture failed."
 */
object EmbeddedPictureDetector {

    // Fast in-memory cache of verified paths (1000 entries)
    private val detectionCache = object : LruCache<String, Boolean>(1000) {}

    fun hasEmbeddedPicture(filePath: String?): Boolean {
        if (filePath.isNullOrBlank()) return false

        synchronized(detectionCache) {
            val cached = detectionCache.get(filePath)
            if (cached != null) return cached
        }

        val hasArt = try {
            val file = File(filePath)
            if (!file.exists() || !file.canRead() || file.length() < 2048) {
                false
            } else {
                checkFileForEmbeddedPicture(file)
            }
        } catch (_: Throwable) {
            false
        }

        synchronized(detectionCache) {
            detectionCache.put(filePath, hasArt)
        }
        return hasArt
    }

    private fun checkFileForEmbeddedPicture(file: File): Boolean {
        val ext = file.extension.lowercase()
        FileInputStream(file).buffered().use { input ->
            val header = ByteArray(12)
            val bytesRead = input.read(header)
            if (bytesRead < 4) return false

            // 1. MP3 / ID3v2 Check
            if (header[0] == 'I'.code.toByte() && header[1] == 'D'.code.toByte() && header[2] == '3'.code.toByte()) {
                val majorVersion = header[3].toInt() and 0xFF
                if (bytesRead < 10) return false
                val tagSize = ((header[6].toInt() and 0x7F) shl 21) or
                        ((header[7].toInt() and 0x7F) shl 14) or
                        ((header[8].toInt() and 0x7F) shl 7) or
                        (header[9].toInt() and 0x7F)

                if (tagSize <= 0) return false

                // Search for APIC (ID3v2.3/2.4) or PIC (ID3v2.2) within the tag bytes (up to 256 KB)
                val maxSearch = minOf(tagSize, 256 * 1024)
                val buffer = ByteArray(maxSearch)
                var total = 0
                while (total < maxSearch) {
                    val r = input.read(buffer, total, maxSearch - total)
                    if (r <= 0) break
                    total += r
                }

                return if (majorVersion == 2) {
                    containsAscii(buffer, total, "PIC")
                } else {
                    containsAscii(buffer, total, "APIC")
                }
            }

            // 2. FLAC Check
            if (header[0] == 'f'.code.toByte() && header[1] == 'L'.code.toByte() &&
                header[2] == 'a'.code.toByte() && header[3] == 'C'.code.toByte()
            ) {
                var isLast = false
                while (!isLast) {
                    val blockHeader = ByteArray(4)
                    if (readFully(input, blockHeader) < 4) break
                    val blockType = blockHeader[0].toInt() and 0x7F
                    isLast = (blockHeader[0].toInt() and 0x80) != 0

                    if (blockType == 6) { // METADATA_BLOCK_PICTURE
                        return true
                    }

                    val blockLength = ((blockHeader[1].toInt() and 0xFF) shl 16) or
                            ((blockHeader[2].toInt() and 0xFF) shl 8) or
                            (blockHeader[3].toInt() and 0xFF)

                    if (blockLength < 0 || skipFully(input, blockLength.toLong()) < blockLength) break
                }
                return false
            }

            // 3. MP4 / M4A / 3GP Check
            if (ext in listOf("m4a", "mp4", "aac", "3gp")) {
                val buffer = ByteArray(128 * 1024)
                System.arraycopy(header, 0, buffer, 0, bytesRead)
                var total = bytesRead
                while (total < buffer.size) {
                    val r = input.read(buffer, total, buffer.size - total)
                    if (r <= 0) break
                    total += r
                }
                return containsAscii(buffer, total, "covr")
            }

            // 4. Standalone MP3 without ID3 header: cannot contain embedded pictures
            if (ext == "mp3") {
                return false
            }

            // 5. Other formats (ogg, opus, wav): quick scan first 64KB for APIC or covr
            val buffer = ByteArray(64 * 1024)
            System.arraycopy(header, 0, buffer, 0, bytesRead)
            var total = bytesRead
            while (total < buffer.size) {
                val r = input.read(buffer, total, buffer.size - total)
                if (r <= 0) break
                total += r
            }
            return containsAscii(buffer, total, "APIC") || containsAscii(buffer, total, "covr")
        }
    }

    private fun containsAscii(buffer: ByteArray, length: Int, target: String): Boolean {
        val targetBytes = target.toByteArray(Charsets.US_ASCII)
        val maxI = length - targetBytes.size
        for (i in 0..maxI) {
            var match = true
            for (j in targetBytes.indices) {
                if (buffer[i + j] != targetBytes[j]) {
                    match = false
                    break
                }
            }
            if (match) return true
        }
        return false
    }

    private fun readFully(input: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val r = input.read(buffer, total, buffer.size - total)
            if (r <= 0) break
            total += r
        }
        return total
    }

    private fun skipFully(input: InputStream, bytesToSkip: Long): Long {
        var totalSkipped = 0L
        while (totalSkipped < bytesToSkip) {
            val skipped = input.skip(bytesToSkip - totalSkipped)
            if (skipped <= 0) {
                if (input.read() == -1) break
                totalSkipped += 1
            } else {
                totalSkipped += skipped
            }
        }
        return totalSkipped
    }
}
