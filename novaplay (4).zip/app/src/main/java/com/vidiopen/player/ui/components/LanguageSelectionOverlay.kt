package com.vidiopen.player.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidiopen.player.R
import kotlin.math.sin

/**
 * Idea 3: Cultural Carousel & Wave Language Selection Screen
 * Featuring Made in India tricolor accents, dynamic audio/media wave canvas,
 * and high-contrast interactive cards for Hindi & English.
 */
@Composable
fun LanguageSelectionOverlay(
    currentLanguage: String = "en",
    onDismiss: (() -> Unit)? = null,
    onLanguageSelected: (String) -> Unit
) {
    // Default selected state based on existing language or fallback to Hindi as default
    var selectedLang by remember {
        mutableStateOf(if (currentLanguage.isNotEmpty()) currentLanguage else "hi")
    }

    // Animation state for screen entrance
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        isVisible = true
    }

    val contentAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "contentAlpha"
    )

    val contentOffsetY by animateFloatAsState(
        targetValue = if (isVisible) 0f else 60f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "contentOffsetY"
    )

    // Wave animation phase
    val infiniteTransition = rememberInfiniteTransition(label = "waveTransition")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wavePhase"
    )

    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A12))
            .testTag("language_selection_overlay"),
        contentAlignment = Alignment.Center
    ) {
        // --- 1. Dynamic Audio/Media Soundwave Background ---
        Canvas(
            modifier = Modifier.fillMaxSize()
        ) {
            val width = size.width
            val height = size.height

            // Subtle dark ambient gradient glow at top & bottom
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x33FF9933), Color.Transparent),
                    center = Offset(width * 0.2f, height * 0.25f),
                    radius = width * 0.7f
                )
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x2800F0FF), Color.Transparent),
                    center = Offset(width * 0.8f, height * 0.75f),
                    radius = width * 0.7f
                )
            )

            // Animated undulating waves
            val path1 = Path()
            val path2 = Path()
            val path3 = Path()

            val baseY1 = height * 0.45f
            val baseY2 = height * 0.55f
            val baseY3 = height * 0.65f

            path1.moveTo(0f, baseY1)
            path2.moveTo(0f, baseY2)
            path3.moveTo(0f, baseY3)

            val step = 15f
            var x = 0f
            while (x <= width) {
                val wave1 = (sin((x / width * 3 * Math.PI) + wavePhase) * 28f).toFloat()
                val wave2 = (sin((x / width * 2.5 * Math.PI) - wavePhase * 0.8f) * 22f).toFloat()
                val wave3 = (sin((x / width * 3.5 * Math.PI) + wavePhase * 1.2f) * 18f).toFloat()

                path1.lineTo(x, baseY1 + wave1)
                path2.lineTo(x, baseY2 + wave2)
                path3.lineTo(x, baseY3 + wave3)
                x += step
            }

            // Draw wave strokes with cultural theme colors (Saffron, Cyan, Emerald)
            drawPath(
                path = path1,
                color = Color(0x30FF9933),
                style = Stroke(width = 2.5f)
            )
            drawPath(
                path = path2,
                color = Color(0x2500F0FF),
                style = Stroke(width = 2.0f)
            )
            drawPath(
                path = path3,
                color = Color(0x28138808),
                style = Stroke(width = 2.5f)
            )
        }

        // Close Button (if dismissable dialog mode)
        if (onDismiss != null) {
            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 48.dp, end = 20.dp)
                    .size(40.dp)
                    .background(Color(0x33FFFFFF), CircleShape)
                    .testTag("language_dialog_close")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = "Close",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // --- 2. Main Content Card with Animated Spring Entrance ---
        Column(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .offset(y = contentOffsetY.dp)
                .scale(contentAlpha.coerceIn(0.9f, 1f))
                .padding(vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // App Branding & Made in India Badge
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .shadow(16.dp, CircleShape, spotColor = Color(0xFF00F0FF))
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF1E2846), Color(0xFF0D1222))
                        ),
                        shape = CircleShape
                    )
                    .border(
                        width = 1.5.dp,
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFFFF9933),
                                Color.White,
                                Color(0xFF138808),
                                Color(0xFF00F0FF),
                                Color(0xFFFF9933)
                            )
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_vidiopen_logo),
                    contentDescription = "Vidiopen Logo",
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 🇮🇳 MADE IN INDIA Tricolor Pill Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier
                    .clip(RoundedCornerShape(50.dp))
                    .background(Color(0xFF141A2E).copy(alpha = 0.85f))
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFFFF9933).copy(alpha = glowPulse),
                                Color.White.copy(alpha = 0.8f),
                                Color(0xFF138808).copy(alpha = glowPulse)
                            )
                        ),
                        shape = RoundedCornerShape(50.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "🇮🇳",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MADE IN INDIA",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.3.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Primary Header Text
            Text(
                text = "अपनी भाषा चुनें / Select Language",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Choose your preferred language for the best media experience",
                color = Color(0xFF9AA7C2),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // --- 3. Interactive Language Option Cards (Cultural vs Global) ---
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Card 1: HINDI (Cultural Tricolor & Warm Accent)
                LanguageCard(
                    title = "हिन्दी",
                    subtitle = "नमस्ते! ऐप का संपूर्ण अनुभव हिंदी में",
                    symbol = "अ",
                    flagEmoji = "🇮🇳",
                    badgeText = "भारतीय भाषा",
                    isSelected = selectedLang == "hi",
                    activeGlowColor = Color(0xFFFF9933),
                    activeBorderBrush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFFFF9933), Color(0xFFFFFFFF), Color(0xFF138808))
                    ),
                    onSelect = { selectedLang = "hi" },
                    testTag = "lang_card_hindi"
                )

                // Card 2: ENGLISH (Cyber Cyan & Global Accent)
                LanguageCard(
                    title = "English",
                    subtitle = "Hello! Clean and international interface",
                    symbol = "A",
                    flagEmoji = "🌐",
                    badgeText = "Global Standard",
                    isSelected = selectedLang == "en",
                    activeGlowColor = Color(0xFF00F0FF),
                    activeBorderBrush = Brush.horizontalGradient(
                        colors = listOf(Color(0xFF00F0FF), Color(0xFF7B2CBF), Color(0xFF00F0FF))
                    ),
                    onSelect = { selectedLang = "en" },
                    testTag = "lang_card_english"
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // --- 4. Glowing Continue / Confirm Button ---
            val isHindi = selectedLang == "hi"
            val buttonGradient = if (isHindi) {
                Brush.horizontalGradient(
                    listOf(Color(0xFFFF8800), Color(0xFFFFB347), Color(0xFF138808))
                )
            } else {
                Brush.horizontalGradient(
                    listOf(Color(0xFF00C6FF), Color(0xFF0072FF), Color(0xFF7B2CBF))
                )
            }

            Button(
                onClick = { onLanguageSelected(selectedLang) },
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = PaddingValues(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(
                        elevation = 16.dp,
                        shape = RoundedCornerShape(16.dp),
                        spotColor = if (isHindi) Color(0xFFFF8800) else Color(0xFF00F0FF)
                    )
                    .background(buttonGradient, shape = RoundedCornerShape(16.dp))
                    .testTag("btn_confirm_language")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Text(
                        text = if (isHindi) "आगे बढ़ें (Continue)" else "Continue (आगे बढ़ें)",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "➔",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

/**
 * Modern High-Impact Language Choice Card
 */
@Composable
private fun LanguageCard(
    title: String,
    subtitle: String,
    symbol: String,
    flagEmoji: String,
    badgeText: String,
    isSelected: Boolean,
    activeGlowColor: Color,
    activeBorderBrush: Brush,
    onSelect: () -> Unit,
    testTag: String
) {
    val scale by animateFloatAsState(
        targetValue = if (isSelected) 1.02f else 1.0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )

    val elevation by animateDpAsState(
        targetValue = if (isSelected) 12.dp else 2.dp,
        animationSpec = tween(durationMillis = 250),
        label = "cardElevation"
    )

    val backgroundAlpha by animateFloatAsState(
        targetValue = if (isSelected) 0.95f else 0.65f,
        animationSpec = tween(durationMillis = 200),
        label = "bgAlpha"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .shadow(
                elevation = elevation,
                shape = RoundedCornerShape(20.dp),
                spotColor = if (isSelected) activeGlowColor else Color.Transparent
            )
            .clip(RoundedCornerShape(20.dp))
            .background(
                color = if (isSelected) Color(0xFF151C30).copy(alpha = backgroundAlpha)
                else Color(0xFF0F1424).copy(alpha = backgroundAlpha)
            )
            .then(
                if (isSelected) {
                    Modifier.border(
                        width = 2.dp,
                        brush = activeBorderBrush,
                        shape = RoundedCornerShape(20.dp)
                    )
                } else {
                    Modifier.border(
                        width = 1.dp,
                        color = Color(0xFF222B45),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onSelect
            )
            .padding(18.dp)
            .testTag(testTag)
    ) {
        // Large Background Script Watermark (अ / A)
        Text(
            text = symbol,
            color = if (isSelected) activeGlowColor.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f),
            fontSize = 72.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = (-8).dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon Avatar Pill
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        if (isSelected) activeGlowColor.copy(alpha = 0.2f)
                        else Color(0xFF1E263D)
                    )
                    .border(
                        width = 1.dp,
                        color = if (isSelected) activeGlowColor.copy(alpha = 0.6f) else Color(0xFF2C3857),
                        shape = RoundedCornerShape(16.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = flagEmoji,
                    fontSize = 24.sp
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            // Text Info
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    // Small Tag
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(
                                if (isSelected) activeGlowColor.copy(alpha = 0.2f)
                                else Color(0xFF1D253A)
                            )
                            .padding(horizontal = 7.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = if (isSelected) activeGlowColor else Color(0xFF8896B3),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    color = if (isSelected) Color(0xFFCBD5E1) else Color(0xFF828DA4),
                    fontSize = 12.5.sp,
                    lineHeight = 16.sp
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Selection Radio / Check Indicator
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(
                        if (isSelected) activeGlowColor else Color(0xFF1A2238)
                    )
                    .border(
                        width = 1.5.dp,
                        color = if (isSelected) activeGlowColor else Color(0xFF384666),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Selected",
                        tint = Color(0xFF070A12),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
