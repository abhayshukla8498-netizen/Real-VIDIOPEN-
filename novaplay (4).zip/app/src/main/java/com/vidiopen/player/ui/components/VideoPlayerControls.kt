package com.vidiopen.player.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

/**
 * Top Bar for Video Player
 */
@Composable
fun VideoPlayerTopBar(
    title: String,
    volumePercent: Int,
    subtitlesEnabled: Boolean,
    orientationLabel: String,
    onBack: () -> Unit,
    onToggleBoost: () -> Unit,
    onLockScreen: () -> Unit,
    onPip: () -> Unit,
    onToggleOrientation: () -> Unit,
    onOpenAudioTracks: () -> Unit,
    onOpenSubtitles: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenVideoSwitcher: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Back Button & Title
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Action Buttons Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Video Switcher / Change Video Button
            if (onOpenVideoSwitcher != null) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF00F0FF).copy(alpha = 0.22f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF).copy(alpha = 0.55f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onOpenVideoSwitcher() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.VideoLibrary,
                            contentDescription = "Change Video",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "Change",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Orientation Toggle Button
            IconButton(onClick = onToggleOrientation) {
                Icon(
                    imageVector = Icons.Rounded.ScreenRotation,
                    contentDescription = "Rotate Screen ($orientationLabel)",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Audio Track Selector Button
            IconButton(onClick = onOpenAudioTracks) {
                Icon(
                    imageVector = Icons.Rounded.Audiotrack,
                    contentDescription = "Audio Tracks",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Subtitle CC Button
            IconButton(onClick = onOpenSubtitles) {
                Icon(
                    imageVector = if (subtitlesEnabled) Icons.Rounded.ClosedCaption else Icons.Rounded.ClosedCaptionDisabled,
                    contentDescription = "Subtitles",
                    tint = if (subtitlesEnabled) Color(0xFF00F0FF) else Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            // 200% Volume Boost Icon Button
            IconButton(onClick = onToggleBoost) {
                Badge(
                    containerColor = if (volumePercent > 100) Color(0xFF00F0FF) else Color.Transparent
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Volume Boost",
                        tint = if (volumePercent > 100) Color(0xFF00F0FF) else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // Kids Touch Lock Button
            IconButton(onClick = onLockScreen) {
                Icon(
                    imageVector = Icons.Rounded.Lock,
                    contentDescription = "Touch Lock",
                    tint = Color(0xFFFF2E93),
                    modifier = Modifier.size(22.dp)
                )
            }

            // PIP / Floating Button
            IconButton(onClick = onPip) {
                Icon(
                    imageVector = Icons.Rounded.PictureInPicture,
                    contentDescription = "PIP",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }

            // More / Settings Menu Button
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "Player Settings",
                    tint = Color.White,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

/**
 * Center Play/Pause & Rewind/Forward Controls
 */
@Composable
fun VideoPlayerCenterControls(
    isPlaying: Boolean,
    onRewind10: () -> Unit,
    onPlayPause: () -> Unit,
    onForward10: () -> Unit,
    onPreviousVideo: (() -> Unit)? = null,
    onNextVideo: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Previous Video Button
        if (onPreviousVideo != null) {
            IconButton(
                onClick = onPreviousVideo,
                modifier = Modifier
                    .size(44.dp)
                    .background(Color.White.copy(alpha = 0.15f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipPrevious,
                    contentDescription = "Previous Video",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        // Rewind 10s
        IconButton(
            onClick = onRewind10,
            modifier = Modifier
                .size(48.dp)
                .background(Color.White.copy(alpha = 0.15f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Rounded.Replay10,
                contentDescription = "Rewind 10s",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }

        // Play / Pause Button
        IconButton(
            onClick = onPlayPause,
            modifier = Modifier
                .size(72.dp)
                .background(Color(0xFF00F0FF), CircleShape)
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.Black,
                modifier = Modifier.size(38.dp)
            )
        }

        // Forward 10s
        IconButton(
            onClick = onForward10,
            modifier = Modifier
                .size(48.dp)
                .background(Color.White.copy(alpha = 0.15f), CircleShape)
        ) {
            Icon(
                imageVector = Icons.Rounded.Forward10,
                contentDescription = "Forward 10s",
                tint = Color.White,
                modifier = Modifier.size(26.dp)
            )
        }

        // Next Video Button
        if (onNextVideo != null) {
            IconButton(
                onClick = onNextVideo,
                modifier = Modifier
                    .size(44.dp)
                    .background(Color.White.copy(alpha = 0.15f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Rounded.SkipNext,
                    contentDescription = "Next Video",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

/**
 * Bottom Bar with Seekbar, Timestamps, and Quick Control Chips
 */
@Composable
fun VideoPlayerBottomBar(
    currentPositionMs: Long,
    durationMs: Long,
    playbackSpeed: Float,
    aspectRatioLabel: String,
    repeatModeLabel: String,
    sleepTimerMinutes: Int,
    volumePercent: Int,
    isMuted: Boolean,
    onSeek: (Long) -> Unit,
    onOpenSpeed: () -> Unit,
    onCycleAspectRatio: () -> Unit,
    onCycleRepeatMode: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onSetVolume: (Int) -> Unit,
    onToggleMute: () -> Unit,
    onOpenVideoSwitcher: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        // Time Row & Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatDurationWithHours(currentPositionMs),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            Text(
                text = formatDurationWithHours(durationMs),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 12.sp
            )
        }

        Slider(
            value = currentPositionMs.toFloat(),
            onValueChange = { targetPos ->
                onSeek(targetPos.toLong())
            },
            valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
            colors = SliderDefaults.colors(
                thumbColor = Color(0xFF00F0FF),
                activeTrackColor = Color(0xFF00F0FF),
                inactiveTrackColor = Color.White.copy(alpha = 0.22f)
            ),
            modifier = Modifier.fillMaxWidth()
        )

        // Quick Feature Chips Row (Horizontally Scrollable)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Change Video Chip
            if (onOpenVideoSwitcher != null) {
                QuickControlChip(
                    icon = Icons.Rounded.VideoLibrary,
                    text = "Change Video",
                    isActive = true,
                    activeColor = Color(0xFF00F0FF),
                    onClick = onOpenVideoSwitcher
                )
            }

            // Speed Chip
            QuickControlChip(
                icon = Icons.Rounded.Speed,
                text = "${playbackSpeed}x",
                isActive = playbackSpeed != 1.0f,
                onClick = onOpenSpeed
            )

            // Aspect Ratio Chip
            QuickControlChip(
                icon = Icons.Rounded.AspectRatio,
                text = aspectRatioLabel,
                isActive = aspectRatioLabel != "Fit",
                onClick = onCycleAspectRatio
            )

            // Repeat Mode Chip
            QuickControlChip(
                icon = if (repeatModeLabel == "One") Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                text = repeatModeLabel,
                isActive = repeatModeLabel != "Off",
                onClick = onCycleRepeatMode
            )

            // Sleep Timer Chip
            QuickControlChip(
                icon = Icons.Rounded.Timer,
                text = if (sleepTimerMinutes > 0) "${sleepTimerMinutes}m" else "Timer",
                isActive = sleepTimerMinutes > 0,
                onClick = onOpenSleepTimer
            )

            // Mute / Unmute Button
            QuickControlChip(
                icon = if (isMuted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp,
                text = if (isMuted) "Muted" else "$volumePercent%",
                isActive = isMuted || volumePercent > 100,
                activeColor = if (volumePercent > 100) Color(0xFFFF2E93) else Color(0xFF00F0FF),
                onClick = onToggleMute
            )

            // Quick Booster Chips
            QuickTextChip(
                text = "100%",
                isActive = volumePercent == 100,
                onClick = { onSetVolume(100) }
            )
            QuickTextChip(
                text = "150%",
                isActive = volumePercent == 150,
                activeColor = Color(0xFF00F0FF),
                onClick = { onSetVolume(150) }
            )
            QuickTextChip(
                text = "200% 🔥",
                isActive = volumePercent == 200,
                activeColor = Color(0xFFFF2E93),
                onClick = { onSetVolume(200) }
            )
        }
    }
}

@Composable
private fun QuickControlChip(
    icon: ImageVector,
    text: String,
    isActive: Boolean,
    activeColor: Color = Color(0xFF00F0FF),
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isActive) activeColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.12f),
        border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, activeColor) else null,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = if (isActive) activeColor else Color.White,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = text,
                color = if (isActive) activeColor else Color.White,
                fontSize = 11.sp,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun QuickTextChip(
    text: String,
    isActive: Boolean,
    activeColor: Color = Color(0xFF00F0FF),
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isActive) activeColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.1f),
        border = if (isActive) androidx.compose.foundation.BorderStroke(1.dp, activeColor) else null,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = if (isActive) activeColor else Color.White.copy(alpha = 0.85f),
            fontSize = 11.sp,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        )
    }
}

/**
 * Playback Speed Selection Dialog
 */
@Composable
fun PlaybackSpeedDialog(
    currentSpeed: Float,
    onSelectSpeed: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val speeds = listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Playback Speed",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    speeds.forEach { speed ->
                        val isSelected = speed == currentSpeed
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF)) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectSpeed(speed)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (speed == 1.0f) "1.0x (Normal)" else "${speed}x",
                                    color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                if (isSelected) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Sleep Timer Selection Dialog
 */
@Composable
fun SleepTimerDialog(
    currentMinutesRemaining: Int,
    onSetTimerMinutes: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf(
        0 to "Turn Off Timer",
        15 to "15 Minutes",
        30 to "30 Minutes",
        45 to "45 Minutes",
        60 to "60 Minutes"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sleep Timer",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                if (currentMinutesRemaining > 0) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Active: Auto-pause in $currentMinutesRemaining min",
                        color = Color(0xFF00F0FF),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { (minutes, label) ->
                        val isSelected = (minutes == 0 && currentMinutesRemaining <= 0) || (minutes > 0 && currentMinutesRemaining == minutes)
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                            border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF)) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSetTimerMinutes(minutes)
                                    onDismiss()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                if (isSelected) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Audio Track Selection Dialog
 */
@Composable
fun AudioTrackDialog(
    audioTracks: List<String>,
    selectedTrackIndex: Int,
    onSelectTrack: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Audio Track",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (audioTracks.isEmpty()) {
                    Text(
                        text = "Standard Audio (1 Track Detected)",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        audioTracks.forEachIndexed { index, trackName ->
                            val isSelected = index == selectedTrackIndex
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF)) else null,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        onSelectTrack(index)
                                        onDismiss()
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = trackName,
                                        color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                    if (isSelected) {
                                        Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Subtitles Dialog
 */
@Composable
fun SubtitlesDialog(
    subtitleTracks: List<String>,
    selectedSubtitleIndex: Int,
    subtitlesEnabled: Boolean,
    onToggleSubtitles: (Boolean) -> Unit,
    onSelectSubtitleTrack: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Subtitles (CC)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle Switch Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (subtitlesEnabled) "Subtitles: ON" else "Subtitles: OFF",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Switch(
                        checked = subtitlesEnabled,
                        onCheckedChange = { onToggleSubtitles(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color(0xFF00F0FF)
                        )
                    )
                }

                if (subtitlesEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    if (subtitleTracks.isEmpty()) {
                        Text(
                            text = "No embedded subtitle streams detected in this video file.",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            subtitleTracks.forEachIndexed { index, name ->
                                val isSelected = index == selectedSubtitleIndex
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f),
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00F0FF)) else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onSelectSubtitleTrack(index)
                                            onDismiss()
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = name,
                                            color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                            fontSize = 13.sp
                                        )
                                        if (isSelected) {
                                            Icon(Icons.Rounded.Check, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(18.dp))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Player Full Settings Dialog
 */
@Composable
fun VideoPlayerSettingsDialog(
    playbackSpeed: Float,
    aspectRatioLabel: String,
    repeatModeLabel: String,
    sleepTimerMinutes: Int,
    subtitlesEnabled: Boolean,
    onOpenSpeed: () -> Unit,
    onCycleAspectRatio: () -> Unit,
    onCycleRepeatMode: () -> Unit,
    onOpenSleepTimer: () -> Unit,
    onOpenAudioTracks: () -> Unit,
    onOpenSubtitles: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF16161E)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .border(1.dp, Color.White.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Video Player Settings",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.LightGray)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SettingsItemRow(
                        icon = Icons.Rounded.Speed,
                        title = "Playback Speed",
                        value = "${playbackSpeed}x",
                        onClick = {
                            onDismiss()
                            onOpenSpeed()
                        }
                    )
                    SettingsItemRow(
                        icon = Icons.Rounded.AspectRatio,
                        title = "Aspect Ratio",
                        value = aspectRatioLabel,
                        onClick = onCycleAspectRatio
                    )
                    SettingsItemRow(
                        icon = Icons.Rounded.Repeat,
                        title = "Repeat Mode",
                        value = repeatModeLabel,
                        onClick = onCycleRepeatMode
                    )
                    SettingsItemRow(
                        icon = Icons.Rounded.Timer,
                        title = "Sleep Timer",
                        value = if (sleepTimerMinutes > 0) "${sleepTimerMinutes}m" else "Off",
                        onClick = {
                            onDismiss()
                            onOpenSleepTimer()
                        }
                    )
                    SettingsItemRow(
                        icon = Icons.Rounded.Audiotrack,
                        title = "Audio Tracks",
                        value = "Configure",
                        onClick = {
                            onDismiss()
                            onOpenAudioTracks()
                        }
                    )
                    SettingsItemRow(
                        icon = Icons.Rounded.ClosedCaption,
                        title = "Subtitles",
                        value = if (subtitlesEnabled) "ON" else "OFF",
                        onClick = {
                            onDismiss()
                            onOpenSubtitles()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsItemRow(
    icon: ImageVector,
    title: String,
    value: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.White.copy(alpha = 0.05f),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = Color(0xFF00F0FF), modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = title, color = Color.White, fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = value, color = Color(0xFF00F0FF), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(18.dp))
            }
        }
    }
}
