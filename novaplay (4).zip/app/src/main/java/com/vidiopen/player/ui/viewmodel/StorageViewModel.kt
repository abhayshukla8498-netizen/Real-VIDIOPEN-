package com.vidiopen.player.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.ScannedVideo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class StorageStats(
    val usedInternal: Long = 0L,
    val totalInternal: Long = 0L,
    val usedSdCard: Long = 0L,
    val totalSdCard: Long = 0L,
    val usedStorage: Long = 0L,
    val totalStorage: Long = 0L,
    val freeStorage: Long = 0L,
    val sdCardAvailable: Boolean = false
)

data class StorageInsights(
    val totalVideoSize: Long = 0L,
    val averageVideoSize: Long = 0L,
    val largestVideo: String = "",
    val largestVideoSize: Long = 0L,
    val largestFolder: String = "",
    val largestFolderSize: Long = 0L,
    val totalVideoCount: Int = 0
)

data class DuplicateGroup(
    val size: Long,
    val videos: List<ScannedVideo>
)

sealed interface DeletionItem {
    data class Video(val video: ScannedVideo) : DeletionItem
    data class Folder(val path: String) : DeletionItem
}

class StorageViewModel : ViewModel() {

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _storageStats = MutableStateFlow(StorageStats())
    val storageStats: StateFlow<StorageStats> = _storageStats.asStateFlow()

    private val _storageInsights = MutableStateFlow(StorageInsights())
    val storageInsights: StateFlow<StorageInsights> = _storageInsights.asStateFlow()

    private val _largeVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())
    val largeVideos: StateFlow<List<ScannedVideo>> = _largeVideos.asStateFlow()

    private val _duplicateGroups = MutableStateFlow<List<DuplicateGroup>>(emptyList())
    val duplicateGroups: StateFlow<List<DuplicateGroup>> = _duplicateGroups.asStateFlow()

    private val _emptyFolders = MutableStateFlow<List<String>>(emptyList())
    val emptyFolders: StateFlow<List<String>> = _emptyFolders.asStateFlow()

    private val _pendingDeletion = MutableStateFlow<DeletionItem?>(null)
    val pendingDeletion: StateFlow<DeletionItem?> = _pendingDeletion.asStateFlow()

    private val _undoCountdown = MutableStateFlow(0)
    val undoCountdown: StateFlow<Int> = _undoCountdown.asStateFlow()

    fun analyzeStorage(videos: List<ScannedVideo>) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            try {
                val totalSize = videos.sumOf { it.size }
                val avgSize = if (videos.isNotEmpty()) totalSize / videos.size else 0L
                val largest = videos.maxByOrNull { it.size }

                val groups = videos.groupBy { File(it.path).parent ?: "" }
                val largestFolderEntry = groups.maxByOrNull { entry -> entry.value.sumOf { it.size } }

                _storageInsights.value = StorageInsights(
                    totalVideoSize = totalSize,
                    averageVideoSize = avgSize,
                    largestVideo = largest?.title ?: "",
                    largestVideoSize = largest?.size ?: 0L,
                    largestFolder = largestFolderEntry?.key?.substringAfterLast('/') ?: "",
                    largestFolderSize = largestFolderEntry?.value?.sumOf { it.size } ?: 0L
                )

                _largeVideos.value = videos.filter { it.size > 100 * 1024 * 1024 }.sortedByDescending { it.size }

                val dupes = videos.groupBy { it.size }
                    .filter { it.value.size > 1 && it.key > 1024 * 1024 }
                    .map { DuplicateGroup(it.key, it.value) }
                _duplicateGroups.value = dupes

                val statFs = android.os.StatFs(android.os.Environment.getDataDirectory().path)
                val blockSize = statFs.blockSizeLong
                val totalBlocks = statFs.blockCountLong
                val availableBlocks = statFs.availableBlocksLong
                val totalBytes = totalBlocks * blockSize
                val freeBytes = availableBlocks * blockSize
                val usedBytes = totalBytes - freeBytes

                _storageStats.value = StorageStats(
                    usedInternal = usedBytes,
                    totalInternal = totalBytes,
                    usedStorage = usedBytes,
                    totalStorage = totalBytes,
                    freeStorage = freeBytes
                )
            } catch (_: Exception) {
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun requestDeleteVideo(video: ScannedVideo) {
        _pendingDeletion.value = DeletionItem.Video(video)
    }

    fun requestDeleteFolder(path: String) {
        _pendingDeletion.value = DeletionItem.Folder(path)
    }

    fun undoDeletion() {
        _pendingDeletion.value = null
    }

    fun confirmDeletion() {
        _pendingDeletion.value = null
    }
}
