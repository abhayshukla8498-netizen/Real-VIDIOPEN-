package com.vidiopen.player.domain.usecase

import com.vidiopen.player.data.repository.MediaRepository

class ToggleFavoriteUseCase(private val repository: MediaRepository) {
    suspend operator fun invoke(id: String, isFavorite: Boolean) {
        repository.toggleFavorite(id, isFavorite)
    }
}
