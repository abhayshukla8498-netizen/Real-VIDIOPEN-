package com.vidiopen.player.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.data.model.ScannedVideo
import com.vidiopen.player.data.model.VideoFolder
import com.vidiopen.player.data.repository.MediaStoreRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

enum class VideoSortOrder {
    NEWEST,
    OLDEST,
    NAME_A_Z,
    NAME_Z_A,
    SIZE_LARGEST,
    SIZE_SMALLEST,
    DURATION_LONGEST,
    DURATION_SHORTEST
}

enum class VideoFilterType {
    ALL,
    SHORT,
    LONG,
    RECENT,
    FAVORITES
}

class MediaStoreViewModel(
    application: Application,
    private val repository: MediaStoreRepository
) : AndroidViewModel(application) {

    private val _scannedVideos = MutableStateFlow<List<ScannedVideo>>(emptyList())
    val scannedVideos: StateFlow<List<ScannedVideo>> = _scannedVideos.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _sortOrder = MutableStateFlow(VideoSortOrder.NEWEST)
    val sortOrder: StateFlow<VideoSortOrder> = _sortOrder.asStateFlow()

    private val _filterType = MutableStateFlow(VideoFilterType.ALL)
    val filterType: StateFlow<VideoFilterType> = _filterType.asStateFlow()

    val sdCardAvailable: Boolean = false

    private val vaultDao = com.vidiopen.player.data.database.AppDatabase.getDatabase(application).vaultDao()

    val totalVideoCount: StateFlow<Int> = _scannedVideos.map { it.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val filteredVideos: StateFlow<List<ScannedVideo>> = combine(
        _scannedVideos,
        _searchQuery,
        _sortOrder,
        _filterType,
        vaultDao.getVaultItems()
    ) { videos, query, sort, filter, vaultList ->
        val vaultTitles = vaultList.map { it.title.lowercase() }.toSet()
        val vaultPaths = vaultList.map { it.path.lowercase() }.toSet()

        // Hide any video currently in the private vault from public library views
        var list = videos.filter { video ->
            val pathLower = video.path.lowercase()
            val titleLower = video.title.lowercase()
            !vaultTitles.contains(titleLower) &&
            !vaultPaths.contains(pathLower) &&
            !pathLower.contains("vidiopen_vault")
        }

        if (query.isNotBlank()) {
            val q = query.trim().lowercase()
            list = list.filter { it.title.lowercase().contains(q) || it.path.lowercase().contains(q) }
        }

        list = when (sort) {
            VideoSortOrder.NEWEST -> list.sortedByDescending { it.dateAdded }
            VideoSortOrder.OLDEST -> list.sortedBy { it.dateAdded }
            VideoSortOrder.NAME_A_Z -> list.sortedBy { it.title.lowercase() }
            VideoSortOrder.NAME_Z_A -> list.sortedByDescending { it.title.lowercase() }
            VideoSortOrder.SIZE_LARGEST -> list.sortedByDescending { it.size }
            VideoSortOrder.SIZE_SMALLEST -> list.sortedBy { it.size }
            VideoSortOrder.DURATION_LONGEST -> list.sortedByDescending { it.duration }
            VideoSortOrder.DURATION_SHORTEST -> list.sortedBy { it.duration }
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredFolders: StateFlow<List<VideoFolder>> = filteredVideos.map { videos ->
        videos.groupBy { File(it.path).parent ?: "Videos" }
            .map { (path, folderVideos) ->
                VideoFolder(
                    path = path,
                    name = path.substringAfterLast('/'),
                    videoCount = folderVideos.size,
                    totalSize = folderVideos.sumOf { it.size },
                    latestVideoThumbnail = folderVideos.firstOrNull()?.thumbnailUrl,
                    latestVideoDateAdded = folderVideos.maxOfOrNull { it.dateAdded } ?: 0L,
                    videos = folderVideos
                )
            }.sortedByDescending { it.latestVideoDateAdded }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun scanVideos() {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                val videos = repository.scanVideos()
                _scannedVideos.value = videos
            } catch (_: Exception) {
            } finally {
                _isScanning.value = false
            }
        }
    }

    fun updateScannedVideos(videos: List<ScannedVideo>) {
        _scannedVideos.value = videos
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSortOrder(order: VideoSortOrder) {
        _sortOrder.value = order
    }

    fun setFilterType(type: VideoFilterType) {
        _filterType.value = type
    }

    fun removeVideoFromScanned(video: ScannedVideo) {
        _scannedVideos.value = _scannedVideos.value.filter { it.id != video.id && it.path != video.path }
    }

    fun removeVideoFromScanned(videoId: Long) {
        _scannedVideos.value = _scannedVideos.value.filter { it.id != videoId }
    }

    fun renameVideoTitle(videoId: Long, newTitle: String) {
        _scannedVideos.value = _scannedVideos.value.map {
            if (it.id == videoId) it.copy(title = newTitle) else it
        }
    }

    fun compressVideo(videoId: Long, onDone: (() -> Unit)? = null) {
        onDone?.invoke()
    }

    fun renameVideoTitle(video: ScannedVideo, newTitle: String) {
        _scannedVideos.value = _scannedVideos.value.map {
            if (it.id == video.id) it.copy(title = newTitle) else it
        }
    }

    fun compressVideo(video: ScannedVideo, onDone: (() -> Unit)? = null) {
        onDone?.invoke()
    }

    companion object {
        fun formatSize(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB", "TB")
            val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
            val index = digitGroups.coerceIn(0, units.size - 1)
            val value = bytes / Math.pow(1024.0, index.toDouble())
            return String.format(Locale.US, "%.1f %s", value, units[index])
        }

        @JvmName("convertScannedVideoToMediaEntity")
        fun ScannedVideo.toMediaEntity(): MediaEntity {
            return MediaEntity(
                id = this.path,
                title = this.title,
                url = this.uriString,
                duration = this.duration,
                artist = "Local Video",
                thumbnailUrl = this.thumbnailUrl,
                category = "Movie"
            )
        }

        fun toMediaEntity(video: ScannedVideo): MediaEntity = video.toMediaEntity()
    }
}

class MediaStoreViewModelFactory(
    private val application: Application,
    private val repository: MediaStoreRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MediaStoreViewModel::class.java)) {
            return MediaStoreViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
