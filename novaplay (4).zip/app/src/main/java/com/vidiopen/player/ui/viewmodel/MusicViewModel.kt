package com.vidiopen.player.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Player
import com.vidiopen.player.data.model.MoodCategory
import com.vidiopen.player.data.model.ScannedSong
import com.vidiopen.player.data.repository.MusicRepository
import com.vidiopen.player.data.repository.MusicThemeRepository
import com.vidiopen.player.player.MusicPlayerManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

data class AlbumItem(
    val name: String,
    val artist: String,
    val artworkUri: String? = null,
    val songs: List<ScannedSong>
)

data class ArtistItem(
    val name: String,
    val artworkUri: String? = null,
    val songs: List<ScannedSong>
)

data class FolderItem(
    val name: String,
    val path: String,
    val songs: List<ScannedSong>,
    val totalSize: Long
)

data class MusicThemeItem(
    val id: String,
    val name: String,
    val primaryColor: Long = 0xFF00F0FF,
    val backgroundGradient: List<Long> = listOf(0xFF0F172A, 0xFF020617),
    val isDark: Boolean = true
)

class MusicViewModel(
    application: Application,
    private val musicRepository: MusicRepository,
    private val playerManager: MusicPlayerManager,
    private val themeRepository: MusicThemeRepository
) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("vidiopen_music_prefs", android.content.Context.MODE_PRIVATE)

    // Player state from MusicPlayerManager
    val currentPlayingSong: StateFlow<ScannedSong?> = playerManager.currentPlayingSong
    val isPlaying: StateFlow<Boolean> = playerManager.isPlaying
    val currentPosition: StateFlow<Long> = playerManager.currentPosition
    val duration: StateFlow<Long> = playerManager.duration
    val queue: StateFlow<List<ScannedSong>> = playerManager.queue
    val repeatMode: StateFlow<Int> = playerManager.repeatMode

    private val _songs = MutableStateFlow<List<ScannedSong>>(emptyList())
    val songs: StateFlow<List<ScannedSong>> = _songs.asStateFlow()
    val allSongs: StateFlow<List<ScannedSong>> = _songs.asStateFlow()

    private val _albums = MutableStateFlow<List<AlbumItem>>(emptyList())
    val albums: StateFlow<List<AlbumItem>> = _albums.asStateFlow()

    private val _artists = MutableStateFlow<List<ArtistItem>>(emptyList())
    val artists: StateFlow<List<ArtistItem>> = _artists.asStateFlow()

    private val _folders = MutableStateFlow<List<FolderItem>>(emptyList())
    val folders: StateFlow<List<FolderItem>> = _folders.asStateFlow()

    private val _moodPlaylists = MutableStateFlow<Map<MoodCategory, List<ScannedSong>>>(emptyMap())
    val moodPlaylists: StateFlow<Map<MoodCategory, List<ScannedSong>>> = _moodPlaylists.asStateFlow()

    private val _selectedMoodFilter = MutableStateFlow<String?>(null)
    val selectedMoodFilter: StateFlow<String?> = _selectedMoodFilter.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    // Shake Detector
    private val shakeDetector = com.vidiopen.player.player.ShakeDetector(application).apply {
        setOnShakeListener {
            if (_shakeToChangeEnabled.value) {
                playerManager.next()
            }
        }
    }

    // Themes
    private val defaultThemes = listOf(
        MusicThemeItem("cosmic_nebula", "Cosmic Nebula", 0xFF00F0FF, listOf(0xFF080016, 0xFF00030A)),
        MusicThemeItem("cyberpunk_neon", "Cyberpunk Wave", 0xFFFF007F, listOf(0xFF150028, 0xFF020006)),
        MusicThemeItem("emerald_aurora", "Aurora Borealis", 0xFF00FFB2, listOf(0xFF001217, 0xFF000306)),
        MusicThemeItem("vinyl_pulse", "Retro Vinyl Pulse", 0xFFFF9100, listOf(0xFF1C0D03, 0xFF040200)),
        MusicThemeItem("ocean_abyss", "Ocean Abyss", 0xFF00E5FF, listOf(0xFF00192F, 0xFF00050B)),
        MusicThemeItem("sunset_dream", "Sunset Dream", 0xFFFF5376, listOf(0xFF330C3E, 0xFF0D0114)),
        MusicThemeItem("quantum_vortex", "Quantum Vortex", 0xFFE040FB, listOf(0xFF16002A, 0xFF030008)),
        MusicThemeItem("digital_matrix", "Digital Matrix", 0xFF00FF66, listOf(0xFF01180A, 0xFF000401)),
        MusicThemeItem("hyper_lumina", "Hyperdrive Lumina", 0xFF00F0FF, listOf(0xFF07001C, 0xFF000412)),
        MusicThemeItem("fire_phoenix", "Inferno Phoenix", 0xFFFF3D00, listOf(0xFF280600, 0xFF0A0100)),
        MusicThemeItem("custom_image", "Custom Wallpaper", 0xFF00F0FF, listOf(0x00000000, 0x00000000))
    )

    private val _currentTheme = MutableStateFlow(defaultThemes.first())
    val currentTheme: StateFlow<MusicThemeItem> = _currentTheme.asStateFlow()

    private val _customThemeImageUri = MutableStateFlow<String?>(null)
    val customThemeImageUri: StateFlow<String?> = _customThemeImageUri.asStateFlow()

    // Favorites & Playback settings
    private val _favoriteSongIds = MutableStateFlow<Set<Long>>(emptySet())
    val favoriteSongIds: StateFlow<Set<Long>> = _favoriteSongIds.asStateFlow()

    private val _shuffleModeEnabled = MutableStateFlow(false)
    val shuffleModeEnabled: StateFlow<Boolean> = _shuffleModeEnabled.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    // Audio effects
    private val _eqEnabled = MutableStateFlow(prefs.getBoolean("eq_enabled", true))
    val eqEnabled: StateFlow<Boolean> = _eqEnabled.asStateFlow()

    private val _eqBands = MutableStateFlow(listOf(0, 0, 0, 0, 0))
    val eqBands: StateFlow<List<Int>> = _eqBands.asStateFlow()

    private val _selectedPreset = MutableStateFlow(prefs.getString("eq_preset", "Normal") ?: "Normal")
    val selectedPreset: StateFlow<String> = _selectedPreset.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(prefs.getInt("bass_boost", 0))
    val bassBoostStrength: StateFlow<Int> = _bassBoostStrength.asStateFlow()

    private val _virtualizerStrength = MutableStateFlow(prefs.getInt("virtualizer", 0))
    val virtualizerStrength: StateFlow<Int> = _virtualizerStrength.asStateFlow()

    private val _reverbPreset = MutableStateFlow("None")
    val reverbPreset: StateFlow<String> = _reverbPreset.asStateFlow()

    private val _vocalRemoverEnabled = MutableStateFlow(false)
    val vocalRemoverEnabled: StateFlow<Boolean> = _vocalRemoverEnabled.asStateFlow()

    private val _shakeToChangeEnabled = MutableStateFlow(prefs.getBoolean("shake_to_change", false))
    val shakeToChangeEnabled: StateFlow<Boolean> = _shakeToChangeEnabled.asStateFlow()

    private val _shakeSensitivityLevel = MutableStateFlow(prefs.getString("shake_sensitivity_level", "MEDIUM") ?: "MEDIUM")
    val shakeSensitivityLevel: StateFlow<String> = _shakeSensitivityLevel.asStateFlow()

    private val _edgeLightingEnabled = MutableStateFlow(prefs.getBoolean("edge_lighting_enabled", true))
    val edgeLightingEnabled: StateFlow<Boolean> = _edgeLightingEnabled.asStateFlow()

    private val _edgeLightingStyle = MutableStateFlow(prefs.getString("edge_lighting_style", "NEON_BEAT") ?: "NEON_BEAT")
    val edgeLightingStyle: StateFlow<String> = _edgeLightingStyle.asStateFlow()

    private val _edgeLightingIntensity = MutableStateFlow(prefs.getFloat("edge_lighting_intensity", 1.0f))
    val edgeLightingIntensity: StateFlow<Float> = _edgeLightingIntensity.asStateFlow()

    private val _edgeLightingThickness = MutableStateFlow(prefs.getFloat("edge_lighting_thickness", 6.0f))
    val edgeLightingThickness: StateFlow<Float> = _edgeLightingThickness.asStateFlow()

    private val _edgeLightingSpeed = MutableStateFlow(prefs.getFloat("edge_lighting_speed", 1.0f))
    val edgeLightingSpeed: StateFlow<Float> = _edgeLightingSpeed.asStateFlow()

    private val _edgeLightingBeatPulse = MutableStateFlow(prefs.getBoolean("edge_lighting_beat_pulse", true))
    val edgeLightingBeatPulse: StateFlow<Boolean> = _edgeLightingBeatPulse.asStateFlow()

    private val _edgeLightingAlbumArtSync = MutableStateFlow(prefs.getBoolean("edge_lighting_album_art_sync", false))
    val edgeLightingAlbumArtSync: StateFlow<Boolean> = _edgeLightingAlbumArtSync.asStateFlow()

    private val _edgeLightingAnimationMode = MutableStateFlow(prefs.getString("edge_lighting_anim_mode", "SWEEP_ROTATION") ?: "SWEEP_ROTATION")
    val edgeLightingAnimationMode: StateFlow<String> = _edgeLightingAnimationMode.asStateFlow()

    fun setEdgeLightingEnabled(enabled: Boolean) {
        _edgeLightingEnabled.value = enabled
        prefs.edit().putBoolean("edge_lighting_enabled", enabled).apply()
    }

    fun setEdgeLightingStyle(style: String) {
        _edgeLightingStyle.value = style
        prefs.edit().putString("edge_lighting_style", style).apply()
    }

    fun setEdgeLightingAnimationMode(mode: String) {
        _edgeLightingAnimationMode.value = mode
        prefs.edit().putString("edge_lighting_anim_mode", mode).apply()
    }

    fun setEdgeLightingIntensity(intensity: Float) {
        _edgeLightingIntensity.value = intensity
        prefs.edit().putFloat("edge_lighting_intensity", intensity).apply()
    }

    fun setEdgeLightingThickness(thickness: Float) {
        _edgeLightingThickness.value = thickness
        prefs.edit().putFloat("edge_lighting_thickness", thickness).apply()
    }

    fun setEdgeLightingSpeed(speed: Float) {
        _edgeLightingSpeed.value = speed
        prefs.edit().putFloat("edge_lighting_speed", speed).apply()
    }

    fun setEdgeLightingBeatPulse(enabled: Boolean) {
        _edgeLightingBeatPulse.value = enabled
        prefs.edit().putBoolean("edge_lighting_beat_pulse", enabled).apply()
    }

    fun setEdgeLightingAlbumArtSync(enabled: Boolean) {
        _edgeLightingAlbumArtSync.value = enabled
        prefs.edit().putBoolean("edge_lighting_album_art_sync", enabled).apply()
    }

    private val _sleepTimerMode = MutableStateFlow("OFF")
    val sleepTimerMode: StateFlow<String> = _sleepTimerMode.asStateFlow()

    private val _sleepTimerRemaining = MutableStateFlow(0L)
    val sleepTimerRemaining: StateFlow<Long> = _sleepTimerRemaining.asStateFlow()

    private var sleepTimerJob: Job? = null

    init {
        applySensitivityLevel(_shakeSensitivityLevel.value)
        viewModelScope.launch {
            themeRepository.selectedThemeId.collect { id ->
                val normalizedId = when (id) {
                    "moonlight_night" -> "cosmic_nebula"
                    "sunset_gold" -> "sunset_dream"
                    "royal_amethyst" -> "quantum_vortex"
                    else -> id
                }
                _currentTheme.value = defaultThemes.find { it.id == normalizedId } ?: defaultThemes.first()
            }
        }
        viewModelScope.launch {
            themeRepository.customThemeImageUri.collect { uri ->
                _customThemeImageUri.value = uri
            }
        }
        if (_shakeToChangeEnabled.value) {
            shakeDetector.startListening()
        }
        scanMusicFiles(forceRefresh = false)
    }

    fun setShakeToChangeEnabled(enabled: Boolean) {
        _shakeToChangeEnabled.value = enabled
        prefs.edit().putBoolean("shake_to_change", enabled).apply()
        if (enabled) {
            applySensitivityLevel(_shakeSensitivityLevel.value)
            shakeDetector.startListening()
        } else {
            shakeDetector.stopListening()
        }
    }

    fun setShakeSensitivityLevel(level: String) {
        _shakeSensitivityLevel.value = level
        prefs.edit().putString("shake_sensitivity_level", level).apply()
        applySensitivityLevel(level)
    }

    private fun applySensitivityLevel(level: String) {
        when (level) {
            "GENTLE" -> {
                shakeDetector.sensitivity = 1.35f
                shakeDetector.deltaThreshold = 8.0f
            }
            "FIRM" -> {
                shakeDetector.sensitivity = 2.05f
                shakeDetector.deltaThreshold = 15.0f
            }
            else -> { // "MEDIUM"
                shakeDetector.sensitivity = 1.65f
                shakeDetector.deltaThreshold = 11.0f
            }
        }
    }

    fun triggerSimulatedShake() {
        shakeDetector.triggerHapticFeedback()
        playerManager.next()
    }

    fun toggleShakeToChange() {
        setShakeToChangeEnabled(!_shakeToChangeEnabled.value)
    }

    fun scanMusicFiles(forceRefresh: Boolean = false) {
        viewModelScope.launch {
            _isScanning.value = true
            try {
                // Fetch cached songs first if available so UI doesn't delay
                val initialCached = musicRepository.getCachedSongs()
                if (initialCached.isNotEmpty() && _songs.value.isEmpty()) {
                    _songs.value = initialCached
                    updateGroupings(initialCached)
                    playerManager.syncScannedSongs(initialCached)
                }

                // Scan in background IO thread
                val scanned = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    musicRepository.scanAudio(forceRefresh = forceRefresh)
                }
                _songs.value = scanned
                updateGroupings(scanned)
                playerManager.syncScannedSongs(scanned)
            } catch (e: Exception) {
                timber.log.Timber.e(e, "Error scanning music files")
            } finally {
                _isScanning.value = false
            }
        }
    }

    private fun updateGroupings(songs: List<ScannedSong>) {
        // Group albums
        val albumGroups = songs.groupBy { it.album ?: "Unknown Album" }
            .map { (albumName, albumSongs) ->
                AlbumItem(
                    name = albumName,
                    artist = albumSongs.firstOrNull()?.artist ?: "Unknown Artist",
                    artworkUri = albumSongs.firstOrNull()?.albumArtUri,
                    songs = albumSongs
                )
            }
        _albums.value = albumGroups

        // Group artists
        val artistGroups = songs.groupBy { it.artist ?: "Unknown Artist" }
            .map { (artistName, artistSongs) ->
                ArtistItem(
                    name = artistName,
                    artworkUri = artistSongs.firstOrNull()?.albumArtUri,
                    songs = artistSongs
                )
            }
        _artists.value = artistGroups

        // Group mood categories
        val moodMap = MoodCategory.entries.associateWith { category ->
            songs.filter { song ->
                val text = "${song.title} ${song.artist.orEmpty()} ${song.album.orEmpty()}".lowercase()
                category.keywords.any { kw -> text.contains(kw) }
            }
        }
        _moodPlaylists.value = moodMap

        // Group folders
        val folderGroups = songs.groupBy { File(it.path).parent ?: "Music" }
            .map { (path, folderSongs) ->
                FolderItem(
                    name = path.substringAfterLast('/'),
                    path = path,
                    songs = folderSongs,
                    totalSize = folderSongs.sumOf { it.size }
                )
            }
        _folders.value = folderGroups
    }

    override fun onCleared() {
        super.onCleared()
        shakeDetector.stopListening()
    }

    fun playSong(song: ScannedSong, newQueue: List<ScannedSong> = emptyList()) {
        val q = if (newQueue.isNotEmpty()) newQueue else _songs.value
        playerManager.playSong(song, q)
    }

    fun playNext(song: ScannedSong) {
        playerManager.playNext(song)
    }

    fun togglePlayPause() {
        playerManager.togglePlayPause()
    }

    fun pause() {
        playerManager.pause()
    }

    fun next() {
        playerManager.next()
    }

    fun previous() {
        playerManager.previous()
    }

    fun seekTo(positionMs: Long) {
        playerManager.seekTo(positionMs)
    }

    fun toggleFavorite(songId: Long) {
        val current = _favoriteSongIds.value.toMutableSet()
        if (current.contains(songId)) {
            current.remove(songId)
        } else {
            current.add(songId)
        }
        _favoriteSongIds.value = current
    }

    fun setRepeatMode(mode: Int) {
        playerManager.setRepeatMode(mode)
    }

    fun setShuffleMode(enabled: Boolean) {
        _shuffleModeEnabled.value = enabled
        playerManager.setShuffleMode(enabled)
    }

    fun clearQueue() {
        playerManager.clearQueue()
    }

    fun removeFromQueue(index: Int) {
        queue.value.getOrNull(index)?.let { song ->
            playerManager.removeFromQueue(song.id)
        }
    }

    fun closePlayer() {
        playerManager.closePlayer()
    }

    fun selectTheme(themeId: String) {
        viewModelScope.launch {
            themeRepository.saveSelectedThemeId(themeId)
        }
    }

    fun setCustomThemeImage(uri: String?) {
        viewModelScope.launch {
            themeRepository.saveCustomThemeImageUri(uri)
        }
    }

    fun setMoodFilter(mood: String?) {
        _selectedMoodFilter.value = mood
    }

    fun setMoodFilter(mood: MoodCategory?) {
        _selectedMoodFilter.value = mood?.id
    }

    fun playMood(mood: String) {
        val category = MoodCategory.entries.find { it.id == mood }
        val moodSongs = (_moodPlaylists.value[category] ?: _songs.value)
        if (moodSongs.isNotEmpty()) {
            playSong(moodSongs.first(), moodSongs)
        }
    }

    fun playMood(mood: MoodCategory) {
        val moodSongs = _moodPlaylists.value[mood] ?: _songs.value
        if (moodSongs.isNotEmpty()) {
            playSong(moodSongs.first(), moodSongs)
        }
    }

    fun shuffleMood(mood: String) {
        val category = MoodCategory.entries.find { it.id == mood }
        val moodSongs = (_moodPlaylists.value[category] ?: _songs.value).shuffled()
        if (moodSongs.isNotEmpty()) {
            setShuffleMode(true)
            playSong(moodSongs.first(), moodSongs)
        }
    }

    fun shuffleMood(mood: MoodCategory) {
        val moodSongs = (_moodPlaylists.value[mood] ?: _songs.value).shuffled()
        if (moodSongs.isNotEmpty()) {
            setShuffleMode(true)
            playSong(moodSongs.first(), moodSongs)
        }
    }

    fun setEqEnabled(enabled: Boolean) {
        _eqEnabled.value = enabled
        prefs.edit().putBoolean("eq_enabled", enabled).apply()
        playerManager.audioEffectsManager.setEqualizerEnabled(enabled)
    }

    fun setEqBand(band: Int, level: Int) {
        val bands = _eqBands.value.toMutableList()
        if (band in bands.indices) {
            bands[band] = level
            _eqBands.value = bands
            playerManager.audioEffectsManager.setBandLevel(band.toShort(), level.toShort())
        }
    }

    fun selectPreset(preset: String) {
        _selectedPreset.value = preset
        prefs.edit().putString("eq_preset", preset).apply()
        playerManager.audioEffectsManager.usePreset(preset)
    }

    fun setBassBoostEnabled(enabled: Boolean) {
        playerManager.audioEffectsManager.bassBoostEnabled = enabled
    }

    fun setBassBoostStrength(strength: Int) {
        _bassBoostStrength.value = strength
        prefs.edit().putInt("bass_boost", strength).apply()
        playerManager.audioEffectsManager.bassBoostStrength = strength
    }

    fun setVirtualizerEnabled(enabled: Boolean) {
        playerManager.audioEffectsManager.virtualizerEnabled = enabled
    }

    fun setVirtualizerStrength(strength: Int) {
        _virtualizerStrength.value = strength
        prefs.edit().putInt("virtualizer", strength).apply()
        playerManager.audioEffectsManager.virtualizerStrength = strength
    }

    fun setSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes <= 0) {
            _sleepTimerMode.value = "OFF"
            _sleepTimerRemaining.value = 0L
            return
        }
        _sleepTimerMode.value = "${minutes}m"
        val totalMs = minutes * 60 * 1000L
        _sleepTimerRemaining.value = totalMs
        sleepTimerJob = viewModelScope.launch {
            var rem = totalMs
            while (rem > 0) {
                delay(1000)
                rem -= 1000
                _sleepTimerRemaining.value = rem
            }
            playerManager.pause()
            _sleepTimerMode.value = "OFF"
        }
    }

    fun setSleepTimerEndOfSong() {
        _sleepTimerMode.value = "END_OF_SONG"
    }

    // ID3 Tag & Cover Photo Editor feature implementation
    fun updateSongTags(
        songId: Long,
        newTitle: String,
        newArtist: String,
        newAlbum: String,
        newArtworkUri: String?
    ) {
        viewModelScope.launch {
            val list = _songs.value.map { song ->
                if (song.id == songId) {
                    song.copy(
                        title = newTitle.ifBlank { song.title },
                        artist = newArtist.ifBlank { song.artist },
                        album = newAlbum.ifBlank { song.album },
                        artworkUri = newArtworkUri ?: song.artworkUri
                    )
                } else song
            }
            _songs.value = list
            // If current playing song is updated, update active item
            if (currentPlayingSong.value?.id == songId) {
                list.find { it.id == songId }?.let { updated ->
                    playerManager.updateCurrentSongMetadata(updated)
                }
            }
        }
    }
}

class MusicViewModelFactory(
    private val application: Application,
    private val musicRepository: MusicRepository,
    private val playerManager: MusicPlayerManager,
    private val themeRepository: MusicThemeRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MusicViewModel::class.java)) {
            return MusicViewModel(application, musicRepository, playerManager, themeRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
