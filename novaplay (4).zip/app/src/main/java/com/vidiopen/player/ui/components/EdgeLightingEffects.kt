package com.vidiopen.player.ui.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.vidiopen.player.data.model.ScannedSong
import com.vidiopen.player.ui.viewmodel.MusicViewModel
import com.vidiopen.player.utils.AudioArtworkUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

/**
 * Data class representing a curated Edge Lighting Preset.
 */
data class EdgeLightingPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val previewColors: List<Color>,
    val badge: String? = null
)

val EdgeLightingPresets = listOf(
    EdgeLightingPreset(
        id = "ALBUM_ART_SYNC",
        name = "Album Art Sync",
        subtitle = "Auto-matches current track artwork",
        previewColors = listOf(Color(0xFFFF0844), Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF0844)),
        badge = "✨ DYNAMIC"
    ),
    EdgeLightingPreset(
        id = "NEON_BEAT",
        name = "Neon Beat",
        subtitle = "Electric Cyan, Violet & Hot Pink",
        previewColors = listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF2E93), Color(0xFF00F0FF)),
        badge = "🔥 POPULAR"
    ),
    EdgeLightingPreset(
        id = "CYBER_PULSE",
        name = "Cyber Pulse",
        subtitle = "Cyberpunk Magenta & Neon Aqua",
        previewColors = listOf(Color(0xFFFF007F), Color(0xFF00F0FF), Color(0xFF7928CA), Color(0xFFFF007F)),
        badge = "⚡ RAVE"
    ),
    EdgeLightingPreset(
        id = "GOLDEN_SUNSET",
        name = "Golden Sunset",
        subtitle = "Warm Amber, Crimson & Solar Gold",
        previewColors = listOf(Color(0xFFFF9100), Color(0xFFFF0055), Color(0xFFFFD600), Color(0xFFFF9100))
    ),
    EdgeLightingPreset(
        id = "EMERALD_FLOW",
        name = "Emerald Aurora",
        subtitle = "Vibrant Emerald, Mint & Cyan",
        previewColors = listOf(Color(0xFF00E676), Color(0xFF00B0FF), Color(0xFF1DE9B6), Color(0xFF00E676))
    ),
    EdgeLightingPreset(
        id = "COSMIC_VORTEX",
        name = "Cosmic Vortex",
        subtitle = "Deep Violet, Magenta & Electric Indigo",
        previewColors = listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFF00F2FE), Color(0xFF8A2387))
    ),
    EdgeLightingPreset(
        id = "RUBY_BLAZE",
        name = "Ruby Blaze",
        subtitle = "Crimson Red, Orange & Coral Fire",
        previewColors = listOf(Color(0xFFFF1744), Color(0xFFFF5252), Color(0xFFFF9100), Color(0xFFFF1744))
    ),
    EdgeLightingPreset(
        id = "ELECTRIC_VIOLET",
        name = "Electric Violet",
        subtitle = "Ultra Violet, Indigo & Electric Blue",
        previewColors = listOf(Color(0xFF8A2BE2), Color(0xFF00F0FF), Color(0xFFE040FB), Color(0xFF8A2BE2)),
        badge = "⚡ ULTRA"
    ),
    EdgeLightingPreset(
        id = "RAINBOW_SPECTRUM",
        name = "Rainbow Prism",
        subtitle = "Full 360 Spectrum RGB Concert Flow",
        previewColors = listOf(Color(0xFFFF0055), Color(0xFFFF9900), Color(0xFFFFEE00), Color(0xFF00FF66), Color(0xFF00F0FF), Color(0xFFBD00FF)),
        badge = "🌈 SPECTRUM"
    ),
    EdgeLightingPreset(
        id = "FIRE_AND_ICE",
        name = "Fire & Ice Dual",
        subtitle = "Blazing Cyan vs Scorching Crimson Duel",
        previewColors = listOf(Color(0xFF00F0FF), Color(0xFFFF2A6D), Color(0xFF05D9E8), Color(0xFFFF5E00)),
        badge = "❄️🔥 DUAL"
    )
)

data class EdgeAnimationPreset(
    val id: String,
    val name: String,
    val subtitle: String,
    val emoji: String,
    val badge: String? = null
)

val EdgeAnimationPresets = listOf(
    EdgeAnimationPreset(
        id = "SWEEP_ROTATION",
        name = "Laser Sweep",
        subtitle = "Continuous 360° laser sweep border",
        emoji = "🔄",
        badge = "DEFAULT"
    ),
    EdgeAnimationPreset(
        id = "PULSE_WAVE",
        name = "Bass Pulse Wave",
        subtitle = "Deep breathing neon glow synced to beat",
        emoji = "💓",
        badge = "BASS"
    ),
    EdgeAnimationPreset(
        id = "CHASING_COMET",
        name = "Chasing Comets",
        subtitle = "Twin luminous neon comets orbiting screen",
        emoji = "☄️",
        badge = "HYPER"
    ),
    EdgeAnimationPreset(
        id = "CORNER_BURST",
        name = "Quad Corner Beams",
        subtitle = "Pulsating energy flares from 4 corners",
        emoji = "💥"
    ),
    EdgeAnimationPreset(
        id = "DUAL_ORBIT",
        name = "Dual Collision Orbit",
        subtitle = "Clockwise & counter-clockwise collision orbs",
        emoji = "🪐"
    ),
    EdgeAnimationPreset(
        id = "EQUALIZER_BARS",
        name = "Border Audio Bars",
        subtitle = "Dynamic audio frequency bars on all 4 edges",
        emoji = "📊",
        badge = "AUDIO"
    ),
    EdgeAnimationPreset(
        id = "STAR_SPARKLE",
        name = "Cosmic Sparkles",
        subtitle = "Glittering diamond sparks and starbursts",
        emoji = "✨"
    ),
    EdgeAnimationPreset(
        id = "LASER_STROBE",
        name = "Concert Strobe",
        subtitle = "Rhythmic club strobe flashes on borders",
        emoji = "⚡"
    ),
    EdgeAnimationPreset(
        id = "LIQUID_WAVE",
        name = "Liquid Wave Ripple",
        subtitle = "Undulating ocean fluid sine waves flowing",
        emoji = "🌊"
    ),
    EdgeAnimationPreset(
        id = "INFERNO_FLAME",
        name = "Inferno Fire Border",
        subtitle = "Blazing neon fire tongues licking borders",
        emoji = "🔥",
        badge = "HOT"
    )
)

/**
 * Dynamically derives high-vibrance neon glow colors from the current playing song.
 * Uses album artwork bytes or metadata-derived curated palettes.
 */
@Composable
fun rememberDynamicAlbumArtColors(song: ScannedSong?): List<Color> {
    val context = LocalContext.current
    val fallbackColors = remember(song?.id) {
        if (song != null) {
            val paletteIndex = kotlin.math.abs((song.id.hashCode() * 31 + song.title.hashCode())) % ThumbnailArtworkGradients.size
            val baseList = ThumbnailArtworkGradients[paletteIndex]
            if (baseList.size >= 2) {
                listOf(baseList[0], baseList[1], if (baseList.size > 2) baseList[2] else baseList[0], baseList[0])
            } else {
                listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF2E93), Color(0xFF00F0FF))
            }
        } else {
            listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF2E93), Color(0xFF00F0FF))
        }
    }

    var extractedColors by remember(song?.id, song?.artworkUri) { mutableStateOf<List<Color>?>(null) }

    LaunchedEffect(song?.id, song?.artworkUri) {
        if (song == null) {
            extractedColors = null
            return@LaunchedEffect
        }
        withContext(Dispatchers.IO) {
            try {
                var bmp: Bitmap? = null
                val bytes = AudioArtworkUtil.getArtworkByteArray(context, song)
                if (bytes != null && bytes.isNotEmpty()) {
                    val opts = BitmapFactory.Options().apply { inSampleSize = 4 }
                    bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                }
                if (bmp != null) {
                    val w = bmp.width
                    val h = bmp.height
                    val sampled = mutableListOf<Color>()
                    val samplePoints = listOf(
                        w / 4 to h / 4,
                        (3 * w) / 4 to h / 4,
                        w / 2 to h / 2,
                        w / 4 to (3 * h) / 4,
                        (3 * w) / 4 to (3 * h) / 4
                    )
                    for ((x, y) in samplePoints) {
                        if (x in 0 until w && y in 0 until h) {
                            val pixel = bmp.getPixel(x, y)
                            val r = android.graphics.Color.red(pixel)
                            val g = android.graphics.Color.green(pixel)
                            val b = android.graphics.Color.blue(pixel)
                            val hsv = FloatArray(3)
                            android.graphics.Color.RGBToHSV(r, g, b, hsv)
                            // Boost saturation and brightness for vivid luminescence
                            hsv[1] = (hsv[1] * 1.35f).coerceIn(0.75f, 1.0f)
                            hsv[2] = (hsv[2] * 1.25f).coerceIn(0.85f, 1.0f)
                            val neonPixel = android.graphics.Color.HSVToColor(hsv)
                            sampled.add(Color(neonPixel))
                        }
                    }
                    if (sampled.size >= 2) {
                        val c1 = sampled[0]
                        val c2 = sampled.getOrElse(1) { sampled[0] }
                        val c3 = sampled.getOrElse(2) { sampled[0] }
                        extractedColors = listOf(c1, c2, c3, c1)
                    }
                }
            } catch (_: Throwable) {
                // Fallback will be used safely
            }
        }
    }

    return extractedColors ?: fallbackColors
}

/**
 * Premium Edge Lighting screen border overlay.
 * Features rotating neon sweep gradients, multi-layer ambient halos,
 * customizable thickness and flow speed, and Audio Beat-Reactive Pulse.
 */
@Composable
fun EdgeLightingOverlay(
    isPlaying: Boolean,
    style: String = "NEON_BEAT",
    animationMode: String = "SWEEP_ROTATION",
    intensity: Float = 1.0f,
    thickness: Float = 6.0f,
    speed: Float = 1.0f,
    beatPulse: Boolean = true,
    albumArtSync: Boolean = false,
    song: ScannedSong? = null,
    cornerRadius: Dp = 0.dp,
    modifier: Modifier = Modifier
) {
    if (!isPlaying) return

    val effectiveSpeed = speed.coerceIn(0.4f, 3.0f)
    val effectiveThickness = thickness.coerceIn(2.0f, 14.0f)
    val effectiveIntensity = intensity.coerceIn(0.4f, 2.0f)

    // Smooth continuous gradient rotation
    val infiniteTransition = rememberInfiniteTransition(label = "edge_lighting_rotation")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = (2200 / effectiveSpeed).toInt().coerceAtLeast(350),
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    // Audio Beat-reactive pulse cycle (~125 BPM rhythm envelope)
    val beatTransition = rememberInfiniteTransition(label = "edge_lighting_beat")
    val beatCycle by beatTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 480, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "beatCycle"
    )

    val dynamicAlbumColors = rememberDynamicAlbumArtColors(song)

    val colors = remember(style, albumArtSync, dynamicAlbumColors) {
        when {
            albumArtSync || style == "ALBUM_ART_SYNC" -> dynamicAlbumColors
            style == "CYBER_PULSE" -> listOf(Color(0xFFFF007F), Color(0xFF00F0FF), Color(0xFF7928CA), Color(0xFFFF007F))
            style == "GOLDEN_SUNSET" -> listOf(Color(0xFFFF9100), Color(0xFFFF0055), Color(0xFFFFD600), Color(0xFFFF9100))
            style == "EMERALD_FLOW" -> listOf(Color(0xFF00E676), Color(0xFF00B0FF), Color(0xFF1DE9B6), Color(0xFF00E676))
            style == "COSMIC_VORTEX" -> listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFF00F2FE), Color(0xFF8A2387))
            style == "RUBY_BLAZE" -> listOf(Color(0xFFFF1744), Color(0xFFFF5252), Color(0xFFFF9100), Color(0xFFFF1744))
            style == "ELECTRIC_VIOLET" -> listOf(Color(0xFF8A2BE2), Color(0xFF00F0FF), Color(0xFFE040FB), Color(0xFF8A2BE2))
            style == "RAINBOW_SPECTRUM" -> listOf(Color(0xFFFF0055), Color(0xFFFF9900), Color(0xFFFFEE00), Color(0xFF00FF66), Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF0055))
            style == "FIRE_AND_ICE" -> listOf(Color(0xFF00F0FF), Color(0xFFFF2A6D), Color(0xFF05D9E8), Color(0xFFFF5E00), Color(0xFF00F0FF))
            else -> listOf(Color(0xFF00F0FF), Color(0xFFBD00FF), Color(0xFFFF2E93), Color(0xFF00F0FF))
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(cornerRadius))
    ) {
        // Natural musical kick-decay envelope computed during Draw Phase (0 recomposition cost)
        val currentBeat = beatCycle
        val rawPulse = if (currentBeat < 0.2f) {
            (currentBeat / 0.2f)
        } else if (currentBeat < 0.5f) {
            1f - ((currentBeat - 0.2f) / 0.3f) * 0.7f
        } else if (currentBeat < 0.65f) {
            0.3f + ((currentBeat - 0.5f) / 0.15f) * 0.4f
        } else {
            0.7f - ((currentBeat - 0.65f) / 0.35f) * 0.7f
        }

        val pulseScale = if (beatPulse) (1.0f + (rawPulse * 0.26f * effectiveIntensity)) else 1.0f
        val pulseAlpha = if (beatPulse) (0.80f + (rawPulse * 0.20f)).coerceIn(0f, 1f) else 1.0f

        val baseStrokeWidth = effectiveThickness.dp.toPx()
        val coreStrokeWidth = baseStrokeWidth * pulseScale
        val center = Offset(size.width / 2f, size.height / 2f)
        val cr = CornerRadius(cornerRadius.toPx(), cornerRadius.toPx())

        val brush = Brush.sweepGradient(
            colors = colors,
            center = center
        )

        when (animationMode) {
            "PULSE_WAVE" -> {
                // Expanding breathing glow
                val waveScale = 1.0f + 0.55f * kotlin.math.sin(phase * 2.0 * Math.PI).toFloat() * effectiveIntensity
                val strokeW = coreStrokeWidth * waveScale
                val halfW = strokeW / 2f
                val insetSize = Size((size.width - strokeW).coerceAtLeast(1f), (size.height - strokeW).coerceAtLeast(1f))
                val waveBrush = Brush.linearGradient(colors = colors, start = Offset.Zero, end = Offset(size.width, size.height))
                drawRoundRect(
                    brush = waveBrush,
                    topLeft = Offset(halfW * 1.5f, halfW * 1.5f),
                    size = Size((size.width - strokeW * 1.5f).coerceAtLeast(1f), (size.height - strokeW * 1.5f).coerceAtLeast(1f)),
                    cornerRadius = cr,
                    style = Stroke(width = strokeW * 1.8f),
                    alpha = (0.32f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                )
                drawRoundRect(
                    brush = waveBrush,
                    topLeft = Offset(halfW, halfW),
                    size = insetSize,
                    cornerRadius = cr,
                    style = Stroke(width = strokeW),
                    alpha = (0.95f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                )
            }
            "CHASING_COMET" -> {
                // Base subtle border track
                drawRoundRect(
                    color = colors.first().copy(alpha = 0.20f),
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth * 0.6f)
                )
                // Two racing comets around rectangular perimeter
                val perimeter = 2f * (size.width + size.height)
                fun getPointOnRect(distance: Float): Offset {
                    val d = (distance % perimeter + perimeter) % perimeter
                    return when {
                        d < size.width -> Offset(d, 0f)
                        d < size.width + size.height -> Offset(size.width, d - size.width)
                        d < 2f * size.width + size.height -> Offset(size.width - (d - (size.width + size.height)), size.height)
                        else -> Offset(0f, size.height - (d - (2f * size.width + size.height)))
                    }
                }
                for (cometIdx in 0..1) {
                    val baseDist = ((phase + cometIdx * 0.5f) % 1f) * perimeter
                    val cometColor = colors.getOrElse(cometIdx * 2) { colors.first() }
                    for (t in 0..10) {
                        val tailDist = baseDist - t * (perimeter * 0.012f)
                        val pos = getPointOnRect(tailDist)
                        val tailAlpha = (1f - (t / 11f)) * 0.85f * effectiveIntensity * pulseAlpha
                        val radius = (coreStrokeWidth * (1.6f - t * 0.1f)).coerceAtLeast(2f)
                        drawCircle(
                            color = cometColor.copy(alpha = tailAlpha.coerceIn(0f, 1f)),
                            radius = radius,
                            center = pos
                        )
                    }
                    val headPos = getPointOnRect(baseDist)
                    drawCircle(color = Color.White, radius = coreStrokeWidth * 1.2f, center = headPos)
                }
            }
            "CORNER_BURST" -> {
                val corners = listOf(
                    Offset(0f, 0f),
                    Offset(size.width, 0f),
                    Offset(0f, size.height),
                    Offset(size.width, size.height)
                )
                corners.forEachIndexed { idx, corner ->
                    val color = colors.getOrElse(idx % colors.size) { colors.first() }
                    for (ring in 0..2) {
                        val ringProgress = ((rawPulse + ring * 0.33f) % 1f)
                        val radius = ringProgress * (size.width * 0.35f)
                        val alpha = (1f - ringProgress) * 0.75f * effectiveIntensity * pulseAlpha
                        drawCircle(
                            color = color.copy(alpha = alpha.coerceIn(0f, 1f)),
                            radius = radius,
                            center = corner,
                            style = Stroke(width = coreStrokeWidth * (1.5f - ringProgress))
                        )
                    }
                }
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth * 0.8f),
                    alpha = (0.5f * effectiveIntensity).coerceIn(0f, 1f)
                )
            }
            "DUAL_ORBIT" -> {
                val perimeter = 2f * (size.width + size.height)
                fun getPointOnRect(distance: Float): Offset {
                    val d = (distance % perimeter + perimeter) % perimeter
                    return when {
                        d < size.width -> Offset(d, 0f)
                        d < size.width + size.height -> Offset(size.width, d - size.width)
                        d < 2f * size.width + size.height -> Offset(size.width - (d - (size.width + size.height)), size.height)
                        else -> Offset(0f, size.height - (d - (2f * size.width + size.height)))
                    }
                }
                val orb1Dist = (phase % 1f) * perimeter
                val orb2Dist = ((1f - phase) % 1f) * perimeter
                val p1 = getPointOnRect(orb1Dist)
                val p2 = getPointOnRect(orb2Dist)

                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth * 0.6f),
                    alpha = (0.35f * effectiveIntensity).coerceIn(0f, 1f)
                )

                val col1 = colors[0]
                drawCircle(color = col1.copy(alpha = 0.4f * effectiveIntensity), radius = coreStrokeWidth * 3f, center = p1)
                drawCircle(color = Color.White, radius = coreStrokeWidth * 1.2f, center = p1)

                val col2 = colors.getOrElse(1) { colors.last() }
                drawCircle(color = col2.copy(alpha = 0.4f * effectiveIntensity), radius = coreStrokeWidth * 3f, center = p2)
                drawCircle(color = Color.White, radius = coreStrokeWidth * 1.2f, center = p2)

                val distBetween = (p1 - p2).getDistance()
                if (distBetween < 80.dp.toPx()) {
                    val mid = (p1 + p2) / 2f
                    drawCircle(
                        brush = Brush.radialGradient(listOf(Color.White, col1, Color.Transparent), center = mid, radius = 60.dp.toPx()),
                        radius = 60.dp.toPx(),
                        center = mid
                    )
                }
            }
            "EQUALIZER_BARS" -> {
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth * 0.7f),
                    alpha = (0.5f * effectiveIntensity).coerceIn(0f, 1f)
                )
                val barsCountH = 18
                val stepX = size.width / (barsCountH + 1)
                for (i in 1..barsCountH) {
                    val barH = (kotlin.math.sin(phase * 6.28f + i * 0.5f) * 0.5f + 0.5f) * (24.dp.toPx() * pulseScale)
                    val bx = i * stepX
                    val color = colors[i % colors.size]
                    drawLine(color = color, start = Offset(bx, 0f), end = Offset(bx, barH), strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawLine(color = color, start = Offset(bx, size.height), end = Offset(bx, size.height - barH), strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                }
                val barsCountV = 22
                val stepY = size.height / (barsCountV + 1)
                for (j in 1..barsCountV) {
                    val barW = (kotlin.math.cos(phase * 6.28f + j * 0.45f) * 0.5f + 0.5f) * (20.dp.toPx() * pulseScale)
                    val by = j * stepY
                    val color = colors[(j + 2) % colors.size]
                    drawLine(color = color, start = Offset(0f, by), end = Offset(barW, by), strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                    drawLine(color = color, start = Offset(size.width, by), end = Offset(size.width - barW, by), strokeWidth = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                }
            }
            "STAR_SPARKLE" -> {
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth * 0.8f),
                    alpha = (0.7f * effectiveIntensity).coerceIn(0f, 1f)
                )
                val starCount = 16
                val perimeter = 2f * (size.width + size.height)
                fun getPointOnRect(d: Float): Offset {
                    val dist = (d % perimeter + perimeter) % perimeter
                    return when {
                        dist < size.width -> Offset(dist, 0f)
                        dist < size.width + size.height -> Offset(size.width, dist - size.width)
                        dist < 2f * size.width + size.height -> Offset(size.width - (dist - (size.width + size.height)), size.height)
                        else -> Offset(0f, size.height - (dist - (2f * size.width + size.height)))
                    }
                }
                for (s in 0 until starCount) {
                    val d = (s.toFloat() / starCount) * perimeter
                    val pt = getPointOnRect(d)
                    val twinkle = (kotlin.math.sin(phase * 12f + s * 1.5f) * 0.5f + 0.5f) * pulseScale
                    val starSize = 5.dp.toPx() * twinkle * effectiveIntensity
                    val starColor = colors[s % colors.size]
                    drawLine(color = Color.White, start = Offset(pt.x - starSize, pt.y), end = Offset(pt.x + starSize, pt.y), strokeWidth = 1.8.dp.toPx())
                    drawLine(color = Color.White, start = Offset(pt.x, pt.y - starSize), end = Offset(pt.x, pt.y + starSize), strokeWidth = 1.8.dp.toPx())
                    drawCircle(color = starColor.copy(alpha = (0.5f * twinkle).coerceIn(0f, 1f)), radius = starSize * 1.5f, center = pt)
                }
            }
            "LASER_STROBE" -> {
                val strobeOn = (phase * 8f).toInt() % 2 == 0
                val strobeIntensity = if (strobeOn) 1.5f else 0.4f
                val strokeW = coreStrokeWidth * (if (strobeOn) 1.8f else 0.8f)
                val halfW = strokeW / 2f
                val inset = Size(size.width - strokeW, size.height - strokeW)
                if (inset.width > 0 && inset.height > 0) {
                    drawRoundRect(
                        brush = brush,
                        topLeft = Offset(halfW, halfW),
                        size = inset,
                        cornerRadius = cr,
                        style = Stroke(width = strokeW),
                        alpha = (0.85f * strobeIntensity * pulseAlpha).coerceIn(0f, 1f)
                    )
                    if (strobeOn) {
                        drawRoundRect(
                            color = Color.White.copy(alpha = 0.5f * pulseAlpha),
                            topLeft = Offset(halfW, halfW),
                            size = inset,
                            cornerRadius = cr,
                            style = Stroke(width = coreStrokeWidth * 0.6f)
                        )
                    }
                }
            }
            "LIQUID_WAVE" -> {
                val wavePath = Path()
                val waveFreq = 0.04f
                val waveAmp = 8.dp.toPx() * pulseScale
                wavePath.moveTo(0f, kotlin.math.sin(phase * 6.28f) * waveAmp + coreStrokeWidth)
                for (x in 0..size.width.toInt() step 15) {
                    val fx = x.toFloat()
                    val y = kotlin.math.sin(fx * waveFreq + phase * 6.28f) * waveAmp + coreStrokeWidth
                    wavePath.lineTo(fx, y)
                }
                for (y in 0..size.height.toInt() step 15) {
                    val fy = y.toFloat()
                    val x = size.width - (kotlin.math.cos(fy * waveFreq + phase * 6.28f) * waveAmp + coreStrokeWidth)
                    wavePath.lineTo(x, fy)
                }
                for (x in size.width.toInt() downTo 0 step 15) {
                    val fx = x.toFloat()
                    val y = size.height - (kotlin.math.sin(fx * waveFreq + phase * 6.28f) * waveAmp + coreStrokeWidth)
                    wavePath.lineTo(fx, y)
                }
                for (y in size.height.toInt() downTo 0 step 15) {
                    val fy = y.toFloat()
                    val x = kotlin.math.cos(fy * waveFreq + phase * 6.28f) * waveAmp + coreStrokeWidth
                    wavePath.lineTo(x, fy)
                }
                wavePath.close()

                drawPath(
                    path = wavePath,
                    brush = brush,
                    style = Stroke(width = coreStrokeWidth * 1.5f),
                    alpha = (0.85f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                )
            }
            "INFERNO_FLAME" -> {
                drawRoundRect(
                    brush = brush,
                    topLeft = Offset(coreStrokeWidth / 2f, coreStrokeWidth / 2f),
                    size = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth),
                    cornerRadius = cr,
                    style = Stroke(width = coreStrokeWidth),
                    alpha = (0.7f * effectiveIntensity).coerceIn(0f, 1f)
                )
                val flameCount = 20
                val stepX = size.width / flameCount
                for (f in 0 until flameCount) {
                    val fx = f * stepX + stepX / 2f
                    val flameH = (kotlin.math.sin(phase * 10f + f * 1.2f) * 0.5f + 0.5f) * (28.dp.toPx() * pulseScale)
                    val flamePath = Path().apply {
                        moveTo(fx - stepX / 2f, size.height)
                        quadraticBezierTo(fx, size.height - flameH, fx, size.height - flameH)
                        quadraticBezierTo(fx, size.height - flameH, fx + stepX / 2f, size.height)
                        close()
                    }
                    drawPath(
                        path = flamePath,
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFFFFD600), Color(0xFFFF3D00).copy(alpha = 0.8f), Color.Transparent),
                            startY = size.height - flameH,
                            endY = size.height
                        ),
                        alpha = (0.8f * pulseAlpha).coerceIn(0f, 1f)
                    )
                }
            }
            else -> {
                // SWEEP_ROTATION
                rotate(degrees = phase * 360f, pivot = center) {
                    val outerStrokeWidth = coreStrokeWidth * 2.3f
                    val outerHalf = outerStrokeWidth / 2f
                    val outerInsetSize = Size(size.width - outerStrokeWidth, size.height - outerStrokeWidth)
                    if (outerInsetSize.width > 0 && outerInsetSize.height > 0) {
                        drawRoundRect(
                            brush = brush,
                            topLeft = Offset(outerHalf, outerHalf),
                            size = outerInsetSize,
                            cornerRadius = cr,
                            style = Stroke(width = outerStrokeWidth),
                            alpha = (0.24f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                        )
                    }

                    val midStrokeWidth = coreStrokeWidth * 1.5f
                    val midHalf = midStrokeWidth / 2f
                    val midInsetSize = Size(size.width - midStrokeWidth, size.height - midStrokeWidth)
                    if (midInsetSize.width > 0 && midInsetSize.height > 0) {
                        drawRoundRect(
                            brush = brush,
                            topLeft = Offset(midHalf, midHalf),
                            size = midInsetSize,
                            cornerRadius = cr,
                            style = Stroke(width = midStrokeWidth),
                            alpha = (0.48f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                        )
                    }

                    val halfCore = coreStrokeWidth / 2f
                    val insetSize = Size(size.width - coreStrokeWidth, size.height - coreStrokeWidth)
                    if (insetSize.width > 0 && insetSize.height > 0) {
                        drawRoundRect(
                            brush = brush,
                            topLeft = Offset(halfCore, halfCore),
                            size = insetSize,
                            cornerRadius = cr,
                            style = Stroke(width = coreStrokeWidth),
                            alpha = (0.95f * effectiveIntensity * pulseAlpha).coerceIn(0f, 1f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * Modern, attractive Edge Lighting customization dialog.
 * Includes interactive live phone preview, Beat-Reactive Pulse switch,
 * Album Art Auto-Coloring toggle, preset selector, and Thickness/Speed controls.
 */
@Composable
fun EdgeLightingDialog(
    musicViewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val enabled by musicViewModel.edgeLightingEnabled.collectAsState()
    val currentStyle by musicViewModel.edgeLightingStyle.collectAsState()
    val intensity by musicViewModel.edgeLightingIntensity.collectAsState()
    val thickness by musicViewModel.edgeLightingThickness.collectAsState()
    val speed by musicViewModel.edgeLightingSpeed.collectAsState()
    val beatPulse by musicViewModel.edgeLightingBeatPulse.collectAsState()
    val albumArtSync by musicViewModel.edgeLightingAlbumArtSync.collectAsState()
    val animationMode by musicViewModel.edgeLightingAnimationMode.collectAsState()
    val currentSong by musicViewModel.currentPlayingSong.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: 10 Animations, 1: 10 Themes

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF101322)),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f)
                .border(1.dp, Color(0xFF00F0FF).copy(alpha = 0.25f), RoundedCornerShape(28.dp))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(Color(0xFF00F0FF), Color(0xFFBD00FF)))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LightMode,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Edge Lighting FX",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Beat Pulse & Dynamic Glow",
                                color = Color(0xFF00F0FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.08f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "Close",
                            tint = Color.LightGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Interactive Live Screen Preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .background(Color(0xFF080B14))
                            .border(1.dp, Color.White.copy(alpha = 0.1f), RoundedCornerShape(18.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Live active Edge Lighting overlay inside the mini phone frame
                        if (enabled) {
                            EdgeLightingOverlay(
                                isPlaying = true,
                                style = currentStyle,
                                animationMode = animationMode,
                                intensity = intensity,
                                thickness = thickness,
                                speed = speed,
                                beatPulse = beatPulse,
                                albumArtSync = albumArtSync,
                                song = currentSong,
                                cornerRadius = 18.dp
                            )
                        }

                        // Inside Screen Center Info
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (enabled) Color(0xFF00E676) else Color.Gray)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (enabled) "LIVE PREVIEW" else "LIGHTING OFF",
                                    color = if (enabled) Color(0xFF00F0FF) else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }
                            if (enabled && beatPulse) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "🎵 Beat Pulse Active",
                                    color = Color(0xFFFF007F),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Master Enable Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Enable Edge Lighting", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text("Screen borders glow during playback", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = enabled,
                            onCheckedChange = { musicViewModel.setEdgeLightingEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00F0FF),
                                checkedTrackColor = Color(0xFF00F0FF).copy(alpha = 0.4f),
                                uncheckedThumbColor = Color.LightGray,
                                uncheckedTrackColor = Color.DarkGray
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Audio Beat-Reactive Pulse Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🎵 Audio Beat-Reactive Pulse", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFFFF007F).copy(alpha = 0.2f))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("BASS SYNC", color = Color(0xFFFF007F), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("Edges rhythmically pump & expand on bass hits", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = beatPulse,
                            onCheckedChange = { musicViewModel.setEdgeLightingBeatPulse(it) },
                            enabled = enabled,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFFFF007F),
                                checkedTrackColor = Color(0xFFFF007F).copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Album Art Auto-Coloring Switch
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🎨 Album Art Auto-Coloring", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF00E676).copy(alpha = 0.2f))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text("AUTO SYNC", color = Color(0xFF00E676), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("Dynamically extracts glow palette from track cover", color = Color.Gray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = albumArtSync || currentStyle == "ALBUM_ART_SYNC",
                            onCheckedChange = {
                                musicViewModel.setEdgeLightingAlbumArtSync(it)
                                if (it) musicViewModel.setEdgeLightingStyle("ALBUM_ART_SYNC")
                            },
                            enabled = enabled,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color(0xFF00E676),
                                checkedTrackColor = Color(0xFF00E676).copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Segmented Tabs: 10 Animations vs 10 Themes
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White.copy(alpha = 0.06f))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selectedTab == 0) Color(0xFF00F0FF) else Color.Transparent)
                                .clickable { selectedTab = 0 },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "⚡ 10 Animations",
                                color = if (selectedTab == 0) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selectedTab == 1) Color(0xFF00F0FF) else Color.Transparent)
                                .clickable { selectedTab = 1 },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "🎨 10 Themes",
                                color = if (selectedTab == 1) Color.Black else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (selectedTab == 0) {
                        // 10 Screen Animations
                        Text(
                            text = "Edge Screen Animations (1-Click Select)",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        EdgeAnimationPresets.forEach { anim ->
                            val isSelected = anim.id == animationMode
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f))
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF00F0FF) else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        if (isSelected && enabled) {
                                            // 1-Click Deselect toggle
                                            musicViewModel.setEdgeLightingEnabled(false)
                                        } else {
                                            // 1-Click Select
                                            if (!enabled) musicViewModel.setEdgeLightingEnabled(true)
                                            musicViewModel.setEdgeLightingAnimationMode(anim.id)
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.25f) else Color.White.copy(alpha = 0.06f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(text = anim.emoji, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = anim.name,
                                            color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (anim.badge != null) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = anim.badge,
                                                color = Color(0xFFFFD600),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Text(
                                        text = anim.subtitle,
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                RadioButton(
                                    selected = isSelected && enabled,
                                    onClick = null,
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = Color(0xFF00F0FF),
                                        unselectedColor = Color.DarkGray
                                    )
                                )
                            }
                        }
                    } else {
                        // 10 Color Themes
                        Text(
                            text = "Edge Glow Themes (1-Click Select)",
                            color = Color.LightGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        EdgeLightingPresets.forEach { preset ->
                            val isSelected = (preset.id == currentStyle && !albumArtSync) || (preset.id == "ALBUM_ART_SYNC" && albumArtSync)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(if (isSelected) Color(0xFF00F0FF).copy(alpha = 0.15f) else Color.White.copy(alpha = 0.03f))
                                    .border(
                                        width = 1.dp,
                                        color = if (isSelected) Color(0xFF00F0FF) else Color.Transparent,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                    .clickable {
                                        if (isSelected && enabled) {
                                            // 1-Click Deselect toggle
                                            musicViewModel.setEdgeLightingEnabled(false)
                                        } else {
                                            // 1-Click Select
                                            if (!enabled) musicViewModel.setEdgeLightingEnabled(true)
                                            musicViewModel.setEdgeLightingStyle(preset.id)
                                            if (preset.id == "ALBUM_ART_SYNC") {
                                                musicViewModel.setEdgeLightingAlbumArtSync(true)
                                            } else {
                                                musicViewModel.setEdgeLightingAlbumArtSync(false)
                                            }
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Brush.sweepGradient(preset.previewColors))
                                        .border(1.5.dp, Color.White.copy(alpha = 0.4f), CircleShape)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = preset.name,
                                            color = if (isSelected) Color(0xFF00F0FF) else Color.White,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        if (preset.badge != null) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = preset.badge,
                                                color = Color(0xFFFFD600),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    Text(
                                        text = preset.subtitle,
                                        color = Color.Gray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                RadioButton(
                                    selected = isSelected && enabled,
                                    onClick = null,
                                    colors = RadioButtonDefaults.colors(
                                        selectedColor = Color(0xFF00F0FF),
                                        unselectedColor = Color.DarkGray
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Thickness Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Border Thickness", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val thicknessLabel = when {
                            thickness < 4f -> "Sleek (${thickness.toInt()} dp)"
                            thickness < 8f -> "Standard (${thickness.toInt()} dp)"
                            thickness < 11f -> "Vivid (${thickness.toInt()} dp)"
                            else -> "Neon Bold (${thickness.toInt()} dp)"
                        }
                        Text(thicknessLabel, color = Color(0xFF00F0FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = thickness,
                        onValueChange = { musicViewModel.setEdgeLightingThickness(it) },
                        valueRange = 2f..14f,
                        enabled = enabled,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00F0FF),
                            activeTrackColor = Color(0xFF00F0FF),
                            inactiveTrackColor = Color.DarkGray
                        )
                    )

                    // Speed Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Flow Speed", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        val speedLabel = when {
                            speed < 0.8f -> "Ambient (${String.format(Locale.US, "%.1fx", speed)})"
                            speed < 1.4f -> "Smooth (${String.format(Locale.US, "%.1fx", speed)})"
                            speed < 2.0f -> "Energetic (${String.format(Locale.US, "%.1fx", speed)})"
                            else -> "Rave (${String.format(Locale.US, "%.1fx", speed)})"
                        }
                        Text(speedLabel, color = Color(0xFFBD00FF), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = speed,
                        onValueChange = { musicViewModel.setEdgeLightingSpeed(it) },
                        valueRange = 0.5f..2.5f,
                        enabled = enabled,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFBD00FF),
                            activeTrackColor = Color(0xFFBD00FF),
                            inactiveTrackColor = Color.DarkGray
                        )
                    )

                    // Luminescence / Intensity Control
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Glow Brightness", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("${(intensity * 100).toInt()}%", color = Color(0xFFFF007F), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = intensity,
                        onValueChange = { musicViewModel.setEdgeLightingIntensity(it) },
                        valueRange = 0.5f..1.5f,
                        enabled = enabled,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFF007F),
                            activeTrackColor = Color(0xFFFF007F),
                            inactiveTrackColor = Color.DarkGray
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Done Button
                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00F0FF)
                    )
                ) {
                    Text(
                        text = "Apply & Done",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}
