package com.vidiopen.player.ui.viewmodel

import android.app.Application
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FolderSpecial
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.data.model.SmartCollectionItem
import com.vidiopen.player.data.repository.MediaRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SmartCollectionsViewModel(
    application: Application,
    private val repository: MediaRepository
) : AndroidViewModel(application) {

    private val _smartCollections = MutableStateFlow<List<SmartCollectionItem>>(emptyList())
    val smartCollections: StateFlow<List<SmartCollectionItem>> = _smartCollections.asStateFlow()

    private val _recentlyOpenedFolder = MutableStateFlow<SmartCollectionItem?>(null)
    val recentlyOpenedFolder: StateFlow<SmartCollectionItem?> = _recentlyOpenedFolder.asStateFlow()

    private val _lastPlayedVideo = MutableStateFlow<MediaEntity?>(null)
    val lastPlayedVideo: StateFlow<MediaEntity?> = _lastPlayedVideo.asStateFlow()

    private val _favoriteCollection = MutableStateFlow<SmartCollectionItem?>(null)
    val favoriteCollection: StateFlow<SmartCollectionItem?> = _favoriteCollection.asStateFlow()

    private val _largestCollection = MutableStateFlow<SmartCollectionItem?>(null)
    val largestCollection: StateFlow<SmartCollectionItem?> = _largestCollection.asStateFlow()

    init {
        loadCollections()
    }

    private fun loadCollections() {
        viewModelScope.launch {
            repository.allMedia.collect { list ->
                _lastPlayedVideo.value = list.firstOrNull()
            }
        }
    }

    fun updateScannedVideos(videos: List<com.vidiopen.player.data.model.ScannedVideo>) {
        if (videos.isEmpty()) return
        val items = listOf(
            SmartCollectionItem(
                id = "all_videos",
                name = "All Videos",
                icon = Icons.Rounded.FolderSpecial,
                videos = videos,
                description = "${videos.size} videos available"
            )
        )
        _smartCollections.value = items
    }
}

class SmartCollectionsViewModelFactory(
    private val application: Application,
    private val repository: MediaRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SmartCollectionsViewModel::class.java)) {
            return SmartCollectionsViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
