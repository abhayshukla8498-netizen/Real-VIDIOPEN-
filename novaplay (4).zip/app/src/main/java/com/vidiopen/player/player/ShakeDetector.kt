package com.vidiopen.player.player

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.sqrt

class ShakeDetector(private val context: Context) : SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    private var onShakeListener: (() -> Unit)? = null
    private var lastShakeTimestamp: Long = 0L
    private var isListening = false

    var sensitivity: Float = 1.65f // Medium default (gentle wrist shake)
    var deltaThreshold: Float = 11.0f // Delta sum threshold
    var hapticEnabled: Boolean = true

    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    private var hasPrevSample = false

    private val _liveGForce = MutableStateFlow(1.0f)
    val liveGForce: StateFlow<Float> = _liveGForce.asStateFlow()

    fun setOnShakeListener(listener: () -> Unit) {
        this.onShakeListener = listener
    }

    fun startListening() {
        if (isListening || accelerometer == null || sensorManager == null) return
        hasPrevSample = false
        // Use SENSOR_DELAY_GAME for high responsiveness and fast capture of shake transients
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME)
        isListening = true
    }

    fun stopListening() {
        if (!isListening || sensorManager == null) return
        sensorManager.unregisterListener(this)
        isListening = false
        hasPrevSample = false
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        val gX = x / SensorManager.GRAVITY_EARTH
        val gY = y / SensorManager.GRAVITY_EARTH
        val gZ = z / SensorManager.GRAVITY_EARTH

        // Calculate normalized gForce
        val gForce = sqrt((gX * gX + gY * gY + gZ * gZ).toDouble()).toFloat()
        _liveGForce.value = gForce

        var isShakeDetected = false

        if (hasPrevSample) {
            val deltaX = Math.abs(x - lastX)
            val deltaY = Math.abs(y - lastY)
            val deltaZ = Math.abs(z - lastZ)
            val deltaAcc = deltaX + deltaY + deltaZ

            if (deltaAcc > deltaThreshold || gForce > sensitivity) {
                isShakeDetected = true
            }
        }
        lastX = x
        lastY = y
        lastZ = z
        hasPrevSample = true

        if (isShakeDetected) {
            val now = System.currentTimeMillis()
            // Ignore shake events within 1.0s to prevent rapid accidental double-skips
            if (lastShakeTimestamp + 1000L > now) {
                return
            }

            lastShakeTimestamp = now
            triggerHapticFeedback()
            onShakeListener?.invoke()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Not used
    }

    fun triggerHapticFeedback() {
        if (!hapticEnabled || vibrator == null || !vibrator.hasVibrator()) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(70, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(70)
            }
        } catch (_: Throwable) {}
    }
}
