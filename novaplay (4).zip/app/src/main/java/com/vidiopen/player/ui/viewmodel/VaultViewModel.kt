package com.vidiopen.player.ui.viewmodel

import android.app.Application
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Environment
import android.provider.OpenableColumns
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.VaultEntity
import com.vidiopen.player.data.repository.MediaRepository
import com.vidiopen.player.utils.StorageDeletionHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

class VaultViewModel(
    application: Application,
    private val repository: MediaRepository
) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("vidiopen_vault_prefs", android.content.Context.MODE_PRIVATE)

    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _unlockMethod = MutableStateFlow(prefs.getString("unlock_method", "PIN") ?: "PIN")
    val unlockMethod: StateFlow<String> = _unlockMethod.asStateFlow()

    private val _hasPin = MutableStateFlow(prefs.contains("vault_pin"))
    val hasPin: StateFlow<Boolean> = _hasPin.asStateFlow()

    private val _hasPattern = MutableStateFlow(prefs.contains("vault_pattern"))
    val hasPattern: StateFlow<Boolean> = _hasPattern.asStateFlow()

    private val _hasPassword = MutableStateFlow(prefs.contains("vault_password"))
    val hasPassword: StateFlow<Boolean> = _hasPassword.asStateFlow()

    private val _isBiometricEnabled = MutableStateFlow(prefs.getBoolean("biometric_enabled", false))
    val isBiometricEnabled: StateFlow<Boolean> = _isBiometricEnabled.asStateFlow()

    private val _autoLockTimeout = MutableStateFlow(prefs.getInt("auto_lock_timeout", 30))
    val autoLockTimeout: StateFlow<Int> = _autoLockTimeout.asStateFlow()

    private val _isCalculatorDisguiseEnabled = MutableStateFlow(prefs.getBoolean("calculator_disguise", false))
    val isCalculatorDisguiseEnabled: StateFlow<Boolean> = _isCalculatorDisguiseEnabled.asStateFlow()

    private val _activeSection = MutableStateFlow("HOME")
    val activeSection: StateFlow<String> = _activeSection.asStateFlow()

    private val _videos = MutableStateFlow<List<VaultEntity>>(emptyList())
    val videos: StateFlow<List<VaultEntity>> = _videos.asStateFlow()

    private val _photos = MutableStateFlow<List<VaultEntity>>(emptyList())
    val photos: StateFlow<List<VaultEntity>> = _photos.asStateFlow()

    private val _audio = MutableStateFlow<List<VaultEntity>>(emptyList())
    val audio: StateFlow<List<VaultEntity>> = _audio.asStateFlow()

    private val _documents = MutableStateFlow<List<VaultEntity>>(emptyList())
    val documents: StateFlow<List<VaultEntity>> = _documents.asStateFlow()

    private val _favorites = MutableStateFlow<List<VaultEntity>>(emptyList())
    val favorites: StateFlow<List<VaultEntity>> = _favorites.asStateFlow()

    private val _recentlyAdded = MutableStateFlow<List<VaultEntity>>(emptyList())
    val recentlyAdded: StateFlow<List<VaultEntity>> = _recentlyAdded.asStateFlow()

    private val _activeDecryptedFile = MutableStateFlow<File?>(null)
    val activeDecryptedFile: StateFlow<File?> = _activeDecryptedFile.asStateFlow()

    private val _activeDecryptedItem = MutableStateFlow<VaultEntity?>(null)
    val activeDecryptedItem: StateFlow<VaultEntity?> = _activeDecryptedItem.asStateFlow()

    private val _isDecrypting = MutableStateFlow(false)
    val isDecrypting: StateFlow<Boolean> = _isDecrypting.asStateFlow()

    init {
        loadVaultItems()
    }

    private fun loadVaultItems() {
        viewModelScope.launch {
            repository.allVaultItems.collect { items ->
                _videos.value = items.filter { it.type == "VIDEO" }
                _photos.value = items.filter { it.type == "PHOTO" }
                _audio.value = items.filter { it.type == "AUDIO" }
                _documents.value = items.filter { it.type == "DOCUMENT" }
                _favorites.value = items.filter { it.isFavorite }
                _recentlyAdded.value = items.sortedByDescending { it.addedDate }
            }
        }
    }

    fun verifyUnlock(input: String): Boolean {
        val storedPin = prefs.getString("vault_pin", "0000")
        val success = (input == storedPin)
        if (success) _isUnlocked.value = true
        return success
    }

    fun verifyBiometricSuccess() {
        _isUnlocked.value = true
    }

    fun lock() {
        _isUnlocked.value = false
        _activeDecryptedFile.value = null
        _activeDecryptedItem.value = null
    }

    fun savePin(pin: String) {
        prefs.edit().putString("vault_pin", pin).apply()
        _hasPin.value = true
    }

    fun resetPin() {
        prefs.edit().remove("vault_pin").apply()
        _hasPin.value = false
    }

    fun setUnlockMethod(method: String) {
        prefs.edit().putString("unlock_method", method).apply()
        _unlockMethod.value = method
    }

    fun setBiometricEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("biometric_enabled", enabled).apply()
        _isBiometricEnabled.value = enabled
    }

    fun setAutoLockTimeout(seconds: Int) {
        prefs.edit().putInt("auto_lock_timeout", seconds).apply()
        _autoLockTimeout.value = seconds
    }

    fun setCalculatorDisguiseEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("calculator_disguise", enabled).apply()
        _isCalculatorDisguiseEnabled.value = enabled
    }

    fun setActiveSection(section: String) {
        _activeSection.value = section
    }

    fun selectItemForPlaybackOrView(item: VaultEntity, onError: ((String) -> Unit)? = null) {
        try {
            _activeDecryptedItem.value = item
            _activeDecryptedFile.value = File(item.path)
        } catch (e: Exception) {
            onError?.invoke(e.message ?: "Failed to open item")
        }
    }

    fun dismissActiveViewer() {
        _activeDecryptedItem.value = null
        _activeDecryptedFile.value = null
    }

    fun toggleVaultFavorite(id: Int, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.toggleVaultFavorite(id, isFavorite)
        }
    }

    fun toggleVaultFavorite(item: VaultEntity) {
        viewModelScope.launch {
            repository.toggleVaultFavorite(item.id, !item.isFavorite)
        }
    }

    fun deleteVaultItem(item: VaultEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(item.path)
                if (file.exists()) {
                    file.delete()
                }
            } catch (_: Exception) {}
            repository.deleteVaultItem(item)
        }
    }

    /**
     * Restores/Unhides an item from private vault back to user's public gallery and storage.
     */
    fun exportVaultItem(item: VaultEntity, onDone: (Boolean) -> Unit) {
        restoreVaultItemToGallery(
            item = item,
            onSuccess = { onDone(true) },
            onError = { onDone(false) }
        )
    }

    fun exportVaultItem(
        item: VaultEntity,
        destDir: File,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        restoreVaultItemToGallery(
            item = item,
            targetDir = destDir,
            onSuccess = onSuccess,
            onError = onError
        )
    }

    fun restoreVaultItemToGallery(
        item: VaultEntity,
        targetDir: File? = null,
        onSuccess: (String) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val srcFile = File(item.path)
                if (!srcFile.exists()) {
                    withContext(Dispatchers.Main) {
                        onError("Source file in vault was not found on disk.")
                    }
                    return@launch
                }

                val publicDir = targetDir ?: when (item.type) {
                    "VIDEO" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
                    "PHOTO" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                    "AUDIO" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
                    else -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                }

                if (!publicDir.exists()) {
                    publicDir.mkdirs()
                }

                val ext = if (srcFile.name.contains(".")) {
                    srcFile.name.substringAfterLast(".")
                } else {
                    when (item.type) {
                        "PHOTO" -> "jpg"
                        "AUDIO" -> "mp3"
                        "DOCUMENT" -> "pdf"
                        else -> "mp4"
                    }
                }

                var baseName = item.title.trim()
                if (!baseName.endsWith(".$ext", ignoreCase = true)) {
                    baseName = "$baseName.$ext"
                }

                var restoredFile = File(publicDir, baseName)
                if (restoredFile.exists()) {
                    val timeTag = System.currentTimeMillis() % 100000
                    restoredFile = File(publicDir, "${item.title.substringBeforeLast(".")}_restored_$timeTag.$ext")
                }

                FileInputStream(srcFile).use { input ->
                    FileOutputStream(restoredFile).use { output ->
                        input.copyTo(output)
                    }
                }

                if (restoredFile.exists() && restoredFile.length() > 0L) {
                    // Notify Android MediaScanner so file immediately shows in Gallery & Players
                    MediaScannerConnection.scanFile(
                        app,
                        arrayOf(restoredFile.absolutePath),
                        null
                    ) { _, _ -> }

                    // Delete the encrypted file from internal vault directory
                    try { srcFile.delete() } catch (_: Exception) {}

                    // Remove from vault database
                    repository.deleteVaultItem(item)

                    withContext(Dispatchers.Main) {
                        onSuccess("Restored successfully to ${publicDir.name} & Gallery!")
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        onError("Failed to copy file back to public storage.")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError(e.message ?: "Failed to restore file.")
                }
            }
        }
    }

    private fun getFileNameAndExtension(context: Context, uri: Uri, defaultType: String): Pair<String, String> {
        var displayName: String? = null
        var ext = ""
        try {
            if (uri.scheme == "content") {
                context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex != -1) {
                            displayName = cursor.getString(nameIndex)
                        }
                    }
                }
            }
            if (displayName == null) {
                displayName = uri.lastPathSegment
            }
        } catch (_: Exception) {}

        val cleanName = displayName ?: "media_${System.currentTimeMillis()}"
        if (cleanName.contains(".")) {
            ext = cleanName.substringAfterLast(".").lowercase()
        }
        if (ext.isEmpty() || ext.length > 5) {
            ext = when (defaultType) {
                "PHOTO" -> "jpg"
                "AUDIO" -> "mp3"
                "DOCUMENT" -> "pdf"
                else -> "mp4"
            }
        }
        return Pair(cleanName, ext)
    }

    fun importFileFromUri(uri: Uri, type: String, onDone: (Boolean) -> Unit) {
        importFileFromUri(
            uri = uri,
            type = type,
            customTitle = null,
            onImportSuccess = { deleteAction ->
                deleteAction()
                onDone(true)
            },
            onError = { onDone(false) }
        )
    }

    fun importFileFromUri(
        uri: Uri,
        type: String,
        customTitle: String? = null,
        deleteAction: Boolean = false,
        onSuccess: (VaultEntity) -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        importFileFromUri(
            uri = uri,
            type = type,
            customTitle = customTitle,
            onImportSuccess = { delAction ->
                if (deleteAction) delAction()
                val latest = _recentlyAdded.value.firstOrNull() ?: VaultEntity(title = customTitle ?: "Imported File", path = uri.toString(), type = type)
                onSuccess(latest)
            },
            onError = { msg -> onError(msg) }
        )
    }

    fun importFileFromUri(
        uri: Uri,
        type: String,
        customTitle: String? = null,
        onImportSuccess: (((() -> Unit)) -> Unit)? = null,
        onError: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val vaultDir = File(app.filesDir, "vidiopen_vault")
                if (!vaultDir.exists()) vaultDir.mkdirs()

                val noMedia = File(vaultDir, ".nomedia")
                if (!noMedia.exists()) {
                    try { noMedia.createNewFile() } catch (_: Exception) {}
                }

                val (originalName, ext) = getFileNameAndExtension(app, uri, type)
                val finalTitle = customTitle?.ifBlank { null } ?: originalName

                val secureFileName = "vault_${UUID.randomUUID()}.$ext"
                val secureDestFile = File(vaultDir, secureFileName)

                var copySuccess = false

                // Try direct file copy if file:// scheme
                val origPath = if (uri.scheme == "file") uri.path else null
                val origFile = if (origPath != null) File(origPath) else null

                if (origFile != null && origFile.exists()) {
                    try {
                        origFile.copyTo(secureDestFile, overwrite = true)
                        copySuccess = secureDestFile.exists() && secureDestFile.length() > 0L
                    } catch (_: Exception) {}
                }

                if (!copySuccess) {
                    // Copy stream from ContentResolver
                    try {
                        app.contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(secureDestFile).use { output ->
                                input.copyTo(output)
                            }
                        }
                        copySuccess = secureDestFile.exists() && secureDestFile.length() > 0L
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }

                if (!copySuccess || !secureDestFile.exists() || secureDestFile.length() == 0L) {
                    withContext(Dispatchers.Main) {
                        onError?.invoke("Failed to copy file into encrypted vault storage.")
                    }
                    return@launch
                }

                val fileSize = secureDestFile.length()
                val entity = VaultEntity(
                    title = finalTitle,
                    path = secureDestFile.absolutePath,
                    type = type,
                    size = fileSize,
                    isFavorite = false,
                    addedDate = System.currentTimeMillis()
                )
                repository.insertVaultItem(entity)

                // Define delete callback for completely erasing the original public file from phone storage & gallery
                val deleteAction: () -> Unit = {
                    viewModelScope.launch(Dispatchers.IO) {
                        try {
                            StorageDeletionHelper.deletePermanently(
                                context = app,
                                path = origPath,
                                uriString = uri.toString(),
                                isAudio = (type == "AUDIO")
                            )
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                }

                withContext(Dispatchers.Main) {
                    onImportSuccess?.invoke(deleteAction)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    onError?.invoke(e.message ?: "Import failed")
                }
            }
        }
    }

    fun onAppGoToBackground() {}
    fun onAppReturnToForeground() {}
    fun suspendLocking(suspend: Boolean) {}
}

class VaultViewModelFactory(
    private val application: Application,
    private val repository: MediaRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VaultViewModel::class.java)) {
            return VaultViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
