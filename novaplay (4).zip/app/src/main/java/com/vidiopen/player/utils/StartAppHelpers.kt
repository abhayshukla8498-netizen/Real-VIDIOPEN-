package com.vidiopen.player.utils

import android.content.Context

object StartAppInterstitialHelper {
    fun showInterstitial(context: Context, onClosed: (() -> Unit)? = null) {
        onClosed?.invoke()
    }

    fun showMultipleAds(context: Context, count: Int, onComplete: () -> Unit) {
        onComplete()
    }

    fun showRewardedVideoAd(context: Context, onRewarded: () -> Unit) {
        onRewarded()
    }
}
