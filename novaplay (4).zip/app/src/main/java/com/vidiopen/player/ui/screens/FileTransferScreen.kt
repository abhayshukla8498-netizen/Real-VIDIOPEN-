package com.vidiopen.player.ui.screens

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidiopen.player.data.model.ActiveTransfer
import com.vidiopen.player.data.model.DiscoveredDevice
import com.vidiopen.player.data.model.TransferFile
import com.vidiopen.player.data.model.TransferStatus
import com.vidiopen.player.ui.viewmodel.FileTransferViewModel
import java.io.File
import java.util.Locale

/**
 * Modern, ultra-attractive Jetpack Compose Offline File Transfer Screen for VIDIOpen.
 * Features:
 * - Direct Send & Receive via local Hotspot/Wi-Fi sockets (No internet required)
 * - 6-Digit Auto Connect PIN code for zero-friction instant connection without QR
 * - ZXing generated QR code for hotspot & quick IP pairing
 * - Live UDP Radar Auto-Discovery of nearby VIDIOpen devices
 * - Real-time animated byte transfer progress bar, speed indicator, and ETA
 * - Automatic MediaStore indexing on receive
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileTransferScreen(
    viewModel: FileTransferViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Send, 1 = Receive, 2 = Live Progress

    val isServerRunning by viewModel.isServerRunning.collectAsState()
    val isTransferring by viewModel.isTransferring.collectAsState()
    val serverIp by viewModel.serverIp.collectAsState()
    val serverPort by viewModel.serverPort.collectAsState()
    val sessionCode by viewModel.sessionCode.collectAsState()
    val activeTransfers by viewModel.activeTransfers.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val transferError by viewModel.transferError.collectAsState()
    val completeMessage by viewModel.transferCompleteMessage.collectAsState()

    // Dialog state for 6-digit Code Connect & Camera QR Scanner
    var showCodeConnectDialog by remember { mutableStateOf(false) }
    var showCameraQrScanner by remember { mutableStateOf(false) }
    var targetDeviceForCode by remember { mutableStateOf<DiscoveredDevice?>(null) }

    // Auto switch to Progress tab when transfer starts
    LaunchedEffect(isTransferring) {
        if (isTransferring) {
            selectedTab = 2
        }
    }

    // Permission launcher for nearby Wi-Fi devices & storage & camera
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Permissions handled
    }

    LaunchedEffect(Unit) {
        val permissions = mutableListOf<String>()
        permissions.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    // Custom Back handler
    BackHandler {
        if (isTransferring) {
            viewModel.cancelTransfer()
        }
        if (isServerRunning) {
            viewModel.stopReceiving()
        }
        viewModel.stopDiscovery()
        onBack()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Offline File Transfer",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Ultra Fast • No Internet Needed",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (isTransferring) viewModel.cancelTransfer()
                            if (isServerRunning) viewModel.stopReceiving()
                            viewModel.stopDiscovery()
                            onBack()
                        },
                        modifier = Modifier.testTag("transfer_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Quick Action: Hotspot / Wi-Fi settings shortcut
                    IconButton(
                        onClick = {
                            try {
                                context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                            } catch (e: Exception) {
                                // fallback
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Wifi,
                            contentDescription = "Wi-Fi Settings",
                            tint = Color.White.copy(alpha = 0.8f)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0B0E17)
                )
            )
        },
        containerColor = Color(0xFF07090F)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Mode Tabs (Send, Receive, Progress)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF101426),
                contentColor = Color(0xFF00E5FF),
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = Color(0xFF00E5FF),
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.AutoMirrored.Rounded.Send,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Send", fontWeight = FontWeight.SemiBold)
                            if (selectedFiles.isNotEmpty()) {
                                Spacer(Modifier.width(6.dp))
                                Badge(containerColor = Color(0xFF00E5FF), contentColor = Color.Black) {
                                    Text("${selectedFiles.size}")
                                }
                            }
                        }
                    },
                    selectedContentColor = Color(0xFF00E5FF),
                    unselectedContentColor = Color.Gray
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        if (!isServerRunning) {
                            viewModel.startReceiving()
                        }
                    },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Download,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Receive", fontWeight = FontWeight.SemiBold)
                            if (isServerRunning) {
                                Spacer(Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00E676))
                                )
                            }
                        }
                    },
                    selectedContentColor = Color(0xFF00E5FF),
                    unselectedContentColor = Color.Gray
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Rounded.Sync,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Activity", fontWeight = FontWeight.SemiBold)
                            if (activeTransfers.isNotEmpty()) {
                                Spacer(Modifier.width(6.dp))
                                Badge(
                                    containerColor = if (isTransferring) Color(0xFFFF9100) else Color(0xFF7C4DFF),
                                    contentColor = Color.White
                                ) {
                                    Text("${activeTransfers.size}")
                                }
                            }
                        }
                    },
                    selectedContentColor = Color(0xFF00E5FF),
                    unselectedContentColor = Color.Gray
                )
            }

            // Error or Success Banner
            AnimatedVisibility(
                visible = transferError != null || completeMessage != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                val isErr = transferError != null
                Surface(
                    color = if (isErr) Color(0x33FF1744) else Color(0x3300E676),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = if (isErr) Icons.Rounded.ErrorOutline else Icons.Rounded.CheckCircle,
                                contentDescription = null,
                                tint = if (isErr) Color(0xFFFF5252) else Color(0xFF00E676),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = transferError ?: completeMessage.orEmpty(),
                                color = Color.White,
                                fontSize = 13.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        IconButton(
                            onClick = { viewModel.clearTransfers() },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Close,
                                contentDescription = "Dismiss",
                                tint = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // Content per tab
            when (selectedTab) {
                0 -> SenderTabContent(
                    viewModel = viewModel,
                    onOpenDirectConnect = { device ->
                        targetDeviceForCode = device
                        showCodeConnectDialog = true
                    },
                    onOpenQrScanner = {
                        showCameraQrScanner = true
                    }
                )
                1 -> ReceiverTabContent(
                    viewModel = viewModel,
                    serverIp = serverIp,
                    serverPort = serverPort,
                    sessionCode = sessionCode,
                    isServerRunning = isServerRunning
                )
                2 -> ActivityProgressTabContent(
                    viewModel = viewModel,
                    activeTransfers = activeTransfers,
                    isTransferring = isTransferring
                )
            }
        }
    }

    // Camera QR Code Scanner Dialog
    if (showCameraQrScanner) {
        QrCameraScannerDialog(
            onDismiss = { showCameraQrScanner = false },
            onQrCodeScanned = { ip, port, code ->
                showCameraQrScanner = false
                if (ip.isNotBlank()) {
                    viewModel.sendToDevice(ip, port, code) { success ->
                        if (success) {
                            selectedTab = 2
                        }
                    }
                } else if (code.length == 6) {
                    viewModel.sendBySixDigitCode(code) { success ->
                        if (success) {
                            selectedTab = 2
                        }
                    }
                }
            }
        )
    }

    // Direct Code Connect Dialog (for manual 6-digit PIN input or device connection)
    if (showCodeConnectDialog) {
        DirectPinConnectDialog(
            targetDevice = targetDeviceForCode,
            selectedFilesCount = selectedFiles.size,
            onDismiss = { showCodeConnectDialog = false },
            onConnectByCodeOnly = { code ->
                showCodeConnectDialog = false
                viewModel.sendBySixDigitCode(code) { success ->
                    if (success) {
                        selectedTab = 2
                    }
                }
            },
            onConnectAndSend = { ip, port, code ->
                showCodeConnectDialog = false
                viewModel.sendToDevice(ip, port, code) { success ->
                    if (success) {
                        selectedTab = 2
                    }
                }
            }
        )
    }
}

// =============================================================================
// TAB 1: SENDER CONTENT
// =============================================================================
@Composable
private fun SenderTabContent(
    viewModel: FileTransferViewModel,
    onOpenDirectConnect: (DiscoveredDevice?) -> Unit,
    onOpenQrScanner: () -> Unit
) {
    val selectedFiles by viewModel.selectedFiles.collectAsState()
    val videos by viewModel.storageVideos.collectAsState()
    val audio by viewModel.storageAudio.collectAsState()
    val docs by viewModel.storageDocs.collectAsState()
    val isLoading by viewModel.isLoadingStorage.collectAsState()
    val discoveredDevices by viewModel.discoveredDevices.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    var mediaCategory by remember { mutableIntStateOf(0) } // 0 = Videos, 1 = Music, 2 = Docs

    Column(modifier = Modifier.fillMaxSize()) {
        // Top Toolbar: Radar Discovery & Manual PIN Connect
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF14192B)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Nearby Devices",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isScanning) "Searching for receivers..." else "Radar paused",
                            color = if (isScanning) Color(0xFF00E5FF) else Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Scan Toggle
                        IconButton(
                            onClick = {
                                if (isScanning) viewModel.stopDiscovery() else viewModel.startDiscovery()
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.08f))
                        ) {
                            Icon(
                                imageVector = if (isScanning) Icons.Rounded.Refresh else Icons.Rounded.Radar,
                                contentDescription = "Scan Radar",
                                tint = if (isScanning) Color(0xFF00E5FF) else Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(Modifier.width(6.dp))

                        // Camera QR Scanner Button
                        IconButton(
                            onClick = onOpenQrScanner,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00E5FF).copy(alpha = 0.18f))
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.QrCodeScanner,
                                contentDescription = "Scan QR with Camera",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(Modifier.width(6.dp))

                        // Manual 6-Digit PIN Connect Button
                        Button(
                            onClick = { onOpenDirectConnect(null) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF7C4DFF)
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                Icons.Rounded.Dialpad,
                                contentDescription = null,
                                modifier = Modifier.size(15.dp),
                                tint = Color.White
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("6-Digit PIN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Discovered Devices Carousel
                if (discoveredDevices.isNotEmpty()) {
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "Tap to Auto-Connect & Send:",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        discoveredDevices.forEach { device ->
                            DeviceRadarChip(
                                device = device,
                                onClick = { onOpenDirectConnect(device) }
                            )
                        }
                    }
                } else if (isScanning) {
                    Spacer(Modifier.height(8.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            color = Color(0xFF00E5FF),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "Waiting for other device in VIDIOpen Receive mode...",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Category Filter Tabs (Videos, Audio, Docs)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CategoryChip(
                title = "Videos (${videos.size})",
                icon = Icons.Rounded.Movie,
                isSelected = mediaCategory == 0,
                onClick = { mediaCategory = 0 }
            )
            CategoryChip(
                title = "Music (${audio.size})",
                icon = Icons.Rounded.MusicNote,
                isSelected = mediaCategory == 1,
                onClick = { mediaCategory = 1 }
            )
            CategoryChip(
                title = "Files (${docs.size})",
                icon = Icons.Rounded.FolderZip,
                isSelected = mediaCategory == 2,
                onClick = { mediaCategory = 2 }
            )
        }

        // Media List
        val currentList = when (mediaCategory) {
            0 -> videos
            1 -> audio
            else -> docs
        }

        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color(0xFF00E5FF))
            }
        } else if (currentList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.FolderOpen,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "No files found in this category",
                        color = Color.LightGray,
                        fontSize = 14.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(currentList, key = { it.id }) { file ->
                    val isSelected = viewModel.isFileSelected(file)
                    FileSelectItemRow(
                        file = file,
                        isSelected = isSelected,
                        onToggle = { viewModel.toggleFileSelection(file) }
                    )
                }
            }
        }

        // Bottom Send Action Bar
        Surface(
            color = Color(0xFF101426),
            tonalElevation = 8.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "${selectedFiles.size} Files Selected",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    val totalBytes = selectedFiles.sumOf { it.size }
                    Text(
                        text = formatFileSize(totalBytes),
                        color = Color(0xFF00E5FF),
                        fontSize = 12.sp
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (selectedFiles.isNotEmpty()) {
                        OutlinedButton(
                            onClick = { viewModel.clearSelectedFiles() },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.LightGray)
                        ) {
                            Text("Clear", fontSize = 12.sp)
                        }
                    }

                    Button(
                        onClick = {
                            if (selectedFiles.isNotEmpty()) {
                                onOpenDirectConnect(discoveredDevices.firstOrNull())
                            }
                        },
                        enabled = selectedFiles.isNotEmpty(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF00E5FF),
                            disabledContainerColor = Color.White.copy(alpha = 0.1f)
                        ),
                        modifier = Modifier.testTag("send_selected_button")
                    ) {
                        Icon(
                            Icons.AutoMirrored.Rounded.Send,
                            contentDescription = null,
                            tint = if (selectedFiles.isNotEmpty()) Color.Black else Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "Send Now",
                            color = if (selectedFiles.isNotEmpty()) Color.Black else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

// =============================================================================
// TAB 2: RECEIVER CONTENT (WITH QR CODE & 6-DIGIT CODE)
// =============================================================================
@Composable
private fun ReceiverTabContent(
    viewModel: FileTransferViewModel,
    serverIp: String?,
    serverPort: Int,
    sessionCode: String,
    isServerRunning: Boolean
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val transferSuccessCount by viewModel.transferSuccessCount.collectAsState()

    val pulseAnim = rememberInfiniteTransition(label = "pulse")
    val pulseScale by pulseAnim.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Main Receiver Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(if (isServerRunning) pulseScale else 1f),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF13182C)),
                border = BorderStroke(
                    1.5.dp,
                    if (isServerRunning) Brush.linearGradient(
                        listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF))
                    ) else Brush.linearGradient(listOf(Color.White.copy(alpha = 0.1f), Color.Transparent))
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Receiver Beacon Icon
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(
                                if (isServerRunning) Color(0xFF00E5FF).copy(alpha = 0.15f)
                                else Color.White.copy(alpha = 0.05f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isServerRunning) Icons.Rounded.Sensors else Icons.Rounded.SensorsOff,
                            contentDescription = null,
                            tint = if (isServerRunning) Color(0xFF00E5FF) else Color.Gray,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    Text(
                        text = if (isServerRunning) "Ready to Receive Files" else "Receiver Stopped",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = if (isServerRunning) "Other phones can connect via QR or 6-Digit PIN"
                        else "Tap Start Receiver to begin waiting for files",
                        color = Color.LightGray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    if (isServerRunning && serverIp != null) {
                        Spacer(Modifier.height(20.dp))

                        // 6-Digit Unique Code Highlight Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1E2542)),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "YOUR 6-DIGIT PAIRING CODE",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )

                                Spacer(Modifier.height(8.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = sessionCode,
                                        color = Color.White,
                                        fontSize = 32.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 4.sp
                                    )
                                    Spacer(Modifier.width(12.dp))
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(sessionCode))
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Rounded.ContentCopy,
                                            contentDescription = "Copy Code",
                                            tint = Color.LightGray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                Text(
                                    text = "Sender enters this code or uses Auto-Discovery",
                                    color = Color.Gray,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                        }

                        Spacer(Modifier.height(20.dp))

                        // ZXing QR Code
                        val qrPayload = "VIDIOPEN|$serverIp|$serverPort|$sessionCode"
                        QrCodeImage(
                            content = qrPayload,
                            size = 190.dp,
                            foregroundColor = android.graphics.Color.WHITE
                        )

                        Spacer(Modifier.height(10.dp))

                        Text(
                            text = "Or scan this QR code with sender phone",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )

                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = "Local Socket: $serverIp:$serverPort",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(Modifier.height(20.dp))

                    // Start / Stop Toggle Button
                    Button(
                        onClick = {
                            if (isServerRunning) {
                                viewModel.stopReceiving()
                            } else {
                                viewModel.startReceiving()
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isServerRunning) Color(0xFFFF3366) else Color(0xFF00E5FF)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isServerRunning) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                            contentDescription = null,
                            tint = if (isServerRunning) Color.White else Color.Black
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = if (isServerRunning) "Stop Receiver" else "Start Receiver",
                            color = if (isServerRunning) Color.White else Color.Black,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    if (isServerRunning) {
                        Spacer(Modifier.height(10.dp))
                        TextButton(onClick = { viewModel.resetSessionCode() }) {
                            Icon(
                                Icons.Rounded.Refresh,
                                contentDescription = null,
                                tint = Color.LightGray,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text("Generate New 6-Digit Code", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // How it works info card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF101426)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Easy Offline Connection:",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    StepInstructionRow(step = "1", text = "Connect both phones to the same Wi-Fi or turn on Hotspot on one phone.")
                    StepInstructionRow(step = "2", text = "On sender phone, select files and enter the 6-Digit code or tap this device in radar.")
                    StepInstructionRow(step = "3", text = "Received videos and songs appear automatically in VIDIOpen's library!")
                }
            }
        }
    }
}

// =============================================================================
// TAB 3: ACTIVITY & LIVE PROGRESS CONTENT
// =============================================================================
@Composable
private fun ActivityProgressTabContent(
    viewModel: FileTransferViewModel,
    activeTransfers: List<ActiveTransfer>,
    isTransferring: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Transfer Activity",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (isTransferring) "Transferring files in background..." else "All items",
                    color = if (isTransferring) Color(0xFF00E5FF) else Color.Gray,
                    fontSize = 12.sp
                )
            }

            if (isTransferring) {
                Button(
                    onClick = { viewModel.cancelTransfer() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3366)),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Cancel", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else if (activeTransfers.isNotEmpty()) {
                TextButton(onClick = { viewModel.clearTransfers() }) {
                    Text("Clear List", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        if (activeTransfers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Rounded.SwapHoriz,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "No transfer in progress",
                        color = Color.LightGray,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Files sent or received will appear here with live speed and progress.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(activeTransfers, key = { it.id }) { transfer ->
                    TransferProgressCard(transfer = transfer)
                }
            }
        }
    }
}

// =============================================================================
// SUB-COMPONENTS
// =============================================================================

@Composable
private fun TransferProgressCard(transfer: ActiveTransfer) {
    val progress = if (transfer.fileSize > 0) {
        (transfer.bytesTransferred.toFloat() / transfer.fileSize.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val percent = (progress * 100).toInt()
    val speedStr = formatSpeed(transfer.speedBytesPerSecond)
    val etaStr = if (transfer.remainingTimeSeconds > 0) "${transfer.remainingTimeSeconds}s remaining" else ""

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF13182C)),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            1.dp,
            when (transfer.status) {
                TransferStatus.IN_PROGRESS -> Color(0xFF00E5FF).copy(alpha = 0.4f)
                TransferStatus.SUCCESS -> Color(0xFF00E676).copy(alpha = 0.3f)
                TransferStatus.FAILED -> Color(0xFFFF3366).copy(alpha = 0.3f)
                else -> Color.White.copy(alpha = 0.05f)
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (transfer.isIncoming) Color(0xFF00E5FF).copy(alpha = 0.15f)
                            else Color(0xFF7C4DFF).copy(alpha = 0.15f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (transfer.isIncoming) Icons.Rounded.Download else Icons.AutoMirrored.Rounded.Send,
                        contentDescription = null,
                        tint = if (transfer.isIncoming) Color(0xFF00E5FF) else Color(0xFFB388FF),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = transfer.fileName,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "${formatFileSize(transfer.bytesTransferred)} / ${formatFileSize(transfer.fileSize)}",
                            color = Color.LightGray,
                            fontSize = 11.sp
                        )
                        if (transfer.status == TransferStatus.IN_PROGRESS && speedStr.isNotEmpty()) {
                            Text(
                                text = "• $speedStr",
                                color = Color(0xFF00E5FF),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Status Badge
                when (transfer.status) {
                    TransferStatus.IN_PROGRESS -> {
                        Text(
                            text = "$percent%",
                            color = Color(0xFF00E5FF),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                    TransferStatus.SUCCESS -> {
                        Icon(
                            Icons.Rounded.CheckCircle,
                            contentDescription = "Success",
                            tint = Color(0xFF00E676),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    TransferStatus.FAILED -> {
                        Icon(
                            Icons.Rounded.Error,
                            contentDescription = "Failed",
                            tint = Color(0xFFFF3366),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    else -> {}
                }
            }

            if (transfer.status == TransferStatus.IN_PROGRESS) {
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = Color(0xFF00E5FF),
                    trackColor = Color.White.copy(alpha = 0.1f)
                )

                if (etaStr.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = etaStr,
                        color = Color.Gray,
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }
    }
}

@Composable
private fun FileSelectItemRow(
    file: TransferFile,
    isSelected: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF1A223D) else Color(0xFF111422)
        ),
        border = BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.05f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        when (file.type) {
                            "VIDEO" -> Color(0xFFFF5252).copy(alpha = 0.15f)
                            "MUSIC" -> Color(0xFF00E676).copy(alpha = 0.15f)
                            else -> Color(0xFF00E5FF).copy(alpha = 0.15f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when (file.type) {
                        "VIDEO" -> Icons.Rounded.Videocam
                        "MUSIC" -> Icons.Rounded.MusicNote
                        else -> Icons.Rounded.InsertDriveFile
                    },
                    contentDescription = null,
                    tint = when (file.type) {
                        "VIDEO" -> Color(0xFFFF5252)
                        "MUSIC" -> Color(0xFF00E676)
                        else -> Color(0xFF00E5FF)
                    },
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = file.name,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = formatFileSize(file.size),
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }

            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = Color(0xFF00E5FF),
                    checkmarkColor = Color.Black,
                    uncheckedColor = Color.Gray
                )
            )
        }
    }
}

@Composable
private fun DeviceRadarChip(
    device: DiscoveredDevice,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF1E2644),
        border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E5FF).copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Rounded.PhoneAndroid,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(Modifier.width(8.dp))
            Column {
                Text(
                    text = device.deviceName,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "PIN: ${device.sessionCode}",
                    color = Color(0xFF00E5FF),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun CategoryChip(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) Color(0xFF00E5FF) else Color(0xFF14192B),
        border = BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.08f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isSelected) Color.Black else Color.LightGray,
                modifier = Modifier.size(14.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = title,
                color = if (isSelected) Color.Black else Color.White,
                fontSize = 12.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun StepInstructionRow(step: String, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .clip(CircleShape)
                .background(Color(0xFF7C4DFF)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = step,
                color = Color.White,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.width(10.dp))
        Text(
            text = text,
            color = Color.LightGray,
            fontSize = 12.sp,
            modifier = Modifier.weight(1f)
        )
    }
}

// =============================================================================
// DIRECT 6-DIGIT PIN CONNECT DIALOG
// =============================================================================
@Composable
private fun DirectPinConnectDialog(
    targetDevice: DiscoveredDevice?,
    selectedFilesCount: Int,
    onDismiss: () -> Unit,
    onConnectByCodeOnly: (code: String) -> Unit,
    onConnectAndSend: (ip: String, port: Int, code: String) -> Unit
) {
    var enteredCode by remember { mutableStateOf(targetDevice?.sessionCode ?: "") }
    var enteredIp by remember { mutableStateOf(targetDevice?.ip ?: "") }
    var showAdvancedIp by remember { mutableStateOf(targetDevice != null || enteredIp.isNotEmpty()) }
    var enteredPort by remember { mutableStateOf(targetDevice?.port?.toString() ?: "8989") }
    val keyboardController = LocalSoftwareKeyboardController.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF14192B),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Rounded.Dialpad,
                    contentDescription = null,
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = if (targetDevice != null) "Connect to ${targetDevice.deviceName}" else "Instant 6-Digit PIN Connect",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "No QR scan or IP address needed! Just type the 6-digit PIN shown on the receiver phone.",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )

                // 6-Digit PIN input field - Primary method
                OutlinedTextField(
                    value = enteredCode,
                    onValueChange = { if (it.length <= 6) enteredCode = it },
                    label = { Text("6-Digit PIN Code (e.g. 748291)") },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        fontFamily = FontFamily.Monospace
                    ),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color.Gray,
                        focusedLabelColor = Color(0xFF00E5FF)
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Optional Advanced: IP address
                if (!showAdvancedIp) {
                    TextButton(
                        onClick = { showAdvancedIp = true },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "+ Enter IP address manually (optional)",
                            color = Color(0xFF00E5FF),
                            fontSize = 12.sp
                        )
                    }
                } else {
                    OutlinedTextField(
                        value = enteredIp,
                        onValueChange = { enteredIp = it },
                        label = { Text("Receiver IP (Optional, e.g. 192.168.43.1)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Next
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF00E5FF),
                            unfocusedBorderColor = Color.Gray,
                            focusedLabelColor = Color(0xFF00E5FF)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (selectedFilesCount > 0) {
                    Text(
                        text = "Ready to send $selectedFilesCount selected files at superfast speed.",
                        color = Color(0xFF00E676),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val port = enteredPort.toIntOrNull() ?: 8989
                    val code = enteredCode.trim()
                    val ip = enteredIp.trim()
                    if (ip.isNotEmpty()) {
                        onConnectAndSend(ip, port, code.ifEmpty { "AUTO_DISCOVERY" })
                    } else if (code.length == 6) {
                        onConnectByCodeOnly(code)
                    }
                },
                enabled = enteredCode.length == 6 || enteredIp.isNotBlank() || targetDevice != null,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("Connect & Send", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.LightGray)
            }
        }
    )
}

// =============================================================================
// HELPER FORMATTERS
// =============================================================================
private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format(
        Locale.US,
        "%.1f %s",
        bytes / Math.pow(1024.0, digitGroups.toDouble()),
        units[digitGroups]
    )
}

private fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0) return ""
    return "${formatFileSize(bytesPerSec)}/s"
}
