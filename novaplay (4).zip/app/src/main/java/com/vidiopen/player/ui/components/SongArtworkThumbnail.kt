package com.vidiopen.player.ui.components

import android.net.Uri
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImagePainter
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import com.vidiopen.player.data.model.ScannedSong
import java.io.File
import kotlin.math.abs

/**
 * 12 Curated high-aesthetic, colorful gradient palettes for song thumbnails.
 */
val ThumbnailArtworkGradients = listOf(
    listOf(Color(0xFFFF0844), Color(0xFFFFB199)),               // Sunset Coral
    listOf(Color(0xFF8A2387), Color(0xFFE94057), Color(0xFFF27121)), // Cyberpunk Magenta
    listOf(Color(0xFF00C6FF), Color(0xFF0072FF)),               // Electric Azure
    listOf(Color(0xFF0BA360), Color(0xFF3CBA92)),               // Emerald Mint
    listOf(Color(0xFF7F00FF), Color(0xFFE100FF)),               // Neon Ultraviolet
    listOf(Color(0xFFFF512F), Color(0xFFDD2476)),               // Ruby Flame
    listOf(Color(0xFF11998E), Color(0xFF38EF7D)),               // Neon Teal
    listOf(Color(0xFFFF8008), Color(0xFFFFC837)),               // Golden Amber
    listOf(Color(0xFF4776E6), Color(0xFF8E54E9)),               // Deep Indigo
    listOf(Color(0xFFFA709A), Color(0xFFFEE140)),               // Tropical Sunrise
    listOf(Color(0xFF30CFD0), Color(0xFF330867)),               // Mystic Ocean
    listOf(Color(0xFF654EA3), Color(0xFFEAAFC8))                // Lavender Dream
)

private val FallbackIcons = listOf(
    Icons.Rounded.MusicNote,
    Icons.Rounded.Headphones,
    Icons.Rounded.GraphicEq,
    Icons.Rounded.Audiotrack,
    Icons.Rounded.Album
)

/**
 * High-aesthetic, colorful song artwork thumbnail component.
 * Displays embedded/scanned artwork if available.
 * If not available or loading fails, dynamically renders an eye-catching,
 * colorful gradient album art with vinyl grooves and musical iconography.
 * When playing, shows an animated audio equalizer overlay.
 */
@Composable
fun SongArtworkThumbnail(
    song: ScannedSong,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = false,
    size: Dp = 44.dp,
    shape: Shape = RoundedCornerShape(10.dp),
    showPlayingAnimation: Boolean = true
) {
    SongArtworkThumbnail(
        title = song.title,
        artist = song.artist,
        artworkUri = song.artworkUri,
        songId = song.id,
        songPath = song.path,
        modifier = modifier,
        isPlaying = isPlaying,
        size = size,
        shape = shape,
        showPlayingAnimation = showPlayingAnimation
    )
}

@Composable
fun SongArtworkThumbnail(
    title: String,
    artist: String? = null,
    artworkUri: String? = null,
    songId: Long = 0L,
    songPath: String? = null,
    modifier: Modifier = Modifier,
    isPlaying: Boolean = false,
    size: Dp = 44.dp,
    shape: Shape = RoundedCornerShape(10.dp),
    showPlayingAnimation: Boolean = true
) {
    val context = LocalContext.current

    // Deterministic palette and icon based on song metadata
    val hash = remember(songId, title) {
        abs(songId.hashCode() * 31 + title.hashCode())
    }
    val gradientColors = remember(hash) {
        ThumbnailArtworkGradients[hash % ThumbnailArtworkGradients.size]
    }
    val icon = remember(hash) {
        FallbackIcons[(hash / 7) % FallbackIcons.size]
    }

    // Determine candidate model for Coil
    val imageModel = remember(artworkUri, songPath) {
        when {
            !artworkUri.isNullOrBlank() -> Uri.parse(artworkUri)
            !songPath.isNullOrBlank() && com.vidiopen.player.utils.EmbeddedPictureDetector.hasEmbeddedPicture(songPath) -> File(songPath)
            else -> null
        }
    }

    val painter = if (imageModel != null) {
        rememberAsyncImagePainter(
            model = ImageRequest.Builder(context)
                .data(imageModel)
                .crossfade(true)
                .build()
        )
    } else null

    val isImageLoaded = painter?.state is AsyncImagePainter.State.Success

    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .then(
                if (isPlaying) {
                    Modifier.border(1.5.dp, Color(0xFF25D366), shape)
                } else {
                    Modifier.border(1.dp, Color.White.copy(alpha = 0.14f), shape)
                }
            ),
        contentAlignment = Alignment.Center
    ) {
        if (painter != null && isImageLoaded) {
            Image(
                painter = painter,
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            ColorfulArtworkFallback(
                gradientColors = gradientColors,
                icon = icon,
                size = size
            )
        }

        // Live Playing Equalizer animation overlay
        if (isPlaying && showPlayingAnimation) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.42f)),
                contentAlignment = Alignment.Center
            ) {
                MiniPlayingEqualizer(size = size)
            }
        }
    }
}

/**
 * Renders the vibrant colorful gradient album art with vinyl grooves and gloss.
 */
@Composable
private fun ColorfulArtworkFallback(
    gradientColors: List<Color>,
    icon: ImageVector,
    size: Dp
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    colors = gradientColors,
                    start = Offset.Zero,
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Vinyl record rings
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val maxR = (this.size.width.coerceAtMost(this.size.height)) / 2f

            // Concentric delicate grooves
            drawCircle(
                color = Color.White.copy(alpha = 0.12f),
                radius = maxR * 0.4f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.2.dp.toPx())
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.10f),
                radius = maxR * 0.7f,
                center = Offset(cx, cy),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // Top glossy highlight
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.26f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.22f)
                        )
                    )
                )
        )

        // Center music icon
        val iconSize = (size * 0.44f).coerceIn(16.dp, 26.dp)
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(iconSize)
        )
    }
}

/**
 * Dancing 3-bar equalizer animation indicating active playback.
 */
@Composable
private fun MiniPlayingEqualizer(size: Dp) {
    val barHeight = (size * 0.40f).coerceIn(12.dp, 20.dp)
    Row(
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalAlignment = Alignment.Bottom,
        modifier = Modifier.height(barHeight)
    ) {
        val infiniteTransition = rememberInfiniteTransition(label = "MiniEqualizer")
        repeat(3) { i ->
            val animHeight = infiniteTransition.animateFloat(
                initialValue = 0.25f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 350 + i * 140,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "Wave$i"
            )
            Box(
                modifier = Modifier
                    .width(2.5.dp)
                    .fillMaxHeight(animHeight.value)
                    .background(Color(0xFF25D366), RoundedCornerShape(1.dp))
            )
        }
    }
}
