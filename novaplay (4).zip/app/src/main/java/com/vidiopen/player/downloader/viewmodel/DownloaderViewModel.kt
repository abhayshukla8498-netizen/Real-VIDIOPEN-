package com.vidiopen.player.downloader.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.downloader.model.DetectedVideo
import com.vidiopen.player.downloader.model.DownloadedVideoItem
import com.vidiopen.player.downloader.model.VideoQualityOption
import com.vidiopen.player.downloader.service.VidiopenDownloadManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URI

enum class DownloaderTab {
    BROWSER,
    DOWNLOADS
}

class DownloaderViewModel(application: Application) : AndroidViewModel(application) {

    private val downloadManager = VidiopenDownloadManager(application)

    private val _selectedTab = MutableStateFlow(DownloaderTab.BROWSER)
    val selectedTab: StateFlow<DownloaderTab> = _selectedTab.asStateFlow()

    private val _currentUrl = MutableStateFlow("https://www.google.com")
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _detectedVideo = MutableStateFlow<DetectedVideo?>(null)
    val detectedVideo: StateFlow<DetectedVideo?> = _detectedVideo.asStateFlow()

    private val _selectedQuality = MutableStateFlow("720p")
    val selectedQuality: StateFlow<String> = _selectedQuality.asStateFlow()

    private val _activeCardDownloadId = MutableStateFlow<Long?>(null)
    val activeCardDownloadId: StateFlow<Long?> = _activeCardDownloadId.asStateFlow()

    private val _hiddenWebViewUrl = MutableStateFlow<String?>(null)
    val hiddenWebViewUrl: StateFlow<String?> = _hiddenWebViewUrl.asStateFlow()

    private val _warningMessage = MutableStateFlow<String?>(null)
    val warningMessage: StateFlow<String?> = _warningMessage.asStateFlow()

    private val _infoMessage = MutableStateFlow<String?>(null)
    val infoMessage: StateFlow<String?> = _infoMessage.asStateFlow()

    val downloadedVideos: StateFlow<List<DownloadedVideoItem>> = downloadManager.downloadedVideos
    val activeDownloads: StateFlow<Map<Long, DownloadedVideoItem>> = downloadManager.activeDownloads

    private var analyzeJob: kotlinx.coroutines.Job? = null

    init {
        // Polling coroutine for active downloads (updates progress & live speed smoothly)
        viewModelScope.launch {
            while (isActive) {
                if (downloadManager.activeDownloads.value.isNotEmpty()) {
                    downloadManager.updateActiveProgress()
                }
                delay(500)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        downloadManager.unregister()
    }

    fun setSelectedTab(tab: DownloaderTab) {
        _selectedTab.value = tab
        if (tab == DownloaderTab.DOWNLOADS) {
            refreshDownloads()
        }
    }

    fun setUrlInput(input: String) {
        _urlInput.value = input
    }

    fun setSelectedQuality(quality: String) {
        _selectedQuality.value = quality
    }

    fun clearWarningMessage() {
        _warningMessage.value = null
    }

    fun clearInfoMessage() {
        _infoMessage.value = null
    }

    fun clearDetectedVideo() {
        analyzeJob?.cancel()
        _detectedVideo.value = null
        _isAnalyzing.value = false
        _hiddenWebViewUrl.value = null
    }

    /**
     * Triggered when the user clicks "Get Video".
     * First runs ultra-fast direct network extraction, and simultaneously loads
     * hidden WebView sniffer as a fallback for JavaScript-hydrated pages.
     */
    fun getVideo(input: String) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) {
            _warningMessage.value = "Please paste a video link first"
            return
        }

        // Clean and extract URL from pasted string (even if user pasted text around the link)
        val extractedUrl = com.vidiopen.player.downloader.util.VideoExtractorUtil.extractCleanUrl(trimmed)
            ?: if (trimmed.contains(".") && !trimmed.contains(" ")) "https://$trimmed" else null

        if (extractedUrl == null) {
            _warningMessage.value = "Link not found. Please enter a valid video link (e.g. from Instagram, Facebook, Twitter, Moj, Josh)"
            return
        }

        // Strictly enforce Rule: Do NOT add YouTube downloader anywhere
        if (extractedUrl.contains("youtube.com", ignoreCase = true) || extractedUrl.contains("youtu.be", ignoreCase = true)) {
            _warningMessage.value = "YouTube downloading is not supported. Please paste links from Instagram, Facebook, Twitter, Moj, Josh, etc."
            return
        }

        val targetUrl = extractedUrl
        _urlInput.value = targetUrl
        _detectedVideo.value = null
        _activeCardDownloadId.value = null
        _isAnalyzing.value = true
        _infoMessage.value = "Fetching video via Cobalt API & In-App Extractor..."

        // 1. Immediately activate hidden WebView sniffer so it navigates in parallel without waiting!
        _hiddenWebViewUrl.value = targetUrl

        // Cancel any pending analysis timeout
        analyzeJob?.cancel()
        analyzeJob = viewModelScope.launch {
            // Concurrently run ultra-fast direct network extraction
            val extractorJob = launch(Dispatchers.IO) {
                try {
                    val directResult = com.vidiopen.player.downloader.util.VideoExtractorUtil.extractVideo(targetUrl)
                    if (directResult != null && directResult.videoUrl.isNotBlank()) {
                        val cleanVideo = com.vidiopen.player.downloader.util.VideoExtractorUtil.cleanVideoUrl(directResult.videoUrl)
                        val qualities = buildQualityOptions(
                            hdUrl = directResult.hdUrl?.let { com.vidiopen.player.downloader.util.VideoExtractorUtil.cleanVideoUrl(it) },
                            sdUrl = directResult.sdUrl?.let { com.vidiopen.player.downloader.util.VideoExtractorUtil.cleanVideoUrl(it) },
                            fallbackUrl = cleanVideo,
                            contentLengthBytes = directResult.contentLengthBytes
                        )

                        val detected = DetectedVideo(
                            url = cleanVideo,
                            title = directResult.title.ifBlank { "${directResult.sourceDomain} Video" },
                            sourceDomain = directResult.sourceDomain,
                            mimeType = "video/mp4",
                            thumbnail = directResult.thumbnail,
                            qualities = qualities
                        )

                        withContext(Dispatchers.Main) {
                            if (_detectedVideo.value == null) {
                                _detectedVideo.value = detected
                                _selectedQuality.value = "720p"
                                _isAnalyzing.value = false
                                _hiddenWebViewUrl.value = null
                                _infoMessage.value = "Video ready! Choose quality and tap Download Now."

                                if (directResult.thumbnail.isNullOrBlank()) {
                                    viewModelScope.launch(Dispatchers.IO) {
                                        try {
                                            val frameThumb = com.vidiopen.player.downloader.util.VideoExtractorUtil.extractFrameThumbnail(
                                                getApplication(),
                                                cleanVideo
                                            )
                                            if (!frameThumb.isNullOrBlank()) {
                                                withContext(Dispatchers.Main) {
                                                    val cur = _detectedVideo.value
                                                    if (cur != null && cur.thumbnail.isNullOrBlank()) {
                                                        _detectedVideo.value = cur.copy(thumbnail = frameThumb)
                                                    }
                                                }
                                            }
                                        } catch (_: Exception) {}
                                    }
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    timber.log.Timber.w(e, "Fast direct extraction failed, relying on concurrent WebView sniffer")
                }
            }

            // High-speed overall safety timeout (28s allows Cobalt and in-app fallbacks to finish)
            delay(28000)
            if (_isAnalyzing.value && _detectedVideo.value == null) {
                extractorJob.cancel()
                _isAnalyzing.value = false
                _hiddenWebViewUrl.value = null
                _warningMessage.value = "Video not found. Please verify the post or reel is public and accessible."
            }
        }
    }

    /**
     * Called by hidden WebView when an MP4 or video stream URL is intercepted.
     */
    fun onVideoDetected(rawUrl: String, optionalTitle: String? = null, optionalThumbnail: String? = null) {
        val cleanUrl = com.vidiopen.player.downloader.util.VideoExtractorUtil.cleanVideoUrl(rawUrl.trim())
        if (cleanUrl.isEmpty()) return

        // Rule: Do NOT download YouTube
        if (cleanUrl.contains("youtube.com", ignoreCase = true) ||
            cleanUrl.contains("youtu.be", ignoreCase = true) ||
            cleanUrl.contains("googlevideo.com", ignoreCase = true)
        ) {
            return
        }

        // Avoid blob / data URLs
        if (cleanUrl.startsWith("blob:", ignoreCase = true) || cleanUrl.startsWith("data:", ignoreCase = true)) {
            return
        }

        val lower = cleanUrl.lowercase()
        val isVideoUrl = lower.contains(".mp4") ||
                lower.contains(".webm") ||
                lower.contains(".mkv") ||
                lower.contains(".mov") ||
                lower.contains("/video/") ||
                lower.contains("mime_type=video") ||
                lower.contains("fbcdn.net") ||
                lower.contains("cdninstagram.com") ||
                lower.contains("twimg.com") ||
                lower.contains("tiktokcdn.com") ||
                lower.contains("v.redd.it") ||
                lower.contains("pinimg.com") ||
                lower.contains("moj") ||
                lower.contains("josh")

        if (!isVideoUrl) return

        // If video is already detected, update thumbnail if previous was null
        val current = _detectedVideo.value
        if (current != null) {
            if (current.thumbnail.isNullOrBlank() && !optionalThumbnail.isNullOrBlank()) {
                _detectedVideo.value = current.copy(thumbnail = optionalThumbnail)
            }
            return
        }

        val sourceDomain = com.vidiopen.player.downloader.util.VideoExtractorUtil.extractDomain(cleanUrl)
        val title = optionalTitle?.ifBlank { null } ?: "$sourceDomain Video"

        val qualities = buildQualityOptions(
            hdUrl = cleanUrl,
            sdUrl = cleanUrl,
            fallbackUrl = cleanUrl,
            contentLengthBytes = 0L
        )

        val newDetected = DetectedVideo(
            url = cleanUrl,
            title = title,
            sourceDomain = sourceDomain,
            mimeType = "video/mp4",
            thumbnail = optionalThumbnail,
            qualities = qualities
        )

        analyzeJob?.cancel()
        _detectedVideo.value = newDetected
        _selectedQuality.value = "720p"
        _isAnalyzing.value = false
        _hiddenWebViewUrl.value = null
        _infoMessage.value = "Video ready! Choose quality and tap Download Now."

        // If thumbnail is still null, extract frame thumbnail in background so user sees video thumbnail instantly!
        if (optionalThumbnail.isNullOrBlank()) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    val frameThumb = com.vidiopen.player.downloader.util.VideoExtractorUtil.extractFrameThumbnail(
                        getApplication(),
                        cleanUrl
                    )
                    if (!frameThumb.isNullOrBlank()) {
                        withContext(Dispatchers.Main) {
                            val cur = _detectedVideo.value
                            if (cur != null && cur.thumbnail.isNullOrBlank()) {
                                _detectedVideo.value = cur.copy(thumbnail = frameThumb)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun buildQualityOptions(
        hdUrl: String?,
        sdUrl: String?,
        fallbackUrl: String,
        contentLengthBytes: Long = 0L
    ): List<VideoQualityOption> {
        val baseBytes = if (contentLengthBytes > 0) contentLengthBytes else 22_400_000L
        val size1080 = (baseBytes * 1.55).toLong()
        val size720 = baseBytes
        val size480 = (baseBytes * 0.52).toLong()
        val size360 = (baseBytes * 0.26).toLong()

        fun toMbStr(bytes: Long): String {
            val mb = bytes / (1024.0 * 1024.0)
            return String.format(java.util.Locale.US, "%.1f MB", mb)
        }

        return listOf(
            VideoQualityOption(
                label = "1080p",
                resolution = "Full HD (1080p)",
                estimatedSize = toMbStr(size1080),
                sizeBytes = size1080,
                badge = "BEST QUALITY",
                description = "Maximum clarity & details",
                videoUrl = hdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "720p",
                resolution = "High Definition (720p)",
                estimatedSize = toMbStr(size720),
                sizeBytes = size720,
                badge = "RECOMMENDED",
                description = "Optimal balance of quality & data",
                videoUrl = hdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "480p",
                resolution = "Standard (480p)",
                estimatedSize = toMbStr(size480),
                sizeBytes = size480,
                badge = "SAVES 50%",
                description = "Fast download for quick sharing",
                videoUrl = sdUrl ?: fallbackUrl
            ),
            VideoQualityOption(
                label = "360p",
                resolution = "Data Saver (360p)",
                estimatedSize = toMbStr(size360),
                sizeBytes = size360,
                badge = "SAVES 75%",
                description = "Lowest data usage & ultra-fast",
                videoUrl = sdUrl ?: fallbackUrl
            )
        )
    }

    /**
     * Starts download of the detected video in the card using Android's DownloadManager.
     */
     fun downloadCurrentVideo() {
        val video = _detectedVideo.value ?: return
        val quality = video.qualities.find { it.label.equals(_selectedQuality.value, ignoreCase = true) }
            ?: video.qualities.firstOrNull()
            ?: return

        val title = video.title.ifBlank { "vidiopen_${System.currentTimeMillis()}" }
        val downloadId = downloadManager.enqueueDownload(
            videoUrl = quality.videoUrl,
            rawTitle = title,
            qualityLabel = quality.label,
            expectedSizeBytes = quality.sizeBytes
        )
        if (downloadId != null) {
            _activeCardDownloadId.value = downloadId
            _infoMessage.value = "Downloading ${quality.label} (${quality.estimatedSize}) to /Vidiopen/Downloads..."
        } else {
            _warningMessage.value = "Failed to start download. Please check storage permissions."
        }
    }

    fun cancelDownload(downloadId: Long) {
        downloadManager.cancelDownload(downloadId)
        if (_activeCardDownloadId.value == downloadId) {
            _activeCardDownloadId.value = null
        }
        _infoMessage.value = "Download cancelled"
    }

    fun startDownload(video: DetectedVideo, quality: VideoQualityOption) {
        val title = video.title.ifBlank { "video_${System.currentTimeMillis()}" }
        val downloadId = downloadManager.enqueueDownload(
            videoUrl = quality.videoUrl,
            rawTitle = title,
            qualityLabel = quality.label,
            expectedSizeBytes = quality.sizeBytes
        )
        if (downloadId != null) {
            _activeCardDownloadId.value = downloadId
            _infoMessage.value = "Download started! (${quality.label} • ${quality.estimatedSize})"
        } else {
            _warningMessage.value = "Failed to start download. Please try again."
        }
    }

    fun refreshDownloads() {
        downloadManager.refreshDownloadedVideos()
    }

    fun deleteDownloadedVideo(item: DownloadedVideoItem) {
        downloadManager.deleteDownloadedVideo(item)
    }

    fun shareDownloadedVideo(item: DownloadedVideoItem) {
        downloadManager.shareDownloadedVideo(item)
    }

    private fun String.capitalizeDomain(): String {
        return this.split(".").firstOrNull()?.replaceFirstChar { it.uppercase() } ?: this
    }
}

class DownloaderViewModelFactory(private val application: Application) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(DownloaderViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return DownloaderViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
