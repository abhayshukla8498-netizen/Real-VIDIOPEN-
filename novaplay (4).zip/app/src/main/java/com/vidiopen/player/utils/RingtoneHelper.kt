package com.vidiopen.player.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object RingtoneHelper {

    /**
     * Checks if app has permission to write system settings (required to change ringtone on Android 6+).
     */
    fun canWriteSettings(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.System.canWrite(context)
        } else {
            true
        }
    }

    /**
     * Opens System Settings screen so the user can enable "Modify system settings".
     */
    fun requestWriteSettingsPermission(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                // Fallback to general settings
                try {
                    val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(fallbackIntent)
                } catch (_: Exception) {}
            }
        }
    }

    /**
     * Sets an audio file (or trimmed audio) as the Android phone ringtone.
     * Works across Android versions (Android 10, 11, 12, 13, 14, 15) using public MediaStore or file copy.
     */
    suspend fun setAsRingtone(
        context: Context,
        sourceFilePathOrUri: String,
        title: String,
        appLang: String,
        ringtoneType: Int = RingtoneManager.TYPE_RINGTONE
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            // Check permission first
            if (!canWriteSettings(context)) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        if (appLang == "hi")
                            "रिंगटोन सेट करने के लिए 'Modify system settings' अनुमति चालू करें"
                        else
                            "Please grant 'Modify system settings' permission to set ringtone",
                        Toast.LENGTH_LONG
                    ).show()
                    requestWriteSettingsPermission(context)
                }
                return@withContext false
            }

            val sanitizedTitle = title.ifBlank { "Custom Ringtone" }
            val ringtoneUri = insertIntoRingtonesMediaStore(context, sourceFilePathOrUri, sanitizedTitle)

            if (ringtoneUri != null) {
                try {
                    RingtoneManager.setActualDefaultRingtoneUri(context, ringtoneType, ringtoneUri)
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            if (appLang == "hi")
                                "🔔 '$sanitizedTitle' फ़ोन की रिंगटोन सफलतापूर्वक सेट हो गई!"
                            else
                                "🔔 '$sanitizedTitle' set as phone ringtone successfully!",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    return@withContext true
                } catch (e: SecurityException) {
                    e.printStackTrace()
                    withContext(Dispatchers.Main) {
                        Toast.makeText(
                            context,
                            if (appLang == "hi")
                                "रिंगटोन सेट करने की अनुमति नहीं मिली, कृपया सेटिंग्स में अनुमति दें"
                            else
                                "Permission denied to change ringtone. Please grant in settings.",
                            Toast.LENGTH_LONG
                        ).show()
                        requestWriteSettingsPermission(context)
                    }
                    return@withContext false
                }
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        context,
                        if (appLang == "hi")
                            "रिंगटोन फ़ाइल सिस्टम में सेव नहीं हो सकी"
                        else
                            "Could not save ringtone to system",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                return@withContext false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            withContext(Dispatchers.Main) {
                Toast.makeText(
                    context,
                    if (appLang == "hi")
                        "रिंगटोन सेट करने में त्रुटि: ${e.localizedMessage ?: "Unknown error"}"
                    else
                        "Error setting ringtone: ${e.localizedMessage ?: "Unknown error"}",
                    Toast.LENGTH_SHORT
                ).show()
            }
            return@withContext false
        }
    }

    /**
     * Copies or inserts the audio file into the system's public MediaStore Ringtones collection
     * and returns the resulting content Uri accessible by the system ringtone service.
     */
    private fun insertIntoRingtonesMediaStore(
        context: Context,
        sourceFilePathOrUri: String,
        title: String
    ): Uri? {
        val resolver = context.contentResolver
        val isContent = sourceFilePathOrUri.startsWith("content://")
        val sourceFile = if (!isContent) File(sourceFilePathOrUri) else null

        // Determine mime type and extension
        val mimeType = when {
            sourceFilePathOrUri.endsWith(".wav", ignoreCase = true) -> "audio/wav"
            sourceFilePathOrUri.endsWith(".m4a", ignoreCase = true) -> "audio/mp4"
            sourceFilePathOrUri.endsWith(".ogg", ignoreCase = true) -> "audio/ogg"
            else -> "audio/mpeg"
        }
        val ext = when {
            sourceFilePathOrUri.endsWith(".wav", ignoreCase = true) -> ".wav"
            sourceFilePathOrUri.endsWith(".m4a", ignoreCase = true) -> ".m4a"
            sourceFilePathOrUri.endsWith(".ogg", ignoreCase = true) -> ".ogg"
            else -> ".mp3"
        }
        val fileName = "Ringtone_${title.replace(Regex("[^a-zA-Z0-9_]"), "_")}_${System.currentTimeMillis()}$ext"

        // For Android 10+ (API 29+), insert via MediaStore into Environment.DIRECTORY_RINGTONES
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Audio.Media.TITLE, title)
                put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_RINGTONES + "/VidiOpen")
                put(MediaStore.Audio.Media.IS_RINGTONE, 1)
                put(MediaStore.Audio.Media.IS_NOTIFICATION, 0)
                put(MediaStore.Audio.Media.IS_ALARM, 0)
                put(MediaStore.Audio.Media.IS_MUSIC, 0)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }

            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val itemUri = resolver.insert(collection, contentValues) ?: return null

            try {
                resolver.openOutputStream(itemUri)?.use { outStream ->
                    if (isContent) {
                        resolver.openInputStream(Uri.parse(sourceFilePathOrUri))?.use { inStream ->
                            inStream.copyTo(outStream)
                        } ?: return null
                    } else if (sourceFile != null && sourceFile.exists()) {
                        FileInputStream(sourceFile).use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    } else {
                        return null
                    }
                }

                // Finish pending
                val updateValues = ContentValues().apply {
                    put(MediaStore.Audio.Media.IS_PENDING, 0)
                }
                resolver.update(itemUri, updateValues, null, null)
                return itemUri
            } catch (e: Exception) {
                e.printStackTrace()
                try { resolver.delete(itemUri, null, null) } catch (_: Exception) {}
                return null
            }
        } else {
            // Android 9 and below
            val ringtonesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_RINGTONES)
            if (!ringtonesDir.exists()) ringtonesDir.mkdirs()
            val destFile = File(ringtonesDir, fileName)

            try {
                FileOutputStream(destFile).use { outStream ->
                    if (isContent) {
                        resolver.openInputStream(Uri.parse(sourceFilePathOrUri))?.use { inStream ->
                            inStream.copyTo(outStream)
                        } ?: return null
                    } else if (sourceFile != null && sourceFile.exists()) {
                        FileInputStream(sourceFile).use { inStream ->
                            inStream.copyTo(outStream)
                        }
                    } else {
                        return null
                    }
                }

                val contentValues = ContentValues().apply {
                    put(MediaStore.Audio.Media.DATA, destFile.absolutePath)
                    put(MediaStore.Audio.Media.TITLE, title)
                    put(MediaStore.Audio.Media.MIME_TYPE, mimeType)
                    put(MediaStore.Audio.Media.SIZE, destFile.length())
                    put(MediaStore.Audio.Media.IS_RINGTONE, 1)
                    put(MediaStore.Audio.Media.IS_NOTIFICATION, 0)
                    put(MediaStore.Audio.Media.IS_ALARM, 0)
                    put(MediaStore.Audio.Media.IS_MUSIC, 0)
                }

                val collection = MediaStore.Audio.Media.getContentUriForPath(destFile.absolutePath)
                    ?: MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                resolver.delete(collection, "${MediaStore.Audio.Media.DATA}=?", arrayOf(destFile.absolutePath))
                val insertedUri = resolver.insert(collection, contentValues)

                MediaScannerConnection.scanFile(context, arrayOf(destFile.absolutePath), arrayOf(mimeType), null)
                return insertedUri ?: Uri.fromFile(destFile)
            } catch (e: Exception) {
                e.printStackTrace()
                return null
            }
        }
    }
}
