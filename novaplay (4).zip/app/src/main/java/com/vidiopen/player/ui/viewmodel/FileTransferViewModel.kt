package com.vidiopen.player.ui.viewmodel

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.ActiveTransfer
import com.vidiopen.player.data.model.DiscoveredDevice
import com.vidiopen.player.data.model.TransferFile
import com.vidiopen.player.data.transfer.FileTransferManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Modern Jetpack Compose ViewModel for VIDIOpen Offline File Transfer.
 * Manages Send / Receive state, 6-digit PIN pairing, UDP Radar discovery,
 * file selection from MediaStore, and live byte-level transfer progress.
 */
class FileTransferViewModel(
    application: Application,
    val transferManager: FileTransferManager
) : AndroidViewModel(application) {

    // Manager state bridges
    val isServerRunning: StateFlow<Boolean> = transferManager.isServerRunning
    val isScanning: StateFlow<Boolean> = transferManager.isScanning
    val isTransferring: StateFlow<Boolean> = transferManager.isTransferring
    val serverIp: StateFlow<String?> = transferManager.serverIp
    val serverPort: StateFlow<Int> = transferManager.serverPort
    val sessionCode: StateFlow<String> = transferManager.sessionCode
    val discoveredDevices: StateFlow<List<DiscoveredDevice>> = transferManager.discoveredDevices
    val activeTransfers: StateFlow<List<ActiveTransfer>> = transferManager.activeTransfers
    val transferError: StateFlow<String?> = transferManager.transferError
    val transferSuccessCount: StateFlow<Int> = transferManager.transferSuccessCount

    // Selected files to send
    private val _selectedFiles = MutableStateFlow<List<TransferFile>>(emptyList())
    val selectedFiles: StateFlow<List<TransferFile>> = _selectedFiles.asStateFlow()

    // Scanned device storage media (Videos, Audio, Documents)
    private val _storageVideos = MutableStateFlow<List<TransferFile>>(emptyList())
    val storageVideos: StateFlow<List<TransferFile>> = _storageVideos.asStateFlow()

    private val _storageAudio = MutableStateFlow<List<TransferFile>>(emptyList())
    val storageAudio: StateFlow<List<TransferFile>> = _storageAudio.asStateFlow()

    private val _storageDocs = MutableStateFlow<List<TransferFile>>(emptyList())
    val storageDocs: StateFlow<List<TransferFile>> = _storageDocs.asStateFlow()

    private val _isLoadingStorage = MutableStateFlow(false)
    val isLoadingStorage: StateFlow<Boolean> = _isLoadingStorage.asStateFlow()

    // Active transfer banner status
    private val _transferCompleteMessage = MutableStateFlow<String?>(null)
    val transferCompleteMessage: StateFlow<String?> = _transferCompleteMessage.asStateFlow()

    init {
        loadDeviceMedia()
    }

    // -------------------------------------------------------------------------
    // RECEIVER WORKFLOW
    // -------------------------------------------------------------------------
    fun startReceiving() {
        transferManager.startReceiverServer()
    }

    fun stopReceiving() {
        transferManager.stopReceiverServer()
    }

    fun resetSessionCode() {
        transferManager.resetSession()
    }

    // -------------------------------------------------------------------------
    // SENDER WORKFLOW & DISCOVERY
    // -------------------------------------------------------------------------
    fun startDiscovery() {
        transferManager.startNearbyDeviceScanner()
    }

    fun stopDiscovery() {
        transferManager.stopNearbyDeviceScanner()
    }

    fun toggleFileSelection(file: TransferFile) {
        val current = _selectedFiles.value.toMutableList()
        val index = current.indexOfFirst { it.id == file.id }
        if (index != -1) {
            current.removeAt(index)
        } else {
            current.add(file)
        }
        _selectedFiles.value = current
    }

    fun isFileSelected(file: TransferFile): Boolean {
        return _selectedFiles.value.any { it.id == file.id }
    }

    fun clearSelectedFiles() {
        _selectedFiles.value = emptyList()
    }

    fun selectAllCategory(files: List<TransferFile>) {
        val current = _selectedFiles.value.toMutableList()
        files.forEach { file ->
            if (current.none { it.id == file.id }) {
                current.add(file)
            }
        }
        _selectedFiles.value = current
    }

    /**
     * Send files using 6-digit PIN code direct connection or radar device
     */
    fun sendToDevice(
        targetIp: String,
        targetPort: Int,
        targetCode: String,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val filesToSend = _selectedFiles.value
        if (filesToSend.isEmpty()) return

        transferManager.sendFiles(
            targetIp = targetIp,
            targetPort = targetPort,
            targetCode = targetCode,
            filesToSend = filesToSend,
            onProgress = {},
            onComplete = { success, errorMsg ->
                if (success) {
                    _transferCompleteMessage.value = "Sent ${filesToSend.size} files successfully!"
                    clearSelectedFiles()
                } else {
                    _transferCompleteMessage.value = errorMsg ?: "Transfer failed"
                }
                onComplete(success)
            }
        )
    }

    /**
     * Connect and send using ONLY a 6-digit unique code without having to enter IP address.
     * Looks up device from radar discovery or attempts local network resolution.
     */
    fun sendBySixDigitCode(
        code: String,
        fallbackIp: String? = null,
        onComplete: (Boolean) -> Unit = {}
    ) {
        val cleanCode = code.trim()
        val foundDevice = transferManager.findDeviceByCode(cleanCode)

        val targetIp = foundDevice?.ip ?: fallbackIp?.ifBlank { null }
        val targetPort = foundDevice?.port ?: 8989

        if (!targetIp.isNullOrBlank()) {
            sendToDevice(
                targetIp = targetIp,
                targetPort = targetPort,
                targetCode = cleanCode,
                onComplete = onComplete
            )
        } else {
            _transferCompleteMessage.value = "Device with code $cleanCode not found nearby yet. Make sure receiver is on the same Wi-Fi/Hotspot."
            onComplete(false)
        }
    }

    fun cancelTransfer() {
        transferManager.cancelAllTransfers()
    }

    fun clearTransfers() {
        transferManager.clearTransfers()
        _transferCompleteMessage.value = null
    }

    // -------------------------------------------------------------------------
    // MEDIA STORE SCANNER
    // -------------------------------------------------------------------------
    fun loadDeviceMedia() {
        viewModelScope.launch {
            _isLoadingStorage.value = true
            val context = getApplication<Application>()
            withContext(Dispatchers.IO) {
                _storageVideos.value = queryVideos(context)
                _storageAudio.value = queryAudio(context)
                _storageDocs.value = queryDownloads(context)
            }
            _isLoadingStorage.value = false
        }
    }

    private fun queryVideos(context: Context): List<TransferFile> {
        val list = mutableListOf<TransferFile>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.DATE_MODIFIED
        )
        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
            )
            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val mimeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val name = it.getString(nameCol) ?: "Video_$id"
                    val size = it.getLong(sizeCol)
                    val path = it.getString(dataCol) ?: ""
                    val mime = it.getString(mimeCol) ?: "video/mp4"
                    val date = it.getLong(dateCol)

                    if (size > 0 && path.isNotEmpty() && File(path).exists()) {
                        list.add(
                            TransferFile(
                                id = "vid_$id",
                                name = name,
                                size = size,
                                path = path,
                                type = "VIDEO",
                                mimeType = mime,
                                dateModified = date
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Permission or querying exception
        }
        return list
    }

    private fun queryAudio(context: Context): List<TransferFile> {
        val list = mutableListOf<TransferFile>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_MODIFIED
        )
        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
            )
            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dataCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val mimeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val name = it.getString(nameCol) ?: "Audio_$id"
                    val size = it.getLong(sizeCol)
                    val path = it.getString(dataCol) ?: ""
                    val mime = it.getString(mimeCol) ?: "audio/mpeg"
                    val date = it.getLong(dateCol)

                    if (size > 0 && path.isNotEmpty() && File(path).exists()) {
                        list.add(
                            TransferFile(
                                id = "aud_$id",
                                name = name,
                                size = size,
                                path = path,
                                type = "MUSIC",
                                mimeType = mime,
                                dateModified = date
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        return list
    }

    private fun queryDownloads(context: Context): List<TransferFile> {
        val list = mutableListOf<TransferFile>()
        try {
            val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(
                android.os.Environment.DIRECTORY_DOWNLOADS
            )
            if (downloadsDir.exists() && downloadsDir.isDirectory) {
                downloadsDir.listFiles()?.forEach { file ->
                    if (file.isFile && file.length() > 0) {
                        val name = file.name
                        val ext = name.substringAfterLast(".", "").lowercase()
                        val type = when (ext) {
                            "pdf", "doc", "docx", "txt", "xlsx", "zip", "rar" -> "DOCUMENT"
                            "apk" -> "APK"
                            "jpg", "jpeg", "png", "webp" -> "PHOTO"
                            else -> "FILE"
                        }
                        list.add(
                            TransferFile(
                                id = "doc_${file.absolutePath.hashCode()}",
                                name = name,
                                size = file.length(),
                                path = file.absolutePath,
                                type = type,
                                mimeType = null,
                                dateModified = file.lastModified()
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        return list
    }

    override fun onCleared() {
        super.onCleared()
        transferManager.stopNearbyDeviceScanner()
    }
}

class FileTransferViewModelFactory(
    private val application: Application,
    private val transferManager: FileTransferManager
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FileTransferViewModel::class.java)) {
            return FileTransferViewModel(application, transferManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
