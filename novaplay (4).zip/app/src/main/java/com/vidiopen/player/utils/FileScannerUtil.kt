package com.vidiopen.player.utils

import android.content.Context
import android.os.Environment
import com.vidiopen.player.data.model.TransferFile
import java.io.File

object FileScannerUtil {
    fun scanFiles(context: Context, type: String): List<TransferFile> {
        val result = mutableListOf<TransferFile>()
        try {
            val root = Environment.getExternalStorageDirectory() ?: return emptyList()
            val extensions = when (type.uppercase()) {
                "VIDEO" -> setOf("mp4", "mkv", "avi", "mov", "webm", "3gp")
                "PHOTO" -> setOf("jpg", "jpeg", "png", "webp", "gif")
                "MUSIC" -> setOf("mp3", "m4a", "flac", "wav", "ogg", "opus")
                "DOCUMENT" -> setOf("pdf", "doc", "docx", "txt", "xlsx", "pptx")
                "APK" -> setOf("apk")
                else -> emptySet()
            }

            fun scanDir(dir: File) {
                val files = dir.listFiles() ?: return
                for (file in files) {
                    if (file.isDirectory && !file.name.startsWith(".")) {
                        if (!file.absolutePath.contains("/Android/data")) {
                            scanDir(file)
                        }
                    } else if (file.isFile) {
                        val ext = file.extension.lowercase()
                        if (extensions.contains(ext) || type == "ALL") {
                            result.add(
                                TransferFile(
                                    id = file.absolutePath,
                                    name = file.name,
                                    size = file.length(),
                                    path = file.absolutePath,
                                    type = type,
                                    mimeType = null,
                                    dateModified = file.lastModified()
                                )
                            )
                        }
                    }
                }
            }
            scanDir(root)
        } catch (_: Exception) {}
        return result
    }
}
