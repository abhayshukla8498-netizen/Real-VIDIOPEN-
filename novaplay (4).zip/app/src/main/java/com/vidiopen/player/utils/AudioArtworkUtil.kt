package com.vidiopen.player.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.util.LruCache
import com.vidiopen.player.data.model.ScannedSong
import java.io.ByteArrayOutputStream
import java.io.File
import kotlin.math.abs

/**
 * Utility for generating and retrieving artwork bytes for notification drawers and media sessions.
 */
object AudioArtworkUtil {

    private val artworkCache = object : LruCache<Long, ByteArray>(150) {}
    private val noEmbeddedArt = object : LruCache<Long, Boolean>(500) {}

    // 12 curated vibrant hex color pairs for fallback artwork rendering
    private val gradientPalettes = listOf(
        Pair(0xFFFF0844.toInt(), 0xFFFFB199.toInt()), // Sunset Coral
        Pair(0xFF8A2387.toInt(), 0xFFE94057.toInt()), // Cyberpunk Magenta
        Pair(0xFF00C6FF.toInt(), 0xFF0072FF.toInt()), // Electric Azure
        Pair(0xFF0BA360.toInt(), 0xFF3CBA92.toInt()), // Emerald Mint
        Pair(0xFF7F00FF.toInt(), 0xFFE100FF.toInt()), // Neon Ultraviolet
        Pair(0xFFFF512F.toInt(), 0xFFDD2476.toInt()), // Ruby Flame
        Pair(0xFF11998E.toInt(), 0xFF38EF7D.toInt()), // Neon Teal
        Pair(0xFFFF8008.toInt(), 0xFFFFC837.toInt()), // Golden Amber
        Pair(0xFF4776E6.toInt(), 0xFF8E54E9.toInt()), // Deep Indigo
        Pair(0xFFFA709A.toInt(), 0xFFFEE140.toInt()), // Tropical Sunrise
        Pair(0xFF30CFD0.toInt(), 0xFF330867.toInt()), // Mystic Ocean
        Pair(0xFF654EA3.toInt(), 0xFFEAAFC8.toInt())  // Lavender Dream
    )

    fun getArtworkByteArray(context: Context, song: ScannedSong): ByteArray? {
        val cached = artworkCache.get(song.id)
        if (cached != null) return cached

        // 1. Try embedded picture from file only if embedded artwork exists
        if (song.path.isNotEmpty() && noEmbeddedArt.get(song.id) != true) {
            try {
                if (EmbeddedPictureDetector.hasEmbeddedPicture(song.path)) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(song.path)
                        val pic = retriever.embeddedPicture
                        if (pic != null && pic.isNotEmpty()) {
                            artworkCache.put(song.id, pic)
                            return pic
                        } else {
                            noEmbeddedArt.put(song.id, true)
                        }
                    } catch (_: Throwable) {
                        noEmbeddedArt.put(song.id, true)
                    } finally {
                        try { retriever.release() } catch (_: Throwable) {}
                    }
                } else {
                    noEmbeddedArt.put(song.id, true)
                }
            } catch (_: Throwable) {
                noEmbeddedArt.put(song.id, true)
            }
        }

        // 2. Generate a lightweight, vibrant colorful 120x120 cover bitmap (fast allocation)
        try {
            val width = 120
            val height = 120
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565)
            val canvas = Canvas(bitmap)

            val paletteIndex = abs((song.id.hashCode() * 31 + song.title.hashCode())) % gradientPalettes.size
            val (c1, c2) = gradientPalettes[paletteIndex]

            // Background Linear Gradient
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), c1, c2, Shader.TileMode.CLAMP)
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

            // Vinyl groove concentric rings
            val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 1.5f
                color = 0x2FFFFFFF.toInt()
            }
            val cx = width / 2f
            val cy = height / 2f
            canvas.drawCircle(cx, cy, 18f, ringPaint)
            canvas.drawCircle(cx, cy, 33f, ringPaint)
            canvas.drawCircle(cx, cy, 48f, ringPaint)

            // Center disc
            val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0x55000000.toInt()
            }
            canvas.drawCircle(cx, cy, 14f, centerPaint)

            val innerHolePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFFFFFF.toInt()
            }
            canvas.drawCircle(cx, cy, 4f, innerHolePaint)

            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
            val bytes = stream.toByteArray()
            artworkCache.put(song.id, bytes)
            return bytes
        } catch (_: Throwable) {
            return null
        }
    }
}
