package com.vidiopen.player.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.vidiopen.player.R
import kotlinx.coroutines.delay

/**
 * Option 2: Cinematic Studio & Audio-Wave Splash Screen
 * Features a high-speed ~2.2s launch, pulsing aura, live audio equalizer wave animation,
 * and the iconic 🇮🇳 Made in India badge.
 */
@Composable
fun SplashAnimationScreen(
    appLanguage: String = "en",
    onFinished: () -> Unit
) {
    val scale = remember { Animatable(0.7f) }
    val alpha = remember { Animatable(0f) }
    val badgeAlpha = remember { Animatable(0f) }
    val badgeOffsetY = remember { Animatable(25f) }

    val infiniteTransition = rememberInfiniteTransition(label = "studioAura")

    // Pulsing aura behind the main logo
    val auraScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraScale"
    )
    val auraAlpha by infiniteTransition.animateFloat(
        initialValue = 0.18f,
        targetValue = 0.42f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraAlpha"
    )

    // Made in India badge subtle breathing animation
    val badgeGlow by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "badgeGlow"
    )

    LaunchedEffect(Unit) {
        // Fast, super-smooth entry (approx 450ms)
        alpha.animateTo(1f, animationSpec = tween(380))
        scale.animateTo(
            targetValue = 1.04f,
            animationSpec = spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            )
        )
        scale.animateTo(1.0f, animationSpec = tween(180))

        // Slide up & fade in the Made in India badge
        badgeOffsetY.animateTo(0f, animationSpec = tween(320, easing = FastOutSlowInEasing))
        badgeAlpha.animateTo(1f, animationSpec = tween(320))

        // Total visible duration ~ 2.2 seconds (fast & ultra-responsive)
        delay(1350)

        // Silky smooth exit fade & slight scale
        alpha.animateTo(0f, animationSpec = tween(260))
        scale.animateTo(0.97f, animationSpec = tween(260))
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF050914),
                        Color(0xFF091124),
                        Color(0xFF020409)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .scale(scale.value)
                .alpha(alpha.value)
        ) {
            // Glowing Ambient Aura & Glassmorphic Logo Shield
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(130.dp)
            ) {
                // Outer glowing halo
                Box(
                    modifier = Modifier
                        .size(125.dp)
                        .scale(auraScale)
                        .alpha(auraAlpha)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    Color(0xFF00F0FF),
                                    Color(0xFF3B82F6).copy(alpha = 0.5f),
                                    Color.Transparent
                                )
                            )
                        )
                )

                // Glassmorphism Logo Container
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color.White.copy(alpha = 0.12f),
                                    Color.White.copy(alpha = 0.04f)
                                )
                            )
                        )
                        .border(
                            width = 2.dp,
                            brush = Brush.sweepGradient(
                                listOf(
                                    Color(0xFF00F0FF),
                                    Color(0xFF3B82F6),
                                    Color(0xFF8B5CF6),
                                    Color(0xFF00F0FF)
                                )
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_vidiopen_logo),
                        contentDescription = "Vidiopen Logo",
                        modifier = Modifier.size(72.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Main Brand Title
            Text(
                text = "VIDIOPEN PRO",
                color = Color.White,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.5.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Tagline
            Text(
                text = if (appLanguage == "hi") "आपका निजी मीडिया प्लेयर" else "Next-Gen HD Video & Music Player",
                color = Color(0xFF00F0FF),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Live Animated Soundwave Equalizer
            AudioEqualizerWave()

            Spacer(modifier = Modifier.height(22.dp))

            // 🇮🇳 Sleek Animated "Made in India" Badge
            Box(
                modifier = Modifier
                    .offset(y = badgeOffsetY.value.dp)
                    .alpha(badgeAlpha.value)
                    .scale(badgeGlow)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF131B2E).copy(alpha = 0.85f))
                    .border(
                        width = 1.5.dp,
                        brush = Brush.horizontalGradient(
                            listOf(
                                Color(0xFFFF9933), // Saffron / केसरिया
                                Color(0xFFFFFFFF), // White / श्वेत
                                Color(0xFF138808)  // Green / हरा
                            )
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "🇮🇳",
                        fontSize = 17.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "MADE IN INDIA",
                        color = Color.White,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp
                    )
                }
            }
        }
    }
}

/**
 * Animated Soundwave Equalizer for media player feel
 */
@Composable
private fun AudioEqualizerWave(modifier: Modifier = Modifier) {
    val infiniteTransition = rememberInfiniteTransition(label = "equalizer")

    val bar1 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(420, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(550, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar3"
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(620, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar4"
    )
    val bar5 by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(460, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bar5"
    )

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val bars = listOf(bar1, bar2, bar3, bar4, bar5)
        bars.forEach { fraction ->
            Box(
                modifier = Modifier
                    .width(3.5.dp)
                    .height((20 * fraction).coerceAtLeast(4f).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF00F0FF),
                                Color(0xFF3B82F6)
                            )
                        )
                    )
            )
        }
    }
}
