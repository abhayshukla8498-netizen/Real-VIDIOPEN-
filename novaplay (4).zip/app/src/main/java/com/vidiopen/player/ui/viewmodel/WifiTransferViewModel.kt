package com.vidiopen.player.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vidiopen.player.data.model.ActiveTransfer
import com.vidiopen.player.data.model.ConnectionRequest
import com.vidiopen.player.data.model.DiscoveredDevice
import com.vidiopen.player.data.repository.WifiTransferRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File

class WifiTransferViewModel(
    application: Application,
    private val repository: WifiTransferRepository
) : AndroidViewModel(application) {

    val isServerRunning: StateFlow<Boolean> = repository.isServerRunning
    val serverIp: StateFlow<String?> = repository.serverIp
    val serverPort: StateFlow<Int> = repository.serverPort
    val sessionCode: StateFlow<String?> = repository.sessionCode
    val connectionRequest: StateFlow<ConnectionRequest?> = repository.connectionRequest
    val activeTransfers: StateFlow<List<ActiveTransfer>> = repository.activeTransfers
    val discoveredDevices: StateFlow<List<String>> = repository.discoveredDevices
    val discoveredDeviceObjects: StateFlow<List<DiscoveredDevice>> = repository.discoveredDeviceObjects
    val isScanning: StateFlow<Boolean> = repository.isScanning

    fun startServer(context: android.content.Context) {
        viewModelScope.launch {
            repository.startServer(context)
        }
    }

    fun stopServer() {
        viewModelScope.launch {
            repository.stopServer()
        }
    }

    fun startDiscovery() {
        viewModelScope.launch {
            repository.startDiscovery()
        }
    }

    fun stopDiscovery() {
        viewModelScope.launch {
            repository.stopDiscovery()
        }
    }

    fun sendFiles(targetIp: String, files: List<File>) {
        viewModelScope.launch {
            repository.sendFiles(targetIp, files)
        }
    }

    fun cancelTransfer(id: String) {
        viewModelScope.launch {
            repository.cancelTransfer(id)
        }
    }
}

class WifiTransferViewModelFactory(
    private val application: Application,
    private val repository: WifiTransferRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WifiTransferViewModel::class.java)) {
            return WifiTransferViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
