package com.vidiopen.player.utils

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object CryptoManager {
    fun encryptFile(source: File, dest: File): Boolean {
        return try {
            FileInputStream(source).use { input ->
                FileOutputStream(dest).use { output ->
                    input.copyTo(output)
                }
            }
            dest.exists() && dest.length() > 0L
        } catch (_: Exception) {
            false
        }
    }

    fun decryptFile(source: File, dest: File): Boolean {
        return try {
            FileInputStream(source).use { input ->
                FileOutputStream(dest).use { output ->
                    input.copyTo(output)
                }
            }
            dest.exists() && dest.length() > 0L
        } catch (_: Exception) {
            false
        }
    }
}
