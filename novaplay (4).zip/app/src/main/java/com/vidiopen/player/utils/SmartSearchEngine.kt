package com.vidiopen.player.utils

import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.data.model.ScannedVideo

data class ScoredMediaEntity(
    val entity: MediaEntity,
    val score: Int
)

object SmartSearchEngine {
    fun scoreMediaEntity(item: MediaEntity, query: String): ScoredMediaEntity? {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return ScoredMediaEntity(item, 100)

        val title = item.title.lowercase()
        val artist = (item.artist ?: "").lowercase()
        val category = item.category.lowercase()

        return when {
            title.startsWith(q) -> ScoredMediaEntity(item, 100)
            title.contains(q) -> ScoredMediaEntity(item, 80)
            artist.contains(q) -> ScoredMediaEntity(item, 60)
            category.contains(q) -> ScoredMediaEntity(item, 40)
            else -> null
        }
    }

    fun getSmartSuggestions(query: String, videos: List<ScannedVideo>): List<String> {
        if (videos.isEmpty()) return emptyList()
        val result = mutableListOf<String>()
        val folders = videos.mapNotNull { it.path.substringBeforeLast('/', "").substringAfterLast('/') }.distinct()
        folders.take(4).forEach { folder ->
            if (folder.isNotEmpty()) {
                result.add("📁 Folder: $folder")
            }
        }
        result.add("🎬 Filter Movies")
        result.add("⚡ Filter Short Clips")
        return result
    }
}
