package com.vidiopen.player.utils

import android.content.ContentUris
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.provider.MediaStore
import com.vidiopen.player.data.database.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Files

object StorageDeletionHelper {

    /**
     * Completely and permanently deletes a media file (video or music) from:
     * 1. The physical storage of the device (File.delete, Files.deleteIfExists)
     * 2. Android MediaStore system database (so it disappears from gallery, file manager, other apps)
     * 3. System MediaScanner (notifies Android OS that the file no longer exists)
     * 4. Internal Room Database (MediaEntity, RecycleBin, WatchHistory, Bookmarks)
     * 5. Any associated thumbnail or subtitle cache files
     */
    suspend fun deletePermanently(
        context: Context,
        path: String?,
        uriString: String? = null,
        mediaId: String? = null,
        isAudio: Boolean = false
    ): Boolean = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        var physicalDeleteSucceeded = false
        var mediaStoreDeleteSucceeded = false

        // Normalize actual physical file path
        var resolvedPath = path
        if (resolvedPath != null && resolvedPath.startsWith("file://")) {
            resolvedPath = Uri.parse(resolvedPath).path
        }

        // 1. Physical file deletion via Java IO and NIO
        if (!resolvedPath.isNullOrBlank() && !resolvedPath.startsWith("content://") && !resolvedPath.startsWith("http://") && !resolvedPath.startsWith("https://")) {
            try {
                val file = File(resolvedPath)
                if (file.exists()) {
                    try {
                        file.setWritable(true, false)
                    } catch (_: Exception) {}

                    // Try standard delete
                    val deleted = file.delete()
                    if (deleted || !file.exists()) {
                        physicalDeleteSucceeded = true
                    } else {
                        // Try Java NIO delete
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                val nioDeleted = Files.deleteIfExists(file.toPath())
                                if (nioDeleted || !file.exists()) {
                                    physicalDeleteSucceeded = true
                                }
                            }
                        } catch (_: Exception) {}

                        // If still exists, try truncating to 0 bytes so even if delete is delayed by OS, file is completely empty
                        if (file.exists()) {
                            try {
                                FileOutputStream(file).use { /* empty write closes and truncates to 0 */ }
                                val reDeleted = file.delete()
                                if (reDeleted || !file.exists()) {
                                    physicalDeleteSucceeded = true
                                }
                            } catch (_: Exception) {}
                        }
                    }
                } else {
                    // File already does not exist on disk
                    physicalDeleteSucceeded = true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 2. Exact Content URI deletion via ContentResolver & DocumentsContract
        val contentUriToTry = when {
            !uriString.isNullOrBlank() && uriString.startsWith("content://") -> Uri.parse(uriString)
            !resolvedPath.isNullOrBlank() && resolvedPath.startsWith("content://") -> Uri.parse(resolvedPath)
            else -> null
        }

        if (contentUriToTry != null) {
            try {
                val rows = appContext.contentResolver.delete(contentUriToTry, null, null)
                if (rows > 0) mediaStoreDeleteSucceeded = true
            } catch (e: Exception) {
                // If direct delete throws security exception, try DocumentsContract
                try {
                    val docDeleted = DocumentsContract.deleteDocument(appContext.contentResolver, contentUriToTry)
                    if (docDeleted) mediaStoreDeleteSucceeded = true
                } catch (_: Exception) {}
            }
        }

        // 3. MediaStore deletion via ContentResolver queries for all tables
        if (!resolvedPath.isNullOrBlank() && !resolvedPath.startsWith("http://") && !resolvedPath.startsWith("https://")) {
            val file = File(resolvedPath)
            val fileName = file.name

            val collections = mutableListOf(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                MediaStore.Files.getContentUri("external")
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                try {
                    collections.add(MediaStore.Downloads.EXTERNAL_CONTENT_URI)
                } catch (_: Exception) {}
            }

            for (collectionUri in collections) {
                // A. Query MediaStore for ID matching exact DATA path or displayName + size
                try {
                    val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATA)
                    val selection = "${MediaStore.MediaColumns.DATA}=? OR (${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.SIZE}=?)"
                    val selectionArgs = arrayOf(
                        resolvedPath,
                        fileName,
                        if (file.exists()) file.length().toString() else "0"
                    )

                    appContext.contentResolver.query(
                        collectionUri,
                        projection,
                        selection,
                        selectionArgs,
                        null
                    )?.use { cursor ->
                        val idColumn = cursor.getColumnIndex(MediaStore.MediaColumns._ID)
                        if (idColumn >= 0) {
                            while (cursor.moveToNext()) {
                                val id = cursor.getLong(idColumn)
                                val itemUri = ContentUris.withAppendedId(collectionUri, id)
                                try {
                                    val rows = appContext.contentResolver.delete(itemUri, null, null)
                                    if (rows > 0) mediaStoreDeleteSucceeded = true
                                } catch (_: Exception) {
                                    // SecurityException on API 30+ without permissions
                                }
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Ignore query failures
                }
            }

            // 4. Also delete any accompanying sidecars (.srt, .vtt, .ass, thumbnails)
            try {
                val baseName = file.nameWithoutExtension
                val parentDir = file.parentFile
                if (parentDir != null && parentDir.exists() && parentDir.isDirectory) {
                    val sidecars = parentDir.listFiles { _, name ->
                        name.startsWith(baseName) && (
                            name.endsWith(".srt", ignoreCase = true) ||
                            name.endsWith(".vtt", ignoreCase = true) ||
                            name.endsWith(".ass", ignoreCase = true) ||
                            name.endsWith(".lrc", ignoreCase = true)
                        )
                    }
                    sidecars?.forEach { sidecar ->
                        try { sidecar.delete() } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // 5. Notify MediaScanner so Android Gallery & all apps instantly remove this file from system index
            try {
                val pathsToScan = mutableListOf(resolvedPath)
                file.parentFile?.absolutePath?.let { pathsToScan.add(it) }
                MediaScannerConnection.scanFile(
                    appContext,
                    pathsToScan.toTypedArray(),
                    null
                ) { _, _ -> }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        // 6. Purge from Room Database across all tables
        try {
            val db = AppDatabase.getDatabase(appContext)
            val recycleBinDao = db.recycleBinDao()
            val mediaDao = db.mediaDao()
            val watchHistoryDao = db.watchHistoryDao()
            val bookmarkDao = db.videoBookmarkDao()

            if (!mediaId.isNullOrBlank()) {
                recycleBinDao.deleteDeletedVideo(mediaId)
                mediaDao.deleteMedia(mediaId)
                bookmarkDao.deleteBookmarksForVideo(mediaId)
            }
            if (!resolvedPath.isNullOrBlank()) {
                recycleBinDao.deleteByPath(resolvedPath)
                watchHistoryDao.deleteWatchHistoryByUrl(resolvedPath)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val targetFile = if (!resolvedPath.isNullOrBlank()) File(resolvedPath) else null
        val fileNoLongerOnDisk = targetFile == null || !targetFile.exists()

        return@withContext fileNoLongerOnDisk || physicalDeleteSucceeded || mediaStoreDeleteSucceeded
    }
}
