package com.vidiopen.player.di

import android.content.Context
import com.vidiopen.player.data.database.AppDatabase
import com.vidiopen.player.data.repository.MediaRepository
import com.vidiopen.player.data.repository.MediaStoreRepository
import com.vidiopen.player.data.repository.MusicRepository
import com.vidiopen.player.data.repository.MusicThemeRepository
import com.vidiopen.player.data.repository.WifiTransferRepository
import com.vidiopen.player.domain.usecase.GetMediaUseCase
import com.vidiopen.player.domain.usecase.ToggleFavoriteUseCase
import com.vidiopen.player.player.MusicPlayerManager
import com.vidiopen.player.player.BalanceAudioProcessor
import com.vidiopen.player.player.AudioEffectsManager

interface AppContainer {
    val mediaRepository: MediaRepository
    val mediaStoreRepository: MediaStoreRepository
    val musicRepository: MusicRepository
    val musicThemeRepository: MusicThemeRepository
    val wifiTransferRepository: WifiTransferRepository
    val getMediaUseCase: GetMediaUseCase
    val toggleFavoriteUseCase: ToggleFavoriteUseCase
    val musicPlayerManager: MusicPlayerManager
    val balanceAudioProcessor: BalanceAudioProcessor
    val audioEffectsManager: AudioEffectsManager
}

class AppContainerImpl(private val context: Context) : AppContainer {
    private val database: AppDatabase by lazy {
        AppDatabase.getDatabase(context)
    }

    override val mediaRepository: MediaRepository by lazy {
        MediaRepository(context, database)
    }

    override val mediaStoreRepository: MediaStoreRepository by lazy {
        MediaStoreRepository(context)
    }

    override val musicRepository: MusicRepository by lazy {
        MusicRepository(context)
    }

    override val musicThemeRepository: MusicThemeRepository by lazy {
        MusicThemeRepository(context)
    }

    override val wifiTransferRepository: WifiTransferRepository by lazy {
        WifiTransferRepository(database)
    }

    override val getMediaUseCase: GetMediaUseCase by lazy {
        GetMediaUseCase(mediaRepository)
    }

    override val toggleFavoriteUseCase: ToggleFavoriteUseCase by lazy {
        ToggleFavoriteUseCase(mediaRepository)
    }

    override val balanceAudioProcessor: BalanceAudioProcessor by lazy {
        BalanceAudioProcessor()
    }

    override val audioEffectsManager: AudioEffectsManager by lazy {
        AudioEffectsManager(context)
    }

    override val musicPlayerManager: MusicPlayerManager by lazy {
        MusicPlayerManager(context, musicRepository, balanceAudioProcessor, audioEffectsManager)
    }
}
