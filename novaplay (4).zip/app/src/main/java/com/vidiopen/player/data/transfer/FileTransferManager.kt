package com.vidiopen.player.data.transfer

import android.content.Context
import android.media.MediaScannerConnection
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import com.vidiopen.player.data.model.ActiveTransfer
import com.vidiopen.player.data.model.DiscoveredDevice
import com.vidiopen.player.data.model.TransferFile
import com.vidiopen.player.data.model.TransferStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import java.io.*
import java.net.*
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * High-performance, offline Wi-Fi & Hotspot File Transfer Manager.
 * Operates purely peer-to-peer using direct local sockets and UDP broadcast beacons.
 * Completely offline - No Internet required.
 */
class FileTransferManager(private val context: Context) {

    private val managerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // State Flows
    private val _isServerRunning = MutableStateFlow(false)
    val isServerRunning: StateFlow<Boolean> = _isServerRunning.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _isTransferring = MutableStateFlow(false)
    val isTransferring: StateFlow<Boolean> = _isTransferring.asStateFlow()

    private val _serverIp = MutableStateFlow<String?>(null)
    val serverIp: StateFlow<String?> = _serverIp.asStateFlow()

    private val _serverPort = MutableStateFlow(DEFAULT_SERVER_PORT)
    val serverPort: StateFlow<Int> = _serverPort.asStateFlow()

    // 6-digit unique pairing code (100000..999999) - persistent per device session
    private val _sessionCode = MutableStateFlow(getOrGeneratePersistentDeviceCode())
    val sessionCode: StateFlow<String> = _sessionCode.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredDevice>> = _discoveredDevices.asStateFlow()

    private val _activeTransfers = MutableStateFlow<List<ActiveTransfer>>(emptyList())
    val activeTransfers: StateFlow<List<ActiveTransfer>> = _activeTransfers.asStateFlow()

    private val _transferError = MutableStateFlow<String?>(null)
    val transferError: StateFlow<String?> = _transferError.asStateFlow()

    private val _transferSuccessCount = MutableStateFlow(0)
    val transferSuccessCount: StateFlow<Int> = _transferSuccessCount.asStateFlow()

    // Sockets & Locks
    private var serverSocket: ServerSocket? = null
    private var activeClientSocket: Socket? = null
    private var beaconBroadcastJob: Job? = null
    private var beaconListenJob: Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val isCancelled = AtomicBoolean(false)

    // Cached map of recently discovered peers (sessionCode -> DiscoveredDevice)
    private val codeToDeviceMap = ConcurrentHashMap<String, DiscoveredDevice>()

    companion object {
        const val DEFAULT_SERVER_PORT = 8989
        const val UDP_BEACON_PORT = 8889
        const val BEACON_HEADER = "VIDIOPEN_BEACON"
        const val BUFFER_SIZE = 256 * 1024 // 256 KB superfast socket chunk buffer

        fun generateRandomCode(): String {
            return String.format(Locale.US, "%06d", 100000 + Random().nextInt(900000))
        }
    }

    private fun getOrGeneratePersistentDeviceCode(): String {
        val prefs = context.getSharedPreferences("vidiopen_transfer_prefs", Context.MODE_PRIVATE)
        var code = prefs.getString("device_unique_code", null)
        if (code == null || code.length != 6) {
            code = generateRandomCode()
            prefs.edit().putString("device_unique_code", code).apply()
        }
        return code
    }

    // ---------------------------------------------------------------------------
    // DEVICE INFO HELPERS
    // ---------------------------------------------------------------------------
    fun getDeviceDisplayName(): String {
        val manufacturer = Build.MANUFACTURER.orEmpty().replaceFirstChar {
            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
        }
        val model = Build.MODEL.orEmpty()
        return if (model.contains(manufacturer, ignoreCase = true)) model else "$manufacturer $model".trim().ifEmpty { "Vidiopen Device" }
    }

    fun getLocalWifiIp(): String {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return "127.0.0.1"
            for (intf in Collections.list(interfaces)) {
                if (intf.isLoopback || !intf.isUp) continue
                val addrs = intf.inetAddresses ?: continue
                for (addr in Collections.list(addrs)) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val host = addr.hostAddress ?: continue
                        if (!host.startsWith("127.")) return host
                    }
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error finding local IP")
        }
        return "127.0.0.1"
    }

    // ---------------------------------------------------------------------------
    // RECEIVER / SERVER WORKFLOW
    // ---------------------------------------------------------------------------
    fun startReceiverServer() {
        if (_isServerRunning.value) return
        _transferError.value = null
        _transferSuccessCount.value = 0
        isCancelled.set(false)

        acquireLocks()
        // Use existing device unique pairing code or generate one
        val code = _sessionCode.value

        managerScope.launch(Dispatchers.IO) {
            var port = DEFAULT_SERVER_PORT
            var socket: ServerSocket? = null
            for (p in DEFAULT_SERVER_PORT..(DEFAULT_SERVER_PORT + 10)) {
                try {
                    socket = ServerSocket().apply {
                        reuseAddress = true
                        receiveBufferSize = BUFFER_SIZE
                        bind(InetSocketAddress(p))
                    }
                    port = p
                    break
                } catch (e: Exception) {
                    // Try next port
                }
            }

            if (socket == null) {
                try {
                    socket = ServerSocket().apply {
                        reuseAddress = true
                        receiveBufferSize = BUFFER_SIZE
                        bind(InetSocketAddress(0))
                    }
                    port = socket.localPort
                } catch (e: Exception) {
                    _transferError.value = "Failed to start receiver server: ${e.message}"
                    return@launch
                }
            }

            serverSocket = socket
            _serverPort.value = port
            _serverIp.value = getLocalWifiIp()
            _isServerRunning.value = true
            Timber.i("Receiver Server started on ${_serverIp.value}:$port with code: $code")

            // Start UDP beacon broadcasting for auto-connect radar discovery
            startBeaconBroadcaster(code, port)

            // Listen for incoming sender connections
            while (isActive && _isServerRunning.value) {
                try {
                    val client = socket.accept()
                    client.tcpNoDelay = true
                    client.soTimeout = 45000
                    client.receiveBufferSize = BUFFER_SIZE
                    client.sendBufferSize = BUFFER_SIZE
                    activeClientSocket = client

                    launch(Dispatchers.IO) {
                        handleIncomingConnection(client)
                    }
                } catch (e: SocketException) {
                    break // Server stopped
                } catch (e: Exception) {
                    Timber.e(e, "Error accepting client")
                }
            }
        }
    }

    private fun handleIncomingConnection(socket: Socket) {
        var dis: DataInputStream? = null
        var dos: DataOutputStream? = null
        try {
            _isTransferring.value = true
            dis = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            dos = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

            // 1. Handshake
            val handshakeMsg = dis.readUTF() // Format: CONNECT|<code>|<senderName>
            val parts = handshakeMsg.split("|")
            if (parts.size < 3 || parts[0] != "CONNECT") {
                dos.writeUTF("AUTH_FAIL|Bad handshake")
                dos.flush()
                return
            }

            val clientCode = parts[1]
            val clientName = parts[2]

            // Check pairing code (allow code match or auto-connect flag)
            if (clientCode != _sessionCode.value && clientCode != "AUTO_DISCOVERY") {
                dos.writeUTF("AUTH_FAIL|Invalid 6-digit code")
                dos.flush()
                _transferError.value = "Device $clientName entered wrong code ($clientCode)"
                return
            }

            dos.writeUTF("AUTH_OK|${getDeviceDisplayName()}")
            dos.flush()

            // 2. Read Batch Info
            val batchMsg = dis.readUTF() // START_BATCH|<totalFiles>|<totalBytes>
            val batchParts = batchMsg.split("|")
            val totalFiles = batchParts.getOrNull(1)?.toIntOrNull() ?: 1
            dos.writeUTF("BATCH_OK")
            dos.flush()

            var filesReceived = 0

            // 3. Receive Files Loop
            while (!isCancelled.get() && filesReceived < totalFiles) {
                val fileHeader = dis.readUTF()
                if (fileHeader == "END_BATCH") break

                // Format: FILE|<name>|<size>|<mime>
                val fileParts = fileHeader.split("|")
                if (fileParts.size < 3 || fileParts[0] != "FILE") {
                    dos.writeUTF("FILE_ERR|Invalid header")
                    dos.flush()
                    continue
                }

                val originalName = fileParts[1]
                val fileSize = fileParts[2].toLongOrNull() ?: 0L
                val mimeType = fileParts.getOrNull(3) ?: "application/octet-stream"

                dos.writeUTF("READY_FILE")
                dos.flush()

                // Save to public storage directory
                val savedFile = receiveSingleFileStream(dis, originalName, fileSize, mimeType)
                if (savedFile != null && savedFile.exists()) {
                    filesReceived++
                    _transferSuccessCount.value = filesReceived
                    dos.writeUTF("FILE_ACK|OK")
                    dos.flush()

                    // Index into MediaStore so it immediately appears in VIDIOpen's player!
                    MediaScannerConnection.scanFile(
                        context,
                        arrayOf(savedFile.absolutePath),
                        arrayOf(mimeType),
                        null
                    )
                } else {
                    dos.writeUTF("FILE_ACK|FAILED")
                    dos.flush()
                }
            }

            dos.writeUTF("BATCH_DONE")
            dos.flush()

        } catch (e: Exception) {
            Timber.e(e, "Error during incoming transfer")
            _transferError.value = "Transfer interrupted: ${e.message}"
        } finally {
            _isTransferring.value = false
            try { socket.close() } catch (ignored: Exception) {}
        }
    }

    private fun receiveSingleFileStream(
        dis: DataInputStream,
        fileName: String,
        fileSize: Long,
        mimeType: String
    ): File? {
        val transferId = UUID.randomUUID().toString()
        val activeItem = ActiveTransfer(
            id = transferId,
            fileName = fileName,
            fileSize = fileSize,
            bytesTransferred = 0L,
            isIncoming = true,
            status = TransferStatus.IN_PROGRESS
        )
        updateActiveTransfer(activeItem)

        // Select directory based on media type
        val targetDirName = when {
            mimeType.startsWith("video/") || fileName.endsWith(".mp4", true) || fileName.endsWith(".mkv", true) -> Environment.DIRECTORY_MOVIES
            mimeType.startsWith("audio/") || fileName.endsWith(".mp3", true) || fileName.endsWith(".m4a", true) -> Environment.DIRECTORY_MUSIC
            else -> Environment.DIRECTORY_DOWNLOADS
        }

        val baseDir = Environment.getExternalStoragePublicDirectory(targetDirName)
        val appFolder = File(baseDir, "Vidiopen").apply { if (!exists()) mkdirs() }
        
        // Avoid overwriting existing files
        var targetFile = File(appFolder, fileName)
        if (targetFile.exists()) {
            val nameWithoutExt = fileName.substringBeforeLast(".")
            val ext = fileName.substringAfterLast(".", "")
            val extPart = if (ext.isNotEmpty()) ".$ext" else ""
            targetFile = File(appFolder, "${nameWithoutExt}_${System.currentTimeMillis()}$extPart")
        }

        var fos: FileOutputStream? = null
        try {
            fos = FileOutputStream(targetFile)
            val buffer = ByteArray(BUFFER_SIZE)
            var bytesRemaining = fileSize
            var totalRead = 0L
            var lastUpdateTime = System.currentTimeMillis()
            var lastBytes = 0L

            while (bytesRemaining > 0 && !isCancelled.get()) {
                val toRead = minOf(buffer.size.toLong(), bytesRemaining).toInt()
                val read = dis.read(buffer, 0, toRead)
                if (read == -1) break

                fos.write(buffer, 0, read)
                totalRead += read
                bytesRemaining -= read

                val now = System.currentTimeMillis()
                if (now - lastUpdateTime >= 250 || bytesRemaining == 0L) {
                    val timeDiff = (now - lastUpdateTime).coerceAtLeast(1)
                    val speed = ((totalRead - lastBytes) * 1000) / timeDiff
                    val remainingTime = if (speed > 0) bytesRemaining / speed else 0L

                    updateActiveTransfer(
                        activeItem.copy(
                            bytesTransferred = totalRead,
                            speedBytesPerSecond = speed,
                            remainingTimeSeconds = remainingTime,
                            status = if (bytesRemaining == 0L) TransferStatus.SUCCESS else TransferStatus.IN_PROGRESS
                        )
                    )
                    lastUpdateTime = now
                    lastBytes = totalRead
                }
            }
            fos.flush()
            return targetFile
        } catch (e: Exception) {
            Timber.e(e, "Failed receiving file: $fileName")
            updateActiveTransfer(activeItem.copy(status = TransferStatus.FAILED))
            return null
        } finally {
            try { fos?.close() } catch (ignored: Exception) {}
        }
    }

    fun stopReceiverServer() {
        isCancelled.set(true)
        beaconBroadcastJob?.cancel()
        beaconBroadcastJob = null

        try { activeClientSocket?.close() } catch (ignored: Exception) {}
        try { serverSocket?.close() } catch (ignored: Exception) {}
        activeClientSocket = null
        serverSocket = null

        _isServerRunning.value = false
        _serverIp.value = null
        _isTransferring.value = false
        releaseLocks()
        Timber.i("Receiver Server stopped")
    }

    // ---------------------------------------------------------------------------
    // SENDER / CLIENT WORKFLOW
    // ---------------------------------------------------------------------------
    fun sendFiles(
        targetIp: String,
        targetPort: Int,
        targetCode: String,
        filesToSend: List<TransferFile>,
        onProgress: (ActiveTransfer) -> Unit = {},
        onComplete: (Boolean, String?) -> Unit
    ) {
        _transferError.value = null
        _transferSuccessCount.value = 0
        isCancelled.set(false)
        acquireLocks()

        managerScope.launch(Dispatchers.IO) {
            var socket: Socket? = null
            var dis: DataInputStream? = null
            var dos: DataOutputStream? = null

            try {
                _isTransferring.value = true

                // Connect to receiver
                socket = Socket().apply {
                    tcpNoDelay = true
                    soTimeout = 45000
                    sendBufferSize = BUFFER_SIZE
                    receiveBufferSize = BUFFER_SIZE
                }
                socket.connect(InetSocketAddress(targetIp, targetPort), 8000)
                activeClientSocket = socket

                dis = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
                dos = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))

                // 1. Handshake with 6-digit code & device name
                val senderName = getDeviceDisplayName()
                dos.writeUTF("CONNECT|$targetCode|$senderName")
                dos.flush()

                val authResp = dis.readUTF()
                if (!authResp.startsWith("AUTH_OK")) {
                    val errMsg = authResp.substringAfter("|", "Connection declined by receiver")
                    _transferError.value = errMsg
                    withContext(Dispatchers.Main) { onComplete(false, errMsg) }
                    return@launch
                }

                // 2. Start Batch
                val totalBytes = filesToSend.sumOf { it.size }
                dos.writeUTF("START_BATCH|${filesToSend.size}|$totalBytes")
                dos.flush()

                val batchAck = dis.readUTF()
                if (batchAck != "BATCH_OK") {
                    withContext(Dispatchers.Main) { onComplete(false, "Receiver rejected batch") }
                    return@launch
                }

                var successCount = 0

                // 3. Send Files Sequentially
                for (fileItem in filesToSend) {
                    if (isCancelled.get()) break
                    val file = File(fileItem.path)
                    if (!file.exists()) continue

                    val transferId = fileItem.id
                    var activeItem = ActiveTransfer(
                        id = transferId,
                        fileName = fileItem.name,
                        fileSize = fileItem.size,
                        bytesTransferred = 0L,
                        isIncoming = false,
                        status = TransferStatus.IN_PROGRESS
                    )
                    updateActiveTransfer(activeItem)
                    withContext(Dispatchers.Main) { onProgress(activeItem) }

                    // Send File Header
                    dos.writeUTF("FILE|${file.name}|${file.length()}|${fileItem.mimeType ?: "application/octet-stream"}")
                    dos.flush()

                    val readyResp = dis.readUTF()
                    if (readyResp != "READY_FILE") continue

                    // Stream binary bytes
                    val fis = FileInputStream(file)
                    val buffer = ByteArray(BUFFER_SIZE)
                    var bytesRead: Int
                    var totalSent = 0L
                    var lastUpdateTime = System.currentTimeMillis()
                    var lastBytes = 0L

                    while (fis.read(buffer).also { bytesRead = it } != -1 && !isCancelled.get()) {
                        dos.write(buffer, 0, bytesRead)
                        totalSent += bytesRead

                        val now = System.currentTimeMillis()
                        if (now - lastUpdateTime >= 250 || totalSent == fileItem.size) {
                            val timeDiff = (now - lastUpdateTime).coerceAtLeast(1)
                            val speed = ((totalSent - lastBytes) * 1000) / timeDiff
                            val eta = if (speed > 0) (fileItem.size - totalSent) / speed else 0L

                            activeItem = activeItem.copy(
                                bytesTransferred = totalSent,
                                speedBytesPerSecond = speed,
                                remainingTimeSeconds = eta,
                                status = if (totalSent == fileItem.size) TransferStatus.SUCCESS else TransferStatus.IN_PROGRESS
                            )
                            updateActiveTransfer(activeItem)
                            withContext(Dispatchers.Main) { onProgress(activeItem) }

                            lastUpdateTime = now
                            lastBytes = totalSent
                        }
                    }
                    dos.flush()
                    fis.close()

                    val ack = dis.readUTF()
                    if (ack.startsWith("FILE_ACK|OK")) {
                        successCount++
                        _transferSuccessCount.value = successCount
                    }
                }

                dos.writeUTF("END_BATCH")
                dos.flush()

                val doneAck = dis.readUTF()
                val isAllSuccess = successCount == filesToSend.size
                withContext(Dispatchers.Main) {
                    onComplete(isAllSuccess, if (isAllSuccess) null else "Some files could not be sent")
                }

            } catch (e: Exception) {
                Timber.e(e, "Error sending files")
                _transferError.value = "Send failed: ${e.message}"
                withContext(Dispatchers.Main) { onComplete(false, e.message) }
            } finally {
                _isTransferring.value = false
                try { socket?.close() } catch (ignored: Exception) {}
                releaseLocks()
            }
        }
    }

    // ---------------------------------------------------------------------------
    // UDP BEACON AUTO-RADAR DISCOVERY
    // ---------------------------------------------------------------------------
    private fun getBroadcastAddresses(): List<InetAddress> {
        val broadcastList = mutableListOf<InetAddress>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return listOf(InetAddress.getByName("255.255.255.255"))
            for (networkInterface in Collections.list(interfaces)) {
                if (networkInterface.isLoopback || !networkInterface.isUp) continue
                for (interfaceAddress in networkInterface.interfaceAddresses) {
                    val broadcast = interfaceAddress.broadcast
                    if (broadcast != null) {
                        broadcastList.add(broadcast)
                    }
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "Error finding interface broadcast addresses")
        }
        if (broadcastList.isEmpty()) {
            try {
                broadcastList.add(InetAddress.getByName("255.255.255.255"))
            } catch (ignored: Exception) {}
        }
        return broadcastList
    }

    private fun startBeaconBroadcaster(code: String, port: Int) {
        beaconBroadcastJob?.cancel()
        beaconBroadcastJob = managerScope.launch(Dispatchers.IO) {
            var beaconSocket: DatagramSocket? = null
            try {
                beaconSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                }
                val deviceName = getDeviceDisplayName()
                val payload = "$BEACON_HEADER|$code|$port|$deviceName|${Build.MODEL}|VDP-$code".toByteArray(Charsets.UTF_8)
                val globalBroadcast = InetAddress.getByName("255.255.255.255")

                while (isActive && _isServerRunning.value) {
                    try {
                        val targets = getBroadcastAddresses().toMutableList()
                        if (!targets.contains(globalBroadcast)) targets.add(globalBroadcast)
                        for (target in targets) {
                            try {
                                val packet = DatagramPacket(payload, payload.size, target, UDP_BEACON_PORT)
                                beaconSocket.send(packet)
                            } catch (ignored: Exception) {}
                        }
                    } catch (e: Exception) {
                        // Ignore periodic broadcast socket errors
                    }
                    delay(1200)
                }
            } catch (e: Exception) {
                Timber.w(e, "UDP beacon broadcaster stopped")
            } finally {
                beaconSocket?.close()
            }
        }
    }

    fun startNearbyDeviceScanner() {
        if (_isScanning.value) return
        _isScanning.value = true
        _discoveredDevices.value = emptyList()

        beaconListenJob?.cancel()
        beaconListenJob = managerScope.launch(Dispatchers.IO) {
            var listenSocket: DatagramSocket? = null
            try {
                listenSocket = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    soTimeout = 2000
                    bind(InetSocketAddress(UDP_BEACON_PORT))
                }

                val buffer = ByteArray(1024)
                val packet = DatagramPacket(buffer, buffer.size)
                val knownDevices = ConcurrentHashMap<String, DiscoveredDevice>()

                while (isActive && _isScanning.value) {
                    try {
                        listenSocket.receive(packet)
                        val text = String(packet.data, 0, packet.length, Charsets.UTF_8)
                        val senderIp = packet.address.hostAddress ?: continue
                        val myIp = getLocalWifiIp()

                        // Ignore echo of our own broadcasts
                        if (senderIp == myIp) continue

                        if (text.startsWith(BEACON_HEADER)) {
                            val parts = text.split("|")
                            if (parts.size >= 5) {
                                val code = parts[1]
                                val port = parts[2].toIntOrNull() ?: DEFAULT_SERVER_PORT
                                val devName = parts[3]
                                val devModel = parts[4]
                                val devId = parts.getOrNull(5) ?: senderIp

                                val discovered = DiscoveredDevice(
                                    ip = senderIp,
                                    deviceName = devName,
                                    deviceModel = devModel,
                                    deviceId = devId,
                                    sessionCode = code,
                                    port = port
                                )
                                val old = knownDevices[devId]
                                if (old != discovered) {
                                    knownDevices[devId] = discovered
                                    codeToDeviceMap[code] = discovered
                                    _discoveredDevices.value = knownDevices.values.toList()
                                }
                            }
                        }
                    } catch (timeout: SocketTimeoutException) {
                        // Normal receive timeout, continue loop
                    } catch (e: Exception) {
                        if (!isActive) break
                    }
                }
            } catch (e: Exception) {
                Timber.w(e, "Beacon listener error")
            } finally {
                listenSocket?.close()
            }
        }
    }

    fun findDeviceByCode(code: String): DiscoveredDevice? {
        val cleanCode = code.trim()
        codeToDeviceMap[cleanCode]?.let { return it }
        return _discoveredDevices.value.firstOrNull { it.sessionCode == cleanCode }
    }

    fun stopNearbyDeviceScanner() {
        _isScanning.value = false
        beaconListenJob?.cancel()
        beaconListenJob = null
    }

    // ---------------------------------------------------------------------------
    // UTILITIES & LOCKS
    // ---------------------------------------------------------------------------
    private fun updateActiveTransfer(item: ActiveTransfer) {
        val current = _activeTransfers.value.toMutableList()
        val idx = current.indexOfFirst { it.id == item.id }
        if (idx != -1) {
            current[idx] = item
        } else {
            current.add(0, item)
        }
        _activeTransfers.value = current
    }

    fun cancelAllTransfers() {
        isCancelled.set(true)
        try { activeClientSocket?.close() } catch (ignored: Exception) {}
        _isTransferring.value = false
    }

    fun clearTransfers() {
        _activeTransfers.value = emptyList()
        _transferError.value = null
        _transferSuccessCount.value = 0
    }

    fun resetSession() {
        _sessionCode.value = generateRandomCode()
    }

    private fun acquireLocks() {
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Vidiopen:FileTransferWakeLock")?.apply {
                setReferenceCounted(false)
                acquire(45 * 60 * 1000L) // 45 minutes
            }
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "Vidiopen:FileTransferWifiLock")?.apply {
                setReferenceCounted(false)
                acquire()
            }
            multicastLock = wm?.createMulticastLock("Vidiopen:MulticastLock")?.apply {
                setReferenceCounted(true)
                acquire()
            }
        } catch (e: Exception) {
            Timber.w(e, "Could not acquire locks")
        }
    }

    private fun releaseLocks() {
        try {
            wakeLock?.let { if (it.isHeld) it.release() }
            wifiLock?.let { if (it.isHeld) it.release() }
            multicastLock?.let { if (it.isHeld) it.release() }
        } catch (ignored: Exception) {}
    }
}
