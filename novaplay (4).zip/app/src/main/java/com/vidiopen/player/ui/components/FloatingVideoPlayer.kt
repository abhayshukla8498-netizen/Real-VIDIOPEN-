package com.vidiopen.player.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.vidiopen.player.data.model.MediaEntity
import com.vidiopen.player.ui.viewmodel.MediaViewModel
import kotlin.math.roundToInt

@Composable
fun FloatingVideoPlayer(
    media: MediaEntity,
    viewModel: MediaViewModel,
    onClose: () -> Unit,
    onReturnToFull: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isPlaying by remember { mutableStateOf(true) }
    var offsetX by remember { mutableStateOf(50f) }
    var offsetY by remember { mutableStateOf(200f) }

    val exoPlayer = remember {
        val renderersFactory = com.vidiopen.player.utils.SafeRenderersFactory(context)
        ExoPlayer.Builder(context, renderersFactory).build().apply {
            val uri = android.net.Uri.parse(media.url)
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(media) {
        onDispose {
            try {
                exoPlayer.clearVideoSurface()
                exoPlayer.stop()
            } catch (_: Throwable) {}
            exoPlayer.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Box(
            modifier = Modifier
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .size(240.dp, 135.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        offsetX += dragAmount.x
                        offsetY += dragAmount.y
                    }
                }
        ) {
            AndroidView(
                factory = { ctx ->
                    try {
                        val view = android.view.LayoutInflater.from(ctx).inflate(
                            com.vidiopen.player.R.layout.layout_player_view,
                            null,
                            false
                        ) as PlayerView
                        view.apply {
                            player = exoPlayer
                            useController = false
                        }
                    } catch (_: Throwable) {
                        PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                        }
                    }
                },
                onRelease = { playerView ->
                    playerView.player = null
                },
                modifier = Modifier.fillMaxSize()
            )

            // Mini overlay controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(6.dp)
                    .align(Alignment.TopEnd),
                horizontalArrangement = Arrangement.End
            ) {
                IconButton(
                    onClick = onReturnToFull,
                    modifier = Modifier.size(28.dp).background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                ) {
                    Icon(Icons.Rounded.Fullscreen, contentDescription = "Full", tint = Color.White, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(28.dp).background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(16.dp))
                }
            }

            IconButton(
                onClick = {
                    if (exoPlayer.isPlaying) {
                        exoPlayer.pause()
                        isPlaying = false
                    } else {
                        exoPlayer.play()
                        isPlaying = true
                    }
                },
                modifier = Modifier
                    .size(36.dp)
                    .align(Alignment.Center)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(18.dp))
            ) {
                Icon(
                    imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = Color(0xFF00F0FF),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
