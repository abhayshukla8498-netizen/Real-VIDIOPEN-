package com.vidiopen.player.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.vidiopen.player.data.model.StatusFilter
import com.vidiopen.player.data.model.WhatsAppStatus
import com.vidiopen.player.data.model.WhatsAppType
import com.vidiopen.player.ui.viewmodel.MediaViewModel
import com.vidiopen.player.utils.WhatsAppStatusHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatusSaverScreen(
    mediaViewModel: MediaViewModel,
    onBack: () -> Unit,
    showTopBar: Boolean = true
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("whatsapp_status_saver_prefs", Context.MODE_PRIVATE) }

    // State
    var selectedType by remember { mutableStateOf(WhatsAppType.WHATSAPP) }
    var selectedFilter by remember { mutableStateOf(StatusFilter.ALL) }
    var allStatuses by remember { mutableStateOf<List<WhatsAppStatus>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var selectedStatusForPreview by remember { mutableStateOf<WhatsAppStatus?>(null) }
    var savingStatusId by remember { mutableStateOf<String?>(null) }
    var hasPermission by remember { mutableStateOf(false) }
    var showPermissionGuideDialog by remember { mutableStateOf(false) }

    // Read stored URI
    fun getStoredUri(isBusiness: Boolean): String? {
        val key = if (isBusiness) WhatsAppStatusHelper.PREF_WB_URI else WhatsAppStatusHelper.PREF_WA_URI
        return prefs.getString(key, null)
    }

    fun checkHasPermission(isBusiness: Boolean): Boolean {
        // Direct file access check first
        val extStorage = android.os.Environment.getExternalStorageDirectory()
        val path = if (isBusiness) "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses" else "Android/media/com.whatsapp/WhatsApp/Media/.Statuses"
        val dir = File(extStorage, path)
        if (dir.exists() && dir.canRead() && (dir.listFiles()?.isNotEmpty() == true)) {
            return true
        }
        val uriStr = getStoredUri(isBusiness)
        return WhatsAppStatusHelper.hasFolderPermission(context, uriStr)
    }

    // Refresh function
    fun refreshStatuses() {
        val isBusiness = (selectedType == WhatsAppType.WHATSAPP_BUSINESS)
        val uriStr = getStoredUri(isBusiness)
        hasPermission = checkHasPermission(isBusiness)

        coroutineScope.launch {
            isLoading = true
            try {
                if (selectedFilter == StatusFilter.SAVED) {
                    allStatuses = WhatsAppStatusHelper.loadSavedStatuses(context)
                } else {
                    allStatuses = WhatsAppStatusHelper.loadStatuses(context, isBusiness, uriStr)
                }
            } catch (e: Exception) {
                allStatuses = emptyList()
            } finally {
                isLoading = false
            }
        }
    }

    // Initial load
    LaunchedEffect(selectedType, selectedFilter) {
        refreshStatuses()
    }

    // SAF Folder Picker Launcher
    val folderPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = result.data?.data
            if (uri != null) {
                val isBusiness = (selectedType == WhatsAppType.WHATSAPP_BUSINESS)
                WhatsAppStatusHelper.takePersistablePermission(context, uri)
                val key = if (isBusiness) WhatsAppStatusHelper.PREF_WB_URI else WhatsAppStatusHelper.PREF_WA_URI
                prefs.edit().putString(key, uri.toString()).apply()
                hasPermission = true
                Toast.makeText(context, "Permission granted successfully! Loading statuses...", Toast.LENGTH_SHORT).show()
                refreshStatuses()
            }
        }
    }

    fun requestFolderPermission() {
        val isBusiness = (selectedType == WhatsAppType.WHATSAPP_BUSINESS)
        try {
            val intent = WhatsAppStatusHelper.createOpenDocumentTreeIntent(isBusiness)
            folderPickerLauncher.launch(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Unable to open folder picker: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    // Filter statuses
    val filteredStatuses = remember(allStatuses, selectedFilter) {
        when (selectedFilter) {
            StatusFilter.ALL -> allStatuses
            StatusFilter.VIDEOS -> allStatuses.filter { it.isVideo }
            StatusFilter.PHOTOS -> allStatuses.filter { !it.isVideo }
            StatusFilter.SAVED -> allStatuses
        }
    }

    Scaffold(
        topBar = {
            if (showTopBar) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                "Status Saver",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                            Text(
                                "Save videos & photos to gallery",
                                color = Color(0xFF22C55E),
                                fontSize = 11.sp
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    actions = {
                        IconButton(onClick = { refreshStatuses() }) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Refresh", tint = Color.White)
                        }
                        IconButton(onClick = {
                            val targetPackage = if (selectedType == WhatsAppType.WHATSAPP_BUSINESS) "com.whatsapp.w4b" else "com.whatsapp"
                            val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)
                            if (launchIntent != null) {
                                context.startActivity(launchIntent)
                            } else {
                                Toast.makeText(context, "Status app is not installed on this device", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Rounded.OpenInNew, contentDescription = "Open App", tint = Color(0xFF22C55E))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0F172A))
                )
            }
        },
        containerColor = Color(0xFF070B14)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // WhatsApp / Business Switcher Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .background(Color(0xFF1E293B), RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                WhatsAppType.values().forEach { type ->
                    val isSelected = selectedType == type
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (isSelected) Color(0xFF22C55E) else Color.Transparent
                            )
                            .clickable {
                                selectedType = type
                            }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (type == WhatsAppType.WHATSAPP) Icons.Rounded.Chat else Icons.Rounded.Business,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = type.title,
                                color = if (isSelected) Color.White else Color.Gray,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            // Filters: All, Videos, Photos, Saved
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatusFilter.values().forEach { filter ->
                    val isSelected = selectedFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedFilter = filter },
                        label = {
                            Text(
                                text = filter.title,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color(0xFF131D31),
                            labelColor = Color.LightGray,
                            selectedContainerColor = Color(0xFF22C55E).copy(alpha = 0.2f),
                            selectedLabelColor = Color(0xFF22C55E)
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = Color(0xFF1E293B),
                            selectedBorderColor = Color(0xFF22C55E)
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Main Content Area
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = Color(0xFF22C55E))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Loading statuses...", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            } else if (filteredStatuses.isEmpty()) {
                // Empty state or permission required state
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .background(Color(0xFF1E293B), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (!hasPermission) Icons.Rounded.FolderSpecial else Icons.Rounded.Schedule,
                                contentDescription = null,
                                tint = if (!hasPermission) Color(0xFF22C55E) else Color.Gray,
                                modifier = Modifier.size(40.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        if (!hasPermission && selectedFilter != StatusFilter.SAVED) {
                            Text(
                                text = "Status Folder Permission Needed",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Android 11+ requires one-time permission to read the '.Statuses' folder. Tap below and select 'Use this folder'.",
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Button(
                                onClick = { showPermissionGuideDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth(0.85f).height(48.dp)
                            ) {
                                Icon(Icons.Rounded.FolderOpen, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Grant Folder Access", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Text(
                                text = if (selectedFilter == StatusFilter.SAVED) "No Saved Statuses Yet" else "No Statuses Found",
                                color = Color.White,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = if (selectedFilter == StatusFilter.SAVED) {
                                    "Save statuses and they will show up here even after 24 hours!"
                                } else {
                                    "View statuses in the status app first, then come back here to save them to your gallery."
                                },
                                color = Color(0xFF94A3B8),
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 18.sp
                            )
                            Spacer(modifier = Modifier.height(20.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Button(
                                    onClick = {
                                        val targetPackage = if (selectedType == WhatsAppType.WHATSAPP_BUSINESS) "com.whatsapp.w4b" else "com.whatsapp"
                                        val launchIntent = context.packageManager.getLaunchIntentForPackage(targetPackage)
                                        if (launchIntent != null) {
                                            context.startActivity(launchIntent)
                                        } else {
                                            Toast.makeText(context, "App is not installed", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open App")
                                }
                                OutlinedButton(
                                    onClick = { refreshStatuses() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Refresh")
                                }
                            }
                        }
                    }
                }
            } else {
                // Status Grid
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredStatuses, key = { it.id }) { status ->
                        StatusGridItem(
                            status = status,
                            isSaving = savingStatusId == status.id,
                            onClick = { selectedStatusForPreview = status },
                            onSave = {
                                coroutineScope.launch {
                                    savingStatusId = status.id
                                    val success = WhatsAppStatusHelper.saveStatus(context, status)
                                    savingStatusId = null
                                    if (success) {
                                        Toast.makeText(context, "Status saved to Gallery!", Toast.LENGTH_SHORT).show()
                                        refreshStatuses()
                                    } else {
                                        Toast.makeText(context, "Failed to save status", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            onShare = {
                                WhatsAppStatusHelper.shareStatus(context, status)
                            }
                        )
                    }
                }
            }
        }
    }

    // Permission Step Guide Dialog
    if (showPermissionGuideDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionGuideDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.FolderSpecial, contentDescription = null, tint = Color(0xFF22C55E))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Select Status Folder", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Due to Android security rules, please grant permission to the status directory:",
                        color = Color(0xFFCBD5E1),
                        fontSize = 13.sp
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            "Step 1: The status folder picker will open.\n" +
                            "Step 2: Tap 'USE THIS FOLDER' at the bottom to allow status viewing.",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPermissionGuideDialog = false
                        requestFolderPermission()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E))
                ) {
                    Text("Choose Folder Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionGuideDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            },
            containerColor = Color(0xFF0F172A),
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Full-screen Preview Modal Dialog
    selectedStatusForPreview?.let { status ->
        StatusPreviewDialog(
            status = status,
            isSaving = savingStatusId == status.id,
            onDismiss = { selectedStatusForPreview = null },
            onSave = {
                coroutineScope.launch {
                    savingStatusId = status.id
                    val success = WhatsAppStatusHelper.saveStatus(context, status)
                    savingStatusId = null
                    if (success) {
                        Toast.makeText(context, "Saved to Gallery successfully!", Toast.LENGTH_SHORT).show()
                        refreshStatuses()
                    } else {
                        Toast.makeText(context, "Save failed", Toast.LENGTH_SHORT).show()
                    }
                }
            },
            onShare = {
                WhatsAppStatusHelper.shareStatus(context, status)
            },
            onRepost = {
                WhatsAppStatusHelper.repostToWhatsApp(context, status, selectedType == WhatsAppType.WHATSAPP_BUSINESS)
            }
        )
    }
}

@Composable
fun StatusGridItem(
    status: WhatsAppStatus,
    isSaving: Boolean,
    onClick: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    Box(
        modifier = Modifier
            .aspectRatio(0.75f)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1E293B))
            .clickable(onClick = onClick)
    ) {
        // Thumbnail Image
        AsyncImage(
            model = status.uri,
            contentDescription = status.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // Gradient overlay for buttons at bottom
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.2f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.75f)
                        )
                    )
                )
        )

        // Video badge
        if (status.isVideo) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = "Video",
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
            }
        }

        // Bottom action buttons
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Share icon
            IconButton(
                onClick = onShare,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Save / Download button
            if (isSaving) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = Color(0xFF22C55E),
                    strokeWidth = 2.dp
                )
            } else if (status.isSaved) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(0xFF22C55E).copy(alpha = 0.3f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Check,
                        contentDescription = "Saved",
                        tint = Color(0xFF22C55E),
                        modifier = Modifier.size(16.dp)
                    )
                }
            } else {
                IconButton(
                    onClick = onSave,
                    modifier = Modifier
                        .size(28.dp)
                        .background(Color(0xFF22C55E), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Download,
                        contentDescription = "Save",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun StatusPreviewDialog(
    status: WhatsAppStatus,
    isSaving: Boolean,
    onDismiss: () -> Unit,
    onSave: () -> Unit,
    onShare: () -> Unit,
    onRepost: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.95f))
        ) {
            // Main Media Content
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 60.dp),
                contentAlignment = Alignment.Center
            ) {
                AsyncImage(
                    model = status.uri,
                    contentDescription = status.title,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )

                if (status.isVideo) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayCircle,
                            contentDescription = "Play Video",
                            tint = Color.White,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }
            }

            // Top bar
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Close", tint = Color.White)
                }

                Text(
                    text = if (status.isVideo) "Video Status" else "Photo Status",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )

                IconButton(
                    onClick = onShare,
                    modifier = Modifier
                        .size(40.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                ) {
                    Icon(Icons.Rounded.Share, contentDescription = "Share", tint = Color.White)
                }
            }

            // Bottom action panel
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Repost to WhatsApp
                Button(
                    onClick = onRepost,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f).height(48.dp)
                ) {
                    Icon(Icons.Rounded.Repeat, contentDescription = null, tint = Color(0xFF22C55E), modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Repost", color = Color.White, fontWeight = FontWeight.SemiBold)
                }

                // Download to gallery
                Button(
                    onClick = onSave,
                    enabled = !isSaving,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (status.isSaved) Color(0xFF10B981) else Color(0xFF22C55E)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1.3f).height(48.dp)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(
                            imageVector = if (status.isSaved) Icons.Rounded.Check else Icons.Rounded.Download,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (status.isSaved) "Saved to Gallery" else "Save to Gallery",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
