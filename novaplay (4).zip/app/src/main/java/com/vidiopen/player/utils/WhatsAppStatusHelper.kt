package com.vidiopen.player.utils

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Log
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import com.vidiopen.player.data.model.WhatsAppStatus
import com.vidiopen.player.data.model.WhatsAppType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

object WhatsAppStatusHelper {
    private const val TAG = "WhatsAppStatusHelper"

    // SAF Tree URIs for WhatsApp and WhatsApp Business
    // DocumentProvider path: Android/media/com.whatsapp/WhatsApp/Media/.Statuses
    // DocumentProvider path: Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses
    const val PREF_WA_URI = "pref_wa_tree_uri"
    const val PREF_WB_URI = "pref_wb_tree_uri"

    // Direct storage paths for Android 10 and below, or MANAGE_EXTERNAL_STORAGE
    private val LEGACY_WA_PATHS = listOf(
        "Android/media/com.whatsapp/WhatsApp/Media/.Statuses",
        "WhatsApp/Media/.Statuses"
    )

    private val LEGACY_WB_PATHS = listOf(
        "Android/media/com.whatsapp.w4b/WhatsApp Business/Media/.Statuses",
        "WhatsApp Business/Media/.Statuses"
    )

    /**
     * Creates an OpenDocumentTree Intent targeting the WhatsApp Media/.Statuses folder
     */
    fun createOpenDocumentTreeIntent(isBusiness: Boolean): Intent {
        val targetPath = if (isBusiness) {
            "Android%2Fmedia%2Fcom.whatsapp.w4b%2FWhatsApp Business%2FMedia%2F.Statuses"
        } else {
            "Android%2Fmedia%2Fcom.whatsapp%2FWhatsApp%2FMedia%2F.Statuses"
        }
        
        val fallbackTargetPath = if (isBusiness) {
            "Android%2Fmedia%2Fcom.whatsapp.w4b"
        } else {
            "Android%2Fmedia%2Fcom.whatsapp"
        }

        val initialUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3A$targetPath")
        val fallbackUri = Uri.parse("content://com.android.externalstorage.documents/document/primary%3A$fallbackTargetPath")

        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            putExtra("android.content.extra.SHOW_ADVANCED", true)
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI, initialUri)
        }
        return intent
    }

    /**
     * Check if a folder URI has persisted permissions
     */
    fun hasFolderPermission(context: Context, uriString: String?): Boolean {
        if (uriString.isNullOrBlank()) return false
        val uri = Uri.parse(uriString)
        val permissions = context.contentResolver.persistedUriPermissions
        return permissions.any { it.uri == uri && (it.isReadPermission || it.isWritePermission) }
    }

    /**
     * Persist SAF permissions for selected folder
     */
    fun takePersistablePermission(context: Context, uri: Uri) {
        val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        try {
            context.contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (e: Exception) {
            Log.e(TAG, "Error taking persistable URI permission", e)
        }
    }

    /**
     * Fetch all statuses from either SAF Tree or Legacy File paths
     */
    suspend fun loadStatuses(
        context: Context,
        isBusiness: Boolean,
        persistedTreeUriString: String?
    ): List<WhatsAppStatus> = withContext(Dispatchers.IO) {
        val result = mutableListOf<WhatsAppStatus>()
        val savedFileNames = getSavedStatusFileNames(context)

        // 1. Try via direct File access first (fast and reliable if permissions allow)
        val directFiles = loadStatusesFromFileSystem(isBusiness)
        if (directFiles.isNotEmpty()) {
            for (file in directFiles) {
                val isVid = isVideoFile(file.name)
                val isImg = isImageFile(file.name)
                if (isVid || isImg) {
                    val uri = Uri.fromFile(file)
                    val isSaved = savedFileNames.contains(file.name)
                    result.add(
                        WhatsAppStatus(
                            id = file.absolutePath,
                            uri = uri,
                            title = file.name,
                            isVideo = isVid,
                            size = file.length(),
                            lastModified = file.lastModified(),
                            isSaved = isSaved,
                            isBusiness = isBusiness,
                            localFilePath = file.absolutePath
                        )
                    )
                }
            }
        }

        // 2. If direct file access returned nothing and we have SAF URI, use SAF DocumentFile
        if (result.isEmpty() && !persistedTreeUriString.isNullOrBlank()) {
            try {
                val treeUri = Uri.parse(persistedTreeUriString)
                val rootDoc = DocumentFile.fromTreeUri(context, treeUri)
                if (rootDoc != null && rootDoc.exists() && rootDoc.isDirectory) {
                    // Search recursively or directly
                    val docFiles = findStatusDocumentFiles(rootDoc)
                    for (doc in docFiles) {
                        val name = doc.name ?: continue
                        val isVid = isVideoFile(name)
                        val isImg = isImageFile(name)
                        if (isVid || isImg) {
                            val isSaved = savedFileNames.contains(name)
                            result.add(
                                WhatsAppStatus(
                                    id = doc.uri.toString(),
                                    uri = doc.uri,
                                    title = name,
                                    isVideo = isVid,
                                    size = doc.length(),
                                    lastModified = doc.lastModified(),
                                    isSaved = isSaved,
                                    isBusiness = isBusiness,
                                    localFilePath = null
                                )
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed reading statuses via SAF: ${e.message}")
            }
        }

        // Sort latest first
        result.sortedByDescending { it.lastModified }
    }

    private fun findStatusDocumentFiles(rootDoc: DocumentFile): List<DocumentFile> {
        val files = mutableListOf<DocumentFile>()
        val children = rootDoc.listFiles()
        
        // If the user selected WhatsApp folder instead of .Statuses, look for .Statuses subfolder
        val statusesFolder = children.find { it.isDirectory && (it.name.equals(".Statuses", ignoreCase = true) || it.name.equals("Statuses", ignoreCase = true)) }
        if (statusesFolder != null) {
            return statusesFolder.listFiles().filter { it.isFile }.toList()
        }

        val mediaFolder = children.find { it.isDirectory && it.name.equals("Media", ignoreCase = true) }
        if (mediaFolder != null) {
            val subStatuses = mediaFolder.listFiles().find { it.isDirectory && (it.name.equals(".Statuses", ignoreCase = true) || it.name.equals("Statuses", ignoreCase = true)) }
            if (subStatuses != null) {
                return subStatuses.listFiles().filter { it.isFile }.toList()
            }
        }

        // Otherwise list files directly from selected directory
        for (doc in children) {
            if (doc.isFile && (isVideoFile(doc.name ?: "") || isImageFile(doc.name ?: ""))) {
                files.add(doc)
            }
        }
        return files
    }

    private fun loadStatusesFromFileSystem(isBusiness: Boolean): List<File> {
        val files = mutableListOf<File>()
        val paths = if (isBusiness) LEGACY_WB_PATHS else LEGACY_WA_PATHS
        val extStorage = Environment.getExternalStorageDirectory() ?: return emptyList()

        for (relPath in paths) {
            val dir = File(extStorage, relPath)
            if (dir.exists() && dir.isDirectory && dir.canRead()) {
                val list = dir.listFiles()
                if (list != null) {
                    files.addAll(list.filter { it.isFile && (isVideoFile(it.name) || isImageFile(it.name)) })
                }
            }
        }
        return files
    }

    /**
     * Get names of files already saved in Vidiopen / Status Saver gallery folder
     */
    fun getSavedStatusFileNames(context: Context): Set<String> {
        val names = mutableSetOf<String>()
        try {
            // Check app's public save folders
            val candidateDirs = listOf(
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen/Statuses"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen/Statuses"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/Statuses"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen Statuses"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen Statuses"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen/WhatsApp Status"),
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen/WhatsApp Status")
            )
            candidateDirs.forEach { dir ->
                if (dir.exists() && dir.isDirectory) {
                    dir.listFiles()?.forEach { names.add(it.name) }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking saved files: ${e.message}")
        }
        return names
    }

    /**
     * Get list of already saved statuses in Gallery
     */
    suspend fun loadSavedStatuses(context: Context): List<WhatsAppStatus> = withContext(Dispatchers.IO) {
        val result = mutableListOf<WhatsAppStatus>()
        val dirs = listOf(
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen/Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen/Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen Statuses"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen/WhatsApp Status"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen/WhatsApp Status"),
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Vidiopen/WhatsApp Status")
        )

        for (dir in dirs) {
            if (dir.exists() && dir.isDirectory) {
                dir.listFiles()?.forEach { file ->
                    if (file.isFile && (isVideoFile(file.name) || isImageFile(file.name))) {
                        result.add(
                            WhatsAppStatus(
                                id = file.absolutePath,
                                uri = Uri.fromFile(file),
                                title = file.name,
                                isVideo = isVideoFile(file.name),
                                size = file.length(),
                                lastModified = file.lastModified(),
                                isSaved = true,
                                isBusiness = false,
                                localFilePath = file.absolutePath
                            )
                        )
                    }
                }
            }
        }
        result.sortedByDescending { it.lastModified }
    }

    /**
     * Save status to phone storage & MediaStore gallery
     */
    suspend fun saveStatus(context: Context, status: WhatsAppStatus): Boolean = withContext(Dispatchers.IO) {
        var inputStream: InputStream? = null
        var outputStream: OutputStream? = null
        try {
            // Obtain input stream
            inputStream = if (status.localFilePath != null) {
                FileInputStream(File(status.localFilePath))
            } else {
                context.contentResolver.openInputStream(status.uri)
            }

            if (inputStream == null) {
                Log.e(TAG, "Could not open inputStream for status: ${status.uri}")
                return@withContext false
            }

            val fileName = if (status.title.startsWith("VID") || status.title.startsWith("IMG") || status.title.contains(".")) {
                status.title
            } else {
                if (status.isVideo) "VID_STATUS_${System.currentTimeMillis()}.mp4" else "IMG_STATUS_${System.currentTimeMillis()}.jpg"
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val resolver: ContentResolver = context.contentResolver
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                    if (status.isVideo) {
                        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Vidiopen Statuses")
                    } else {
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Vidiopen Statuses")
                    }
                }

                val collectionUri = if (status.isVideo) {
                    MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                } else {
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                }

                val itemUri = resolver.insert(collectionUri, contentValues)
                if (itemUri != null) {
                    outputStream = resolver.openOutputStream(itemUri)
                    if (outputStream != null) {
                        inputStream.copyTo(outputStream)
                        outputStream.flush()
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(itemUri, contentValues, null, null)
                    return@withContext true
                }
            }

            // Direct save for fallback / older versions / root
            val targetFolder = if (status.isVideo) {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "Vidiopen/Statuses")
            } else {
                File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Vidiopen/Statuses")
            }
            if (!targetFolder.exists()) {
                targetFolder.mkdirs()
            }
            val targetFile = File(targetFolder, fileName)
            outputStream = FileOutputStream(targetFile)
            inputStream.copyTo(outputStream)
            outputStream.flush()

            // Trigger media scan so it shows in phone Gallery immediately
            val scanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
            scanIntent.data = Uri.fromFile(targetFile)
            context.sendBroadcast(scanIntent)

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed saving status: ${e.message}", e)
            false
        } finally {
            try { inputStream?.close() } catch (_: Exception) {}
            try { outputStream?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Share status to WhatsApp or other apps
     */
    fun shareStatus(context: Context, status: WhatsAppStatus) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = if (status.isVideo) "video/*" else "image/*"
                val shareUri = if (status.localFilePath != null) {
                    try {
                        FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            File(status.localFilePath)
                        )
                    } catch (e: Exception) {
                        status.uri
                    }
                } else {
                    status.uri
                }
                putExtra(Intent.EXTRA_STREAM, shareUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share Status"))
        } catch (e: Exception) {
            Log.e(TAG, "Error sharing status", e)
        }
    }

    /**
     * Repost status directly to WhatsApp
     */
    fun repostToWhatsApp(context: Context, status: WhatsAppStatus, isBusiness: Boolean) {
        try {
            val targetPackage = if (isBusiness) "com.whatsapp.w4b" else "com.whatsapp"
            val shareUri = if (status.localFilePath != null) {
                try {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        File(status.localFilePath)
                    )
                } catch (e: Exception) {
                    status.uri
                }
            } else {
                status.uri
            }

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = if (status.isVideo) "video/*" else "image/*"
                putExtra(Intent.EXTRA_STREAM, shareUri)
                `package` = targetPackage
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback to normal chooser
            shareStatus(context, status)
        }
    }

    fun isVideoFile(fileName: String): Boolean {
        val lower = fileName.lowercase()
        return lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".3gp") || lower.endsWith(".webm")
    }

    fun isImageFile(fileName: String): Boolean {
        val lower = fileName.lowercase()
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp")
    }
}
