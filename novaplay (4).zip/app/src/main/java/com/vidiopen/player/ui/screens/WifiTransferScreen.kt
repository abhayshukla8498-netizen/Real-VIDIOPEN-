package com.vidiopen.player.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vidiopen.player.data.transfer.FileTransferManager
import com.vidiopen.player.ui.viewmodel.FileTransferViewModel
import com.vidiopen.player.ui.viewmodel.FileTransferViewModelFactory
import com.vidiopen.player.ui.viewmodel.MediaViewModel
import com.vidiopen.player.ui.viewmodel.MusicViewModel
import com.vidiopen.player.ui.viewmodel.WifiTransferViewModel

/**
 * Clean wrapper that provides the fully-featured, ultra-attractive FileTransferScreen
 * with 6-digit PIN zero-friction pairing, UDP auto-radar discovery, and QR generation.
 * Perfectly drop-in compatible with existing Navigation composable("wifi_transfer").
 */
@Composable
fun WifiTransferScreen(
    wifiTransferViewModel: WifiTransferViewModel? = null,
    mediaViewModel: MediaViewModel? = null,
    musicViewModel: MusicViewModel? = null,
    onBack: () -> Unit
) {
    val context = LocalContext.current.applicationContext as android.app.Application
    val fileTransferViewModel: FileTransferViewModel = viewModel(
        factory = FileTransferViewModelFactory(
            application = context,
            transferManager = FileTransferManager(context)
        )
    )

    FileTransferScreen(
        viewModel = fileTransferViewModel,
        onBack = onBack
    )
}
