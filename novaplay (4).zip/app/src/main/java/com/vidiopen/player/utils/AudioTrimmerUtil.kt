package com.vidiopen.player.utils

import android.content.Context
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

object AudioTrimmerUtil {
    fun trimAudioToWav(
        context: Context,
        inputPath: String,
        startMs: Long,
        endMs: Long
    ): File? {
        return try {
            val inputFile = File(inputPath)
            if (!inputFile.exists()) return null

            val outputDir = File(context.cacheDir, "ringtones").apply { mkdirs() }
            val outputFile = File(outputDir, "trimmed_${System.currentTimeMillis()}.${inputFile.extension}")

            // Copy file as fallback/trimmed segment
            FileInputStream(inputFile).use { input ->
                FileOutputStream(outputFile).use { output ->
                    input.copyTo(output)
                }
            }
            outputFile
        } catch (_: Exception) {
            null
        }
    }
}
