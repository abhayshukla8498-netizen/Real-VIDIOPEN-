package com.vidiopen.player.utils

import android.content.Context
import android.media.MediaFormat
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.mediacodec.DefaultMediaCodecAdapterFactory
import androidx.media3.exoplayer.mediacodec.MediaCodecAdapter
import androidx.media3.exoplayer.mediacodec.SynchronousMediaCodecAdapter
import timber.log.Timber

/**
 * Custom MediaCodecAdapter.Factory that prevents Codec2 crashes (0xffffffea / BAD_VALUE)
 * on video formats with odd dimensions (e.g., 853x480).
 *
 * Hardware and emulator AVC decoders (c2.goldfish.h264.decoder, c2.android.avc.decoder)
 * require even width and height (divisible by 2) due to YUV 4:2:0 subsampling.
 * When configuring MediaCodec with odd widths like 853, configure() fails with BAD_VALUE (0xffffffea).
 * This adapter adjusts the configuration MediaFormat to the nearest even dimension (e.g. 854).
 */
class SafeMediaCodecAdapterFactory(
    private val delegate: MediaCodecAdapter.Factory = DefaultMediaCodecAdapterFactory()
) : MediaCodecAdapter.Factory {

    override fun createAdapter(configuration: MediaCodecAdapter.Configuration): MediaCodecAdapter {
        sanitizeMediaFormat(configuration.mediaFormat)
        return try {
            delegate.createAdapter(configuration)
        } catch (e: Exception) {
            Timber.w(e, "SafeMediaCodecAdapterFactory: Primary adapter creation failed, attempting synchronous fallback")
            try {
                // Secondary fallback attempt: ensure dimensions aligned to 16-pixel macroblocks
                alignToMacroblocks(configuration.mediaFormat)
                SynchronousMediaCodecAdapter.Factory().createAdapter(configuration)
            } catch (fallbackEx: Exception) {
                Timber.e(fallbackEx, "SafeMediaCodecAdapterFactory: Fallback adapter also failed")
                throw e
            }
        }
    }

    private fun sanitizeMediaFormat(format: MediaFormat) {
        try {
            if (format.containsKey(MediaFormat.KEY_WIDTH)) {
                val width = format.getInteger(MediaFormat.KEY_WIDTH)
                if (width > 0 && width % 2 != 0) {
                    val evenWidth = width + 1
                    Timber.d("SafeMediaCodecAdapterFactory: Adjusting odd width $width -> $evenWidth")
                    format.setInteger(MediaFormat.KEY_WIDTH, evenWidth)
                }
            }
            if (format.containsKey(MediaFormat.KEY_HEIGHT)) {
                val height = format.getInteger(MediaFormat.KEY_HEIGHT)
                if (height > 0 && height % 2 != 0) {
                    val evenHeight = height + 1
                    Timber.d("SafeMediaCodecAdapterFactory: Adjusting odd height $height -> $evenHeight")
                    format.setInteger(MediaFormat.KEY_HEIGHT, evenHeight)
                }
            }
            if (format.containsKey(MediaFormat.KEY_MAX_WIDTH)) {
                val maxWidth = format.getInteger(MediaFormat.KEY_MAX_WIDTH)
                if (maxWidth > 0 && maxWidth % 2 != 0) {
                    format.setInteger(MediaFormat.KEY_MAX_WIDTH, maxWidth + 1)
                }
            }
            if (format.containsKey(MediaFormat.KEY_MAX_HEIGHT)) {
                val maxHeight = format.getInteger(MediaFormat.KEY_MAX_HEIGHT)
                if (maxHeight > 0 && maxHeight % 2 != 0) {
                    format.setInteger(MediaFormat.KEY_MAX_HEIGHT, maxHeight + 1)
                }
            }
            if (format.containsKey(MediaFormat.KEY_STRIDE)) {
                val stride = format.getInteger(MediaFormat.KEY_STRIDE)
                if (stride > 0 && stride % 2 != 0) {
                    format.setInteger(MediaFormat.KEY_STRIDE, stride + 1)
                }
            }
            if (format.containsKey(MediaFormat.KEY_SLICE_HEIGHT)) {
                val sliceHeight = format.getInteger(MediaFormat.KEY_SLICE_HEIGHT)
                if (sliceHeight > 0 && sliceHeight % 2 != 0) {
                    format.setInteger(MediaFormat.KEY_SLICE_HEIGHT, sliceHeight + 1)
                }
            }
        } catch (e: Exception) {
            Timber.w(e, "SafeMediaCodecAdapterFactory: Error sanitizing format")
        }
    }

    private fun alignToMacroblocks(format: MediaFormat) {
        try {
            if (format.containsKey(MediaFormat.KEY_WIDTH)) {
                val width = format.getInteger(MediaFormat.KEY_WIDTH)
                if (width > 0) {
                    val alignedWidth = ((width + 15) / 16) * 16
                    format.setInteger(MediaFormat.KEY_WIDTH, alignedWidth)
                }
            }
            if (format.containsKey(MediaFormat.KEY_HEIGHT)) {
                val height = format.getInteger(MediaFormat.KEY_HEIGHT)
                if (height > 0) {
                    val alignedHeight = ((height + 15) / 16) * 16
                    format.setInteger(MediaFormat.KEY_HEIGHT, alignedHeight)
                }
            }
        } catch (_: Exception) {}
    }
}

/**
 * Open SafeRenderersFactory subclass that overrides getCodecAdapterFactory()
 * to inject SafeMediaCodecAdapterFactory and enable decoder fallback.
 */
open class SafeRenderersFactory(context: Context) : DefaultRenderersFactory(context) {
    init {
        setEnableDecoderFallback(true)
        setAllowedVideoJoiningTimeMs(5000L)
    }

    override fun getCodecAdapterFactory(): MediaCodecAdapter.Factory {
        return SafeMediaCodecAdapterFactory(super.getCodecAdapterFactory())
    }
}
