package com.vidiopen.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val ElectricBlue = Color(0xFF00F0FF)
val RoyalPurple = Color(0xFFBD00FF)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A0B0)
val GlassWhiteBorder = Color(0x1FFFFFFF)

val LocalIsLightTheme = compositionLocalOf { false }

private val DarkColorScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = RoyalPurple,
    tertiary = Color(0xFFFF2E93),
    background = Color(0xFF0B0D17),
    surface = Color(0xFF131728),
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF0070F3),
    secondary = Color(0xFF7928CA),
    tertiary = Color(0xFFFF0080),
    background = Color(0xFFF7F8FC),
    surface = Color(0xFFFFFFFF),
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = Color(0xFF111827),
    onSurface = Color(0xFF111827)
)

@Composable
fun MyApplicationTheme(
    isLightTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isLightTheme) LightColorScheme else DarkColorScheme

    CompositionLocalProvider(LocalIsLightTheme provides isLightTheme) {
        MaterialTheme(
            colorScheme = colorScheme,
            content = content
        )
    }
}
